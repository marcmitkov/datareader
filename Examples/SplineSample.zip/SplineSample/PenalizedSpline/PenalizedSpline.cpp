#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "../Alglib/cpp/src/interpolation.h"
#include <random>
#include <iostream>
#include <cmath>
#include <cerrno>
#include <cfenv>
#include <fstream>

// http://en.cppreference.com/w/cpp/numeric/math/pow

// http://www.alglib.net/translator/man/manual.cpp.html#example_lsfit_d_spline

// http://www.alglib.net/interpolation/leastsquares.php#header12

using namespace alglib;

float threeFunctions(float x);
int splineIT(alglib::real_1d_array x, alglib::real_1d_array y)
{
	//
	// In this example we demonstrate penalized spline fitting of noisy data
	//
	// We have:
	// * x - abscissas
	// * y - vector of experimental data, straight line with small noise
	//
	//real_1d_array x = "[0.00,0.10,0.20,0.30,0.40,0.50,0.60,0.70,0.80,0.90]";
	//real_1d_array y = "[0.10,0.00,0.30,0.40,0.30,0.40,0.62,0.68,0.75,0.95]";
	ae_int_t info;
	double v;
	spline1dinterpolant s;
	spline1dfitreport rep;
	double rho;

	//
	// Fit with VERY small amount of smoothing (rho = -5.0)
	// and large number of basis functions (M=50).
	//
	// With such small regularization penalized spline almost fully reproduces function values
	//
	rho = -5.0;
	spline1dfitpenalized(x, y, 50, rho, info, s, rep);
	printf("%d\n", int(info)); // EXPECTED: 1
	v = spline1dcalc(s, 0.0);
	printf("%.1f\n", double(v)); // EXPECTED: 0.10

								 //
								 // Fit with VERY large amount of smoothing (rho = 10.0)
								 // and large number of basis functions (M=50).
								 //
								 // With such regularization our spline should become close to the straight line fit.
								 // We will compare its value in x=1.0 with results obtained from such fit.
								 //
	rho = +10.0;
	spline1dfitpenalized(x, y, 50, rho, info, s, rep);
	printf("%d\n", int(info)); // EXPECTED: 1
	v = spline1dcalc(s, 1.0);
	printf("%.2f\n", double(v)); // EXPECTED: 0.969

								 //
								 // In real life applications you may need some moderate degree of fitting,
								 // so we try to fit once more with rho=3.0.
								 //
	rho = +3.0;
	spline1dfitpenalized(x, y, 50, rho, info, s, rep);
	printf("%d\n", int(info)); // EXPECTED: 1

	// http://www.alglib.net/translator/man/manual.cpp.html#sub_spline1dcalc

	std::string fn = "C:\\MyProjects\\spline.txt";
	std::ofstream of(fn, std::ofstream::app);

	for (int i = 0; i < x.length(); i++) {
		of << x[i] << ",";
	}
	of << std::endl;

	rho = +0.0;
	spline1dfitpenalized(x, y, 400, rho, info, s, rep);
	printf("%d\n", int(info)); // EXPECTED: 1

	std::vector<double> graphy;
	for (int i = 0; i < x.length(); i++) {
		auto r = alglib::spline1dcalc(s, x[i]);
		graphy.push_back(r);
		of << r << ",";
	}
	of << std::endl;

	rho = +2.0;
	spline1dfitpenalized(x, y, 400, rho, info, s, rep);
	printf("%d\n", int(info)); // EXPECTED: 1

	graphy.clear();
	for (int i = 0; i < x.length(); i++) {
		auto r = alglib::spline1dcalc(s, x[i]);
		graphy.push_back(r);
		of << r << ",";
	}
	of << std::endl;

	rho = +6.0;
	spline1dfitpenalized(x, y, 400, rho, info, s, rep);
	printf("%d\n", int(info)); // EXPECTED: 1

	graphy.clear();
	for (int i = 0; i < x.length(); i++) {
		auto r = alglib::spline1dcalc(s, x[i]);
		graphy.push_back(r);
		of << r << ",";
	}
	of << std::endl;
	return 0;
}


float threeFunctions(float x)
{
#pragma STDC FENV_ACCESS ON
	const double pi = std::acos(-1);

	// typical usage
	std::cout << "sin(pi/6) = " << std::sin(pi / 6) << '\n'
		<< "sin(pi/2) = " << std::sin(pi / 2) << '\n'
		<< "sin(-3*pi/4) = " << std::sin(-3 * pi / 4) << '\n';
	// special values
	std::cout << "sin(+0) = " << std::sin(0.0) << '\n'
		<< "sin(-0) = " << std::sin(-0.0) << '\n';
	// error handling 
	std::feclearexcept(FE_ALL_EXCEPT);
	std::cout << "sin(INFINITY) = " << std::sin(INFINITY) << '\n';
	if (std::fetestexcept(FE_INVALID)) std::cout << "    FE_INVALID raised\n";

	// typical usage
	std::cout << "sin(pi/6) = " << std::sin(pi / 6) << '\n'
		<< "sin(pi/2) = " << std::sin(pi / 2) << '\n'
		<< "sin(-3*pi/4) = " << std::sin(-3 * pi / 4) << '\n';
	// special values
	std::cout << "sin(+0) = " << std::sin(0.0) << '\n'
		<< "sin(-0) = " << std::sin(-0.0) << '\n';
	// error handling 
	std::feclearexcept(FE_ALL_EXCEPT);
	std::cout << "sin(INFINITY) = " << std::sin(INFINITY) << '\n';
	if (std::fetestexcept(FE_INVALID)) std::cout << "    FE_INVALID raised\n";

	// typical usage
	std::cout << "pow(2, 10) = " << std::pow(2, 10) << '\n'
		<< "pow(2, 0.5) = " << std::pow(2, 0.5) << '\n'
		<< "pow(-2, -3) = " << std::pow(-2, -3) << '\n';
	// special values
	std::cout << "pow(-1, NAN) = " << std::pow(-1, NAN) << '\n'
		<< "pow(+1, NAN) = " << std::pow(+1, NAN) << '\n'
		<< "pow(INFINITY, 2) = " << std::pow(INFINITY, 2) << '\n'
		<< "pow(INFINITY, -1) = " << std::pow(INFINITY, -1) << '\n';
	// error handling 
	errno = 0; std::feclearexcept(FE_ALL_EXCEPT);
	std::cout << "pow(-1, 1/3) = " << std::pow(-1, 1.0 / 3) << '\n';
	// if (errno == EDOM) std::cout << "    errno == EDOM " << std::strerror(errno) << '\n';
	if (std::fetestexcept(FE_INVALID)) std::cout << "    FE_INVALID raised\n";

	std::feclearexcept(FE_ALL_EXCEPT);
	std::cout << "pow(-0, -3) = " << std::pow(-0.0, -3) << '\n';
	if (std::fetestexcept(FE_DIVBYZERO)) std::cout << "    FE_DIVBYZERO raised\n";

	float retval = 1 / (1 + 5 * pow(x, 2));
	retval += 0.1*sin(10 * pi*x);
	retval += 0.1*cos(100 * pi*x);
	return retval;
}


float multiSinusoidal(float x)
{
	const double pi = std::acos(-1);
	float retval = 1 / (1 + 5 * pow(x, 2));
	retval += 0.1*sin(10 * pi*x);
	retval += 0.1*cos(100 * pi*x);
	return retval;
}

class Engine
{
public:
	Engine(float mean, float stdev) :
		m_generator(std::random_device()()),
		m_distribution(mean, stdev)
	{}

	double spin() { return m_distribution(m_generator); }
private:
	std::mt19937 m_generator;
	std::uniform_int_distribution<int> m_distribution0;
	std::normal_distribution<float> m_distribution;

};

int mainRandom()
{
	Engine eng(0, 36);

	for (int i = 0; i < 20; ++i)
		std::cout << eng.spin() << '\n';

	return 0;
}



int main(int argc, char **argv)
{
	const int N = 201;
	std::vector<double> X(N), Y(N);
	for (int i = 0; i < N; i++)
	{
		X[i] = (2 * (double)i) / (N - 1) - 1;
		auto y = multiSinusoidal(X[i]);
		Engine e(0, 0.2);
		//std::cout << y << std::endl;
		//Y[i] = y * e.spin();
		Y[i] = y;
		std::cout << X[i] << "{" << Y[i] << "}" << std::endl;

	}
	alglib::real_1d_array AX, AY;
	AX.setcontent(X.size(), &(X[0]));
	AY.setcontent(Y.size(), &(Y[0]));

	splineIT(AX, AY);
}



