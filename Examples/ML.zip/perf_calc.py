#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import logging
import argparse
import numpy as np
from math import sqrt, expm1
from pylab import *
from functools import partial
import matplotlib.pyplot as plt
import os
from pandas.tseries.holiday import USFederalHolidayCalendar
from pandas.tseries.offsets import CustomBusinessDay

portfolioSimAllCols = ['Date','Pnl','Long','Short', 'BookSize','HoldingValue','Trading Value','HeldShares','TradedShares']

def daily_log_ret(df):
    return _aggregated_log_ret(df)


def _to_simple_ret(logret):
    return expm1(logret)


def _percent_format(n):
    return '{:{width}.{prec}f} %'.format(n, width=5, prec=2)


def _double_format(n):
    return '{:{width}.{prec}f}'.format(n, width=5, prec=2)


def _to_simple_ret_str(logret):
    return _double_format(_to_simple_ret(logret))


def _sharpe(df):
    aa = df.agg(['mean','std'])
    return sqrt(252)*aa['lret'][0]/aa['lret'][1]


def _updown_months(df):
    m = df.groupby(pd.Grouper(freq='M'))['lret'].sum()
    #return float(len(m[m.values > 0]))/float(len(m[m.values < 0]))
    n = float(len(m[m.values > 0]))
    d = float(len(m[m.values < 0]))
    r = 12
    if d != 0:
        r = n / d
    return r


def _updown_month_rets(df):
    m = df.groupby(pd.Grouper(freq='M'))['lret'].sum()
    up_ret = m[m.values > 0].mean() * 100
    down_ret = m[m.values < 0].mean() * 100
    return _double_format(up_ret) + " / " + _double_format(down_ret) + " %"


def _winloss_days(df):
    t = float(len(df))
    w = float(len(df[df['lret'] > 0]))
    l = float(len(df[df['lret'] < 0]))
    f = t - (w + l)
    return _double_format(100 * w/t) + " / " + \
           _double_format(100 * l/t) + \
           " [" + _double_format(100 * f/t) + " ]"


def _risk_of_ruin(df):
    m = df.agg('mean').lret
    s = df.agg('std').lret
    r = sqrt(m**2 + s**2)
    return ((2/(1 + (m/r))) - 1) ** (s/r)


# defining sharpe as something annualised
def max_dd(r):
    return np.max(r.expanding().sum().expanding().max() -
                  r.expanding().sum())


def _n_day_analysis(n, df):
    r = df.rolling(n, min_periods=n).sum()
    best = _to_simple_ret(r.max().lret) * 100
    worst = _to_simple_ret(r.min().lret) * 100
    avg = _to_simple_ret(r.mean().lret) * 100
    curr = _to_simple_ret(r.tail(1).lret.values[0]) * 100
    return [_percent_format(best), _percent_format(worst),
            _percent_format(avg), _percent_format(curr)]


def best_21(series):
    r = series.rolling(21, min_periods=21).sum()
    return _percent_format(_to_simple_ret(r.max()) * 100)


def worst_21(series):
    r = series.rolling(21, min_periods=21).sum()
    return _percent_format(_to_simple_ret(r.min()) * 100)



def ann_return(series):
    a = _to_simple_ret(np.sum(series))*100
    return _percent_format(a)


def ann_sharpe(series):
    a = sqrt(252) * (np.mean(series) / np.std(series))
    return _double_format(a)


def depth_dd(series):
    return -100*_to_simple_ret(np.max(series))


def start_dd(series):
    return series.head(1).index.date


def end_dd(series):
    return series.tail(1).index.date


def length_dd(series):
    return len(series)


def _draw_drawdowns_table(df, axis):
    df['expanding_sum'] = df['lret'].expanding().sum()
    df['expanding_max'] = df['expanding_sum'].expanding().max()
    df['drawdowns'] = df['expanding_max'] - df['expanding_sum']
    g = df.drawdowns[df['drawdowns'] > 0].groupby(df['expanding_max'])
    dds = g.agg([depth_dd, start_dd, end_dd, length_dd])
    dds = dds.sort_values(by='depth_dd')
    dds['depth_dd'] = dds['depth_dd'].apply(_percent_format)
    data = dds.head(6).as_matrix()
    colLabels = ('Depth', 'Start', 'End', 'Length (days)')
    axis.axis('off')
    axis.axis('tight')
    if len(dds) > 0:
        the_table = axis.table(cellText=data,
                           colLabels=colLabels,
                           loc='right',
                           bbox=[0.52, -0.2, 0.5, 1.5])


def _draw_day_analysis_table(df, axis):
    days = [1, 5, 21, 63, 126, 252]
    rowLabels = list(map(lambda x: str(x)+" days", days))
    colLabels = ['Best', 'Worst', 'Avg', 'Curr']
    f = partial(_n_day_analysis, df=df)
    data = list(map(f, days))
    axis.axis('off')
    axis.axis('tight')
    the_table = axis.table(cellText=data,
                           rowLabels=rowLabels,
                           colLabels=colLabels,
                           loc='center',
                           bbox=[0.0, -0.2, 0.5, 1.5])


def _draw_year_analysis(df, axis):
    rowLabels = ('Annual return',
                 'Best 21 days',
                 'Worst 21 days',
                 '1 year sharpe')
    g = df.groupby(pd.Grouper(freq='A'))
    v = g.agg([np.mean, np.std, ann_return, best_21, worst_21, ann_sharpe])
    v['lret','sharpe'] = sqrt(252)*(v['lret','mean']/v['lret','std'])
    colLabels = list(map(lambda x:x.year, v['lret'].index.tolist()))
    data = v['lret'][['ann_return', 'best_21', 'worst_21', 'ann_sharpe']].T.as_matrix()
    axis.axis('off')
    #axis.axis('tight')
    the_table = axis.table(cellText=data,
                           rowLabels=rowLabels,
                           colLabels=colLabels,
                           #colWidths=[0.1 for x in colLabels],
                           loc='left',
                           bbox=[0.0, -0.0, 1.0, 0.8])
                           #bbox=[0.0, -0.1, 1.0, 1.5])
    table_props = the_table.properties()
    table_cells = table_props['children']
    #for cell in table_cells: cell.set_width(0.1)


def _draw_table1(df, axis):
    colLabels = ('', '')
    rowLabels = ('Start Date - End Date',
                 'Total Return since inception',
                 'Average Annual ROR',
                 'Winning / Losing Months',
                 'Winning Month Gain / Losing Month Loss',
                 'Sharpe Ratio',
                 'Risk of Ruin',
                 'Return to Drawdown (Calmar)',
                 '% Winning / Losing Days [Flat Days]')
    data = [[pd.to_datetime(df.head(1).index.values[0]).strftime('%Y-%m-%d') + " - " +
             pd.to_datetime(df.tail(1).index.values[0]).strftime('%Y-%m-%d')],
            [_percent_format((df.agg('sum').lret) * 100)],
            [_percent_format(_to_simple_ret(252*df.agg('mean').lret) * 100)],
            [_double_format(_updown_months(df))],
            [_updown_month_rets(df)],
            [_double_format(_sharpe(df))],
            [_double_format(_risk_of_ruin(df))],
            [_double_format(252*df.agg('mean').lret / max_dd(df.lret))],
            [_winloss_days(df)]]
    axis.axis('off')
    axis.axis('tight')
    the_table = axis.table(cellText=data,
                             rowLabels=rowLabels,
                             colLabels=colLabels,
                             loc='center right',
                             bbox=[0.3, -0.2, 0.5, 1.5])
    table_props = the_table.properties()
    #table_cells = table_props['children']
    #for cell in table_cells: cell.set_width(0.5)



def _draw_returns_hist(daily_returns, axis):
    axis.hist(daily_returns.values, bins=50, facecolor='b', alpha=0.5, ec='black')
    axis.set_ylabel('Days')
    # plt.set_xlabel('% Returns')
    axis.set_title('# Daily Returns')
    plt.rc('grid', linestyle=":", color='gray')
    plt.grid(True)


def _draw_cum_returns(daily_returns, axis):
    #xs = daily_returns.values.cumsum()
    xs = daily_returns['lret'].cumsum()
    # helpful for max dd
    i = np.argmax(np.maximum.accumulate(xs) - xs)
    j = np.argmax(xs[:i])
    axis.plot(xs, linewidth=0.8, linestyle='-', c='black')
    # max dd red dots
    axis.plot([i, j], [xs[i], xs[j]], 'o', color='Red', markersize=5)
    axis.set_title('Cumulative Daily Returns')
    axis.set_ylabel('Cumulative % Returns')
    plt.rc('grid', linestyle=":", color='gray')
    plt.grid(True)


# Plots 4x4 cumulative and distributions of returns
def plot_returns(df):
    f, axarr = plt.subplots(4)
    #f.patch.set_visible(False)
    _draw_table1(df, axarr[0])
    _draw_year_analysis(df, axarr[1])
    _draw_day_analysis_table(df, axarr[2])
    _draw_drawdowns_table(df, axarr[2])
    #_draw_cum_returns(df, axarr[3])
    #_draw_returns_hist(df, axarr[3])
    plt.subplots_adjust(left=0.1, bottom=0.1)
    f.tight_layout()
    #plt.show()
    figurePath = os.path.join("c:/MyProjects/WQMaster/output/", 'DD.png')
    plt.savefig(figurePath, dpi=300, bbox_inches="tight")

def plot_returns1(df,outdir, outsuffix=''):
    f, axarr = plt.subplots(3)
    #f.patch.set_visible(False)
    _draw_table1(df, axarr[0])
    _draw_year_analysis(df, axarr[1])
    _draw_day_analysis_table(df, axarr[2])
    _draw_drawdowns_table(df, axarr[2])
    #_draw_cum_returns(df, axarr[3])
    #_draw_returns_hist(df, axarr[3])
    #plt.subplots_adjust(left=0.1, bottom=0.1)
    plt.subplots_adjust(hspace=0.6, left=0.1, bottom=0.1, top=0.9)

    #f.tight_layout()
    #plt.show()
    figurePath = os.path.join(outdir, 'DD' + outsuffix + '.png')
    plt.savefig(figurePath, dpi=300, bbox_inches="tight")

def plot_returns2(df,outdir, outsuffix=''):
    f, axarr = plt.subplots(1)
    #f.patch.set_visible(False)

    _draw_cum_returns(df, axarr)
    #_draw_returns_hist(df, axarr[3])
    #plt.subplots_adjust(left=0.1, bottom=0.1)
    #plt.subplots_adjust(hspace=0.6, left=0.1, bottom=0.1, top=0.9)
    plt.subplots_adjust(left=0.1, bottom=0.1,top=1.5)

    f.tight_layout()
    #plt.show()
    figurePath = os.path.join(outdir, 'DDChart' + outsuffix + '.png')
    plt.savefig(figurePath, dpi=300, bbox_inches="tight")


# All these functions assume a pandas dataframe with timestamp column t.
# works on log rets columns only and returns aggregated log returns only.
def _aggregated_log_ret(df, freq='D', log_ret_col='lret', time_col='t'):
    return df.set_index(time_col).groupby(pd.TimeGrouper(freq))[log_ret_col].sum()


def _print_year(r):
    raw_vals = r[1].apply(lambda x: x * 100).values
    total = raw_vals.sum()
    raw_vals = np.append(raw_vals, np.repeat(0.0, 12 - raw_vals.size))
    display = (r[0].year,) + tuple(raw_vals) + (total,)
    print ("%8s %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f" % display)


def print_returns_table(r):
    month_list = ('Year', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Total')
    print ("%8s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %7s" % month_list)
    monthly_ret = r.apply(expm1).groupby(pd.TimeGrouper(freq='M')).sum()
    map(_print_year, list(monthly_ret.groupby(pd.TimeGrouper(freq='A'))))


# Data loading functions
def load_file(filename):
    return _process_frame(pd.read_csv(filename))


# Perform core calculations required for the data. Maybe move it to the data layer
def _basic_calculations(five_min_bars):
    five_min_bars['sret'] = five_min_bars.close.pct_change()
    five_min_bars['lret'] = np.log(1+five_min_bars.sret)
    return five_min_bars


# Adds or fixes types
def _process_frame(five_min_bars):
    #five_min_bars.drop(['grp', 'volume', 'duration(s)'], inplace=True, axis=1)
    five_min_bars['t'] = pd.to_datetime(five_min_bars['t'], format='%Y-%m-%d %H:%M:%S')
    # five_min_bars.t.tz_localize('UTC')
    return _basic_calculations(five_min_bars)


def test():
    #dat = load_file("F://temp//fx_test.csv");
    dat = load_file('c:/MyProjects/WQMaster/data/fx_test.csv')
    daily_returns = daily_log_ret(dat)
    df = pd.DataFrame(daily_returns.dropna())
    plot_returns(df)

def AddSlice(df):
    us_bd = CustomBusinessDay(calendar=USFederalHolidayCalendar())
    businessDays = pd.DatetimeIndex(start='2018-08-24', end='2018-11-09', freq=us_bd)
    print(pd.DatetimeIndex(start='2018-08-24', end='2018-11-09', freq=us_bd))

    print(len(businessDays))
    # for index, row in df.iterrows():
    #   print(index)
    sliceFactor = 1.0
    idx = df.index.get_loc(pd.to_datetime('2014-08-14', format='%Y-%m-%d'))
    dfSlice = df.iloc[idx:idx + len(businessDays)] * sliceFactor
    dfSlice.index = businessDays
    df = pd.concat([df, dfSlice])

#def DD2 (adir, capital=38000000, outsuffix=''):
# here is where you plug in the VaR number * 100
def GraphPortfolioExposure(adir,noHeader, fromDate, toDate,capital=38000000, outsuffix=''):
    '''dailySimCols = [ 'Date', 'Pnl', 'Long', 'Short', 'PriceReturn', 'HoldingValue', 'TradingValue', 'Heldshares','TradedShares','Ticker', 'AdjClosePrice', 'Multiplier']
    data = os. path.join(adir, "AssetExposure.txt")
    df = pd. read_csv (data, sep='', names=dailySimCols, index_col=False)'''
    data = os.path.join(adir, "PortfolioExposure.csv")

    if noHeader:
        df = pd.read_csv(data, sep=' ', index_col=False,names=portfolioSimAllCols)
    else:
        df = pd.read_csv(data, sep=' ', index_col=False)
    df = df.dropna()

    #df ['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d')
    df ['Date'] = pd.to_datetime(df['Date'], format='%Y%m%d')

    # Sep1

    if fromDate !=  '' and toDate != '':

        df = df.sort_values(['Date'], ascending=True)
        start = pd.to_datetime(fromDate )
        end = pd.to_datetime(toDate )
        print('Fiiltering dataframe- startDate: ',start, ' endDate: ', end)
        mask = (df['Date'] >= start) & (df['Date'] <= end)
        df = df[mask]

    # Sep1End
    df = df.groupby('Date').sum()
    df = df.sort_index()

    df ['Return'] = df ['Pnl'] / capital
    df ['Cumulative'] = df.Pnl.cumsum().round(2)
    df ['Highvalue'] = df['Cumulative'].cummax()
    df ['Drawdown'] = df['Cumulative'] - df ['Highvalue']
    print("Drawdown", (df['Drawdown'].min() / capital) * 100)
    print("PnL", df['Cumulative'][-1:])
    print(df ['Return'].describe())
    # df ['Date'] =pd. to_datetime(df ['Date'l format='%d/%m/%Y')
    ##df [Date'] = pd. to_datetime(df ['Date'l format='%Y% d')
    ##df = df.set_index( Date')
    ##df = df, sort_index()
    #  maybe rename to t
    df ['LogReturn'] = np.log1p(df [ 'Return'])
    df ['LogReturn']. describe()
    # create a dfinput with lret = df ['LogReturn_AB'] index= df. index
    df = df.rename (columns={ 'LogReturn': 'lret'})
    # Add Slice
    maskforDF = (df.index >= pd. to_datetime('2015-01-01', format='%Y-%m-%d'))
    maskDF = df.loc[maskforDF]
    plot_returns1(maskDF, adir, outsuffix)
    plot_returns2 (maskDF, adir, outsuffix)

def GraphAlphasExposure(adir, outputDir, capital=38000000, outsuffix=''):
    '''dailySimCols = [ 'Date', 'Pnl', 'Long', 'Short', 'PriceReturn', 'HoldingValue', 'TradingValue', 'Heldshares','TradedShares','Ticker', 'AdjClosePrice', 'Multiplier']
    data = os. path.join(adir, "AssetExposure.txt")
    df = pd. read_csv (data, sep='', names=dailySimCols, index_col=False)'''
    data = os.path.join(adir, outsuffix + ".csv")
    df = pd.read_csv(data, sep=',', index_col=False)
    df = df.dropna()

    df ['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d')
    df = df.groupby('Date').sum()
    df = df.sort_index()

    df ['Return'] = df ['Pnl'] / capital
    df ['Cumulative'] = df.Pnl.cumsum().round(2)
    df ['Highvalue'] = df['Cumulative'].cummax()
    df ['Drawdown'] = df['Cumulative'] - df ['Highvalue']
    print("Drawdown", (df['Drawdown'].min() / capital) * 100)
    print("PnL", df['Cumulative'][-1:])
    print(df ['Return'].describe())
    # df ['Date'] =pd. to_datetime(df ['Date'l format='%d/%m/%Y')
    ##df [Date'] = pd. to_datetime(df ['Date'l format='%Y% d')
    ##df = df.set_index( Date')
    ##df = df, sort_index()
    #  maybe rename to t
    df ['LogReturn'] = np.log1p(df [ 'Return'])
    df ['LogReturn']. describe()
    # create a dfinput with lret = df ['LogReturn_AB'] index= df. index
    df = df.rename (columns={ 'LogReturn': 'lret'})
    # Add Slice
    maskforDF = (df.index >= pd. to_datetime('2015-01-01', format='%Y-%m-%d'))
    maskDF = df.loc[maskforDF]
    plot_returns1(maskDF, outputDir, outsuffix)
    plot_returns2 (maskDF, outputDir, outsuffix)



def GraphAssetExposure(adir, capital = 38000000, outsuffix=''):
    dailySimCols = ['Date', 'Pnl', 'Long', 'Short', 'PriceReturn', 'HoldingValue', 'TradingValue', 'Heldshares',
                    'TradedShares', 'Ticker', 'AdjClosePrice', 'Multiplier']
    data = os.path.join(adir, "AssetExposure.txt")
    df = pd.read_csv(data, sep='', names=dailySimCols, index_col=False)
    df = df.dropna()

    df[ 'Return'] = df['Pnl'] / capital
    df[ 'Cumulative'] = df.Pnl.cumsum().round(2)
    df[ 'HighValue'] = df['Cumulative'].cummax()
    df[ 'Drawdown'] = df['Cumulative'] - df['HighValue']
    print("Drawdown", (df ['Drawdown'].min() / capital) * 100)
    print("PnL", df [ 'Cumulative'][-1:])
    df ['Return'].describe()
    #df ['Date'] =pd.to_datetime(df ['Date'], format='%d/%m/%Y')
    df ['Date'] =pd.to_datetime(df[ 'Date'],format='%Y%m%d')
    df=df.set_index ('Date')
    df=df.sort_index()
    # maybe rename to t
    df [ 'LogReturn'] = np.log1p(df ['Return'])
    df[ 'LogReturn'].describe()
    #create a dfinput with lret = df ['LogReturn_AB'] index= df. index
    df = df. rename (columns={ 'LogReturn': 'lret'})
    #Add Slice
    maskforDF = (df.index >= pd. to_datetime ('2015-01-01',format='%Y-%m-%d'))
    maskDF = df.loc[maskforDF]
    plot_returns1(maskDF, "/home/lanarayan/MLData/Backtests", outsuffix)
    plot_returns2(maskDF, "/home/lanarayan/MLData/Backtests", outsuffix)

#def DD (adir,bdir, capital = 38000000, factorA=1, factorB=1, outsuffix=''):
def GraphPortfolioExposureMulti(adir, bdir, capital=38000000, factorA=1, factorB=1, outsuffix=''):
    data = os. path.join("/home/lanarayan/MLData/Backtests", adir, "PortfolioExposure.csv")
    df1 = pd.read_csv (data, sep=' ')
    data = os. path.join("/home/lanarayan/MLData/Backtests", bdir, "PortfolioExposure.csv")
    df2 = pd.read_csv (data, sep=' ')
    df = pd.merge(df1, df2, on='Date', how='outer', suffixes=('_A', '_B'))
    df = df.dropna ()
    df ['Pnl_AB'] = factorA * df [ 'Pnl_A'] + factorB * df [ 'Pnl_B']
    df ['Return_AB'] = df['Pnl_AB'] / capital
    df ['Cumulative'] = df.Pnl_AB.cumsum().round(2)
    df ['HighValue'] = df['Cumulative'].cummax()
    df ['Drawdown'] = df['Cumulative'] - df['HighValue']
    print("Drawdown", (df [ 'Drawdown'].min() / capital) * 100)
    print("Pnl", df ['Cumulative'][-1:])
    df['Return_AB'].describe()
    #df ['Date'] =pd. to_datetime(df ['Date'l format='%d/%m/%Y')
    df[ 'Date'] =pd.to_datetime(df['Date'])
    df=df.set_index("Date")
    df=df.sort_index()
    # maybe rename to t
    df['LogReturn_AB'] = np.log1p(df['Return_AB'])
    df ['LogReturn_AB'].describe()
    #create a dfinput with lret = df ['LogReturn AB'] index= df. index

    df = df.rename(columns={'LogReturn_AB': 'lret'})
    # Add slice
    maskforDF = (df.index >= pd.to_datetime('2015-01-01', format='%Y-%m-%d'))
    maskDF = df.loc[maskforDF]
    plot_returns1(maskDF, "/home/lanarayan/MLData/Backtests", outsuffix)
    plot_returns2(maskDF, "/home/lanarayan/MLData/Backtests", outsuffix)



def main():
    logging.basicConfig(level=logging.INFO,
                      format='%(asctime)s %(levelname)s %(message)s')
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version", default="", help = "input version: testSimstatsA${v} testSimstatsB${v}")
    parser.add_argument("-iA", "--inputDirA", default="testSimstatsA", help = "input Dir A:/home/lanarayan/MLData/BacktestsJuly/testSimstatsB${v}")
    parser.add_argument("-iB", "--inputDirB", default="testSimstatsB", help = "input Dir B: testSimstatsB${v}")
    parser.add_argument("-out", "--outputDir", default="", help="input Dir B: testSimstatsB${v}")
    parser.add_argument("-fA", "--factorA", default=1,type=float,
                        help="factorA: PnL factor for A")
    parser. add_argument("-fB", "--factorB", default=1, type=float,
                        help = "factorB: PnL factor for B")
    parser.add_argument("-cb", "--capitalBase", default=38000000, type=float,
                        help="Capital Base")
    parser.add_argument('-pe', '--portfolioExposure', action="store_true", help="if param provided test single PortfolioExposure.csv")
    parser.add_argument('-ae', '--alphaExposure', action="store_true", help="if param provided graph AlphaExposure.csv")
    parser.add_argument('-alpha', '--alpha', default='/home/lanarayan/MLData/Backtests/alphas.txt', help="alphas file location")
    parser.add_argument('-noHeader', '--noHeader', action="store_true", help="if param provided test single PortfolioExposure.csv")
    parser.add_argument('-f', '--fromDate', default='', help="start date YYYYMMDD")
    parser.add_argument('-t', '--toDate', default='', help="end date YYYYMMDD")

    args = parser.parse_args()
    print(args)
    # test single dir
    if args.portfolioExposure:
        #inputDir = 'testSimstatsAB' + args.version
        #DD1(inputDir)
        #o1 = os.path.join("/home/lanarayan/MLData/Backtests", 'DD.png')
        #o2 = os.path.join("/home/lanarayan/MLData/Backtests", 'DDChart.png')
        inputDir =  args.inputDirA # full dir path where PortfolioExposure.csv is located
        GraphPortfolioExposure(inputDir,args.noHeader,args.fromDate,args.toDate,args.capitalBase)
        o1 = os.path.join(inputDir, 'DD.png')
        o2 = os.path.join(inputDir, 'DDChart.png')

        cmd = 'eog ' + o1 + ' ' + o2

        os.system(cmd)
    elif args.alphaExposure:
        alphaFile = os.path.abspath(args.alpha)
        dfAlphas = pd.read_csv(alphaFile, names=['AssetName', 'Frequency', 'Param'], index_col=False)
        #inputDir = os.path.join("/home/lanarayan/MLData/Backtests/" , args.inputDirA)
        inputDir = args.inputDirA

        if args.outputDir == '':
            print("Please specify outputDir. Exiting")
            exit(1)
        elif not os.path.exists(args.outputDir):
            print("Creating outDir folder :" + args.outputDir)
            os.makedirs(args.outputDir)

        for index, row in dfAlphas.iterrows():
            #inputFile= os.path.join(inputDir,row['AssetName']+ '_' +row['Frequency']+ ".csv")
            outputSuffix = row['AssetName']+'_' + row['Frequency']+'_' + row['Param']
            exposure = GraphAlphasExposure(inputDir, args.outputDir, args.capitalBase, outputSuffix)
            o1 = os.path.join(inputDir, 'DD'+ outputSuffix + '.png')
            o2 = os.path.join(inputDir, 'DDChart' + outputSuffix + '.png')
            cmd = 'eog ' + o1 + ' ' + o2
            #os.system(cmd)

    else:
        inputDirA = args.inputDirA + args.version
        inputDirB = args.inputDirB + args.version
        outputSuffix = 'a_' + str(args.factorA) + '_b_' + str(args.factorB) + ' ' + args.version
        GraphPortfolioExposureMulti(inputDirA, inputDirB, args.capitalBase, args.factorA, args.factorB, outputSuffix)

        ''' o1 = os.path.join("/home/lanarayan/MLData/Backtests", inputDirA, 'Pnl Report.csv')
        o2 = os.path.join("/home/lanarayan/MLData/Backtests", inputDirB, 'Pnl Report.csv')
        cmd = 'cat' + o1
        os.system(cmd)
        cmd = 'cat' + o2
        os.system(cmd)'''
        #input("Press enter to continue...")
        print("outputSuffix:", outputSuffix)
        o1 = os.path.join("/home/lanarayan/MLData/Backtests", 'DD' + outputSuffix + '.png')
        o2 = os.path.join("/home/lanarayan/MLData/Backtests", 'DDChart' + outputSuffix + '.png')
        cmd = 'eog' + o1 + ' ' + o2
        os.system(cmd)
    return


if __name__ == '__main__':
    main()