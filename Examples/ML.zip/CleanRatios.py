#!/big/svc_wqln/projects/python/conda/bin/python3.6

import pandas as pd
import argparse
import logging
import os
import shutil


portfolioSimAllCols = [ 'Date', 'Pnl', 'Long', 'Short', 'BookSize', 'HoldingValue', 'Trading Value', 'HeldShares', 'TradedShares']

StrategyAList = ['EURUSD', 'USDJPY']
StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}

def CheckDuplicates(df,dirpath):
    if len(df[df.duplicated(['D'], keep='last')]) > 0:
        print('duplicated rows', df[df.duplicated(['D'], keep='last')])
        print('# duplicated rows', len(df[df.duplicated(['D'], keep='last')]))
        dupDF = df[df.duplicated(['D'], keep='last')]
        logging.debug("Duplicated rows in {}:".format(dirpath))
        logging.debug("{}".format(dupDF))

        # dupDF.to_csv("C:/MyProjects/data/dupLog.txt")

def GetDirectoryList(strategy,baseDir):
    if strategy == 'A':
        assetList = StrategyAList
        frequencyList = ['1D','4H','1H','15m']
        #baseDir = baseDirA
    else:
        assetList = StrategyBMap.keys()
        frequencyList = ['1m']
        #baseDir = baseDirB

    dirParamList = []
    for item in assetList:
        for frequency in frequencyList:
            dir1 = os.path.join(baseDir,item,frequency)
            if os.path.isdir(dir1):
                dirList = os.listdir(dir1)
                for dir in dirList:
                    if dir.startswith('params'):
                        dirParamList.append(os.path.join(dir1,dir))

    return dirParamList

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument('-baseDir', '--baseDir', default='/big/svc_wqln/ML/Backtests/Fit-B-2014', help="base Directory")
    parser.add_argument('-baseOut', '--baseOut', default='/big/svc_wqln/ML/Backtests/OutClean', help="baseOut Directory")
    parser.add_argument('-noHeader', '--noHeader', action="store_false", help="if param provided file has no header")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/OutClean', help="log file  path")
    parser.add_argument('-strategy', '--strategy', default='B', help="log file  path")
    parser.add_argument('-overwrite', '--overwrite', action="store_true", help="if param provided overwrite file")
    parser.add_argument('-move', '--move', action="store_true", help="if param provided move rations.txt to ratios1.txt")

    args = parser.parse_args()
    print (args)

    logging.basicConfig(filename=os.path.join(args.logPath,"CleanRatiosLog.log"), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    #file = os.path.join(args.baseDir, "ratios.txt")

    logging.debug("Testing {}".format("test"))
    args.baseOut = os.path.abspath(args.baseOut)
    if not os.path.exists(args.baseOut):
        print("Creating output folder :" + args.baseOut)
        os.makedirs(args.baseOut)

    dirParamList =GetDirectoryList(args.strategy,args.baseDir)


    for dirpath in dirParamList:
        print("Directory: ", dirpath)
        
        #move to test
        if args.move:
            shutil.move(os.path.join(dirpath, "ratios1.txt"), os.path.join(dirpath, "ratios.txt"))
            continue
            
        if  args.noHeader:
            df = pd.read_csv(os.path.join(dirpath, "ratios.txt"), sep=',', index_col=False, names=['D', 'ratio'])
        else:
            df = pd.read_csv(os.path.join(dirpath, "ratios.txt"), sep=',', index_col=False)

        #create a backup of file
        shutil.copy(os.path.join(dirpath, "ratios.txt"), os.path.join(dirpath, "ratios_bkup.txt"))

        #df['D'] = pd.to_datetime(df['D'], format="%Y%m%d %H:%M:%S")
        df['D'] = pd.to_datetime(df['D'], format="%Y-%b-%d")
        df = df.sort_values(["D"])

        CheckDuplicates(df, dirpath)

        df = df.drop_duplicates(['D'])

        if args.overwrite:
            if args.noHeader:
                df.to_csv(os.path.join(dirpath, "ratios.txt"),header=False)
            else:
                df.to_csv(os.path.join(dirpath, "ratios.txt"))



        #CheckDuplicates(df,dirpath)


if __name__ == '__main__':
     main()