
#!/bin/bash 
TCFACTORA=1
#15m
/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests15m/Fit-A-2019 -baseDirB /big/svc_wqln/ML/Backtests15m/Fit-B-2014 -f 20170601 -t 20190630 -alphas /big/svc_wqln/ML/Backtests15m/AlphaList/V1/alphasA.txt -wt /big/svc_wqln/ML/Backtests15m/AlphaList/V1/weightsA.txt -baseOut /big/svc_wqln/ML/Backtests15m/OutSim/Fit-A-2019/V1 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1
#1H
/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests1H/Fit-A-2019 -baseDirB /big/svc_wqln/ML/Backtests1H/Fit-B-2014 -f 20170601 -t 20190630 -alphas /big/svc_wqln/ML/Backtests1H/AlphaList/V1/alphasA.txt -wt /big/svc_wqln/ML/Backtests1H/AlphaList/V1/weightsA.txt -baseOut /big/svc_wqln/ML/Backtests1H/OutSim/Fit-A-2019/V1 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1


#4H
/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests4H/Fit-A-2019 -baseDirB /big/svc_wqln/ML/Backtests4H/Fit-B-2014 -f 20170601 -t 20190630 -alphas /big/svc_wqln/ML/Backtests4H/AlphaList/V1/alphasA.txt -wt /big/svc_wqln/ML/Backtests4H/AlphaList/V1/weightsA.txt -baseOut /big/svc_wqln/ML/Backtests4H/OutSim/Fit-A-2019/V1 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1


#1D
/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests1D/Fit-A-2019 -baseDirB /big/svc_wqln/ML/Backtests1D/Fit-B-2014 -f 20170601 -t 20190630 -alphas /big/svc_wqln/ML/Backtests1D/AlphaList/V1/alphasA.txt -wt /big/svc_wqln/ML/Backtests1D/AlphaList/V1/weightsA.txt -baseOut /big/svc_wqln/ML/Backtests1D/OutSim/Fit-A-2019/V1 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1
