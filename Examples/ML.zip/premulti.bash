#backup working version
#cp ~/UAT/VishnuWIP/Common/MacroTraderEx.cpp ~/UAT/VishnuWIP/Common/MacroTraderEx.ckk
#cp ~/UAT/VishnuWIP/Base/MacroTrader.cpp ~/UAT/VishnuWIP/Base/MacroTrader.ckk
#cp ~/UAT/VishnuWIP/Base/MacroTrader.h ~/UAT/VishnuWIP/Base/MacroTrader.hkk
cp ~/UAT/VishnuWIP/Trader/Trader.cpp ~/UAT/VishnuWIP/Trader/Trader.ckk
# restore multi version
#cp ~/UAT/VishnuWIP/Common/MacroTraderEx.ckk2 ~/UAT/VishnuWIP/Common/MacroTraderEx.cpp 
#cp ~/UAT/VishnuWIP/Base/MacroTrader.ckk2 ~/UAT/VishnuWIP/Base/MacroTrader.cpp 
#cp ~/UAT/VishnuWIP/Base/MacroTrader.hkk2 ~/UAT/VishnuWIP/Base/MacroTrader.h 
cp ~/UAT/VishnuWIP/Trader/Trader.ckk2 ~/UAT/VishnuWIP/Trader/Trader.cpp