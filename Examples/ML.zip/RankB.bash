#!/bin/bash
ROOT="/big/svc_wqln/ML/Backtests" 
RUN="Fit-B-2014" 
PORTFOLIO="Fit-B-2014" 
RANKCOUNT="10"
RANKBY="TotalReturn"
SELECTCRITERIA="top10_31"
LOGDIR=${ROOT}/Logs
RANKDEPTH="1"
VERSION=V1
LOGFILE=${LOGDIR}/RankB${SELECTCRITERIA}-$(date '+%d%m%Y-%H:%M:%S').txt;
echo $LOGFILE

[ -d ${LOGDIR} ] ||  echo mkdir -p ${LOGDIR} 
[ -d ${LOGDIR} ] || mkdir -p ${LOGDIR}


if [ $# -eq 0 ]
then
  echo "No argument supplied for weight generation. will use manually created weights file as per instructions by script"
fi


[ -e ${LOGFILE} ] && rm ${LOGFILE}



function ShowStatus {
if [ $? -eq 0 ]
 then
        echo PASS $1
        echo PASS $1 >>${LOGFILE} 
 else
        echo FAIL $1 
        echo FAIL $1 >>${LOGFILE} 
        exit 1
fi
}

function RankAlphas {
    echo ./RankAlphasAll.py -baseDir ${ROOT}/${RUN} -baseOut ${ROOT}/${RUN} -pdir ${ROOT}/Portfolios/${PORTFOLIO} -rankCount ${RANKCOUNT} -rankBy ${RANKBY} -sc ${SELECTCRITERIA} -rank ${RANKDEPTH}
    echo ./RankAlphasAll.py -baseDir ${ROOT}/${RUN} -baseOut ${ROOT}/${RUN} -pdir ${ROOT}/Portfolios/${PORTFOLIO} -rankCount ${RANKCOUNT} -rankBy ${RANKBY} -sc ${SELECTCRITERIA} -rank ${RANKDEPTH} >> ${LOGFILE}
    ./RankAlphasAll.py -baseDir ${ROOT}/${RUN} -baseOut ${ROOT}/${RUN} -pdir ${ROOT}/Portfolios/${PORTFOLIO} -rankCount ${RANKCOUNT} -rankBy ${RANKBY} -sc ${SELECTCRITERIA} -rank ${RANKDEPTH}
    ShowStatus RankAlphas 
}


function CreateWeights
{
[ -e ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out/CrossCheckAlpha.txt ] && rm ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out/CrossCheckAlpha.txt

if [ $# -eq 0 ]
then
        echo Using manually created weights file
        echo Using manually created weights file >> ${LOGFILE}
        [ -d ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} ] || mkdir ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}
        echo Selected Alphas listed in:
        echo ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/WeightsAlphaList.csv
        echo generating equal weighted file as template as ${ROOT}/Portfolios/${PORTFOLIO}/weights.txt
        echo ./GenerateWeightsNew.py -wtfile ${ROOT}/Portfolios/${PORTFOLIO}/WeightsAlphaList.csv -f 20140101 -t 20200101 -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}
        ./GenerateWeightsNew.py -wtfile ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/WeightsAlphaList.csv -f 20140101 -t 20200101 -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}
        echo please update ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt manually if needed 
        echo example strat A weights.txt
        echo from,to,ES_4H,NQ_15m,1YM_15m,LCO_1H,USDCHF_15m,GBPUSD_15m,
        echo 20140101,20190101,25,25,25,25,2.5,2.5
        echo example strat B weights.txt
        echo from,to,Hayek,Friedman,Kondratiev,Nash,Smith,Buffet
        echo 20090101,20190131,1,1,1,1,1,1
        read -p  "Press <ENTER> to continue"
        if [ ! -e ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt ]
        then
          echo "Weights file missing"
          exit 1        
        fi
        # below not needed if weights file updated at the correct location
        #echo cp ${ROOT}/${RUN}/weights.txt ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt
        #cp ${ROOT}/${RUN}/weights.txt ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt 
        
else
for arg in "$@"
do 
if [ "$arg" == "-wtalpha" ]
 then
        echo using alphas provided in shell script to generate weights file 
        echo using alphas provided  in shell script to generate weights file >> ${LOGFILE}
        echo ./GenerateWeightsNew.py -a ${Alphas} -f 20140101 -t 20190101 -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}
        ./GenerateWeightsNew.py -a ${Alphas} -f 20140101 -t 20191201 -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} >> ${LOGFILE}
        ShowStatus GenerateWeights
elif [ "$arg" == "-wtdefault" ]
 then
        echo using default alpha list in python script to generate weights file 
        echo using default alpha list in python script to generate weights file >> ${LOGFILE} 
        ./GenerateWeightsNew.py -f 20140101 -t 20190101 -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} 
        ShowStatus GenerateWeights
elif [ "$arg" == "-wtfile" ]
  then
        echo Using alpha list created by RankAlphasAll.py
        echo Using alpha list created by RankAlphasAll.py >> ${LOGFILE}
        echo ./GenerateWeightsNew.py -wtfile ${ROOT}/Portfolios/${PORTFOLIO}/WeightsAlphaList.csv -f 20140101 -t 20200101 -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}
        ./GenerateWeightsNew.py -wtfile ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/WeightsAlphaList.csv -f 20140101 -t 20200101 -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}
#elif [ "$arg" == "-wtSkip" ]      
fi
done
fi
}

function CopyAlphasWeights
{  
  echo cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/Alphas.txt ${ROOT}/AlphaList/${VERSION}/alphasB.txt
  echo cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/Alphas.txt ${ROOT}/AlphaList/${VERSION}/alphasB.txt >> ${LOGFILE}
  cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/Alphas.txt ${ROOT}/AlphaList/${VERSION}/alphasB.txt

  echo cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt ${ROOT}/AlphaList/${VERSION}/weightsB.txt
  echo cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt ${ROOT}/AlphaList/${VERSION}/weightsB.txt >> ${LOGFILE}
  cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt ${ROOT}/AlphaList/${VERSION}/weightsB.txt
  
  echo cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/TotalRanking.csv ${ROOT}/AlphaList/${VERSION}/TotalRankingB.csv
  echo cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/TotalRanking.csv ${ROOT}/AlphaList/${VERSION}/TotalRankingB.csv >> ${LOGFILE}
  cp ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/TotalRanking.csv ${ROOT}/AlphaList/${VERSION}/TotalRankingB.csv
}


function WeightedRiskReport
{
echo ./WeightedRiskReport.py -baseDir ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out -w ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt -mode q >> ${LOGFILE} 
./WeightedRiskReport.py -baseDir ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out -w ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt -mode q 
echo output in ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out
ShowStatus WeightedRiskReport
}

function PortfolioReports
{
echo ./PortfolioReport.py -baseDir ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out >>${LOGFILE} 
./PortfolioReport.py -baseDir ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out
echo output in ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out
ShowStatus PortfolioReport
}

function MasterOpenPositionCount
{
echo ./WeightedSeries.py -baseDir ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out -w ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt -x openPositionCount >>${LOGFILE} 
./WeightedSeries.py -baseDir ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA} -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out -w ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/weights.txt -x openPositionCount 
echo output in ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out
ShowStatus WeightedSeries
}

function VaR
{
[ -e ${ROOT}/Portfolios/${SELECTCRITERIA}/VaRReport.txt ] && rm ${ROOT}/Portfolios/${SELECTCRITERIA}/VaRReport.txt

echo ./VarAnalysisWQ.py -p ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out/MasterOpenPositionCount.csv -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out >> ${LOGFILE} 
     ./VarAnalysisWQ.py -p ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out/MasterOpenPositionCount.csv -baseOut ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out
echo output in ${ROOT}/Portfolios/${PORTFOLIO}/${SELECTCRITERIA}/out
ShowStatus VarAnalysisWQ
}

RankAlphas
CreateWeights
CopyAlphasWeights
#WeightedRiskReport
#PortfolioReports
#MasterOpenPositionCount
#VaR

echo ALL DONE >> ${LOGFILE}
