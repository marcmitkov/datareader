#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import numpy as np
import argparse

from math import sqrt, expm1
from pylab import *
from functools import partial
import matplotlib.pyplot as plt
import os
import functools

EncodePositions = {"1YM": 0.83, "DM": 1, "ES": 1.27, "FCE": 1, "FDX": 1,
                "FF": 1, "FV": 1.33, "NQ": 1, "RMF": 1, "STXE": 1,
                "TFS": 1, "TN": 1,  "TU": 1, "TY": 0.92, "US": 0.87, "CL":1.2, "LCO":0.89,
                "AUDUSD": 1, "EURGBP": 1, "EURJPY": 1,"EURUSD": 1, "GBPUSD": 1,
                "USDCAD": 1, "USDCHF": 1, "USDJPY": 1}

listStrategyB = ['Keynes', 'Buffet', 'Smith', 'Nash', 'Friedman', 'Hayek', 'Marx', 'Tinbergen','Kondratiev']
listCurrency = ['EURUSD', 'GBPUSD', 'EURJPY', 'USDJPY', 'USDCHF','EURCHF','AUDUSD','USDCAD', 'GBPJPY','EURGBP']
# example Strat A filenames: openPositionCount_USD_JPY_1H
# example Strat B filenames: openPositionCount_CME_TUU7_Keynes,
# openPositionCount2_CME_USU7_Keynes
# example Weight Columns: USDJPY_1H, Keynes, Smith
def MergeDataFrames(left, right):
    print(left.columns.values)
    duplicate = False
    colname = right.columns.values[0]

    if colname in left.columns.values:
        duplicate = True
    df = pd.merge(left, right, how='outer',left_index=True, right_index=True)
    df2 = df.fillna(value=0)

    if duplicate:
        print('Adding columns ')
        df2[colname] = df2[colname + '_x'] + df2[colname + '_y']
        #pandas version issue
        #df2 = df2.drop(columns=[colname + '_x', colname + '_y'])
        df2 = df2.drop([colname + '_x', colname + '_y'], axis=1)

    return df2



def processData(baseDir, baseOutDir, weightCSV, filePefix):

    dfPositions = pd.DataFrame()

    data_framesPositions = []

    for dirpath, dirnames, filenames in os.walk(baseDir):
        for file in filenames:
            if os.stat(os.path.join(dirpath, file)).st_size < 2:
                continue

            #if file.startswith( ) :

            if file.startswith(filePefix) :
                print("Traversed File: ", file)
                #extract Keynes for example from TUUS_Keynes.csv
                try:
                    stratbname = file.split('_')[-1].split('.')[-2]
                except:
                    print("valid filename? ", file)
                    continue
                # apply weights here
                print(" applying weight for ", "Strategy B leg " + file.split('_')[0] if stratbname in listStrategyB else "Strategy A")
                # get column name for obtaining weight from weights file
                # (Strategy B: e.g openPositionCount_CME_NQU7_Smith.csv, weight
                # column will be Smith,
                # Strategy A: e.g openPositionCount_EURUSD_15m.csv weight
                # column name will be EURUSD_15m
                if stratbname in listStrategyB:
                    weightColumn = stratbname
                else:
                    weightColumn = file.split('_')[-2] + '_' + file.split('_')[-1].split('.')[-2]

                dfWeights = pd.read_csv(weightCSV)
                if weightColumn not in dfWeights.columns.values:
                    print('weight for ', weightColumn, 'missing. Skip to next file in directory')
                    continue

                dfWeights['from'] = pd.to_datetime(dfWeights['from'], format='%Y%m%d')
                dfWeights['to'] = pd.to_datetime(dfWeights['to'], format='%Y%m%d')
                #  Banku please complete

                # read main file containing timestamp and size
                filePath = os.path.join(dirpath, file)
                print('Reading ', file, 'in', dirpath)
                tmpdf = pd.read_csv(filePath)

                # get column name for renaming 'Count' column
                colName = file.split('_')[-2]
                #this assumes there is no asset name U7
                if 'U7' in colName:
                    colName = colName.replace('U7','')
                print('Renaming Count column to ', colName)
                tmpdf.rename(columns={'Count':colName},inplace=True)

                tmpdf['t'] = pd.to_datetime(tmpdf['t'])
                tmpdf = tmpdf.set_index('t')
                tmpdf = tmpdf.sort_index()

                newdf = pd.DataFrame()
                #Iterate over rows in weights dataframe.  Slice tmpdf based on
                #date range from weights file, Apply weights.
                for index, row in dfWeights.iterrows():
                    print('RANGE: ', row['from'], ' TO ', row['to'])
                    # print(type(row['from']))
                    slicedPosDF = tmpdf[row['from']:row['to']]
                    for col in slicedPosDF:
                        print('column: ', col)
                        print('weight: ', row[weightColumn])
                        slicedPosDF[col] = slicedPosDF[col] * float(row[weightColumn])
                    newdf = newdf.append(slicedPosDF)

                    # add to dataframes list for reduction
                data_framesPositions.append(newdf)

    return data_framesPositions



def main():
    parser = argparse.ArgumentParser()

    #parser.add_argument('-f', '--startDate', default='20090101', help="from
    #date")
    #parser.add_argument('-t', '--endDate', default='20160101', help="to date")
    parser.add_argument('-baseDir', '--baseDir', default='C:/MyProjects/Data/Testzz', help="base input Directory")
    parser.add_argument('-baseOut', '--baseOutDir', default='C:/MyProjects/WQMaster/output/zzz', help="base output Directory")
    parser.add_argument('-w', '--weights', default='C:/MyProjects/Data/csz.csv', help="weights csv")
    parser.add_argument('-x', '--filePrefix', default='openPositionCount', help="file prefix of series")

    args = parser.parse_args()
    args.baseDir = os.path.abspath(args.baseDir)

    print("CSV path:" + args.baseDir)

    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)


    df = processData(args.baseDir, args.baseOutDir, args.weights, args.filePrefix)
    df = functools.reduce(MergeDataFrames, df).fillna(value=0)
    for col in df.columns.values:
        #TYU7 to TY
        if col.endswith('U7'):
            newcol = col[:-2]
            print('renaming',col,newcol)
            df.rename(columns={col:newcol},inplace=True)
        #multiply currency positions by 1MM
        if col in listCurrency:
            print('old column',df[col][-5:-1])
            df[col] = df[col] * 1000000
            print('new column', df[col][-5:-1])

	# Nov 7, 2018: 1 additional step needed here
	# use EncodePositons to multiply respective columns
    for name, values in df.iteritems():
        print('Encoding ', name, ' using ',EncodePositions[name] )
        df[name] = df[name]*EncodePositions[name]

    df.to_csv(os.path.join(args.baseOutDir,'MasterOpenPositionCount.csv'),index=True)

if __name__ == '__main__':
    main()