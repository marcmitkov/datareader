#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import numpy as np
import argparse

from math import sqrt, expm1
from pylab import *
from functools import partial
import matplotlib.pyplot as plt
import os
import functools

gCounter = 0
gContracts = []
listStrategyB = ['Keynes', 'Buffet', 'Smith', 'Nash', 'Friedman', 'Hayek', 'Marx', 'Tinbergen','Kondratiev']
def myMerge(left, right):
    #contracts = ['ES', 'NQ', 'ES2', 'NQ2']
    global gCounter
    print('In Merge')
    print(len(left))
    print(len(right))
    #mysuffixes = tuple([gContracts[0], gContracts[gCounter + 1]])
    #mysuffixes = tuple(['', gContracts[gCounter]])
    #mysuffixes = tuple(['', gContracts[gCounter + 1]])
    mysuffixes = tuple(['', gAvailableContracts[gCounter + 1]])
    gCounter = gCounter + 1
    return pd.merge(left, right, on=['t'], how='outer', suffixes=mysuffixes)

#https://www.geeksforgeeks.org/reduce-in-python/
#https://stackoverflow.com/questions/44327999/python-pandas-merge-multiple-dataframes
#def processSeries(contractSeries, weightCSV,baseDir, baseOutDir,startdate,
#enddate):
def processSeries(weightCSV, baseDir, baseOutDir, startdate, enddate):
    dfWeights = pd.read_csv(weightCSV)
    contractSeries = list(dfWeights.columns.values)
    if 'from' in contractSeries:
        contractSeries.remove('from')
    if 'to' in contractSeries:
        contractSeries.remove('to')

    data_frames = []
    global gContracts
    global gAvailableContracts
    gAvailableContracts = []
    gContracts = contractSeries
    '''for f in contractSeries:
        dftmp = pd.DataFrame()
        csvPath = os.path.join(baseDir, 'return_' + f +'.csv')
        dftmp = pd.read_csv(csvPath)
        data_frames.append(dftmp)'''
    fhReport = open(os.path.join(baseOutDir, 'Report.txt'),'w')
    #NewCode
    for dirpath, dirnames, filenames in os.walk(baseDir):
        for file in filenames:
            if os.stat(os.path.join(dirpath, file)).st_size < 2:
                continue

            if file.startswith('return_') :
                fname = file.split('_')[-1].split('.')[-2]
                if fname in listStrategyB:
                    alpha = file.split('_')[-1].split('.')[0]
                else:
                    alpha = file[7:].split('.')[0]
                gAvailableContracts.append(alpha)
                dftmp = pd.DataFrame()
                csvPath = os.path.join(baseDir, file)
                dftmp = pd.read_csv(csvPath)
                fhReport.write(str(alpha) + "\n")
                fhReport.write(str(dftmp.describe()) + "\n")
                # nefarious error  no need to convert to lret
                data_frames.append(dftmp)

    #############

    suffixTuple = tuple(contractSeries)
    #mergedOuterDF = functools.reduce(lambda left, right: pd.merge(left, right,
    #on=['t'],how='outer'), data_frames).fillna(value=0)
    mergedOuterDF = functools.reduce(myMerge, data_frames).fillna(value=0)
    print(mergedOuterDF.head())
    #dictSeriesWeights = dict(zip(contractSeries, weights))
    #mergedOuterDFNew = pd.DataFrame()

    #the first and leftmost dataframe column name is not suffixed during the
    #merge process hence renaming
    mergedOuterDF.rename(columns={'sret': 'sret' + gAvailableContracts[0] }, inplace=True)

    # manual cross check for to reconcile the return since inception number in
    # the alpha report
    for col in mergedOuterDF:
        print(col)
        if col == 't':
            continue;
        # print(_percent_format(_to_simple_ret(252 *
        # mergedOuterDF[col].agg('mean')) * 100))
        # convert sinmple return to log return for calculation of return since
        # inception through addition of daily returns
        try:
            lrets =  mergedOuterDF[col]
            # Banku, please check for syntax
            valStr = '{:{width}.{prec}f}'.format((lrets.agg('sum') * 100), width=5, prec=2)
            fhLog = open(os.path.join(baseOutDir, 'CrossCheckAlpha.txt'), 'a')
            fhLog.write(dirpath + ',' + col + "," + valStr + "\n")
        except:
            print("there is a problem with cross check alpha")

    mergedOuterDF['sret'] = 0
    #apply date range
    mergedOuterDF['t'] = pd.to_datetime(mergedOuterDF['t'])
    mask = (mergedOuterDF['t'] > startdate) & (mergedOuterDF['t'] <= enddate)
    mergedOuterDF = mergedOuterDF.loc[mask]
    ###################################################################################
    # read weights file in a df
    mergedOuterDFNew = pd.DataFrame()
    wtColNames = ['from','to']
    #UN Changes - commenting lines
    #wtColNames.extend(contractSeries)
    #dfWeights = pd.read_csv(weightCSV,names=wtColNames)
    #################
    dfWeights['from'] = pd.to_datetime(dfWeights['from'], format='%Y%m%d')
    dfWeights['to'] = pd.to_datetime(dfWeights['to'], format='%Y%m%d')
    #mergedOuterDF.to_csv('C:/MyProjects/Data/mergedOuterDF.csv',index=False)
    for index, row in dfWeights.iterrows():
        weightList = (row.tolist())[2:]
        print("normalizing weights...")
        weightList = weightList/sum(weightList[0:len(weightList)])
        print(weightList)
        dictSeriesWeightsNew = dict(zip(contractSeries, weightList))
        print('RANGE: ',row['from'], ' TO ', row['to'])
        maskforDF = (mergedOuterDF['t'] > row['from']) & (mergedOuterDF['t'] <= row['to'])
        maskDF = mergedOuterDF.loc[maskforDF]
        for col in maskDF:
            if col == 't' or col == 'sret':
                continue
            seriesName = col.split("sret", 1)[1]
            weighting = dictSeriesWeightsNew[seriesName]
            maskDF['sret'] = maskDF['sret'] + maskDF[col] * float(weighting)
        mergedOuterDFNew = mergedOuterDFNew.append(maskDF)
    print(mergedOuterDFNew.head())
    # mergedOuterDF['lret'] = np.log(1 + mergedOuterDF.sret)
    # print("sret", mergedOuterDF['sret'].describe())
    debugFilepath = os.path.join(baseOutDir, 'WeightRiskReportDiagnostics.csv')
    mergedOuterDFNew.to_csv(debugFilepath, index=False)
    mergedOuterDFNew['t'] = pd.to_datetime(mergedOuterDFNew['t'], format='%Y-%m-%d %H:%M:%S')
    mergedOuterDFNew = mergedOuterDFNew.set_index('t')
    mergedOuterDFNew = mergedOuterDFNew.sort_index()
    # one_min_bars=one_min_bars.drop(['d', 'ts','vol'],axis=1)
    mergedOuterDFNew = mergedOuterDFNew.reset_index()
    return mergedOuterDFNew
    ##############################################
    '''for col in mergedOuterDF:
        if col == 't' or col == 'lret':
            continue
        seriesName = col.split("lret", 1)[1]
        weighting = dictSeriesWeights[seriesName]
        mergedOuterDF['lret'] = mergedOuterDF['lret'] + mergedOuterDF[col] *float(weighting)

        #dfq =df_merged[df_merged[col] >0]
        #print(dfq)
    print(mergedOuterDF.head())
    #mergedOuterDF['lret'] = np.log(1 + mergedOuterDF.sret)
    #print("sret", mergedOuterDF['sret'].describe())
    debugFilepath = os.path.join(baseOutDir, 'RiskReportDiagnostics.csv')
    mergedOuterDF.to_csv(debugFilepath, index=False)
    mergedOuterDF['t'] = pd.to_datetime(mergedOuterDF['t'], format='%Y-%m-%d %H:%M:%S')
    mergedOuterDF = mergedOuterDF.set_index('t')
    mergedOuterDF = mergedOuterDF.sort_index()
    # one_min_bars=one_min_bars.drop(['d', 'ts','vol'],axis=1)
    mergedOuterDF = mergedOuterDF.reset_index()
    return mergedOuterDF'''

def processSeriesOld(contractSeries, weights,baseDir, baseOutDir):
    '''for f in contractSeries:
        csvPath = os.path.join(baseDir,f +'.csv')
        df = pd.read_csv(csvPath)'''
    csvPath1 = os.path.join(baseDir, contractSeries[0] + '.csv')
    csvPath2 = os.path.join(baseDir, contractSeries[1] + '.csv')
    df1 = pd.read_csv(csvPath1)
    df2 = pd.read_csv(csvPath2)
    mergedOuterDF = pd.merge(df1, df2, on='t', how='outer',suffixes=('_' + contractSeries[0] ,'_' + contractSeries[1]))
    print(mergedOuterDF.head())
    mergedOuterDF.fillna(value=0,inplace=True)
    print(mergedOuterDF.head())
    mergedOuterDF['sret'] = mergedOuterDF['sret_' + contractSeries[0]] * float(weights[0]) + mergedOuterDF['sret_' + contractSeries[1]] * float(weights[1])
    print(mergedOuterDF.head())
    mergedOuterDF['lret'] = np.log(1 + mergedOuterDF.sret)
    print("sret", mergedOuterDF['sret'].describe())
    debugFilepath = os.path.join(baseOutDir, 'RiskReportDiagnostics.csv')
    mergedOuterDF.to_csv(debugFilepath, index=False)
    mergedOuterDF['t'] = pd.to_datetime(mergedOuterDF['t'], format='%Y-%m-%d %H:%M:%S')
    mergedOuterDF = mergedOuterDF.set_index('t')
    mergedOuterDF = mergedOuterDF.sort_index()
    # one_min_bars=one_min_bars.drop(['d', 'ts','vol'],axis=1)
    mergedOuterDF = mergedOuterDF.reset_index()
    return mergedOuterDF

def daily_log_ret(df):
    return _aggregated_log_ret(df)

# All these functions assume a pandas dataframe with timestamp column t.
# works on log rets columns only and returns aggregated log returns only.
# Groups by day and reurns a series (sum of lret for each daily group series)
def _aggregated_log_ret(df, freq='D', log_ret_col='lret', time_col='t'):
    #df=df.set_index(time_col)
    #zz =df.groupby(pd.TimeGrouper(freq))
    return df.set_index(time_col).groupby(pd.TimeGrouper(freq))[log_ret_col].sum()

def _to_simple_ret(logret):
    return expm1(logret)

def _percent_format(n):
    return '{:{width}.{prec}f} %'.format(n, width = 5, prec = 2)


def _double_format(n):
    return '{:{width}.{prec}f}'.format(n, width = 5, prec = 2)

def _to_simple_ret_str(logret):
    return _double_format(_to_simple_ret(logret))


def _sharpe(df):
    aa = df.agg(['mean','std'])
    return sqrt(252) * aa['lret'][0] / aa['lret'][1]


def _updown_months(df):
    m = df.groupby(pd.Grouper(freq='M'))['lret'].sum()
    n = float(len(m[m.values > 0]))
    d = float(len(m[m.values < 0]))
    r = 12
    if d != 0:
        r = n / d
    return r


def _updown_month_rets(df):
    m = df.groupby(pd.Grouper(freq='M'))['lret'].sum()
    up_ret = m[m.values > 0].mean() * 100
    down_ret = m[m.values < 0].mean() * 100
    return _double_format(up_ret) + " / " + _double_format(down_ret) + " %"


def _winloss_days(df):
    t = float(len(df))
    w = float(len(df[df['lret'] > 0]))
    l = float(len(df[df['lret'] < 0]))
    f = t - (w + l)
    return _double_format(100 * w / t) + " / " + \
           _double_format(100 * l / t) + \
           " [" + _double_format(100 * f / t) + " ]"


def _risk_of_ruin(df):
    m = df.agg('mean').lret
    s = df.agg('std').lret
    r = sqrt(m ** 2 + s ** 2)
    return ((2 / (1 + (m / r))) - 1) ** (s / r)


# defining sharpe as something annualised
def max_dd(r):
    return np.max(r.expanding().sum().expanding().max() - r.expanding().sum())


def _n_day_analysis(n, df):
    r = df.rolling(n, min_periods=n).sum()
    best = _to_simple_ret(r.max().lret) * 100
    worst = _to_simple_ret(r.min().lret) * 100
    avg = _to_simple_ret(r.mean().lret) * 100
    curr = _to_simple_ret(r.tail(1).lret.values[0]) * 100
    return [_percent_format(best), _percent_format(worst),
            _percent_format(avg), _percent_format(curr)]


def best_21(series):
    r = series.rolling(21, min_periods=21).sum()
    return _percent_format(_to_simple_ret(r.max()) * 100)


def worst_21(series):
    r = series.rolling(21, min_periods=21).sum()
    return _percent_format(_to_simple_ret(r.min()) * 100)



def ann_return(series):
    a = _to_simple_ret(np.sum(series)) * 100
    return _percent_format(a)


def ann_sharpe(series):
    a = sqrt(252) * (np.mean(series) / np.std(series))
    a = 0
    if np.std(series) != 0:
        a = sqrt(252) * (np.mean(series) / np.std(series))

    return _double_format(a)


def depth_dd(series):
    return -100 * _to_simple_ret(np.max(series))


def start_dd(series):
    return series.head(1).index.date


def end_dd(series):
    return series.tail(1).index.date


def length_dd(series):
    return len(series)


# Plots 4x4 cumulative and distributions of returns
def plot_returns(df, mode,baseOutDir):
    f, axarr = plt.subplots(3)
    print(type(axarr))
    print((axarr[0]))
    #f.patch.set_visible(False)
    retSharpeInceptionDF = _draw_table1(df, axarr[0])
    retSharpeAnnualDF = _draw_year_analysis(df, axarr[1])
    _draw_day_analysis_table(df, axarr[2])
    _draw_drawdowns_table(df, axarr[2])
    #_draw_cum_returns(df, axarr[3])
    #_draw_returns_hist(df, axarr[4])
    #f.suptitle('test title', fontsize=20)
    #plt.subplots_adjust(left=0.1, bottom=0.1,top=1.5)
    plt.subplots_adjust(hspace=0.6,left=0.1, bottom=0.1,top=0.9)
    #f.tight_layout()
    if mode == 'q':
        figurePath = os.path.join(baseOutDir, 'tables_portfolio.png')
        plt.savefig(figurePath,dpi=300, bbox_inches = "tight")
    else:
        plt.show()

    return retSharpeAnnualDF,retSharpeInceptionDF

def plot_returns2(df,pnldf,pnlhist,mode,baseOutDir):
    if pnlhist == 'True':
        f, axarr = plt.subplots(3)
    else:
        f, axarr = plt.subplots(2)
    #f, axarr = plt.subplots(2)
    print(type(axarr))
    print((axarr[0]))
    #f.patch.set_visible(False)
    '''_draw_table1(df, axarr[0])
    _draw_year_analysis(df, axarr[1])
    _draw_day_analysis_table(df, axarr[2])
    _draw_drawdowns_table(df, axarr[2])'''
    _draw_cum_returns(df, axarr[0])
    _draw_returns_hist(df, axarr[1])
    if pnlhist == 'True':
        _draw_pnldiff_hist(pnldf, axarr[2])
    plt.subplots_adjust(left=0.1, bottom=0.1,top=1.5)
    f.tight_layout()
    if mode == 'q':
        figurePath = os.path.join(baseOutDir, 'charts_portfolio.png')
        plt.savefig(figurePath,dpi=300, bbox_inches = "tight")
    else:
        plt.show()

def _draw_table1(df, axis):
    colLabels = ('', '')
    rowLabels = ('Start Date - End Date',
                 'Total Return since inception',
                 'Average Annual ROR',
                 'Winning / Losing Months',
                 'Winning Month Gain / Losing Month Loss',
                 'Sharpe Ratio',
                 'Risk of Ruin',
                 'Return to Drawdown (Calmar)',
                 '% Winning / Losing Days [Flat Days]')
    data = [[pd.to_datetime(df.head(1).index.values[0]).strftime('%Y-%m-%d') + " - " + pd.to_datetime(df.tail(1).index.values[0]).strftime('%Y-%m-%d')],
            [_percent_format((df.agg('sum').lret) * 100)],
            [_percent_format(_to_simple_ret(252 * df.agg('mean').lret) * 100)],
            [_double_format(_updown_months(df))],
            [_updown_month_rets(df)],
            [_double_format(_sharpe(df))],
            [_double_format(_risk_of_ruin(df))],
            [_double_format(252 * df.agg('mean').lret / max_dd(df.lret))],
            [_winloss_days(df)]]
    print('Mytable:')
    print(data)

    #Create dataframe for Return and Sharpe Ratio since inception
    RetAndSharpeList = []
    totReturnStr = '{:{width}.{prec}f}'.format((df.agg('sum').lret * 100), width=5, prec=2)
    # RetAndSharpeList.append([data[1][0],data[5][0],dirname])
    RetAndSharpeList.append([float(totReturnStr), float(data[5][0])])
    RetAndSharpeDF = pd.DataFrame(RetAndSharpeList, columns=['TotalReturn', 'SharpeRatio'])

    axis.axis('off')
    # axis.axis('tight')
    # axis.get_frame_on()
    # plt.subplots_adjust(bottom=0.1, right=0.8, top=2.9)
    axis.set_title('Performance Analysis')
    # Styles for rows and cells
    colorsrow = []
    colorscell = []
    for x in range(len(data)):
        tmpList = []
        if x % 2 == 0:
            tmpList.append("#D0DDAF")
            colorsrow.append("#D0DDAF")
        else:
            tmpList.append("#E6E9E9")
            colorsrow.append("#E6E9E9")
        colorscell.append(tmpList)

    # colorscell =
    # [["#D0DDAF"],["#E6E9E9"],["#D0DDAF"],["#E6E9E9"],["#D0DDAF"],["#E6E9E9"],["#D0DDAF"],["#E6E9E9"],["#D0DDAF"]]
    # colorsrow = ["#D0DDAF", "#E6E9E9", "#D0DDAF", "#E6E9E9", "#D0DDAF",
    # "#E6E9E9", "#D0DDAF", "#E6E9E9", "#D0DDAF"]
    the_table = axis.table(cellText=data,
                           rowLabels=rowLabels,
                           colLabels=None,
                           loc='center right',
                           cellColours=colorscell,
                           rowColours=colorsrow,
                           # bbox=[0.3, -0.6, 0.5, 1.5])
                           # bbox=[0.3, -0.2, 0.5, 1.5])
                           bbox=[0.25, -0.2, 0.7, 1.1])
    '''the_table._cells[(0, 0)].set_facecolor("#56b5fd")
    the_table._cells[(2, 0)].set_facecolor("#1ac3f5")'''
    table_props = the_table.properties()
    # table_cells = table_props['children']
    # for cell in table_cells: cell.set_width(0.5)

    return RetAndSharpeDF


def _draw_year_analysis(df, axis):
    rowLabels = ('Annual return',
                 'Best 21 days',
                 'Worst 21 days',
                 '1 year sharpe')
    g = df.groupby(pd.Grouper(freq='A'))
    v = g.agg([np.mean, np.std, ann_return, best_21, worst_21, ann_sharpe])
    v['lret', 'sharpe'] = sqrt(252) * (v['lret', 'mean'] / v['lret', 'std'])

    # Create Annual Return Sharpe dataframe
    retSharpeAnnualDF = v['lret'][['ann_return', 'ann_sharpe']]
    #retSharpeDF['pval'] = dirname

    colLabels = list(map(lambda x: x.year, v['lret'].index.tolist()))
    data = v['lret'][['ann_return', 'best_21', 'worst_21', 'ann_sharpe']].T.as_matrix()
    print('YA:')
    print(colLabels)
    print(data)
    axis.axis('off')
    # axis.axis('tight')
    axis.set_title('Annual Return')
    colLabelsTemp = colLabels
    ############
    colorscell = []
    colorsrow = []
    for i in range(len(rowLabels)):
        tmpList = []
        for x in range(len(colLabels)):
            if x % 2 == 0:
                tmpList.append("#D0DDAF")
            else:
                tmpList.append("#E6E9E9")
        colorscell.append(tmpList)
        if i % 2 == 0:
            colorsrow.append("#D0DDAF")
        else:
            colorsrow.append("#E6E9E9")
    colorscolumn = colorscell[0]
    ###############

    # axis.text(0.5, 1.5,'Annual Returns',fontsize=12)
    # axis.set_title('Year Analysis')
    # colorscell = [["#D0DDAF","#E6E9E9",
    # "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9",
    # "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9",
    # "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]]
    # colorsrow = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]
    # colorscolumn = ["#D0DDAF","#E6E9E9",
    # "#D0DDAF","#E6E9E9"]#plt.cm.BuPu(np.linspace(0,0.5, len(colLabels)))
    '''colLabelsList =[]
    for label in colLabels:
        print(label)
        colLabelsList.append(label)'''

    the_table = axis.table(cellText=data,
                           rowLabels=rowLabels,
                           colLabels=colLabels,
                           cellColours=colorscell,
                           colColours=colorscolumn,
                           rowColours=colorsrow,
                           loc='left',
                           bbox=[0.0, -0.0, 1.0, 0.8])
    # bbox=[0.0, -0.2, 1.0, 1.1])
    # bbox=[0.0, -0.1, 1.0, 1.5])
    table_props = the_table.properties()
    table_cells = table_props['children']
    #print('YAzzz:')
    # for cell in table_cells: cell.set_width(0.1)

    return retSharpeAnnualDF

def _draw_day_analysis_table(df, axis):
    days = [1, 5, 21, 63, 126, 252]
    rowLabels = list(map(lambda x: str(x) + " days", days))
    colLabels = ['Best', 'Worst', 'Avg', 'Curr']
    f = partial(_n_day_analysis, df=df)
    data = list(map(f, days))
    print('DAY')
    print(data)
    axis.axis('off')
    axis.axis('tight')
    axis.set_title('Time analysis')

    #set styles for rows, cols and cells
    colorscell = []
    colorsrow = []
    for i in range(len(rowLabels)):
        tmpList = []
        for x in range(len(colLabels)):
            if x % 2 == 0:
                tmpList.append("#D0DDAF")
            else:
                tmpList.append("#E6E9E9")
        colorscell.append(tmpList)
        if i % 2 == 0:
             colorsrow.append("#D0DDAF")
        else:
             colorsrow.append("#E6E9E9")
    colorscolumn = colorscell[0]
    #colorscell = [["#D0DDAF","#E6E9E9",
    #"#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9",
    #"#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9",
    #"#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9",
    #"#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9",
    #"#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]]
    #colorsrow = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9",
    #"#D0DDAF","#E6E9E9"]
    #colorscolumn = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]

    #owLabels = getColumnsList(rowLabels)
    the_table = axis.table(cellText=data,
                           rowLabels=rowLabels,
                           colLabels=colLabels,
                           cellColours = colorscell,
                           rowColours = colorsrow,
                           colColours = colorscolumn,
                           loc='center',
                           bbox=[0.0, -0.2, 0.5, 1.0])
                           #bbox=[0.0, -0.2, 0.5, 1.5])
                           #bbox=[0.0, -0.2, 0.5, 1.5])


def _draw_drawdowns_table(df, axis):
    df['expanding_sum'] = df['lret'].expanding().sum()
    df['expanding_max'] = df['expanding_sum'].expanding().max()
    df['drawdowns'] = df['expanding_max'] - df['expanding_sum']
    g = df.drawdowns[df['drawdowns'] > 0].groupby(df['expanding_max'])
    dds = g.agg([depth_dd, start_dd, end_dd, length_dd])
    print('dds:', dds)
    dds = dds.sort_values(by='depth_dd')
    print('dds2:', dds)
    dds['depth_dd'] = dds['depth_dd'].apply(_percent_format)
    data = dds.head(6).as_matrix()
    print('data:', len(data))
    print('Draw')
    print(data)
    colLabels = ('Depth', 'Start', 'End', 'Length (days)')
    axis.axis('off')
    axis.axis('tight')
    axis.set_title('Time Analysis                                                                Drawdown Report')

    colorscell = []
    for i in range(len(data)):
        tmpList = []
        for x in range(4):
            if x % 2 == 0:
                tmpList.append("#D0DDAF")
            else:
                tmpList.append("#E6E9E9")
        colorscell.append(tmpList)
    colorscolumn = colorscell[0]
    # colorsrow = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9",
    # "#D0DDAF","#E6E9E9"]
    # colorscolumn = ["#D0DDAF","#E6E9E9",
    # "#D0DDAF","#E6E9E9"]#plt.cm.BuPu(np.linspace(0,0.5, len(colLabels)))

    the_table = axis.table(cellText=data,
                           colLabels=colLabels,
                           cellColours=colorscell,
                           colColours=colorscolumn,
                           loc='right',
                           bbox=[0.52, -0.2, 0.5, 1.0])
    # bbox=[0.52, -0.2, 0.5, 1.5])
    # bbox=[0.52, -0.2, 0.5, 1.5])


def _draw_cum_returns(daily_returns, axis):
    #xs = daily_returns.values.cumsum()
    xs = daily_returns['lret'].cumsum()
    # helpful for max dd
    i = np.argmax(np.maximum.accumulate(xs) - xs)
    j = np.argmax(xs[:i])
    axis.plot(xs, linewidth=0.8, linestyle='-', c='black')
    # max dd red dots
    axis.plot([i, j], [xs[i], xs[j]], 'o', color='Red', markersize=5)
    axis.set_title('Cumulative Daily Returns')
    axis.set_ylabel('Cumulative % Returns')
    plt.rc('grid', linestyle=":", color='gray')

    plt.grid(True)


def _draw_returns_hist(daily_returns, axis):
    axis.hist(daily_returns.values, bins=50, facecolor='b', alpha=0.5, ec='black')
    axis.set_ylabel('Days')
    # plt.set_xlabel('% Returns')
    axis.set_title('# Daily Returns')
    plt.rc('grid', linestyle=":", color='gray')
    plt.grid(True)

def _draw_pnldiff_hist(pnldf, axis):
    pnldifflist = pnldf['lret'].tolist()
    axis.hist(pnldifflist, bins=50, facecolor='b', alpha=0.5, ec='black')
    axis.set_ylabel('Days')
    # plt.set_xlabel('% Returns')
    axis.set_title('# pnl')
    plt.rc('grid', linestyle=":", color='gray')
    plt.grid(True)

def main():
    parser = argparse.ArgumentParser()
    #parser.add_argument('-cs', '--contractSeries', default=['Es', 'ES2'],
    #help="Contract series list", nargs='*')
    #parser.add_argument('-w', '--weights', default=['0.1', '0.9'],
    #help="weights series list", nargs='*')
    parser.add_argument('-f', '--startDate', default='20090101', help="from date")
    parser.add_argument('-t', '--endDate', default='20190101', help="to date")
    parser.add_argument('-baseDir', '--baseDir', default='C:/MyProjects/WQMaster/output/xxxx', help="base Directory")

    parser.add_argument('-baseOut', '--baseOutDir', default='C:/MyProjects/WQMaster/output/zzz', help="base Directory")
    parser.add_argument('-pnlhist', '--pnlhist', default='True', help="True: show pndiff histo")
    parser.add_argument('-w', '--weights', default='C:/MyProjects/Data/cs.csv', help="weights csv")
    parser.add_argument('-mode', '--mode', default='q', help="q or v")
    args = parser.parse_args()
    args.baseDir = os.path.abspath(args.baseDir)

    print("CSV path:" + args.baseDir)

    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)

    dat = processSeries(args.weights,args.baseDir, args.baseOutDir,args.startDate, args.endDate)
    dat['lret'] = np.log(1 + dat['sret'])
    datReturn = dat.filter(['sret', 't'], axis=1)
    datReturn.to_csv(os.path.join(args.baseOutDir, 'LretSret.csv'),index=False)
    #dat.rename(columns={'sret': 'lret'}, inplace=True)
    ##
    #dat = processSeriesOld(contractSeries, weights, baseDir, baseOutDir)
    #convert sret to lret
    daily_returns = daily_log_ret(dat)
    daily_returns = pd.DataFrame(daily_returns.dropna())
    #plot_returns(daily_returns,args.mode,args.baseOutDir)
    retSharpDF, inceptionDF = plot_returns(daily_returns,args.mode,args.baseOutDir)

    plot_returns2(daily_returns,dat,args.pnlhist,args.mode,args.baseOutDir)
    retSharpDF.to_csv(os.path.join(args.baseOutDir, 'AnnualRetSharpe.csv'),index=True)
    inceptionDF.to_csv(os.path.join(args.baseOutDir, 'InceptionRetSharpe.csv'), index=False)
if __name__ == '__main__':
    main()
