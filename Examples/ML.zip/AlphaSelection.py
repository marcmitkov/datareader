#!/big/svc_wqln/projects/python/conda/bin/python3.6

#-version V16 -runDates 20150101-20191115 -step 1(or2)
# Step 1 (followed by manual alpha selection)
##Copies ranked files from Backtests to MyProjects/Ranks appropriate folder
# Step 2 ( subsequent to manual alpha selection)
## Combines 1H, 15 m etc selected alphas in Ranks folder into single Selected<version>.csv
## creates alpha list in Ranks folder, copies to appropriate Backtests/AlphaList folder

import pandas as pd
import argparse
import xml.etree.ElementTree as et
import shutil
import os
from datetime import datetime,timedelta
import logging
import copy


def custom_rating(genre):
     z = genre['Alpha'].replace('_', ',')
     return z

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-baseBTDir', '--baseBTDir', default='/home/lanarayan/MLData/Backtests',
                        help="base Backtest Directory. args.version will be appended to dir name")
    parser.add_argument('-baseRankDir', '--baseRankDir', default='/home/lanarayan/MyProjects/Ranks',
                        help="base Ranking Directory.args.version will be added to path")
    parser.add_argument('-strategy', '--strategy', default='A',
                        help="to create Fit-A-2019 or Fit-B-2019")
    parser.add_argument('-version', '--version', default='V16',
                        help="version for appending to baseBTDir and for dir  creation in Ranks folder")
    parser.add_argument('-runDates', '--runDates', default='20150101-20191115',
                        help="runDates")
    #parser.add_argument('-rankFiles', '--rankFiles',
    #                   default=["RankedAlphas_20150101-20191115_1H.csv", "RankedAlphas_20150101-20191115_15m.csv"], help="rankFiles files ",
    #                    nargs='*')
    parser.add_argument('-frequency', '--frequency',default=["1H", "15m"],  help="rankFiles files", nargs='*')
    parser.add_argument('-step', '--step', default='',
                        help="1 (followed by manual alpha selection) or 2 ( subsequent to alpha selection, creates alpha list")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    if not os.path.exists(args.logPath):
        print("Creating log folder :" + args.logPath)
        os.makedirs(args.logPath)

    logging.basicConfig(filename=os.path.join(args.logPath,'AlphaSelection-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    rankDir = os.path.join(args.baseRankDir, args.version)
    frequencyList = args.frequency
    if args.step == '1':
        print('Begin Alpha Selection Step 1 ')
        logging.debug('Begin Selection Step 1 ')
        #check if ~/MyProjects/Ranks/V16 exists else create dir (dir where Ranked files from Backtests will be copied
        if not os.path.exists(rankDir):
            print("Creating rank folder :" + rankDir)
            os.makedirs(rankDir)

        #NOTES:
        # cd ~/MLData/BacktestsV16/0utSimRank15m/Fit-A-2019/V0
        # cp RankedAlphas_20150101-20191115.CSV to /home/lanarayan/MyProjects/Ranks/V16/RankedAlphas_20150101-20191115_15m.csv
        # cd /MLData/BacktestsV16/OutSimRank1H/ Fit-A-2019/V0
        # cp RankedAlphas_20150101-29191115.csv to /home/lanarayan/MyProjects/Ranks/V16/RankedAlphas 20150101-20192115_1H.csv
        # manual : insert selected and suffix columns and populate appropriately
        # to get latest active contract: lanarayan@wqropsapi009:~/MLData/BacktestsV16/Fit-A-2019/LCO/1H$] tail LCO.CSV

        # copy rank csv files from BT V0 folder to MyProjects/Ranks/<version> folder
        # e.g copy  ~/MLData/BacktestsV16/OutSimRank1H/Fit-A-2019/V0/RankedAlphas_20150101-20191115 to ~/MyProjects/Ranks/V16/Ranks/RankedAlphas_20150101-20191115_1H.csv
        for frequency in frequencyList:
            srcRankFile = os.path.join(args.baseBTDir + args.version,'OutSimRank' + frequency,'Fit-' + args.strategy + '-2019', 'V0','RankedAlphas_'+ args.runDates + '.csv')
            destRankFile= os.path.join(rankDir,'RankedAlphas_'+ args.runDates + '_' + frequency + '.csv')

            print('Copying Rank files')
            logging.debug('Copying Rank files')
            print('srcRankFile :', srcRankFile)
            logging.debug('srcRankFile :{}'.format(srcRankFile))
            print('destRankFile :', destRankFile)
            logging.debug('destRankFile :{}'.format(destRankFile))

            shutil.copy(srcRankFile,destRankFile)

        print('Alpha Selection Step 1 done')
        logging.debug('Alpha Selection Step 1 done')
        print("Manual :Ready to make alpha selection- insert selected and suffix columns and populate appropriately")
        logging.debug("Manual :Ready to make alpha selection- insert selected and suffix columns and populate appropriately")
    elif args.step == '2':
        print('Begin Alpha Selection Step 2 ')
        logging.debug('Begin Selection Step 2 ')
        # Read the csv file
        # select all rows from df with selected=1
        #Alpha column only create a df
        #replace _ with ,
        #save as alphasA.txt

        rankFileList = []

        # Creating list of Ranked files  from ~/MyProjects/Ranks/V16/  that have selected alphas for creating alphaList
        for frequency in frequencyList:
            rankFileList.append('RankedAlphas_' + args.runDates + '_' + frequency + '.csv')

        #rankFileList = args.rankFiles

        dfTotal = pd.DataFrame()

        #Combine Ranked selected alphas in dfTotal
        for file in rankFileList:
            rankFile = os.path.join(rankDir,file)
            print("Reading RankFile :", rankFile)
            logging.debug("Reading RankFile : {}".format(rankFile))
            df = pd.read_csv(rankFile)
            dfSelected = df[df.Selected == 1]
            dfTotal = dfTotal.append(dfSelected)

        #create Selected<version>.csv of all selected alphas
        print("Creating combined alphas file :", 'Selected' + args.version + '.csv')
        logging.debug("Creating combined alphas file : : {}".format('Selected' + args.version + '.csv'))
        dfTotal.to_csv(os.path.join(rankDir, 'Selected' + args.version + '.csv'), index=False)

        #create alphas file alphasA.txt in MyProjects/Ranks/<version> folder
        dfTotal["Alpha"] = dfTotal["Alpha"].str.replace("_", ",")
        alphas = dfTotal['Alpha']
        #alphas = alphas.apply(lambda x: x['Alpha'].replace('_',','),axis=1)
        print('Creating alphas' + args.strategy + '.txt in ', rankDir)
        logging.debug('Creating alphas {}.txt in {}'.format(args.strategy,rankDir))
        alphas.to_csv(os.path.join(rankDir,'alphas' + args.strategy + '.txt'), index=False, sep=' ')

        # Copy alphasA.txt to Backtests<version>/AlphaList/<version> folder
        srcAlphaFile = os.path.join(rankDir, 'alphas' + args.strategy + '.txt')
        destAlphaDir = os.path.join(args.baseBTDir + args.version, 'AlphaList', args.version)

        if not os.path.exists(destAlphaDir):
            print("Creating alpha version folder :" + destAlphaDir)
            os.makedirs(destAlphaDir)

        print('Copying Alpha file')
        logging.debug('Copying Alpha files')
        print('srcAlphaFile :', srcAlphaFile)
        logging.debug('srcAlphaFile :{}'.format(srcAlphaFile))
        print('destAlphaDir :', destAlphaDir)
        logging.debug('destAlphaDir :{}'.format(destAlphaDir))

        shutil.copy(srcAlphaFile,destAlphaDir)

        print('Alpha Selection Step 2 done')
        logging.debug('Alpha Selection Step 2 done')
    else:
        print("Please specify step 1 or step 2. Exiting")
        logging.debug("Please specify step 1 or step 2. Exiting")
        exit(1)


if __name__ == '__main__':
    main()

