#!/bin/bash 

startScript=$(date -u) 

FROM=$(date --date='1 day ago' '+%Y%m%d')
TO=${FROM}

echo FROM: $FROM
echo TO: $TO

#echo /home/lanarayan/MyProjects/ML/RunDailySimNewDaVinciWIP.bash -m run -e all
#/home/lanarayan/MyProjects/ML/RunDailySimNewDaVinciWIP.bash -m run -e all

echo rm -rf /home/lanarayan/MLData/Builds/buildbkup
#rm -rf /home/lanarayan/MLData/Builds/buildbkup

echo mv /home/lanarayan/MLData/Builds/build /home/lanarayan/MLData/Builds/buildbkup
#mv /home/lanarayan/MLData/Builds/build /home/lanarayan/MLData/Builds/buildbkup

#echo cp -r /home/lanarayan/UAT/VishnuWIP/build /home/lanarayan/MyProjects/ML/Builds
echo cp -r /home/lanarayan/UAT/VishnuWIP/build /home/lanarayan/MLData/Builds
cp -r /home/lanarayan/UAT/VishnuWIP/build /home/lanarayan/MLData/Builds


## SYnc DaVinciWIP and DaVinciFinal
SUFFIXA=DaVinciWIP
SUFFIXB=DaVinciFinal
#echo /home/lanarayan/MyProjects/ML/SyncPositions.py -alpha /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V5/alphasA.txt -f ${FROM} -t ${TO} -baseDirA /home/lanarayan/MLData/BacktestsAlphaWIP/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseOut /home/lanarayan/MLData/SyncPositions/DaVinci -suffixA DaVinciWIP -suffixB DaVinciFinal
#/home/lanarayan/MyProjects/ML/SyncPositions.py -alpha /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V5/alphasA.txt -f ${FROM} -t ${TO} -baseDirA /home/lanarayan/MLData/BacktestsAlphaWIP/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseOut /home/lanarayan/MLData/SyncPositions/DaVinci -suffixA DaVinciWIP -suffixB DaVinciFinal

## SYnc Prod and DaVinciFinal
SUFFIXA=Prod
SUFFIXB=DaVinciFinal
#echo /home/lanarayan/MyProjects/ML/SyncPositions.py -alpha /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V8/alphasA.txt -f ${FROM} -t ${TO} -baseDirA /home/lanarayan/MLData/Builds/build -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseOut /home/lanarayan/MLData/SyncPositions/prod -prod -suffixA Prod -suffixB DaVinciFinal
#/home/lanarayan/MyProjects/ML/SyncPositions.py -alpha /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V5/alphasA.txt -f ${FROM} -t ${TO} -baseDirA /home/lanarayan/MLData/Builds/build -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseOut /home/lanarayan/MLData/SyncPositions/prod -prod -suffixA Prod -suffixB DaVinciFinal

## SYnc Prod and BTAlpha
SUFFIXA=Prod_$FROM
SUFFIXB=BTAlpha_$FROM
echo /home/lanarayan/MyProjects/ML/SyncPositions.py -alpha /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V8/alphasA.txt -f ${FROM} -t ${TO} -baseDirA /home/lanarayan/MLData/Builds/build -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseOut /home/lanarayan/MLData/SyncPositions/prod -prod -suffixA ${SUFFIXA} -suffixB ${SUFFIXB}
/home/lanarayan/MyProjects/ML/SyncPositions.py -alpha /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V8/alphasA.txt -f ${FROM} -t ${TO} -baseDirA /home/lanarayan/MLData/Builds/build -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseOut /home/lanarayan/MLData/SyncPositions/prod -prod -suffixA ${SUFFIXA} -suffixB ${SUFFIXB}

#/home/lanarayan/MyProjects/ML/SyncBTwithProd.py -alphas /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V8/alphasA.txt -copyDate 20191110 -source /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -dest /home/lanarayan/UAT/VishnuWIP/build

echo 'StartTime EveningSyncs:' $startScript
endScript=$(date -u)
echo 'EndTime EveningSyncs:'$endScript