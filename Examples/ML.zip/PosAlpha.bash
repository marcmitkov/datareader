#!/bin/bash 
# -b to run function Test
#https://stackoverflow.com/questions/192249/how-do-i-parse-command-line-arguments-in-bash
startScript=$(date -u) 
echo "you have provided $# argument" 
echo "arguments are $@" 
echo "usage: PosAlpha.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1"
echo "Alphas location,Output are set in script based on -e arg"
# ./PosAlpha.bash -m test -e A -f 20190601 -t 20200901  -v V1


#Common Params
ROOTDIR=/home/lanarayan/MyProjects/ML
INPUTA=Fit-A-2019
INPUTB=Fit-B-2014 
ROOT=/home/lanarayan/MyProjects/ML
DIRROOT=/big/svc_wqln/ML/Backtests

#Can be changed by giving args
MODE='run'
FROM=20190129  
TO=20190201 
VERSION=V1

LOGDIR=${DIRROOT}/Logs 
LOGFILE=${LOGDIR}/PosAlphaBash-$(date '+%d%m%Y-%H:%M:%S').txt; 
echo $LOGFILE
[ -d ${LOGDIR} ] || echo mkdir -p ${LOGDIR} 
[ -d ${LOGDIR} ] || mkdir -p ${LOGDIR}



while [[ $# -gt 0 ]]
do
key="$1"
echo "Key:$key Value:$2"
case $key in
    -f|--from)
		FROM="$2"
		shift # past argument
		shift # past value
    ;;
    -t|--to)
		TO="$2"
		shift # past argument
		shift # past value
    ;;
	-m|--mode)
		MODE="$2"
		shift # past argument
		shift # past value
    ;;
	-v|--version)
		uppercase=${2^^}
		#uppercase=$2| awk '{print toupper($2)}'
		VERSION=${uppercase}
		shift # past argument
		shift # past value
    ;;
	-e|--execute)
		upperCaseArg=${2^^}
		#upperCaseArg=$2| awk '{print toupper($2)}'
		EXECUTE=${upperCaseArg}
		shift # past argument
		shift # past value
    ;;
    *)    # unknown option
		echo "unknown Argument $1"
		echo "usage: GraphSim.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1 -g|--graph 0|1"
		echo "Alphas location, Weights location ,Input,Output are set in script based on -e arg"
		exit
    ;;
esac
done

echo "Args Values:"
echo FROM = "${FROM}"
echo TO = "${TO}"
echo VERSION = "${VERSION}"
echo EXECUTE = "${EXECUTE}"
echo MODE = "${MODE}"

#FOR Strat A
OUTPUTA=Fit-A-2019 
ALPHASA=${DIRROOT}/AlphaList/${VERSION}/alphasA.txt 

#FOR Strat B
OUTPUTB=Fit-B-2014 
ALPHASB=${DIRROOT}/AlphaList/${VERSION}/alphasB.txt 


#For AB
OUTPUTAB=Fit-AB-2019
ALPHASAB=${DIRROOT}/AlphaList/${VERSION}/alphasAB.txt 


function ShowStatus {
if [ $? -eq 0]
 then
	echo PASS $1
	
 else
	echo FAIL $1 
	
	exit 1
	
fi
}

function Period1AB
{

echo ${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTAB}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASAB} -groupBy Strategy -mode v

if [ ${MODE} == 'run' ] 
	then
	echo ${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTAB}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASAB} -groupBy Strategy -mode v >> ${LOGFILE}
	${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTAB}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASAB} -groupBy Strategy -mode v	
	
	ShowStatus PosAlphaPeriod1AB
	
	
fi

}

function Period1A
{

echo ${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTA}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASA} -groupBy Strategy -mode v

if [ ${MODE} == 'run' ] 
	then
	echo ${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTA}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASA} -groupBy Strategy -mode v >> ${LOGFILE}
	${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTA}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASA} -groupBy Strategy -mode v	
	
	ShowStatus PosAlphaPeriod1A
fi

}

function Period1B
{

echo ${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTB}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASB} -groupBy Strategy -mode v

if [ ${MODE} == 'run' ] 
	then
	echo ${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTB}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASB} -groupBy Strategy -mode v >> ${LOGFILE}
	${ROOTDIR}/PosReportAlphaNew.py -baseDirA ${DIRROOT}/${INPUTA} -baseDirB ${DIRROOT}/${INPUTB} -baseOut ${DIRROOT}/PosOut/${OUTPUTB}/${VERSION} -f ${FROM} -t ${TO} -alphaFile ${ALPHASB} -groupBy Strategy -mode v	
	
	ShowStatus PosAlphaPeriod1B
fi

}


if [ "$EXECUTE" == "AB" ] 
		then
			echo "Executing AB"
			Period1AB
		elif [ "$EXECUTE" == "A" ]
		then
			echo "Executing A"
			Period1A
		elif [ "$EXECUTE" == "B" ]
		then
			echo "Executing B"
			Period1B
		else
			echo "Incorrect Execute provided :$EXECUTE"
			echo "usage: PosAlpha.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1"
			echo "Alphas location,Output are set in script based on -e arg"

	fi


echo 'StartTime PosAlpha.bash:' $startScript
endScript=$(date -u)
echo 'EndTime PosAlpha.bash:'$endScript
