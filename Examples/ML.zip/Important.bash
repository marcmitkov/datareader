# the final backtest
cd /big/svc_wqln/ML/BacktestsV16/OutSim20150101-20191115Geoffrey/Fit-A-2019/V16
diff PortfolioExposure.csv PortfolioExposureOriginal.csv 
grep 2016-06-23 W*.txt
grep 2016-11-08 W*.txt