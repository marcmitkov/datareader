#!/bin/bash 

echo "you have provide $# argument" 
echo "arguments are $@" 
echo "usage: RunDailySim.bash  -m|--mode test|run -e|execute all" 

MODE='test'
EXECUTE='allz'

while [[ $# -gt 0 ]]
do
key="$1"
echo "Key is $key"
echo "Value is $2"
case $key in
    -m|--mode)
    MODE="$2"
    shift # past argument
    shift # past value
    ;;   
    -e|--execute)
        lowerCaseArg="${2,,}"
    EXECUTE=${lowerCaseArg}
    shift # past argument
    shift # past value
    ;;
    *)    # unknown option
    echo "unknown Argument $1"
        echo "usage: RunDailySim.bash  -m|--mode test|run -e|execute all" 
     exit
    ;;
esac
done

echo Mode is ${MODE}
echo  Execute is ${EXECUTE}

ROOTDIR='/home/lanarayan/MyProjects/ML'
LOGROOT='/big/svc_wqln/ML/Backtests'

LOGDIR=${LOGROOT}/Logs 
LOGFILE=${LOGDIR}/RunDailySim-$(date '+%d%m%Y-%H:%M:%S').txt; 

function GenerateData {
    #Generate daily data for StratA
    echo ${ROOTDIR}/ResampleLive1Daily.bash
    if [ ${MODE} == 'run' ]
    then
      echo ${ROOTDIR}/ResampleLive1Daily.bash >> ${LOGFILE}
      ${ROOTDIR}/ResampleLive1Daily.bash
      if [ $? -eq 0 ]; 
            then
                    echo PASS ResampleLive1Daily
                    echo PASS ResampleLive1Daily >> ${LOGFILE}
            else 
                    echo FAIL ResampleLive1Daily
                    echo FAIL ResampleLive1Daily >> ${LOGFILE}
            fi
    fi
# Remove duplicates generated after Resampling and concatenating
echo ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live -removeDups
if [ ${MODE} == 'run' ]
then
echo ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live -removeDups >>${LOGFILE}

  ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live -removeDups
  if [ $? -eq 0 ]; 
          then
                  echo PASS RemoveDataDuplicates
                  echo PASS RemoveDataDuplicates >> ${LOGFILE}
          else 
                  echo FAIL RemoveDataDuplicates
                  echo FAIL RemoveDataDuplicates >> ${LOGFILE}
          fi
fi

echo ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/FX/Live -removeDups
if [ ${MODE} == 'run' ]
then
echo ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/FX/Live -removeDups >>${LOGFILE}

  ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/FX/Live -removeDups
  if [ $? -eq 0 ]; 
          then
                  echo PASS RemoveDataDuplicates
                  echo PASS RemoveDataDuplicates >> ${LOGFILE}
          else 
                  echo FAIL RemoveDataDuplicates
                  echo FAIL RemoveDataDuplicates >> ${LOGFILE}
          fi
fi

#Generate daily data for StratB
echo ${ROOTDIR}/AlignLiveDaily.bash
if [ ${MODE} == 'run' ]
then
  echo ${ROOTDIR}/AlignLiveDaily.bash >> ${LOGFILE}
  ${ROOTDIR}/AlignLiveDaily.bash
  if [ $? -eq 0 ]; 
          then
                  echo PASS AlignLiveDaily
                  echo PASS AlignLiveDaily >> ${LOGFILE}
          else 
                  echo FAIL AlignLiveDaily
                  echo FAIL AlignLiveDaily >> ${LOGFILE}
          fi
fi

#Optional: just checking for dups
#${ROOTDIR}/RemoveDataDuplicates.py -strategy B -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live



}

function RunTestSimulator {
    # Run Combinator, RunAlpha and Test Simulator for daily data
    echo ${ROOTDIR}/RunADaily.bash  -e all
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/RunADaily.bash  -e all >> ${LOGFILE}
       ${ROOTDIR}/RunADaily.bash  -e all
      if [ $? -eq 0 ]; 
              then
                      echo PASS RunADaily
                      echo PASS RunADaily >> ${LOGFILE}
              else 
                      echo FAIL RunADaily
                      echo FAIL RunADaily >> ${LOGFILE}
              fi
    fi

    echo ${ROOTDIR}/RunBDaily.bash  -e all
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/RunBDaily.bash  -e all >> ${LOGFILE}
         ${ROOTDIR}/RunBDaily.bash  -e all
      if [ $? -eq 0 ]; 
              then
                      echo PASS RunBDaily
                      echo PASS RunBDaily >> ${LOGFILE}
              else 
                      echo FAIL RunBDaily
                      echo FAIL RunBDaily >> ${LOGFILE}
              fi
    fi

}


# Date generation for GraphSim and PosReportAlpha

FROM=$(date --date='1 day ago' '+%Y%m%d')
TO=$(date '+%Y%m%d')

DAYOFWEEK=$(date '+%A')
echo $DAYOFWEEK

if [ ${DAYOFWEEK} == 'Monday' ]
then
  echo 'itis' ${DAYOFWEEK}
  FROM=$(date --date='3 day ago' '+%Y%m%d')
 fi
 
echo For GraphSim From: $FROM
echo For GraphSim To:$TO

function RunGraphSim {
    echo ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e AB
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e AB >> ${LOGFILE}
      ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e AB
      if [ $? -eq 0 ]; 
              then
                      echo PASS GraphSim
                      echo PASS GraphSim >> ${LOGFILE}
              else 
                      echo FAIL GraphSim
                      echo FAIL GraphSim >> ${LOGFILE}
              fi
    fi

}

function RunGraphSimA {
    echo ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e A
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e A >> ${LOGFILE}
      ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e A
      if [ $? -eq 0 ]; 
              then
                      echo PASS GraphSimA
                      echo PASS GraphSimA >> ${LOGFILE}
              else 
                      echo FAIL GraphSimA
                      echo FAIL GraphSimA >> ${LOGFILE}
              fi
    fi

}


function RunGraphSimB {
    echo ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e B
   
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e B >> ${LOGFILE}
      ${ROOTDIR}/GraphSimDaily.bash -f ${FROM} -t ${TO} -v V1 -e B
      if [ $? -eq 0 ]; 
              then
                      echo PASS GraphSimB
                      echo PASS GraphSimB >> ${LOGFILE}
              else 
                      echo FAIL GraphSimB
                      echo FAIL GraphSimB >> ${LOGFILE}
              fi
    fi

}

function RunPosAlphaA {
echo ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e A

if [ ${MODE} == 'run' ] 
        then
        echo ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e A >> ${LOGFILE}
        ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e A 
        if [ $? -eq 0 ];
        then
                echo PASS RunPosAlphaA
                echo PASS RunPosAlphaA >> ${LOGFILE} 
        else
                echo FAIL RunPosAlphaA 
                echo FAIL RunPosAlphaA >> ${LOGFILE}
        fi
fi
}


function RunPosAlphaB {

echo ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e B

if [ ${MODE} == 'run' ] 
        then
        echo ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e B >> ${LOGFILE}
        ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e B 
        if [ $? -eq 0 ]; 
        then
                echo PASS RunPosAlphaB
                echo PASS RunPosAlphaB >> ${LOGFILE} 
        else
                echo FAIL RunPosAlphaB 
                echo FAIL RunPosAlphaB >> ${LOGFILE}
        fi
fi
}
function RunPosAlphaAB {
echo ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e AB

if [ ${MODE} == 'run' ] 
        then
        echo ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e AB >> ${LOGFILE}
        ${ROOTDIR}/PosAlphaDaily.bash -f ${FROM} -t ${TO} -v V1 -e AB        
        if [ $? -eq 0 ]; 
        then
                echo PASS RunPosAlphaAB
                echo PASS RunPosAlphaAB >> ${LOGFILE} 
        else
                echo FAIL RunPosAlphaAB 
                echo FAIL RunPosAlphaAB >> ${LOGFILE}
        fi
fi
}



if [ "$EXECUTE" == "all" ] 
then
        echo "Executing all in mode " ${MODE}
        GenerateData
        RunTestSimulator
        RunGraphSim
        RunGraphSimA
        RunGraphSimB
        RunPosAlphaA
        #RunPosAlphaB
        #RunPosAlphaAB
  elif [ "$EXECUTE" == "data" ]
  then
	echo "Executing GenerateData in mode" ${MODE} 
        GenerateData
  elif [ "$EXECUTE" == "testsim" ]
  then
	echo "Executing RunTestSimulator in mode" ${MODE} 
	RunTestSimulator	
  elif [ "$EXECUTE" == "simab" ]
  then
	echo "Executing RunGraphSim in mode" ${MODE} 
                        RunGraphSim
  elif [ "$EXECUTE" == "sima" ]
  then
	echo "Executing RunGraphSimA in mode" ${MODE} 
                        RunGraphSimA
  elif [ "$EXECUTE" == "simb" ]
  then
        echo "Executing RunGraphSimB in mode" ${MODE} 
                        RunGraphSimB
  elif [ "$EXECUTE" == "pos" ]
  then
	echo "Executing PosAlpha A,B and AB in mode" ${MODE} 
	RunPosAlphaA
	RunPosAlphaB
	RunPosAlphaAB
   else
	echo "Invalid Execute option"
   fi


OUTPUTFILE='/home/lanarayan/cronOutput2.txt' 
#grep  "FAIL" $OUTPUTFILE

if grep -q "FAIL" $OUTPUTFILE
then
echo "send mail"

mail -s 'Daily Evening Cron failed' lanarayan@worldquant.com < $OUTPUTFILE
fi
#Run GraphSim and PosReportAlpha (e.g for running on 03/19)
#./GraphSimDaily.bash -f 20190318 -t 20190319 -v V1 -e AB
#PosReportAlphaNew.py -baseDirA /home/lanarayan/MLData/Backtests/Fit-A-2019 -baseDirB /home/lanarayan/MLData/Backtests/Fit-B-2014 -baseOut /home/lanarayan/MLData/PosOutTest3/ -f 20190318 -t 20190319 -alphaFile /big/svc_wqln/ML/Backtests/AlphaList/V1/alphasAB.txt -groupBy Strategy -mode v

