# run sim for strat A and strat B
#/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests/SimPeriod1 -baseDirB /big/svc_wqln/ML/Backtests/SimPeriod1 -f 20180824 -t 20190111 -alphas /big/svc_wqln/ML/Backtests/SimPeriod1/alphasAB.txt -wt /big/svc_wqln/ML/Backtests/SimPeriod1/weightsAB.txt -baseOut /big/svc_wqln/ML/Backtests/OutSimPeriod1/AB -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
# run sim for strat A
#/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests/SimPeriod1 -f 20180824 -t 20190111 -alphas /big/svc_wqln/ML/Backtests/SimPeriod1/alphasA.txt -wt /big/svc_wqln/ML/Backtests/SimPeriod1/weightsA.txt -baseOut /big/svc_wqln/ML/Backtests/OutSimPeriod1/A -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
#/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests/StratA2019 -f 20180301 -t 20190110 -alphas /big/svc_wqln/ML/Backtests/StratA2019/alphasA.txt -wt /big/svc_wqln/ML/Backtests/StratA2019/weightsA.txt -baseOut /big/svc_wqln/ML/Backtests/OutSimPeriod1/A -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

# run sim for strat B
#/home/lanarayan/MyProjects/ML/Sim.py -baseDirB /big/svc_wqln/ML/Backtests/SimPeriod1 -f 20180824 -t 20190111 -alphas /big/svc_wqln/ML/Backtests/SimPeriod1/alphasB.txt -wt /big/svc_wqln/ML/Backtests/SimPeriod1/weightsB.txt -baseOut /big/svc_wqln/ML/Backtests/OutSimPeriod1/B -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
#/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests/StratB2019 -f 20180301 -t 20190110 -alphas /big/svc_wqln/ML/Backtests/StratB2019/alphasB.txt -wt /big/svc_wqln/ML/Backtests/StratA2019/weightsB.txt -baseOut /big/svc_wqln/ML/Backtests/OutSimPeriod1/B -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

# graph PnL series from single file
#./perf_calc.py -t -iA OutSimPeriod1/AB
#./perf_calc.py -t -iA OutSimPeriod1/A
#./perf_calc.py -t -iA OutSimPeriod1/B
# graph PnL series from 2 files (strat a sim and strat b sim)
#./perf_calc.py -iA OutSimPeriod1/A -iB OutSimPeriod1/B
#INPUT=Fit-B-2014
#OUTPUT=Fit-B-2014
#ALPHAS=/big/svc_wqln/ML/Backtests/AlphaList/V1/alphasB.txt
#WEIGHTS=/big/svc_wqln/ML/Backtests//AlphaList/V1/weightsB.txt

#Common Params
FROM=20180824
TO=20190124
VERSION=V1

INPUT=Fit-A-2019
OUTPUT=Fit-A-2019
#ALPHAS=/big/svc_wqln/ML/Backtests/AlphaList/V0/alphasA.txt
#WEIGHTS=/big/svc_wqln/ML/Backtests//AlphaList/V0/weightsA.txt
ALPHAS=/big/svc_wqln/ML/Backtests/AlphaList/${VERSION}/alphasA.txt
WEIGHTS=/big/svc_wqln/ML/Backtests//AlphaList/${VERSION}/weightsA.txt

INPUTB=Fit-B-2014
OUTPUTB=Fit-B-2014
ALPHASB=/big/svc_wqln/ML/Backtests/AlphaList/${VERSION}/alphasB.txt
WEIGHTSB=/big/svc_wqln/ML/Backtests//AlphaList/${VERSION}/weightsB.txt
#ALPHASB=/big/svc_wqln/ML/Backtests/AlphaList/V1/alphasB.txt
#WEIGHTSB=/big/svc_wqln/ML/Backtests//AlphaList/V1/weightsB.txt



function Period1A
{
echo /home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests/${INPUT} -f ${FROM} -t ${TO} -alphas ${ALPHAS}  -wt ${WEIGHTS} -baseOut /big/svc_wqln/ML/Backtests/OutSim/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
  /home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/Backtests/${INPUT} -f ${FROM} -t ${TO} -alphas ${ALPHAS}  -wt ${WEIGHTS} -baseOut /big/svc_wqln/ML/Backtests/OutSim/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

echo ./perf_calc.py -t -iA OutSim/${OUTPUT}/${VERSION}
 ./perf_calc.py -t -iA OutSim/${OUTPUT}/${VERSION}

echo ./perf_calc.py -ae -iA OutSim/${OUTPUT}/${VERSION} -alpha ${ALPHAS}
 ./perf_calc.py -ae -iA OutSim/${OUTPUT}/${VERSION} -alpha ${ALPHAS}

}
function Period1B
{
echo /home/lanarayan/MyProjects/ML/Sim.py -baseDirB /big/svc_wqln/ML/Backtests/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB}  -wt ${WEIGHTSB} -baseOut /big/svc_wqln/ML/Backtests/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
    /home/lanarayan/MyProjects/ML/Sim.py -baseDirB /big/svc_wqln/ML/Backtests/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB}  -wt ${WEIGHTSB} -baseOut /big/svc_wqln/ML/Backtests/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

echo ./perf_calc.py -t -iA OutSim/${OUTPUTB}/${VERSION}
     ./perf_calc.py -t -iA OutSim/${OUTPUTB}/${VERSION}

echo ./perf_calc.py -ae -iA OutSim/${OUTPUTB}/${VERSION} -alpha ${ALPHASB}
  ./perf_calc.py -ae -iA OutSim/${OUTPUTB}/${VERSION} -alpha ${ALPHASB}
}

#function Bhaskar
#{
  #PortfolioExposure.csv (Bhaskar)
  #./perf_calc.py -t -iA Prod -noHeader
#}

#Bhaskar
#Period1A
Period1B
