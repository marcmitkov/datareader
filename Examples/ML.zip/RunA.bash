#!/bin/bash 
#./RunAMaster.bash -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H 4H 1D 15m'

#test

./RunAMaster.bash -f 20150101 -t 20190930 -a 'ES' -q '1H ' -v V8 -i 10 -x '/home/lanarayan/MLData/UATDev/TestSimulator/build' | grep EXEDIR


./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'ES' -q '1H ' -i 12 -x '/home/lanarayan/MLData/UATDev/TestSimulator/build' -v V10


# version 11 

./RunAMaster.bash -f 20150101 -t 20190930 -a 'ES' -q '1H ' -i 12 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -v V11 -s '2,8'  -d '21.75' |  grep START


# ran good on Oct 19 PnL  1,188,875
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'ES' -q '1H' -i 12 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -v V11 -s '2,8'  -d '21.75'



#Version  7  runs started on Oct 19, 2019
#wqropsapi009  -  Oct 19, 2019 5:15 pm SGT  (just after  Sat reboot)
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V7 -i 10 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#wqropsapi009 Oct 19, 2019 5:19 pm SGT  (after  Sat reboot)
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO' -q '15m' -v V7 -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#pxssecwqln001 Oct 19, 2019 5:31 pm SGT 
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TY AUL GC TN FV TU' -q '15m' -v V7 -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#pxssecwqln001Oct 19, 2019 5:31 pm SGT 
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD' -q '15m' -v V7 -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# start on pxssecwqln001  Oct 21 712am IST
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCAD' -q '15m' -v V7 -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCHF JY' -q '15m' -v V7 -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'

# after 1H finishes start on wqropsapi009  Oct 21 712am IST
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'AUDUSD' -q '15m' -v V7 -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# after 15m finishes i 151; Started this at Oct 20 11:19 pm EST WS4 terminal V7-15m-i157
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'URO' -q '15m' -v V7 -i 157 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'



#Version  8  runs started on Oct 21, 2019
#wqropsapi009  -  Oct 21
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V8 -i 10 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#wqropsapi009 
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO' -q '15m' -v V8 -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#pxssecwqln001 running AUL at 720  ist
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TY AUL GC TN FV TU' -q '15m' -v V8 -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#pxssecwqln001 running USDJPY at 720  ist
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD' -q '15m' -v V8 -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# start on pxssecwqln001  started on Aug 22 8:25 pm
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCAD' -q '15m' -v V8 -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# start on pxssecwqln001  started on Aug 22 10:10 pm
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCHF' -q '15m' -v V8 -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'

# after 1H finishes start on wqropsapi009 
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'AUDUSD' -q '15m' -v V8 -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# 
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'URO' -q '15m' -v V8 -i 157 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'

./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'JY' -q '15m' -v V8 -i 158 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'

V9  

./RunAMaster.bash -f 20150101 -t 20190930 -a 'ES' -q '1H ' -i 12 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -v V10 -c '0'  -o '0' |  grep CLOSEPASSIVE
./RunAMaster.bash -f 20150101 -t 20190930 -a 'ES' -q '1H ' -i 12 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -v V10 -c '0'  -o '0' |  grep OPENPASSIVE

#wqropsapi009  -  Oct 24 strated at 5:30 pm IST
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V9 -i 10 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#wqropsapi009 -  Oct 24 strated at 5:30 pm IST
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO' -q '15m' -v V9 -c '0' -o '0' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'

#pxssecwqln001 Oct 24 strated at 10:30 pm IST
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TY AUL GC TN FV TU' -q '15m' -v V9 -c '0' -o '0' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
#pxssecwqln001 Oct 24 strated at 10:30 pm IST
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD' -q '15m' -v V9 -c '0' -o '0' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'

# start on pxssecwqln001  ran Oct 26 Dubai 8am
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCAD' -q '15m' -v V9 -c '0' -o '0' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# start on pxssecwqln001  pending ran Oct 26 Dubai 8am
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCHF' -q '15m' -v V9 -c '0' -o '0' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'

# started on Wqr 1:13 am Oct 26 US EST, again on 11:17 am oct 26
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'AUDUSD' -q '15m' -v V9 -c '0' -o '0' -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# Started on wqr 12 noon Oct 26
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'URO' -q '15m' -v V9 -c '0' -o '0' -i 157 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'
# Started on wqr 12 noon Oct 26
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'JY' -q '15m' -v V9 -c '0' -o '0' -i 158 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '21.75'


Note: also started V8 158 on Oct 26 12 noon

V10

#wqropsapi009  -  Oct 31 strated at 11:30 am SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V10 -i 10 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V10 -i 10 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO' -q '15m' -v V10 -c '0' -o '0' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#pxssecwqln001 Nov 1 started at 12:22 pm SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TY AUL GC TN FV TU' -q '15m' -v V10 -c '0' -o '0' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#pxssecwqln001 Nov 1 started at 17:34 pm SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'GC TN FV TU' -q '15m' -v V10 -c '0' -o '0' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#pxssecwqln001 Nov 1 started at 17:34 pm SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V10 -i 11 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


#  Banku please run on wqrops - started at 11:50 am Saturday Nov 2
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD' -q '15m' -v V10 -c '0' -o '0' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

# started at 11:50 am Saturday Nov 2 on wqr
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCAD USDCHF AUDUSD URO JY' -q '15m' -v V10 -c '0' -o '0' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


Sample PosReport Location
file:///big/svc_wqln/ML/BacktestsV10/Fit-A-2019/TY/1H/positionsCombo.html

V11
#1H  Futures -y to copy tuples Running on wqr - started Nov 4 8:30
./RunAMaster.bash -e all -f 20150101 -t 20190930 -y 1 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V11 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
#1H  FX
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V11 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m Futures
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM CL LCO' -q '15m' -v V11 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

## Running on pxs Nov 4 8 am
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TY AUL GC TN FV TU'  -q '15m' -v V11 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m FX
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD' -q '15m' -v V11 -c '0' -o '1' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCAD USDCHF AUDUSD URO JY' -q '15m' -v V11 -c '0' -o '1' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


#Terminal crash wqrops restarting Nov 5 8:47 pm
#1H  Futures -y to copy tuples Running on wqr - restarting Nov 5 8:47 pm
./RunAMaster.bash -e all -f 20150101 -t 20190930 -y 1 -a 'TN FV' -q '1H' -v V11 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#1H  
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'JY TU' -q '1H' -v V11 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m Futures
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'NQ 1YM CL LCO' -q '15m' -v V11 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


# could have started on wqrops after 1H was done (10 and 11)  but 151 was running

#starrted on wqrops 
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'JY' -q '15m' -v V11 -c '0' -o '1' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#starrted on wqrops
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'GBPUSD' -q '15m' -v V11 -c '0' -o '1' -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#started at pxssec after interrupting 154
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TU' -q '15m' -v V11 -c '0' -o '1' -i 157 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#started at WQR - currently running (pxs running 153 and 157)
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'LCO' -q '15m' -v V11 -c '0' -o '1' -i 158 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'CL' -q '15m' -v V11 -c '0' -o '1' -i 159 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


V12  
#1H  Futures -y to copy tuples Running on wqr started 1pm Nov 7 SGT DST aware  done by 3 pm Nov 8
./RunAMaster.bash -e all -f 20150101 -t 20190930 -y 1 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V12 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
#1H  FX  finished 9am SGT Nov 8
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V12 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m Futures
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM' -q '15m' -v V12 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TY AUL GC TN'  -q '15m' -v V12 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'CL LCO FV TU'  -q '15m' -v V12 -c '0' -o '1' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m FX
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD ' -q '15m' -v V12 -c '0' -o '1' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCAD USDCHF AUDUSD URO' -q '15m' -v V12 -c '0' -o '1' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'GBPUSD JY' -q '15m' -v V12 -c '0' -o '1' -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

Inspect positions

cd ~/MLData/BacktestsAlpha/Fit-A-2019
ls */1H/*/20191106/Momentum/*/p*

for f1 in */1H/*/20191106/Momentum/*/p*
do
cat $f1
done

grep STANDING */1H/*/20191106/Momentum/*/p* 

'ID'     'TimeStamp'     'Size'  'Avgpx'         'PnlRealized'   'PnlUnRealized'         'FillPx'        'Open'  'ClosePx'                  'CloseTimeStamp'     'Remaining'     'EntryCriteriaTypeValStrength'  'Status'        'ECStopSizeTgtSizeExpiry'                  'CloseCode'  'CloseRemaining'        'CloseFillPx'   'CloseFillTimeStamp'    'FillTimeStamp'         'ParentID'      'Key'              'ExternalKey'


V13  
#1H  Futures -y to copy tuples Running on wqr started 3:30pm Nov 8 SGT 
./RunAMaster.bash -e all -f 20150101 -t 20190930 -y 1 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V13 -i 10 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
#1H  FX  tarted 3:30pm Nov 8 SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V13 -i 11 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m Futures 152 started 3:30pm Nov 8 SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'US ES NQ 1YM' -q '15m' -v V13 -c '0' -o '0' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TY AUL GC TN'  -q '15m' -v V13 -c '0' -o '0' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'CL LCO FV TU'  -q '15m' -v V13 -c '0' -o '0' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m FX
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURJPY USDJPY EURGBP EURUSD ' -q '15m' -v V13 -c '0' -o '0' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'USDCAD USDCHF AUDUSD URO' -q '15m' -v V13 -c '0' -o '0' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#WQR
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'GBPUSD JY' -q '15m' -v V13 -c '0' -o '0' -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


#Restarting on wqr  @ 9:12 pm EST Nov 8 due to terminal crash
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'GC TN FV TU' -q '1H' -v V13 -i 10 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'URO JY' -q '1H' -v V13 -i 11 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'NQ 1YM' -q '15m' -v V13 -c '0' -o '0' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'GC TN'  -q '15m' -v V13 -c '0' -o '0' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


Restarted on Nov 9  on  pxssec after reboot  at  10:22 pm SGT

./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TN'  -q '15m' -v V13 -c '0' -o '0' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TU'  -q '15m' -v V13 -c '0' -o '0' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m FX
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'EURUSD ' -q '15m' -v V13 -c '0' -o '0' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'URO' -q '15m' -v V13 -c '0' -o '0' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'


Restarted on WQR at 10:38 pm SGT

./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'TU' -q '1H' -v V13 -i 10 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
#1H  FX  tarted 3:30pm Nov 8 SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'JY' -q '1H' -v V13 -i 11 -c '0' -o '0' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m Futures 152 started 3:30pm Nov 8 SGT
./RunAMaster.bash -e all -f 20150101 -t 20190930 -a 'NQ' -q '15m' -v V13 -c '0' -o '0' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

./RunAMaster.bash -e all -f 20150101 -t 20190930 -a '1YM' -q '15m' -v V13 -c '0' -o '0' -i 160 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

DISPLAY=:0.0 /home/lanarayan/UAT/VishnuWIP/build/DaVinci -cu 2>errors.txt




V14  Remainder
#1H  Futures -y to copy tuples Running on wqr started 1pm Nov 7 SGT DST aware  done by 3 pm Nov 8
./RunAMaster.bash -e all -f 20191001 -t 20191115 -y 1 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V14 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
#1H  FX  finished 9am SGT Nov 8
./RunAMaster.bash -e all -f 20191001 -t 20191115 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V14 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m Futures
./RunAMaster.bash -e all -f 20191001 -t 20191115 -a 'US ES NQ 1YM' -q '15m' -v V14 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20191001 -t 20191115 -a 'TY AUL GC TN'  -q '15m' -v V14 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20191001 -t 20191115 -a 'CL LCO FV TU'  -q '15m' -v V14 -c '0' -o '1' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'

#15m FX
./RunAMaster.bash -e all -f 20191001 -t 20191115 -a 'EURJPY USDJPY EURGBP EURUSD ' -q '15m' -v V14 -c '0' -o '1' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20191001 -t 20191115 -a 'USDCAD USDCHF AUDUSD URO' -q '15m' -v V14 -c '0' -o '1' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'
./RunAMaster.bash -e all -f 20191001 -t 20191115 -a 'GBPUSD JY' -q '15m' -v V14 -c '0' -o '1' -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s '2,8' -d '20.75'




V15
#1H  Futures -y to copy tuples Running on wqr started Nov 18 10:30 pm SGT
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V15 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'
#1H  FX  finished 9am SGT Nov 8
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V15 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'

#15m Futures
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'US ES NQ 1YM' -q '15m' -v V15 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'TY AUL GC TN'  -q '15m' -v V15 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'

#started 10:50 pm SGT
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'CL LCO FV TU'  -q '15m' -v V15 -c '0' -o '1' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'

#15m FX
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'EURJPY USDJPY EURGBP EURUSD ' -q '15m' -v V15 -c '0' -o '1' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'USDCAD USDCHF AUDUSD URO' -q '15m' -v V15 -c '0' -o '1' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'GBPUSD JY' -q '15m' -v V15 -c '0' -o '1' -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7 -d '20.75'



V16
#1H  Futures -y to copy tuples Running on wqr started Nov 21 11 am SGT
./RunAMaster.bash -e all -f 20191115 -t 20191229 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V16 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
#1H  FX  finished 9am SGT Nov 8
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V16 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'

#15m Futures
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'US ES NQ 1YM' -q '15m' -v V16 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'TY AUL GC TN'  -q '15m' -v V16 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'

#started 10:50 pm SGT
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'CL LCO FV TU'  -q '15m' -v V16 -c '0' -o '1' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'

#15m FX
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'EURJPY USDJPY EURGBP EURUSD ' -q '15m' -v V16 -c '0' -o '1' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'USDCAD USDCHF AUDUSD URO' -q '15m' -v V16 -c '0' -o '1' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'GBPUSD JY' -q '15m' -v V16 -c '0' -o '1' -i 156 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'


Correction

./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'AUL' -q '1H' -v V16 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'ES' -q '15m' -v V16 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'EURUSD' -q '15m' -v V16 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115 -a 'LCO' -q '1H' -v V16 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'


V17
./RunAMaster.bash -e all -f 20191115 -t 20191229 -a 'US ES NQ 1YM CL LCO TY AUL GC TN FV TU' -q '1H' -v V17 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20191115 -t 20191229 -a 'EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY' -q '1H' -v V17 -i 11 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'

./RunAMaster.bash -e all -f 20191115 -t 20191229 -a 'US ES NQ 1YM' -q '15m' -v V17 -c '0' -o '1' -i 151 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'


./RunAMaster.bash -e all -f 20191115 -t 20191229 -a 'TY AUL GC TN CL LCO FV TU EURJPY USDJPY EURGBP EURUSD USDCAD USDCHF AUDUSD URO GBPUSD JY'  -q '15m' -v V17 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'


./RunAMaster.bash -e all -f 20191115 -t 20191229 -a 'CL' -q '1H' -v V17 -i 10 -c '0' -o '1' -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'

./RunAMaster.bash -e all -f 20191115 -t 20191229 -a 'CL'  -q '15m' -v V17 -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'


#note BAD run  will need to rerun the following again! pending
VERSION=V16
./RunAMaster.bash -e all -f 20150101 -t 20191115  -a 'TY AUL GC TN'  -q '15m' -v ${VERSION} -c '0' -o '1' -i 152 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115  -a 'CL LCO FV TU '  -q '15m' -v ${VERSION} -c '0' -o '1' -i 153 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115  -a 'EURJPY USDJPY EURGBP EURUSD'  -q '15m' -v ${VERSION} -c '0' -o '1' -i 154 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'
./RunAMaster.bash -e all -f 20150101 -t 20191115  -a 'USDCAD USDCHF AUDUSD URO GBPUSD JY'  -q '15m' -v ${VERSION} -c '0' -o '1' -i 155 -x '/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build' -s 7,8 -d '20.75'






