RUN=OutSim20150101-20191115GoldReduced2
CAPITALBASE=38658600
CAPITALBASE=40000000
ALPHAFILE=alphasA.txt

#/home/lanarayan/MyProjects/ML/MonthlyProcess.bash  -m run -e all  -f 20150101 -t 20191115 -d /big/svc_wqln/ML/BacktestsV16 -a alphasA.txt -v V16 -o ${RUN} -x 1 -y 0.3 -z 0.3

# TBD: integrate  cb with perf_calc
#${RUN}OutSim20150101-20191115Wt3/Fit-A-2019/V16 -cb 41045824

#Alpha Exposure graphs:
echo /home/lanarayan/MyProjects/ML/perf_calc.py  -ae -iA /big/svc_wqln/ML/BacktestsV16/${RUN}/Fit-A-2019/V16 -out /big/svc_wqln/ML/BacktestsV16/${RUN}/Fit-A-2019/V16/Graphs -alpha /big/svc_wqln/ML/BacktestsV16/AlphaList/V16/${ALPHAFILE} -cb ${CAPITALBASE}
/home/lanarayan/MyProjects/ML/perf_calc.py  -ae -iA /big/svc_wqln/ML/BacktestsV16/${RUN}/Fit-A-2019/V16 -out /big/svc_wqln/ML/BacktestsV16/${RUN}/Fit-A-2019/V16/Graphs -alpha /big/svc_wqln/ML/BacktestsV16/AlphaList/V16/${ALPHAFILE} -cb ${CAPITALBASE}
    
# create table with following columns:
# alpha name, PnL (Sum from 1YM_15m_params-0.csv), link to the Sim file(1YM_15m_params-0.csv, Weighted_1YM_15m_params-0.txt and UnWtd_1YM_15m_params-0.txt), link to the Graphs from perf_calc -ae
# total for portfolio line  (PortfolioExposure.csv),, link to the Graphs from perf_calc -pe
/home/lanarayan/MyProjects/ML/perf_calc.py -pe -iA /big/svc_wqln/ML/BacktestsV16/${RUN}/Fit-A-2019/V16 -cb ${CAPITALBASE}
echo /home/lanarayan/MyProjects/ML/MonthlyProcess.py -alphas /home/lanarayan/MLData/BacktestsV16/AlphaList/V16/${ALPHAFILE}  -simDir /home/lanarayan/MLData/BacktestsV16/${RUN}/Fit-A-2019/V16 -baseOut /home/lanarayan/MLData/BacktestsV16/MonthlyProcess -aeGraphDir /home/lanarayan/MLData/BacktestsV16/${RUN}/Fit-A-2019/V16/Graphs
/home/lanarayan/MyProjects/ML/MonthlyProcess.py -alphas /home/lanarayan/MLData/BacktestsV16/AlphaList/V16/${ALPHAFILE}  -simDir /home/lanarayan/MLData/BacktestsV16/${RUN}/Fit-A-2019/V16 -baseOut /home/lanarayan/MLData/BacktestsV16/MonthlyProcess//${RUN} -aeGraphDir /home/lanarayan/MLData/BacktestsV16/${RUN}/Fit-A-2019/V16/Graphs
google-chrome /home/lanarayan/MLData/BacktestsV16/MonthlyProcess/${RUN}/MonthlyReport.html
