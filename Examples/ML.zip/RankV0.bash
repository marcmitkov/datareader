#!/bin/bash 

startScript=$(date -u) 

BACKTESTS=BacktestsV17
#FROM=20150101
FROM=20191115
TO=20201231
TCFACTORA=0
#GENERATEALPHAS=0
GENERATEALPHAS=1
VALIDATE=''
#VALIDATE='-validate'

if [ "$GENERATEALPHAS" == "1" ]; then
  mkdir -p /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/

  cp /big/svc_wqln/ML/Backtests/AlphaList/V0/weightsA.txt /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0

  cd ~/MLData/${BACKTESTS}/Fit-A-2019
  ls -d ./*/15m/par* > /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA15m.txt 
  ls -d ./*/1H/par* > /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA1H.txt 
  #formatting
  sed -i 's/\//,/g' /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA15m.txt
  sed -i 's/\.,//g' /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA15m.txt

  sed -i 's/\//,/g' /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA1H.txt
  sed -i 's/\.,//g' /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA1H.txt
fi
#15m
echo /home/lanarayan/MyProjects/ML/Sim.py ${VALIDATE} -baseDir /big/svc_wqln/ML/${BACKTESTS}/Fit-A-2019 -baseDirB /big/svc_wqln/ML/${BACKTESTS}/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA15m.txt -wt /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/weightsA.txt -baseOut /big/svc_wqln/ML/${BACKTESTS}/OutSimRank15m/Fit-A-2019/V0 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 1 -arA 0 -arB 0 -factorA 1 -factorB 1 -varFactorA 1 -varFactorB 1 -noappend
/home/lanarayan/MyProjects/ML/Sim.py ${VALIDATE}  -baseDir /big/svc_wqln/ML/${BACKTESTS}/Fit-A-2019 -baseDirB /big/svc_wqln/ML/${BACKTESTS}/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA15m.txt -wt /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/weightsA.txt -baseOut /big/svc_wqln/ML/${BACKTESTS}/OutSimRank15m/Fit-A-2019/V0 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 1 -arA 0 -arB 0 -factorA 1 -factorB 1 -varFactorA 1 -varFactorB 1 -noappend

#1H
echo /home/lanarayan/MyProjects/ML/Sim.py ${VALIDATE} -baseDir /big/svc_wqln/ML/${BACKTESTS}/Fit-A-2019 -baseDirB /big/svc_wqln/ML/${BACKTESTS}/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA1H.txt -wt /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/weightsA.txt -baseOut /big/svc_wqln/ML/${BACKTESTS}/OutSimRank1H/Fit-A-2019/V0 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 1 -arA 0 -arB 0 -factorA 1 -factorB  1 -varFactorA 1 -varFactorB 1 -noappend
/home/lanarayan/MyProjects/ML/Sim.py ${VALIDATE} -baseDir /big/svc_wqln/ML/${BACKTESTS}/Fit-A-2019 -baseDirB /big/svc_wqln/ML/${BACKTESTS}/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA1H.txt -wt /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/weightsA.txt -baseOut /big/svc_wqln/ML/${BACKTESTS}/OutSimRank1H/Fit-A-2019/V0 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 1 -arA 0 -arB 0 -factorA 1 -factorB  1 -varFactorA 1 -varFactorB 1 -noappend

#4H
#/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/${BACKTESTS}/Fit-A-2019 -baseDirB /big/svc_wqln/ML/${BACKTESTS}/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA4H.txt -wt /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/weightsA.txt -baseOut /big/svc_wqln/ML/${BACKTESTS}/OutSimRank4H/Fit-A-2019/V0 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 1 -varFactorA 1 -varFactorB 1 -noappend

#1D
#/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/${BACKTESTS}/Fit-A-2019 -baseDirB /big/svc_wqln/ML/${BACKTESTS}/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/alphasA1D.txt -wt /big/svc_wqln/ML/${BACKTESTS}/AlphaList/V0/weightsA.txt -baseOut /big/svc_wqln/ML/${BACKTESTS}/OutSimRank1D/Fit-A-2019/V0 -sliceFactor 0 -sliceDate 20160301 -tcFactorA ${TCFACTORA} -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 1 -varFactorA 1 -varFactorB 1 -noappend


echo 'StartTime RankV0.bash:' $startScript
endScript=$(date -u)
echo 'EndTime RankV0.bash:'$endScript