#!/big/svc_wqln/projects/python/conda/bin/python3.6
#https://stackoverflow.com/questions/12393858/xpath-using-contains-with-a-wildcard
#https://stackoverflow.com/questions/12612648/python-element-tree-is-removing-the-xml-declaration
#
####################### Sample Commands#############################################
#-alpha C:/MyProjects/PyCharmProjects/HelloWorldProj/selectedAlphas2.txt -baseConfig C:/MyProjects/PyCharmProjects/HelloWorldProj -log C:/MyProjects/PyCharmProjects/HelloWorldProj
#-alpha /home/lanarayan/MLData/BacktestsV6/OutSim/Fit-A-2019/V6/RankedAlphas.txt -baseConfig /home/lanarayan/UAT/VishnuWIP/build -OutDataDir /home/lanarayan/

###############Params Description:##################################
#-alphas: alphas file read. This should have a Selected column with value 1 for selected alphas. Suffix column
    # with  suffix that is currently in params.xm prod file
#-baseConfig: location from where ConfigLive.xml and params.xml are read for modification
# -OutDataDir: location for output of new paramsOut.xml and ConfigOut.xml

########################## NOTES ######################
#1. Any new nodes required or changed will be done by this script for ConfigLive.xml
#2.For params.xml if asset ie <Key> does not exist at all , it will need to be added manually. Check log for message
# "Error::item not found in params.xml (Add Manually)" to find which ones need to be added. If key exists and another frequency needs to be
# added , script will clone existing key and change nodes required
#3. For BacktestAlpha paramsPROD.xml Run ReplaceText.py on paramsOut.xml for suffix changes and exchange changes

#### FOR BACKTESTALPHA ############
#CBOT_ to CME_
#HOTSPOT  to FXOTC
#CMEFX to CME
#NYMEX to CME
#COMEX to CME
# U9 to U7, V9 to U7, Z9 to U7
import pandas as pd
import argparse
import xml.etree.ElementTree as et
import shutil
import os
from datetime import datetime,timedelta
import logging
import copy

exchangeMap = {"1YM": "CBOT", "ES": "CME", "FV": "CBOT", "NQ": "CME", "TN": "CME", "TU": "CBOT", "TY": "CBOT", "US": "CBOT",
                    "AUL": "CBOT","CL": "NYMEX", "LCO": "CME", "JY": "CMEFX", "URO": "CMEFX", "GC": "COMEX",
                   "AUDUSD": "HOTSPOT", "EURGBP": "HOTSPOT", "EURJPY":"HOTSPOT", "EURUSD": "HOTSPOT", "GBPUSD": "HOTSPOT",
                   "USDCAD": "HOTSPOT", "USDCHF": "HOTSPOT", "USDJPY": "HOTSPOT",  "UN":"XXX"}

exchangeMapBT = {"1YM": "CME", "ES": "CME", "FV": "CME", "NQ": "CME", "TN": "CME", "TU": "CME", "TY": "CME", "US": "CME",
                    "AUL": "CME","CL": "CME", "LCO": "CME", "JY": "CME", "URO": "CME", "GC": "CME",
                   "AUDUSD": "FXOTC", "EURGBP": "FXOTC", "EURJPY":"FXOTC", "EURUSD": "FXOTC", "GBPUSD": "FXOTC",
                   "USDCAD": "FXOTC", "USDCHF": "FXOTC", "USDJPY": "FXOTC",  "UN":"XXX"}


currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD", "USDCHF", "USDJPY"]

StrategyBMap = {'Keynes': ['CME_TUU7', 'CME_USU7'], 'Buffet': ['CME_ESU7', 'CME_1YMU7'],
                    'Smith': ['CME_ESU7', 'CME_NQU7'],
                    'Nash': ['CME_TYU7', 'CME_USU7'], 'Friedman': ['CME_TUU7', 'CME_TYU7'],
                    'Hayek': ['CME_FVU7', 'CME_TYU7'],
                    'Marx': ['CME_FVU7', 'CME_USU7'], 'Tinbergen': [], 'Kondratiev': ['CME_CLU7', 'CME_LCOU7'],
                    'Bernanke': ['CME_TNU7', 'CME_AULU7']}
def add_XMLheaders(xml_file):
    print("Adding xml headers to : ",xml_file)
    logging.debug("Adding xml headers to : {} ".format(xml_file))
    #xml_file = os.path.join(outpath, "params.xml")
    tree = et.parse(xml_file)

    root = tree.getroot()
    xml_str = et.tostring(root,short_empty_elements=False).decode()
    #print(xml_str)

    xml_strNew = '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><!DOCTYPE boost_serialization>' + xml_str
    xml_strNew
    fh = open(xml_file, 'w')
    fh.write(xml_strNew)
    fh.close()

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-alphas', '--alphas', default='/home/lanarayan/MLData/Futures/BacktestV4', help="base input Directory")

    parser.add_argument('-baseConfig', '--baseConfig', default='/home/lanarayan/MLData/Futures/BacktestV4', help="base input Directory")
    parser.add_argument('-OutDataDir', '--OutDataDir', default='/home/lanarayan/MLData/Futures/BacktestV4', help="Output Directory")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    if not os.path.exists(args.logPath):
        print("Creating log folder :" + args.logPath)
        os.makedirs(args.logPath)

    logging.basicConfig(filename=os.path.join(args.logPath,'MonthlyDeploy-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')



    # Read selected alphas - put in map e.g selectedMap["GC"] = ["'1H","15m"]
    # exchangMap["GC"] = COMEX
    # suffixMap["GC"] = "U9"

    #dfSelectedAlphas = pd.read_csv(os.path.join(args.alphas, "SelectedAlphas.txt"))
    dfAllAlphas = pd.read_csv(args.alphas)
    #dfSelectedAlphas = pd.read_csv(args.alphas)
    # get all alphas that have 1 in Selected Column
    dfSelectedAlphas = dfAllAlphas[dfAllAlphas.Selected == 1]
    selectedMap = {} # map of asset and frequencies list e.g GC: [1H,15m]

    suffixMap = {} # map of asset and  current suffix GC: V9
    suffixNewMap = {}
    for index, row in dfSelectedAlphas.iterrows():
        alpha = row["Alpha"] # GC_1H_params-0
        alphaSplit = alpha.split('_') #e.g [GC, 1H, params-0]
        asset = alphaSplit[0] # GC
        freq = alphaSplit[1] # 1H
        if asset in selectedMap:
            if freq not in selectedMap[asset]:
                selectedMap[asset].append(freq)
            else:
                print("Warning:: frequency ", freq, "already selected for: ",asset)
                logging.debug("Warning:: frequency {} already selected for:{} ".format(freq,asset))

        else:
            selectedMap[asset] = [freq]
            #exchangeMap[asset] = row["exchange"]
            if asset in currencyList:
                suffixMap[asset] = ""
                #suffixNewMap[asset] = ""
            else:
                suffixMap[asset] = row["Suffix"]
                #suffixNewMap[asset] = row["SuffixNew"]

    # Read configLive
    print("Read config file from :", args.baseConfig)
    logging.debug("Read config file from : {} ".format(args.baseConfig))

    cfg_file = os.path.join(args.baseConfig, "configLive.xml")

    tree = et.parse(cfg_file)
    root = tree.getroot()

    # Form xml key - iterate selectedMap and form key e.g: COMEX_GCU9 , HOTSPOT_EUR_USD
    exKeysuffix =[] #list of xmlKeyToSearch used later for emptying frequency nodes of keys not in selected alphas
    for key, val in selectedMap.items():
        xmlKeyToSearch =  exchangeMap[key] + "_" + key + suffixMap[key] # e.gCOMEX_GCU9
        if key in currencyList:
            xmlKeyToSearch = exchangeMap[key] + "_" + key[:3] + '_' + key[3:]  # e.g HOTSPOT_EUR_USD

        frequencies = ",".join([str(x) for x in val]) # 1H,15m
        exKeysuffix.append(xmlKeyToSearch)

        # Update Frequency Node if xml node exists else add node
        for elem in root.iter("Instruments"):
            node = elem.find(xmlKeyToSearch)
            if node == None:
                print(xmlKeyToSearch , " not found in ConfigLive. Adding node: ", xmlKeyToSearch)
                logging.debug("{} not found in ConfigLive. Adding node: {} ".format( xmlKeyToSearch,xmlKeyToSearch))
                xmlNodeEl = et.Element(xmlKeyToSearch)
                elem.insert(0, xmlNodeEl)
                print("Adding frequencies ", frequencies, " for new node ", xmlKeyToSearch, " in ConfigLive: ")
                logging.debug("Adding frequencies {} for new node {} in ConfigLive".format( frequencies,  xmlKeyToSearch))
                xmlNodeFreqEl = et.Element("Frequencies")
                xmlNodeEl.insert(0,xmlNodeFreqEl)
                xmlNodeFreqEl.text=frequencies
                #if key not in currencyList:
                    #xmlNodeEl.tag = xmlKeyToSearch[:-2] + suffixNewMap[key]

            else:
                for el in node.iter("Frequencies"):
                    print("Adding frequencies ", frequencies, " for existing node ", xmlKeyToSearch ," in ConfigLive: ")
                    logging.debug("Adding frequencies {} for existing node {} in ConfigLive".format(frequencies, xmlKeyToSearch))

                    #print(el)
                    el.text=frequencies
                    #if key not in currencyList:
                        #node.tag=xmlKeyToSearch[:-2] + suffixNewMap[key]

    # If asset in ConfigLive but not in selected alphas set Frequency to empty
    for item in root.findall("./Instruments"):
        #print(item.tag)
        for child in item:
            #print(child.tag, "::",child.text)
            if child.tag in StrategyBMap:
                print("Skipping StratB alpha: ",child.tag)
                logging.debug("Skipping StratB alpha {} ".format(child.tag))
                continue
            if child.tag not in exKeysuffix:
                print("Set null Frequency for key in ConfigLive but not in selected alpha list: ", child.tag)
                logging.debug("Set null Frequency for key in ConfigLive but not in selected alpha list {} ".format(child.tag))

                xmlNodeFreqEl = child.find("Frequencies")
                xmlNodeFreqEl.text = ""
    tree.write(os.path.join(args.baseConfig, 'ConfigOut.xml'),encoding="utf-8", xml_declaration=True, short_empty_elements=False)

    # Begin Processing for params.xml
    print("Read params file from :", args.baseConfig)
    logging.debug("Read params file from {}".format(args.baseConfig))

    params_file = os.path.join(args.baseConfig, "params.xml")

    # param fields for resetting from selected alphas csv
    #paramList=["HoldingPeriod","ModeA", "Start", "Contracts"]
    paramList = ["HoldingPeriod", "ModeA", "Start"]
    tree = et.parse(params_file)
    root = tree.getroot()

    for index, row in dfSelectedAlphas.iterrows():
        alpha = row["Alpha"] #e.g GC_1H_params-0
        alphaSplit = alpha.split('_') #e.g [GC, 1H, params-0]
        asset = alphaSplit[0] #GC
        freq = alphaSplit[1] #1H
        xmlKeyToSearch = exchangeMap[asset] + "_" + asset + suffixMap[asset] # e.g COMEX_GCU9
        if asset in currencyList:
            xmlKeyToSearch = exchangeMap[asset] + "_" + asset[:3] + '_' + asset[3:]  # e.g HOTSPOT_EUR_USD

        print("params.xml search key and frequency:", xmlKeyToSearch, ": " , freq)
        logging.debug("params.xml search key and frequency {} : {}".format( xmlKeyToSearch , freq))
        #for item in root.findall(".//item[Key='COMEX_GCZ9']" ):
        findKey = root.findall(".//item[Key='" + xmlKeyToSearch + "']")
        #Wildcard serach not working -findKey = root.findall(".//item/Key[starts-with('COMEX_GC')]")
        if len(findKey) == 0:
            print("Error::item not found in params.xml (Add Manually): ", xmlKeyToSearch)
            logging.debug("Error::item not found in params.xml (Add Manually){} ".format( xmlKeyToSearch))
            continue

        # If xmlKeyToSearch found check if selected alpha frequency exists for found xmlKeyToSearch elements
        selectedFreqFound = 0
        for item in root.findall(".//item[Key='" + xmlKeyToSearch + "']"):
            freqEl = item.find("Frequency")

            if freqEl.text == freq:
                print("Frequency match found  for  ", xmlKeyToSearch, " Frequency: ", freqEl.text)
                logging.debug("Frequency match found  for {} Frequency {}".format( xmlKeyToSearch, freqEl.text))
                selectedFreqFound =1
                for child in item:
                    print("child:value ", child.tag, child.text)
                    '''if child.tag == "Symbol":
                        print("Symbol ",child.text)
                        child.text = str("")
                        print("Symbol ", child.text)'''
                    if child.tag in paramList:
                        print("For Key:Frequency ", xmlKeyToSearch, ":", freq, " Setting value ", row[child.tag], " for ", child.tag)
                        logging.debug("For Key:Frequency : {} : {} ,Setting value  {} for {}".format(xmlKeyToSearch, freq,row[child.tag], child.tag))
                        child.text = str(row[child.tag])

        # If  selected alpha frequency does not exist in existing xmlKeyToSearch elements, then clone node and set frequency and
        # other params from paramList
        if selectedFreqFound == 0:
            print("Error::params.xml - frequency value ", freq, "not found for: ", xmlKeyToSearch)
            print("Duplicating ", xmlKeyToSearch, " for frequency: ", freq)
            logging.debug("Error::params.xml - frequency value {} not found for: {}".format(freq, xmlKeyToSearch))
            logging.debug("Duplicating {} for frequency:: ".format( xmlKeyToSearch, freq))
            rootNode =root.find("./npVector/m_npVector")
            countNode = rootNode.find("count")
            currentCount = int(countNode.text)
            print("Current Count :",countNode.text, "Insert clone and increment count")
            logging.debug("Current Count : {} .Insert clone and increment count".format(countNode.text ))
            countNode.text = str(int(countNode.text) + 1)
            dupe = copy.deepcopy(findKey[0])  # copy <c> node
            for child in dupe:
                print("clone child:value is ", child.tag, ":", child.text)
                logging.debug("clone child:value is {} : {} ".format(child.tag, child.text))
                if child.tag =="Frequency":
                    print("resetting clone child ", child.tag, " to", freq)
                    logging.debug("resetting clone child {} to {} ".format( child.tag, freq))
                    child.text = freq
                if child.tag in paramList:
                    print("resetting clone child ", child.tag, " to", row[child.tag])
                    logging.debug("resetting clone child {} to {}".format( child.tag, row[child.tag]))
                    child.text = str(row[child.tag])
                '''if child.tag == "Symbol":
                    print("Symbol ", child.text)
                    child.text = str("")
                    print("Symbol ", child.text)'''
            #print("Inserting clone child ")
            rootNode.insert(currentCount + 1,dupe)

    paramsOutFile = os.path.join(args.baseConfig, 'paramsOut.xml')
    print("Writing params.xml file to ",paramsOutFile)
    logging.debug("Writing params.xml file to {} ".format(paramsOutFile))
    tree.write(paramsOutFile,encoding="utf-8", xml_declaration=False,  short_empty_elements=False)

    add_XMLheaders(paramsOutFile)
        #for node in root.findall("./npVector/m_npVector"):
            #for item in node.findall("item"):
                #Key = item.find('Key').text
                #print("Key: ", Key)'''

if __name__ == '__main__':
    main()

