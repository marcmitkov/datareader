#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import argparse
import xml.etree.ElementTree as et
import shutil
import os
from datetime import datetime,timedelta
import logging
import copy


def custom_rating(genre):
     z = genre['Alpha'].replace('_', ',')
     return z

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-version', '--version', default='V16',
                        help="version")
    parser.add_argument('-run', '--run', default='20150101-20191115',
                        help="run")
    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MyProjects/Ranks/V16',
                        help="base Prod Directory")
    parser.add_argument('-rankFiles', '--rankFiles',
                        default=["RankedAlphas_20150101-20191115_1H.csv", "RankedAlphas_20150101-20191115_15m.csv"], help="rankFiles files ",
                        nargs='*')

    
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    if not os.path.exists(args.logPath):
        print("Creating log folder :" + args.logPath)
        os.makedirs(args.logPath)

    logging.basicConfig(filename=os.path.join(args.logPath,'AlphaSelection-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    #Read the csv file
    # select all rows from df with selected=1
    #Alpha column only create a df
    #remove _ with ,
    #save as alphasA.txt

    #rankFileList = []
    

    # cd ~/MLData/BacktestsV16/OutSimRank1H/Fit-A-2019/V0
    # cp RankedAlphas_20150101-20191115.csv /home/lanarayan/MyProjects/Ranks/V16/RankedAlphas_20150101-20191115_15m.csv
    # cd ~/MLData/BacktestsV16/OutSimRank15m/Fit-A-2019/V0
    # cp RankedAlphas_20150101-20191115.csv /home/lanarayan/MyProjects/Ranks/V16/RankedAlphas_20150101-20191115_1H.csv
    # manual:  insert selected and suffix columns and populate appropriately
    # to get latest active contract: lanarayan@wqropsapi009:~/MLData/BacktestsV16/Fit-A-2019/LCO/1H$] tail LCO.csv
    
    # creates the alphalist from selelected columns  input: rankFiles
    rankFileList = args.rankFiles

    dfTotal = pd.DataFrame()

    for file in rankFileList:
        rankFile = os.path.join(args.baseDir,file)
        print('Rank file: ', rankFile)
        df = pd.read_csv(rankFile)
        dfSelected = df[df.Selected == 1]
        dfTotal = dfTotal.append(dfSelected)

    dfTotal.to_csv(os.path.join(args.baseDir,'Selected' +args.version + '.csv'),index=False)

    dfTotal["Alpha"] = dfTotal["Alpha"].str.replace("_", ",")
    alphas = dfTotal['Alpha']
    #alphas = alphas.apply(lambda x: x['Alpha'].replace('_',','),axis=1)
    alphas.to_csv(os.path.join(args.baseDir,'alphasA.txt'), index=False, sep=' ')
    
    # copy alphalist to following location
    #~/MLData/BacktestsV16/AlphaList/V16$] ls
    #backtestDir =args.baseBacktes
    src = os.path.join(args.baseDir,'alphasA.txt')
    dest = os.path.join('/home/lanarayan/MLData/Backtests' +args.version + '/AlphaList',args.version,'alphasA.txt')
    print('src: ',src)
    print('dest: ', dest)
    shutil.copy(src, dest)
    # alphasA.txt  weightsA.txt
    print("READY to run MonthlyProcess:  Sim, VaR, perf_calc") 

if __name__ == '__main__':
    main()

