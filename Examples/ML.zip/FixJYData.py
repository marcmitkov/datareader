#!/big/svc_wqln/projects/python/conda/bin/python3.6
#  Fixes for JY Data and positions
#  Price Fields are:["LSTP", "INTF", "INTH", "INTL", "LSTB", "LSTA", "HBID", "LBID", "HASK", "LASK"]
#
#


import pandas as pd
import argparse
import os
from datetime import datetime,timedelta
import logging
from decimal import getcontext, Decimal

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-baseDataDir', '--baseDataDir', default='/home/lanarayan/MLData/Futures/Live', help="base input Directory")
    parser.add_argument('-OutDataDir', '--OutDataDir', default='/home/lanarayan/MLData/JYDataTest', help="Output Directory")
    #arg fileList e.g:  -fileList 1D_resample.csv 4H_resample.csv
    parser.add_argument('-fileList', '--fileList', default=['1D_resample.csv', '4H_resample.csv', '1H_resample.csv','15m_resample.csv'], help="file location input series a",
                        nargs='*')
    parser.add_argument('-basePosDir', '--basePosDir', default='/home/lanarayan/MLData/BacktestsV4/Fit-A-2019',
                        help="base input Directory")
    parser.add_argument('-OutPosDir', '--OutPosDir', default='/home/lanarayan/MLData/BacktestsV4',
                        help="Output Directory")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath,'FixJYData-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    args.baseDataDir = os.path.abspath(args.baseDataDir)
    args.OutDataDir = os.path.abspath(args.OutDataDir)
    if not os.path.exists(args.OutDataDir):
        print("Creating output folder :" + args.OutDataDir)
        os.makedirs(args.OutDataDir)

    print("Base Data path:" + args.baseDataDir)
    print("Output Data path:" + args.OutDataDir)

    args.basePosDir = os.path.abspath(args.basePosDir)
    args.OutPosDir = os.path.abspath(args.OutPosDir)
    if not os.path.exists(args.OutPosDir):
        print("Creating output folder :" + args.OutPosDir)
        os.makedirs(args.OutPosDir)
    print("Base Pos path:" + args.basePosDir)

    assetList = ['JY']
    posFileList = ['positions.txt','openpositions.txt','standingpositions.txt']
    # List of columns in JY Futures data that need to be processed
    priceDataColList = ["LSTP", "INTF", "INTH", "INTL", "LSTB", "LSTA", "HBID", "LBID", "HASK", "LASK"]
    posDataColList = ["Avgpx", "ClosePx"]
    posColList = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp', 'ParentID', 'Key',
                'ExternalKey']

    '''for item in assetList:
        for dirpath, dirnames, filenames in os.walk(os.path.join(args.baseDataDir, item)):

            for file in filenames:
                if "live" in file or "intraday" in file or "~" in file:
                    print("Skipping file :" , file)
                    logging.debug("Skipping file {}".format(file))
                    continue;
                dataFile = os.path.join(dirpath,file)
                print("Reading file :", dataFile)
                logging.debug("Reading file {}".format(dataFile))
                df = pd.read_csv(dataFile,index_col=False)
                df['D'] = pd.to_datetime(df['D'])
                #print(df.head())

                for colname, values in df.iteritems():
                    if colname in priceDataColList:
                        print("Processing column: ", colname)
                        logging.debug("Processing column {}".format(colname))
                        mask = df['D']  < pd.to_datetime("2017-10-16")
                        #df.loc[mask, colname] = round(df[colname] / 1000000, 7)
                        #print(getcontext().prec)
                        #getcontext().prec = 7
                        df.loc[mask,colname] = df[colname].apply(lambda x: Decimal(x))
                        df.loc[mask, colname] = df[colname] / (1000000)
                        #print(df.head())


                print('Writing Processed data to:', os.path.join(args.OutDataDir, item, file))
                logging.debug("Writing Processed data to: {}".format(os.path.join(args.OutDataDir, item, file)))
                # dfFX.to_csv(os.path.join(args.OutDataDir,fxitem,"1D_resample.csv"),index=False)
                df.to_csv(os.path.join(args.OutDataDir,  file), index=False)'''

    for item in assetList:
        for dirpath, dirnames, filenames in os.walk(os.path.join(args.basePosDir, item)):
            for posfile in filenames:
                if posfile in posFileList:
                    print("Reading file :", os.path.join(dirpath, posfile))
                    logging.debug("Reading file {}".format(os.path.join(dirpath, posfile)))
                    df = pd.read_csv(os.path.join(dirpath, posfile), names=posColList, index_col=False)
                    dfmask = pd.DataFrame()
                    if len(df) > 0:
                        df['TimeStamp'] = pd.to_datetime(df['TimeStamp'])
                        for colname, values in df.iteritems():
                            if colname in posDataColList:
                                print("Processing column: ", colname)
                                logging.debug("Processing column {}".format(colname))
                                print(" old :", df[colname])
                                mask = df['TimeStamp'] < pd.to_datetime("2017-10-16")
                                dfmask= df[mask]
                                df.loc[mask, colname] = df[colname].apply(lambda x: Decimal(x))
                                df.loc[mask, colname] = df[colname] / (1000000)

                                print("new :", df[colname])
                        if len(dfmask) > 0:
                            tmpPath = dirpath.replace('BacktestsV4','JYPosTest')
                            if not os.path.exists(tmpPath):
                                print("Creating  folder :" + tmpPath)
                                os.makedirs(tmpPath)
                            #dirpath = tmpPath
                            df.to_csv(os.path.join(tmpPath, posfile), index=False)
                        else:
                            print('zzz')

                        '''print("Avgpx old :" ,df.Avgpx)
                        mask = df['TimeStamp'] < pd.to_datetime("2017-10-16")
                        df.loc[mask, Avgpx] = df[colname].apply(lambda x: Decimal(x))
                        df.loc[df.TimeStamp < pd.to_datetime("2017-10-16"), 'Avgpx'] = round(df.Avgpx / 1000000,4 )
                        df.loc[df.TimeStamp < pd.to_datetime("2017-10-16"), 'ClosePx'] = round(df.ClosePx / 1000000,4)
                        print("Avgpx new :", df.Avgpx)
                        tmpPath = dirpath.replace('JYPosTest')
                        if not os.path.exists(tmpPath):
                            print("Creating  folder :" + tmpPath)
                            os.makedirs(tmpPath)
                        dirpath = tmpPath
                        df.to_csv(os.path.join(dirpath, posfile), index=False)'''

    print("All processing done")

if __name__ == '__main__':
     main()