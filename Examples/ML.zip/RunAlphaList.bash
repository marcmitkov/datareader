#!/bin/bash
# Script to run TestSimulator for selected alphas
ROOT=/home/lanarayan/MyProjects/ML
BASE_DIR_A=/home/lanarayan/MLData/Backtests/StratANew
BASE_DIR_B=/home/lanarayan/MLData/Backtests/StratBNew

#Out dir for setup; in and out dir for RunSimulator
BASEOUTDIR=/home/lanarayan/MLData/
ALPHAFILE=/home/lanarayan/MLData/Backtests/alphasAB.txt

DATADIR=/home/lanarayan/MLData #base dir for data 1D_resample.csv etc
START=20140101
END=20190101
EXSIM=/home/lanarayan/MLDATA/UATDev/Vishnu/build

#Copies params.xml and config.xml from base StratA and B folders for consumption by RunSimulator.py
echo ${ROOT}/RunSimulatorSetup.py -baseDirA ${BASE_DIR_A} -baseDirB ${BASE_DIR_B} -baseOut ${BASEOUTDIR} -alpha ${ALPHAFILE}
${ROOT}/RunSimulatorSetup.py -baseDirA ${BASE_DIR_A} -baseDirB ${BASE_DIR_B} -baseOut ${BASEOUTDIR} -alpha ${ALPHAFILE}
if [ $? -eq 0 ]
then
        echo "PASS RunSimulatorSetup" 
else
        echo "FAIL $? RunSimulatorSetup"
        echo ${ROOT}/RunSimulatorSetup.py -baseDirA ${BASE_DIR_A} -baseDirB ${BASE_DIR_B} -baseOut ${BASEOUTDIR} -alpha ${ALPHAFILE}
        exit 1
fi

# paramsDir is input and output dir
echo ${ROOT}/RunSimulator.py -paramsDir ${BASEOUTDIR} -alpha ${ALPHAFILE} -s ${START} -e ${END} -baseDataDir ${DATADIR} -ex ${EXSIM}
${ROOT}/RunSimulator.py -paramsDir ${BASEOUTDIR} -alpha ${ALPHAFILE} -s ${START} -e ${END} -baseDataDir ${DATADIR} -ex ${EXSIM}
if [ $? -eq 0 ]
then
        echo "PASS RunSimulator" 
else
        echo "FAIL $? RunSimulator"
        echo ${ROOT}/RunSimulator.py -paramsDir ${BASEOUTDIR} -alpha ${ALPHAFILE} -s ${START} -e ${END} -baseDataDir ${DATADIR} -ex ${EXSIM}
        exit 1
fi