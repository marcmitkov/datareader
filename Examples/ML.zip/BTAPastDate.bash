#!/bin/bash 

#script for running BacktesrtAlpha 
###### NOTES FOR RunAlphaListDailySim.py################################
# NOTE: -useDates needs to be added to command if running  RunAlphaListDailySim.py for past date. -s and -e params will be relevant and used for data creation. e.g BTA.bash  -f 20191223 -u 1
# Running for today DONOT provide -useDates. When -useDates NOT provided -s and -t are ignored as CreateDailyDataFile method is used by RunAlphaListDailySim.py e.g BTA.bash  -f 20191223 -u 0

### For PAST DATE ######
#For RunAlphaListDailySim.py provide next day as -s and -e e.g: To create 20191223 folder -s 20191224 and -e 20191224
#Sim.py and PosReportAlphaNew.py will take as -f and -t  folder created i.e 20191223
#Sim.py will read 20191223 but PE.csv will show line for 20191224


echo "usage: BTA.bash  -f|from 20190101 -u 0|1"

FROM=20191223 #date for which folder is to be created in /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019/<Asset>/<Freq>/params-0 folder

USEDATES=0


while [[ $# -gt 0 ]]
do
key="$1"
echo "Key is $key"
echo "Value is $2"
case $key in
    -f|--from)
    FROM="$2"
    shift # past argument
    shift # past value
    ;;
    -u|--usedates)
    USEDATES="$2"
    shift # past argument
    shift # past value
    ;; 
    *)    # unknown option
    echo "unknown Argument $1"
        echo "usage: BTA.bash  -f|from 20190101 -u 0|1"
 
    ;;
esac
done

TO=${FROM}

NEXTDAY= date -d  "$TO next day" +%Y%m%d
echo $NEXTDAY

echo USEDATES     = "${USEDATES}"

if [ "${USEDATES}" == "1" ]
then
  echo "Using past dates"
  USEDATES=-useDates
   echo NEXTDAY =  ${NEXTDAY}

  
else 

  echo "Running BTA for today. -s and -e ignored in RunAlphaListDailySim.py"
  FROM=$(date --date='1 day ago' '+%Y%m%d')
  TO=${FROM}
  
fi

echo FROM  = "${FROM}"
echo TO    = "${TO}"
echo USEDATES = ${USEDATES}




echo /home/lanarayan/MyProjects/ML/RunAlphaListDailySim.py -paramsDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseOutDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -alpha /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -ex /home/lanarayan/MLData/UATDev/TestSimulatorWIP/build -baseDataDir /home/lanarayan/MLData -masterParams /home/lanarayan/MyProjects/ML/paramsPROD.xml -configSrcDir /home/lanarayan/MyProjects/ML/Configs -s ${NEXTDAY} -e ${NEXTDAY} -daily -test ${USEDATES}

echo /home/lanarayan/MyProjects/ML/RunAlphaListDailySim.py -paramsDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseOutDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -alpha /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -ex /home/lanarayan/MLData/UATDev/TestSimulatorWIP/build -baseDataDir /home/lanarayan/MLData -masterParams /home/lanarayan/MyProjects/ML/paramsPROD.xml -configSrcDir /home/lanarayan/MyProjects/ML/Configs -s ${NEXTDAY} -e ${NEXTDAY} -daily -test ${USEDATES}
/home/lanarayan/MyProjects/ML/RunAlphaListDailySim.py -paramsDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseOutDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -alpha /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -ex /home/lanarayan/MLData/UATDev/TestSimulatorWIP/build -baseDataDir /home/lanarayan/MLData -masterParams /home/lanarayan/MyProjects/ML/paramsPROD.xml -configSrcDir /home/lanarayan/MyProjects/ML/Configs -s ${NEXTDAY} -e ${NEXTDAY} -daily -test ${USEDATES}

echo /home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -wt /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/weightsA.txt -baseOut /big/svc_wqln/ML/BacktestsAlpha/OutSim/Fit-A-2019/V8 -sliceFactor 0 -sliceDate 20160301 -tcFactorA 0 -tcFactorB 10 -arA 0 -arB 0 -factorA 0.4 -factorB 0.1 -varFactorA 0.4 -varFactorB 1 -backtestAlpha -unrealizedpnl

echo /home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -wt /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/weightsA.txt -baseOut /big/svc_wqln/ML/BacktestsAlpha/OutSim/Fit-A-2019/V8 -sliceFactor 0 -sliceDate 20160301 -tcFactorA 0 -tcFactorB 10 -arA 0 -arB 0 -factorA 0.4 -factorB 0.1 -varFactorA 0.4 -varFactorB 1 -backtestAlpha -unrealizedpnl
/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -wt /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/weightsA.txt -baseOut /big/svc_wqln/ML/BacktestsAlpha/OutSim/Fit-A-2019/V8 -sliceFactor 0 -sliceDate 20160301 -tcFactorA 0 -tcFactorB 10 -arA 0 -arB 0 -factorA 0.4 -factorB 0.1 -varFactorA 0.4 -varFactorB 1 -backtestAlpha -unrealizedpnl

echo /home/lanarayan/MyProjects/ML/PosReportAlphaNew.py -baseDirA /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -baseOut /big/svc_wqln/ML/BacktestsAlpha/PosOut/Fit-A-2019/V8 -f ${FROM} -t ${TO} -alphaFile /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -groupBy Strategy -mode v
echo /home/lanarayan/MyProjects/ML/PosReportAlphaNew.py -baseDirA /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -baseOut /big/svc_wqln/ML/BacktestsAlpha/PosOut/Fit-A-2019/V8 -f ${FROM} -t ${TO} -alphaFile /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -groupBy Strategy -mode v
/home/lanarayan/MyProjects/ML/PosReportAlphaNew.py -baseDirA /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -baseOut /big/svc_wqln/ML/BacktestsAlpha/PosOut/Fit-A-2019/V8 -f ${FROM} -t ${TO} -alphaFile /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -groupBy Strategy -mode v



if [ "${USEDATES}" == "1" ]
then
  echo "Used past dates"
  USEDATES=-useDates

  echo FROM  = "${FROM}"
  echo TO    = "${TO}"
  echo NEXTDAY =  ${NEXTDAY}
  echo USEDATES = ${USEDATES}

else 

  echo "Ran BTA for today. -s and -e ignored in RunAlphaListDailySim.py"
  FROM=$(date --date='1 day ago' '+%Y%m%d')
  TO=${FROM}
  echo FROM  = "${FROM}"
  echo TO    = "${TO}"
fi
