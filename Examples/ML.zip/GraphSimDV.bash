#!/bin/bash 
# -b  to run function Test
startScript=$(date -u) 
echo "you have provided $# argument" 
echo "arguments are $@" 
echo "usage: GraphSim.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1"
echo "Alphas location, Weights location ,Input,Output are set in script based on -e arg"

#P0 
#FROM=2014XXXX 
#TO=20190823

#P1 
#FROM=20180824 
#TO=20190124

# GraphSim.bash -b TestB will call below function with arg 1=TestB
# Example commandline ./GraphSim.bash -b TestB

function Test {
#Common Params 
ROOT=/home/lanarayan/MyProjects/ML
DIRROOT=/big/svc_wqln/ML/Backtests
FROM=20190210 
TO=20190212 
VERSION=V1
INPUTB=$1 
OUTPUTB=$1 
ALPHASB=${DIRROOT}/AlphaList/${VERSION}/alphasB.txt 
WEIGHTSB=${DIRROOT}/AlphaList/${VERSION}/weightsB.txt 

echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
     ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

}

#Common Params 
ROOT=/home/lanarayan/MyProjects/ML
DIRROOT=/big/svc_wqln/ML/Backtests
FROM=20190129 
#TO=20190124 
TO=20190201 
VERSION=V1
INPUT=TestUNStratA
INPUTB=TestUNStratB 

#FOR Strat A
#OUTPUT=Fit-A-2019
OUTPUT=2018AssessMarch
#ALPHAS=/big/svc_wqln/ML/Backtests/AlphaList/V0/alphasA.txt 
#WEIGHTS=/big/svc_wqln/ML/Backtests/AlphaList/V0/weightsA.txt 
ALPHAS=${DIRROOT}/AlphaList/${VERSION}/alphasA.txt 
WEIGHTS=${DIRROOT}/AlphaList/${VERSION}/weightsA.txt

#FOR Strat B
OUTPUTB=Fit-B-2014 
ALPHASB=${DIRROOT}/AlphaList/${VERSION}/alphasB.txt 
WEIGHTSB=${DIRROOT}/AlphaList/${VERSION}/weightsB.txt 

#For AB
OUTPUTAB=TestDV
ALPHASAB=${DIRROOT}/AlphaList/${VERSION}/alphasAB.txt 
WEIGHTSAB=${DIRROOT}/AlphaList/${VERSION}/weightsAB.txt 

while [[ $# -gt 0 ]]
do
key="$1"
echo "Key:$key Value:$2"
case $key in
    -f|--from)
      FROM="$2"
      shift # past argument
      shift # past value
    ;;
    -t|--to)
      TO="$2"
      shift # past argument
      shift # past value
    ;;
    -v|--version)
      uppercase=${2^^}
          #uppercase=$2|awk '{print toupper($2)}'
      VERSION=${uppercase}
    shift # past argument
    shift # past value
    ;;
	-e|--execute)
	upperCaseArg=${2^^}
	EXECUTE=${upperCaseArg}
    shift # past argument
    shift # past value
    ;;
    -b|--basedir)
    EXECUTE="TEST"
    Test $2
    shift # past argument
    shift # past value
    ;;
    *)    # unknown option
    echo "unknown Argument $1"
	echo "usage: GraphSim.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1"
   	echo "Alphas location, Weights location ,Input,Output are set in script based on -e arg"
   	exit

    ;;
esac
done

echo "Args values:"
echo FROM  = "${FROM}"
echo TO    = "${TO}"
echo VERSION  = "${VERSION}"
echo EXECUTE  = "${EXECUTE}"
#end

function ShowStatus {
if [ $? -eq 0 ]
 then
        echo PASS $1
        #echo PASS $1 >>${LOGFILE} 
 else
        echo FAIL $1 
        #echo FAIL $1 >>${LOGFILE} 
        exit 1
fi
}




function Period1AB
{
echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASAB} -wt ${WEIGHTSAB} -baseOut ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 0 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
     ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASAB} -wt ${WEIGHTSAB} -baseOut ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 0 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

      ShowStatus SimPeriod1AB
echo ./perf_calc.py -t -iA OutSim/${OUTPUTAB}/${VERSION}
	# ./perf_calc.py -t -iA OutSim/${OUTPUTAB}/${VERSION}
echo ./perf calc.py -ae -iA OutSim/${OUTPUTAB}/${VERSION} -alpha ${ALPHASAB}
	# ./perf_calc.py -ae -iA OutSim/${OUTPUTAB}/${VERSION} -alpha ${ALPHASAB}
}

function Period1A
{
echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTA} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/OutSim/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
echo    ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTA} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/OutSim/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 - tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

echo ./perf_calc.py -t -iA Outsim/${OUTPUT}/${VERSION}
#	 ./perf_calc.py -t -iA OutSim/${OUTPUT}/${VERSION}
	 
echo ./perf calc.py -ae -iA Outsim/${OUTPUT}/${VERSION} -alpha ${ALPHAS}
  # ./perf_calc.py -ae -iA Outsim/${OUTPUT}/${VERSION} -alpha ${ALPHAS}
}

function Period1B
{
echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1
     ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 2 -factorB 0.1 -varFactorA 2 -varFactorB 1

echo ./perf_calc.py -t -iA Outsim/${OUTPUTB}/${VERSION}
	 ./perf_calc.py -t -iA OutSim/${OUTPUTB}/${VERSION}
	 
echo ./perf calc.py -ae -iA Outsim/${OUTPUTB}/${VERSION} -alpha ${ALPHASB}
	 ./perf_calc.py -ae -iA Outsim/${OUTPUTB}/${VERSION} -alpha ${ALPHASB}
}

if [ "$EXECUTE" == "AB" ] 
		then
			echo "Executing AB"
			Period1AB
		elif [ "$EXECUTE" == "A" ]
		then
			echo "Executing A"
			Period1A
		elif [ "$EXECUTE" == "B" ]
		then
			echo "Executing B"
			Period1B
		elif [ "$EXECUTE" == "TEST" ]
		then
			echo "Executinged Test"    
		else
			echo "Incorrect Execute provided :$EXECUTE"
			echo "usage: GraphSim.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1"
			echo "Alphas location, Weights location ,Input,Output are set in script based on -e arg"

	fi

echo 'StartTime GraphSim.py:' $startScript
endScript=$(date -u)
echo 'EndTime GraphSim.py:'$endScript

echo tail ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION}/PortfolioExposure.csv
tail ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION}/PortfolioExposure.csv
exit 0

