#!/bin/bash

# Test url
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejs/scripts/positionServer.js start=20190318 end=20190319 base=/home/lanarayan/UAT/VishnuWIP/build/ES/1m/params-0 file=openpositions.txt"
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190319 end=20190321 file=positions.txt alpha=/home/lanarayan/MLData/alphasES.txt baseA=/home/lanarayan/UAT/VishnuWIP/build baseB=/home/lanarayan/UAT/VishnuWIP/build"
gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190319 end=20190321 file=positions.txt alpha=/home/lanarayan/MLData/alphasES.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014"

xdg-open file:///home/lanarayan/MyProjects/WQMaster/nodejsDev/PositionJQXClient.html