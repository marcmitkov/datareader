#!/big/svc_wqln/projects/python/conda/bin/python3.6

# e.g command: -strategy A -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live -removeDups
# -strategy A -baseDir /home/lanarayan/MLData/FX/Live/EURGBP -removeDups

import pandas as pd
from datetime import datetime
import argparse
import os
import logging

def main():
    parser = argparse.ArgumentParser()


    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MLData/Futures/Live', help="base Directory containing Futures and FX data")
    #parser.add_argument('-baseDir', '--baseDir', default='C:/MyProjects/Temp/Test', help="base Directory containing Futures and FX data")

    parser.add_argument('-strategy', '--strategy', default='A',
                        help="A for StratA; B for StratB")
    parser.add_argument('-removeDups', '--removeDups', action='store_true', help="Provide arg to remove duplicates")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")
    #parser.add_argument('-log', '--logPath', default='C:/MyProjects/Temp/Logs/',help="log file  path")

    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    if not os.path.exists(args.logPath):
        print("Creating log folder :" + args.logPath)
        os.makedirs(args.logPath)

    logging.basicConfig(filename=os.path.join(args.logPath,'RemoveDuplicatesLog-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    colnames=['D','interval','SYBL','LSTP','LSTS','INTF','INTH','INTL','INTV','NTRD','LSTB','LSBS','LSTA','LSAS','HBID','LBID','HASK','LASK','HBSZ','LBSZ','HASZ','LASZ','HLTS','IVAM']

    fileArrA=['15m_100.csv','1H_100.csv','1D_100.csv','4H_100.csv','1m.csv', '1m_live.csv']
    fileArrB=['1YM.csv','FV.csv','NQ.csv','TY.csv','US.csv','CL.csv','ES.csv','LCO.csv','TU.csv']

    if args.strategy == 'A':
        for dirpath, dirnames, filenames in os.walk(args.baseDir):
            for file in filenames:
                if file.endswith("resample.csv") or file in fileArrA:

                    fileWithPath = os.path.join(dirpath,file)
                    print("Checking for duplicates:", fileWithPath)
                    logging.debug("Checking for duplicates: {}".format(fileWithPath))

                    #if file.endswith("Copy.csv"):
                     #   df = pd.read_csv(fileWithPath, names=colnames)
                    #else:
                    df = pd.read_csv(fileWithPath)
                    df['D'] = pd.to_datetime(df['D'], format='%Y-%m-%d %H:%M:%S')

                    df = df.sort_values(['D'], ascending=True)

                    if len(df[df.duplicated(['D'], keep='last')]) > 0:
                        print('duplicated ', df[df.duplicated(['D'])])
                        print('# duplicated ', len(df[df.duplicated(['D'])]))
                        logging.debug('# duplicated {}'.format(len(df[df.duplicated(['D'])])))
                        logging.debug("duplicates: {}".format(df[df.duplicated(['D'])]))
                        #logging.debug("Before: {}".format(df.head()))
                        if args.removeDups:
                            logging.debug("Removing duplicates: {}".format(fileWithPath))
                            df = df.drop_duplicates(subset=['D'])
                            #print(df.head(2))
                            #logging.debug("After: {}".format(df.head()))
                            df.to_csv(fileWithPath, index=False)
                    else:
                        print("No duplicates:", fileWithPath)
                        logging.debug("No duplicates: {}".format(fileWithPath))

    if args.strategy == 'B':
        for dirpath, dirnames, filenames in os.walk(args.baseDir):
                for file in filenames:
                    if file.endswith("2d.csv") or file in fileArrB:

                        fileWithPath = os.path.join(dirpath, file)
                        print("Checking for duplicates:", fileWithPath)
                        logging.debug("Checking for duplicates: {}".format(fileWithPath))


                        df = pd.read_csv(fileWithPath)
                        df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d %H:%M:%S')

                        df = df.sort_values(['date'], ascending=True)

                        if len(df[df.duplicated(['date'], keep='last')]) > 0:
                            # print('duplicated ', df[df.duplicated(['D'])])
                            print('# duplicated ', len(df[df.duplicated(['date'])]))

                            logging.debug('# duplicated {}'.format(len(df[df.duplicated(['date'])])))
                            logging.debug("duplicates: {}".format(df[df.duplicated(['date'])]))
                            # logging.debug("Before: {}".format(df.head()))

                            if args.removeDups:
                                logging.debug("Removing duplicates: {}".format(fileWithPath))
                                df = df.drop_duplicates(subset=['date'])
                                # print(df.head(2))
                                # logging.debug("After: {}".format(df.head()))
                                df.to_csv(fileWithPath, index=False)
                        else:
                            print("No duplicates:", fileWithPath)
                            logging.debug("No duplicates: {}".format(fileWithPath))


if __name__ == '__main__':
    main()