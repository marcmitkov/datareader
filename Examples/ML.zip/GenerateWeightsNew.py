#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import os

# 1. args.wtSimulation: create an alpha list for equal weights using input file with alpha tuples e,g: <EURUSD,4H,params-0> \n<USDJPY,1H,params-1>
#    used by SimulationStatistiocs.py(alphas.txt)
#2. args.wtfile: create an alpha list for equal weights using input file with alphas list e.g: EURUSD_4H,EURUSD_1H,EURUSD_1D
#   created by RankAlphasAll.py (WeightsAlphaList.csv)
#3. args.wtmanual: directory location of return_xx and position file ; create an alphaList for equal weights using the returns file names
alphas = [
    # "Smith","Hayek","Nash","Buffet","Friedman","Keynes","Marx", "Kondratiev
    "ES_1D", "ES_4H", "ES_1H",
    "NQ_1D", "NQ_4H", "NQ_1H",
    "1YM_1D", "1YM_4H", "1YM_1H",
    "CL_1D", "CL_4H", "CL_1H",
    "USDJPY_1D", "USDJPY_4H", "USDJPY_1H",
    "EURJPY_1D", "EURJPY_4H", "EURJPY_1H",
    "USDCAD_1D", "USDCAD_4H", "USDCAD_1H",
    "GBPUSD_1D", "GBPUSD_4H", "GBPUSD_1H",
    "EURUSD_1D", "EURUSD_4H", "EURUSD_1H",
    "EURGBP_1D", "EURGBP_4H", "EURGBP_1H",
    "USDCHF_1D", "USDCHF_4H", "USDCHF_1H",
    "AUDUSD_1D", "AUDUSD_4H", "AUDUSD_1H"
]

listStrategyB = ['Keynes','Buffet','Smith','Nash','Friedman','Hayek','Marx', 'Tinbergen','Kondratiev']
# n = alphas.len()
# weights= 1/n
# output to weights.txt
currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]
listStrategyA = ['ES', 'NQ', '1YM', 'CL', 'LCO', 'TY', 'FV', 'TU', 'US']
def get_arguments():
    """
    This function initializes the args to specify the inputs :
    :return: args data structure
    """
    import argparse
    parser = argparse.ArgumentParser(description="GenerateWeights  Script")
    parser.add_argument('-a', '--alphaList', default=alphas, help="file location input series a",
                        nargs='*')
    parser.add_argument('-baseOut', '--baseOutDir', default='/big/svc_wqln/ML/Backtests/', help="base output Directory")
    parser.add_argument('-f', '--startDate', default='20090101', help="from date")
    parser.add_argument('-t', '--endDate', default='20190101', help="to date")
    parser.add_argument('-wtfile', '--wtfile', default='', help="weights input file")
    parser.add_argument('-wtmanual', '--wtmanual', default='', help="directory location of return_xx and position file")
    parser.add_argument('-wtSimulation', '--wtSimulation', default='', help="file with path - containing alphas tuples.g:<EURUSD,4H,params-0>")
    parser.add_argument('-equalwt', '--equalwt', action='store_true', help="if specified assign equal weights")

    # parser.print_help()
    args = parser.parse_args()
    return args


def main():
    args = get_arguments()
    print(args)

    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)
    alphaList=[]
    if args.wtfile != "":
        dfWts = pd.read_csv(os.path.abspath(args.wtfile))
        for row in dfWts.iterrows():
            index, data = row
            alphaList =(data.tolist())
    elif args.wtmanual != "":
        # dirs = os.listdir(args.wtmanual)

         for i in os.listdir(args.wtmanual):
            if  os.path.isfile(os.path.join(args.wtmanual, i)) and 'return_' in i:
                alphaName = i.split('_')[2].split('.')[0]

                if alphaName in listStrategyB:
                    alphaList.append(i.split('_')[2].split('.')[0])
                else:
                    alphaList.append(i.split('_')[1] + '_' + i.split('_')[2].split('.')[0])
    elif args.wtSimulation != "":
        colNamesList = ['name', 'frequency', 'pname']
        dfAlphas = pd.read_csv(args.wtSimulation, names=colNamesList)
        dfAlphas['alphaName'] = dfAlphas['name'] + '_' + dfAlphas['frequency']
        alphaList = (dfAlphas['alphaName'].tolist())
    else:
        alphaList = args.alphaList

    numAlphas = len(alphaList)
    if args.equalwt:
        numAlphas = len(alphaList)
        weights = 1 / numAlphas
        colnames = ['from', 'to']
        dataList = [args.startDate, args.endDate]
        for item in alphaList:
            colnames.append(item)
            dataList.append(weights)
    else:
        colnames = ['from', 'to']
        dataList = [args.startDate, args.endDate]
        # more realistic  25 for strata futures,  2.5 for fx and 1 for stratb
        for item in alphaList:
            colnames.append(item)
            asset = item.split('_')[0]
            if asset in listStrategyA:
                dataList.append(25)
            elif asset in currencyList:
                dataList.append(2.5)
            elif asset in listStrategyB:
                dataList.append(1)

    df = pd.DataFrame(data=[dataList], columns=colnames)
    # df[:,:] = weights
    print('NumAlphas:', numAlphas)
    print(df)

    df.to_csv(os.path.join(args.baseOutDir, 'weights.txt'), index=False)


main()


