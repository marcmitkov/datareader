#!/bin/bash
/home/lanarayan/MyProjects/ML/MergeTwoDays.py
/home/lanarayan/MyProjects/ML/MergeTwoDays.py -assets Smith Buffet
