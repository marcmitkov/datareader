#!/bin/bash 
export PROMPT_COMMAND="echo - ne '1033]O; Runs Prod A SHOSTNAME $PWD\007". 
echo "you have provide $# argument" 
echo "arguments are $@" 
echo "usage: RunStratA.bash -e all|risk|pos|test -f|from 20190101 -t|to 20190202 -h|--hold 2,3,4,5"
echo "usage: RunStratA.bash -e all|risk|pos|test -f 20190101 -t 20190202 -h 2,3,4,5" 



function RunAll {
         
           #echo ${SCRIPTDIR}/RunAlphaListDailySim.py -paramsDir ${ROOT}/${RUN} -baseOutDir ${ROOT}/${RUN} -alpha ${SCRIPTDIR}/alphasA.txt -ex ${EXEDIR} -baseDataDir ${DAILYDIR} -masterParams ${MASTERPARAMS} -configSrcDir ${CONFIGSRCDIR}  -s ${FROM} -e ${TO} ${IGNORE} ${DAILY} ${USEDATES}
           #echo ${SCRIPTDIR}/RunAlphaListDailySim.py -paramsDir ${ROOT}/${RUN} -baseOutDir ${ROOT}/${RUN} -alpha ${SCRIPTDIR}/alphasA.txt -ex ${EXEDIR} -baseDataDir ${DAILYDIR} -masterParams ${MASTERPARAMS} -configSrcDir ${CONFIGSRCDIR}  -s ${FROM} -e ${TO} ${IGNORE} ${DAILY} ${USEDATES} >> ${LOGFILE}
           # ${SCRIPTDIR}/RunAlphaListDailySim.py -paramsDir ${ROOT}/${RUN} -baseOutDir ${ROOT}/${RUN} -alpha ${SCRIPTDIR}/alphasA.txt -ex ${EXEDIR} -baseDataDir ${DAILYDIR} -masterParams ${MASTERPARAMS} -configSrcDir ${CONFIGSRCDIR}  -s ${FROM} -e ${TO} ${IGNORE} ${DAILY} ${USEDATES}
           echo ${SCRIPTDIR}/RunAlphaListDailySim.py -paramsDir ${ROOT}/${RUN} -baseOutDir ${ROOT}/${RUN} -alpha ${ROOT}/AlphaList/${VERSION}/alphasA.txt -ex ${EXEDIR} -baseDataDir ${DAILYDIR} -masterParams ${MASTERPARAMS} -configSrcDir ${CONFIGSRCDIR}  -s ${FROM} -e ${TO} ${IGNORE} ${DAILY} ${USEDATES} ${GOPTION} 
           echo ${SCRIPTDIR}/RunAlphaListDailySim.py -paramsDir ${ROOT}/${RUN} -baseOutDir ${ROOT}/${RUN} -alpha ${ROOT}/AlphaList/${VERSION}/alphasA.txt -ex ${EXEDIR} -baseDataDir ${DAILYDIR} -masterParams ${MASTERPARAMS} -configSrcDir ${CONFIGSRCDIR}  -s ${FROM} -e ${TO} ${IGNORE} ${DAILY} ${USEDATES} ${GOPTION} >> ${LOGFILE}
           ${SCRIPTDIR}/RunAlphaListDailySim.py -paramsDir ${ROOT}/${RUN} -baseOutDir ${ROOT}/${RUN} -alpha ${ROOT}/AlphaList/${VERSION}/alphasA.txt -ex ${EXEDIR} -baseDataDir ${DAILYDIR} -masterParams ${MASTERPARAMS} -configSrcDir ${CONFIGSRCDIR}  -s ${FROM} -e ${TO} ${IGNORE} ${DAILY} ${USEDATES} ${GOPTION} 
          
}

        
function TestRunAll {
        echo cp ${SCRIPTDIR}/Configs/config-${INS}-${TIME}.xml config.xml 
        if [ $? -eq 0 ]; 
        then
                echo ${SCRIPTDIR}/CombinatorV3.py -r ${ROOT}/${RUN}/$INS/$TIME/ -baseDir ./ -RhoA 6 -HoldingPeriod ${HOLD} -MinLengthA 100 -CushionA ${CUSHION} -ModeA 0 -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0 
                echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -baseOutDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${INS}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinciFinal/build -baseDataDir /home/lanarayan/MLData/${DAILYDIR} -s ${FROM} -e ${TO} ${IGNORE} ${DAILY}>> ${LOGFILE}
                echo ${SCRIPTDIR}/RiskReport.py - f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/$INS/$TIME -baseOut ${ROOT}/${RUN}/$INS/$TIME -s A -c $INS -suffix $TIME -ptable 
                echo ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN} /$INS/$TIME -output ${ROOT}/${RUN}/$INS/$TIME -groupBy Strategy -s ${EXCHANGE}_${INS1} -v True
        else
                echo FAIL $INS
        fi
        }
        
startScript=$(date -u) 
SCRIPTDIR='/home/lanarayan/MyProjects/ML'

ROOT='/big/svc_wqln/ML/BacktestsAlpha' 
VERSION='V5'
echo ROOT is $ROOT
echo VERSION is $VERSION
[ -d ${ROOT} ] || echo mkdir -p ${ROOT} 
[ -d ${ROOT} ] || mkdir -p ${ROOT}

RUN="Fit-A-2019" 
MASTERPARAMS='/home/lanarayan/MyProjects/ML/paramsPROD.xml'
CONFIGSRCDIR='/home/lanarayan/MyProjects/ML/Configs'
#EXEDIR=/home/lanarayan/MLData/UATDev/DaVinciFinal/build
EXEDIR=/home/lanarayan/MLData/UATDev/DaVinciWIP/build
GOPTION=-test #appends -g to testSimulator command in RunAlphaListDailSim.py
#Used with USEDATES='-useDates'


#Dir where evening data generated.Files are taken from here for snipping
DAILYDIR="/home/lanarayan/MLData/SimDaily"

DAILY="-daily" #flag indicating daily run; for past dates setUSEDATES=-useDates along with this flag

######## PAST DATES ###############
#For past dates uncomment below 2 lines (Daily Dir for getting data files for snipping; also set from and to for data snip
DAILYDIR="/home/lanarayan/MLData/"
USEDATES="-useDates" 


FROM="20190702" 
TO="20190703"

LOGROOT='/big/svc_wqln/ML/Backtests'       
LOGDIR=${LOGROOT}/Logs
LOGFILE=${LOGDIR}/RunDailySimAlphaA-$(date '+%d%m%Y-%H:%M:%S').txt; 
echo LOGFILE is $LOGFILE
[ -d ${LOGDIR} ] || echo mkdir -p ${LOGDIR} 
[ -d ${LOGDIR} ] || mkdir -p ${LOGDIR}



#Start
while [[ $# -gt 0 ]]
do
key="$1"
echo "Key is $key"
echo "Value is $2"
case $key in
    -f|--from)
    FROM="$2"
    shift # past argument
    shift # past value
    ;;
    -t|--to)
    TO="$2"
    shift # past argument
    shift # past value
    ;;
    
        -e|--execute)
        lowerCaseArg="${2,,}"
    EXECUTE=${lowerCaseArg}
    shift # past argument
    shift # past value
    ;;
        -b|--basedir)
    EXECUTE="$2"
    shift # past argument
    shift # past value
    ;;   
    *)    # unknown option
    echo "unknown Argument $1"
        echo "usage: RunDailySimAlphaUseDates.bash -e all|risk|pos|test -f|from 20190101 -t|to 20190202 -h|--hold 2,3,4,5"
        echo "usage: RunDailySimAlphaUseDates.bash -e all|risk|pos|test -f 20190101 -t 20190202 -h 2,3,4,5"
   
    ;;
esac
done

echo ROOT = ${ROOT}
echo RUN = ${RUN}
echo FROM  = "${FROM}"
echo TO    = "${TO}"

echo EXECUTE         = "${EXECUTE}"
#end


echo SCRIPTDIR is $SCRIPTDIR
echo MASTERPARAMS is ${MASTERPARAMS}
echo CONFIGSRCDIR is ${CONFIGSRCDIR}
echo DAILYDIR is ${DAILYDIR}


 if [ "$EXECUTE" == "all" ] 
                then
                        echo "Executing RunAll"
                        RunAll
                elif [ "$EXECUTE" == "risk" ]
                then
                        echo "Executing RunRisk"
                        RunRisk
                elif [ "$EXECUTE" == "pos" ]
                then
                        echo "Executing RunPos"
                        RunPos
                elif [ "$EXECUTE" == "test" ]
                then
                        echo "Executing TestRunAll"
                        TestRunAll
                else
                        echo "Executing Default TestRunAll"
                        TestRunAll
 fi
        
echo LOGFILE : ${LOGFILE}       
echo 'StartTime:' $startScript
endScript=$(date -u)
echo 'EndTime:'$endScript
exit 0


