#!/big/svc_wqln/projects/python/conda/bin/python3.6

import pandas as pd
import argparse
import logging
import os
import shutil
import xml.etree.ElementTree as et
import Common as co
import pathlib
import webbrowser
import tempfile

StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-baseDirA', '--baseDirA', default='/home/lanarayan/MLData/Backtests/Fit-A-2019', help="base Directory")
    parser.add_argument('-baseDirB', '--baseDirB', default='/home/lanarayan/MLData/Backtests/Fit-B-2014',
                        help="base Directory")
    parser.add_argument('-strats', '--strats', default=['A', 'B'], help="file location input series a",
                        nargs='*')
    parser.add_argument('-baseOut', '--baseOut', default='/home/lanarayan/MLData/Backtests/Fit-A-2019',
                        help="base Directory")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")

    args = parser.parse_args()
    print(args)

    '''logging.basicConfig(filename=os.path.join(args.logPath, "CreateConfigsLog.log"), filemode='w',
                        level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')
'''
    args.baseOut = os.path.abspath(args.baseOut)
    if not os.path.exists(args.baseOut):
        print("Creating output folder :" + args.baseOut)
        os.makedirs(args.baseOut)

    for strat in args.strats:
        htmlStr = co.addHTMLHeadElement()+ '<Table>'
        if strat == 'A':
            baseDir = args.baseDirA
        else:
            baseDir = args.baseDirB

        for item in os.listdir(baseDir):
            if os.path.isdir(os.path.join(baseDir, item)):
                for t in ['1H', '4H', '1D', '15m', '1m']:
                    htmlFilepath = os.path.join(baseDir, item,t,'positionsCombo.html')
                    if os.path.isfile(htmlFilepath):
                        htmlStr += '<tr><td>'
                        htmlFilepath = htmlFilepath.replace('\\', '/')
                        print(htmlFilepath)
                        htmlStr += htmlFilepath.split('/')[-3] + '_ ' + htmlFilepath.split('/')[-2]
                        htmlStr += '</td>'

                        viewerPathUrl = pathlib.Path(htmlFilepath).as_uri()
                        htmlStr += '<td><a href=' + viewerPathUrl + ' target="_blank"> click' + '</a></td>'
                        htmlStr += '</tr>'

        '''for dirpath, dirnames, filenames in os.walk(baseDir):
            for dir in dirnames:
                if dir in ['1H', '4H', '1D', '15m']:
                    htmlFilepath = os.path.join(dirpath, dir, 'positionsCombo.html')
                    if os.path.isfile(htmlFilepath):
                        htmlStr += '<tr><td>'
                        dirpath = dirpath.replace('\\', '/')
                        print(dirpath)
                        htmlStr += dirpath.split('/')[-1] + '_' + dir
                        htmlStr += '</td>'


                        viewerPathUrl = pathlib.Path(htmlFilepath).as_uri()
                        htmlStr += '<td><a href=' + viewerPathUrl + ' target="_blank"> click' + '</a></td>'
                        htmlStr += '</tr>'
'''
        htmlStr += '</Table>'
        htmlStr += co.addHTMLBodyEndTag()
        print(htmlStr)
        '''with tempfile.NamedTemporaryFile('w', delete=False) as f:
            url = 'file://' + f.name +'.html'
            f.write(htmlStr)
        webbrowser.open_new_tab(url)'''
        combolHtml = os.path.join(baseDir, 'PosReportViewer' + strat + '.html')
        fCombo = open(combolHtml, 'w')
        fCombo.write(htmlStr)
        fCombo.close()
        webbrowser.open_new_tab(combolHtml)

if __name__ == '__main__':
     main()