#!/bin/bash

sd=`date -d"5 day ago" +'%Y%m%d'`
ed=`date -d"tomorrow" +'%Y%m%d'`

echo sd : $sd
echo ed: $ed

#for fut in `ls /big/svc_wqln/data/Futures`; 
for fut in AUL US
do
echo $fut
 echo /big/svc_wqln/projects/data_reader/interested_future.py -s $fut --startdate $sd --enddate $ed
 /big/svc_wqln/projects/data_reader/interested_future.py -s $fut --startdate $sd --enddate $ed
done


'''
Rolled on Nov 26  in params.xml, names.dat, configLive.xml
USH0;1087
TYH0;1087
FVH0;1087
TUH0;1087
TNH0;1087
AULH0;1087
'''
