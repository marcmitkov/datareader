#!/big/svc_wqln/projects/python/conda/bin/python3.6
# example usage:  Combinator.py  -MinLengthA 100,125 -RhoA 6.0,8.0,4.0
# this will script will generate example comandlines to invoke TestSimulator (C++ program)
# probably use https://linux.die.net/man/3/getopt  to get optional args in C++
# https://www.gnu.org/software/libc/manual/html_node/Example-of-Getopt.html
#cmd = 'TestSimulator -r /home/lanarayan/output -s "2015-1-1 17:00:00" -e  "2015-3-3
#python Combinator.py -MinLengthA 100 -RhoA 6.0,8.0

import sys
import itertools
import argparse
import os
import xml.etree.ElementTree as et
import shutil
import platform
import multiprocessing
#from multiprocessing import Pool
from functools import partial
import pandas as pd
#import snipFile as snip
import numpy as np

currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]
StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}
def get_params_input(paramsDict,fhLog,arguments):
    print("\nCreating list of input params to Combinator for modifying Master params.xml")
    fhLog.write("Creating list of input params to Combinator for modifying Master params.xml\n")
    excludeList= []
    excludeList.append('fromDate')
    excludeList.append('toDate')
    excludeList.append('env')
    excludeList.append('filePath')
    excludeList.append('exeDir')
    excludeList.append('baseDirectory')
    excludeList.append('ignoreTOD')
    excludeList.append('test')
    excludeList.append('snip')
    # excludeList.append('baseDataDir')


    fhLog.write('overridden params\n')
    for key,val  in paramsDict.items():
        #print(key, '::', val)
        #if not (key in excludeList):
            #print(key)
        if val != None and not (key in excludeList):
            arguments.append([key])
            arguments.append(val.split(','))
            fhLog.write(key + '::' + val + '\n')

    # printing the list using loop
    #for x in range(len(arguments)):
        #print (arguments[x])
    return arguments

def add_XMLheaders(outpath, fhLog):
    print("Adding xml headers to params.xml in location: ",outpath)
    fhLog.write("Adding xml headers to params.xml in location: "+ outpath + "\n")
    xml_file = os.path.join(outpath, "params.xml")
    tree = et.parse(xml_file)

    root = tree.getroot()
    xml_str = et.tostring(root).decode()
    #print(xml_str)

    xml_strNew = '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><!DOCTYPE boost_serialization>' + xml_str
    xml_strNew
    fh = open(xml_file, 'w')
    fh.write(xml_strNew)
    fh.close()

def processData():

    parser = argparse.ArgumentParser(description="Combinator")

    # NOTE: Any new arg added should be added too get_params_input methods excludelist so its not considered a param for paramsfile input
    #parser.add_argument('-baseDataDir', '--baseDataDir', default='/home/lanarayan/MLData/', help="base Directory containing Futures and FX data")

    parser.add_argument('-r', '--filePath', default='/home/lanarayan/MyProjects/WQMaster/output/',
                        help="base file path for copying config,params;")
    parser.add_argument('-baseDir', '--baseDirectory', default='/home/lanarayan/MyProjects/WQMaster/data/Positions/',
                        help="base Directory from which main config.xml and params.xml are copied")

    args, unknown = parser.parse_known_args()
    print("\nArguments - argparser:")
    print(args)

    if not os.path.exists(args.filePath):
        os.makedirs(args.filePath)

    #Get frequency and asset name from args.filepath e.g ~/MLData/Backtests/Fit-A-2019/ES/4H
    frequency = os.path.basename((args.filePath).rstrip('/'))
    asset = (args.filePath).rstrip('/').split('/')[-2]

    #location for master params and config.xml for asset
    base_path = args.baseDirectory

    print("Read config file from :", base_path)
    cfg_file = os.path.join(base_path, "config.xml")

    print("Read Master params file from :", base_path)
    xml_file = os.path.join(base_path, "params.xml")

    tree = et.parse(xml_file)
    root = tree.getroot()

    item_children = []

    for child in root:
      #print (child.tag)
      item_children = {t.tag for t in root.findall('.//item/*')}
      #item_children_list = list(item_children)
      #print(item_children_list)  #print((tag_names_list[3]))

    # Add all child elements of <item> to argument parser as these could be params supplied to combinator
    for tagname in item_children:
       arg1 = '-'+ tagname
       arg2 = '--' + tagname
       parser.add_argument(arg1,arg2)

    args, unknown = parser.parse_known_args()
    print("\nArguments3 - argparser:")
    print(args)

    fhLog = open(args.filePath + 'CombinatorLog.txt', 'w')

    #put all args/values as key/value pairs in dictionary
    dictParams = vars(args)

    #Get list of args/values supplied as Combinator args for modifying params file
    arguments = []
    arguments = get_params_input(dictParams,fhLog,arguments)

    alphadf = pd.DataFrame() #df for alpha list

    try:
        dirDict = dict()
        product =list(itertools.product(*arguments))
        #print(product[0][2])        #print(product[0][4])
        #product is  simply a list of tuples
        #<class 'tuple'>: ('ClosePassive', '1', 'ClearHistoryA', '0', 'OpenPassive', '1', 'RhoA', '6', 'MinLengthA', '100', 'HoldingPeriod', '2', 'ModeA', '1', 'CushionA', '0')
        # create  a dictionary for each tuple such as
        # ClosePassive'=> '1', 'ClearHistoryA'=> '0' .....
        # the  sort the keys anc create a compund key such as :
        # 'ClearHistoryA_0_ClosePassive_1'
        # then map the key to an integer  and stpore in a dictionary
        # ClearHistoryA_0_ClosePassive_1 => 0
        # when you look up this dictionary in a subsequent invocation for a different alpha  uniqueness of param  index will be preserved
        # persistent storage per frequency
        # for example 1H will have say 8 combinations,  while 15 m  may have just 2
        # dictionary files could be called 1H.dict  etc

        for (i,productItem) in enumerate(product):
            dirName = 'params-' + str(i)
            if dirName in dirDict:
                raise ValueError('Duplicate key :' + dirName)
            dirDict[dirName] = ""
            #add to df for alphalist generation
            alphadf=alphadf.append({'asset': asset,'frequency':frequency,'param':dirName}, ignore_index=True)

            #outdir for params.xml and config.xml for alpha( <asset.freq.param>)
            #e.g ~/MLData/Backtests/Fit-A-2019/ES/4H/params-0
            outDir = os.path.join(args.filePath, dirName)
            if not os.path.exists(outDir):
                 os.makedirs(outDir)

            zz = iter(productItem)
            # Convert list to dictionary
            b = dict(zip(zz, zz))
            #Update params file with args provided
            for key, val in b.items():
                print(key + "::" + val)
                for elem in root.iter('item'):
                    node = elem.find(key)
                    node.text = val

            print("Writing xml tree to params.xml in params-x location: ", outDir)
            fhLog.write("Writing xml tree to params.xml in location: " + outDir + "\n")
            # write xml tree to outDir e.g ~/MLData/Backtests/Fit-A-2019/ES/4H/params-0/params.xml
            tree.write(os.path.join(outDir, 'params.xml'))

            # Add headers for boost serialization to work
            add_XMLheaders(outDir, fhLog)

            #copy asset config file from to outdir
            print("Copy ", cfg_file, " to ", outDir)
            fhLog.write("Copy " + cfg_file +" to " + outDir + "\n")
            # shutil.copy(cfg_file, outDir)
            shutil.copyfile(cfg_file, os.path.join(outDir, 'config.xml'))

        alphadf.to_csv(os.path.join(args.filePath, 'alphas.txt'), index=False,header=False)
        fhLog.close()
    except IOError as e:
        print("Unable to copy file. %s" % e)
    except ValueError as e:
        print("Dir name already exists:%s" % e)
    except:
        print("Unexpected error:", sys.exc_info())

if __name__ == "__main__":
    #print("simulatorExeDir1: " +simulatorExeDir)
    processData()
   #print("simulatorExeDir2: " +simulatorExeDir)



