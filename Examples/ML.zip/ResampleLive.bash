#!/bin/bash
export PROMPT_COMMAND="echo -ne '\033]0;Resample $HOSTNAME $PWD\007'"

#FROMDATE=`date +%Y%m%d`

#echo $FROMDATE

#ASSETTYPE=Futures
OFFSET=1
BASE=/home/lanarayan/WQData
BASEOUT=/home/lanarayan/MLData
LOGFILE=${BASEOUT}/ResampleLive1.log
ROOT=/home/lanarayan/MyProjects/ML


[ -e ${LOGFILE} ] && cp ${BASEOUT}/ResampleLive1.log ${BASEOUT}/ResampleLive1_bkup.log
[ -e ${LOGFILE} ] && rm ${LOGFILE}
# temp change on June 14 to regenerate 11 -13 for FX
#for i in ES NQ 1YM CL FV TY TU US LCO TN AUL JY URO BP SF CD AD EURJPY EURUSD GBPUSD USDCAD USDJPY USDCHF EURGBP AUDUSD
for i in ES NQ 1YM CL FV TY TU US LCO TN AUL JY URO GC BP SF CD AD EURJPY EURUSD GBPUSD USDCAD USDJPY USDCHF EURGBP AUDUSD
#for i in EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF EURGBP AUDUSD
do
  if [ "$i" == "ES" ] || [ "$i" == "NQ" ] || [ "$i" == "1YM" ] || [ "$i" == "CL" ] || [ "$i" == "FV" ]|| [ "$i" == "TY" ]|| [ "$i" == "TU" ]|| [ "$i" == "US" ]|| [ "$i" == "LCO" ] || [ "$i" == "TN" ] || [ "$i" == "AUL" ] || [ "$i" == "JY" ] || [ "$i" == "URO" ] || [ "$i" == "BP" ] || [ "$i" == "SF" ] || [ "$i" == "CD" ] || [ "$i" == "AD" ] || [ "$i" == "GC" ];
  then
  ASSETTYPE=Futures
  else
  ASSETTYPE=FX
  fi
  # generate 1m data for the last 24 hrs
  cp ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live_bak.csv
  echo ${ROOT}/LiveDataFilter.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET}
  ${ROOT}/LiveDataFilter.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET}
  if [ $? -eq 0 ]
  then
	echo "PASS LiveDataFilter ${i}" 
	echo "PASS LiveDataFilter ${i}" >>${LOGFILE} 
  else
	echo "FAIL $? - ${i}"
	echo "FAIL $?  ${ROOT}/LiveDataFilter.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET}" >>${LOGFILE} 
	exit 1
	
  fi
  cp ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_liveCopy.csv
  ed "${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_liveCopy.csv" <<<$'1d\nwq\n'
  #concatenate to existing master file
  CURRENTTIME=$(date -u)
  echo "${CURRENTTIME} before copy 1m ">>${LOGFILE}
  cat  ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_liveCopy.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m1.csv
  CURRENTTIME=$(date -u)
  echo "${CURRENTTIME} after copy 1m" >>${LOGFILE}
  mv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_bak.csv
  mv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m1.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv

  # resample the last 24 hrs
  # for j in 1D 4H 1H 15m
  # removed the above on Dec 5 , 2019  to  make faster
  for j in 1H 15m
  do
        FREQ=${j}
        if [ "$j" == "15m" ]; then
                FREQ=15min
        fi
        CURRENTTIME=$(date -u)
        #make faster Dec 5, 2019       
        echo ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}
        echo "${CURRENTTIME} before resample" >>${LOGFILE} 
        echo ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ} >>${LOGFILE}    
         ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}
		if [ $? -eq 0 ]
		then
			echo "PASS Resampling ${i} ${j}" 
			echo "PASS Resampling ${i} ${j}">>${LOGFILE} 
		else
			echo "FAIL $? - ${i} ${j}"
			echo "FAIL $? ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}" >>${LOGFILE} 
			exit 1 
		fi
		if [ "$j" == "1D" ]; then
			sed -i '$ d' ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv
                
		fi
        # back up the current resample file if it exists
        # Dec 5,2019: commenting backup of xx_resample.csv
        #cp ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample_bak.csv
        # delete header from the newly resampled file
        ed "${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv" <<<$'1d\nwq\n'
        
        #Nov 13: Commenting because first line in x_live.csv (8 am candle was) getting removed
      
        #if [ "$j" != "1D" ]; then
                 #sed -i '1d' ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv
                
         #fi
        
        #concatenate to existing resample file
        CURRENTTIME=$(date -u)
        echo "${CURRENTTIME} before cat resample" >>${LOGFILE} 
        cat  ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample1.csv
        CURRENTTIME=$(date -u)
        echo "${CURRENTTIME} after cat resample" >>${LOGFILE} 
        mv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample1.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv
        # get the last 100 lines
        FILEMASTER="${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv"
        a=($(wc ${FILEMASTER}))
        LINECOUNT=${a[0]}
        echo  line count is $LINECOUNT
        # make sure lines are > 100
        if [ "${LINECOUNT}" -gt 100 ]; then
                head -1 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv
                tail -100 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv >> ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv
                # discard the last candle from _100 file because  it represents data from a partial interval due to delay in execution of the resample scripts
                # the 3 am resample for a given alpha will execute at a finite/small delay at say 3:02 am depending on the order of alphas in the scripts
                # so a 15m candle with start time 3:00 am would represent data from 3:00am - 3:02am; in Realtime this candle would be generated at 3:15 am and handled
                # so a 1H candle with start time 3:00 am would represent data from 3:00am - 3:03am; in Realtime this candle would be generated at 4:00 am and handled
                # need to make sure that the 3 am candle is generate as a part of the evening run which is a separate process  ---  Nov 10, 2019
        fi
  done

done
	
exit  0