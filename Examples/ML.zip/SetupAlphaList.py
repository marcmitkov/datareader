#!/big/svc_wqln/projects/python/conda/bin/python3.6

#Description: This script will do initial setup before RunSimulator can run. Will read alphas selected and will copy params.xml and config.xml
#  from StratA and StratB location to baseOut which will be used by the RunSimulator Script.

#1.Read alphas file into a dataframe
#2.For each alpha above:
#  a) Create required folder based on AssetName,Frequency,Params from alphas file in baseOut
#  b) Copy params.xml and config.xml from baseDirA or baseDirB into folders created in baseOut

#ARGS DESCRIPTION
#baseDirA :base StratA input Directory containing config and params.xml files to be copied to baseOut
#baseDirB: base StratB input Directory containing config and params.xml files to be copied to baseOut
#baseOut: Output Directory to create alphas folders (baseOut/<AssetName>/<Frequency>/<Param>) where config.xml and params.xml
#         will be copied.

import pandas as pd
import argparse
import os
import shutil

StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-baseDirA', '--baseDirA', default='/home/lanarayan/MLData/Backtests/StratANew', help="base StratA input Directory containing config and params.xml files")
    parser.add_argument('-baseDirB', '--baseDirB', default='/home/lanarayan/MLData/Backtests/StratBNew', help="base StratB input Directory containing config and params.xml files")
    #parser.add_argument('-baseOut', '--baseOutDir', default='/home/lanarayan/MLData/', help="Output Directory to create alphas folders")
    parser.add_argument('-baseOut', '--baseOut', default='/home/lanarayan/MLData/', help="Output Directory where params.xml and config.xml are copied from baseDirA ansd baseDirB")
    parser.add_argument('-alpha', '--alpha', default='/home/lanarayan/MLData/Backtests/alphasAB.txt', help="alphas file with location")

    args = parser.parse_args()
    print(args)
    args.baseDirA = os.path.abspath(args.baseDirA)
    args.baseDirB = os.path.abspath(args.baseDirB)

    columnNames = ['AssetName', 'Frequency', 'Param']

    if not os.path.exists(args.baseOut):
        print("Creating output folder :" + args.baseOut)
        os.makedirs(args.baseOut)

    alphaFile = os.path.abspath(args.alpha)
    dfAlphas = pd.read_csv(alphaFile, names=columnNames, index_col=False)

    # Traverse alpha list dataframe
    for index, row in dfAlphas.iterrows():
        # create folders for param and config file
        outDir = os.path.join(args.baseOut, row['AssetName'], row['Frequency'], row['Param'])
        if not os.path.exists(outDir):
            print("Creating  folder(s) :" + outDir)
            os.makedirs(outDir)

        # Determine location  of source config and params file
        if row['AssetName'] in StrategyBMap:
            sourceBase = args.baseDirB
        else:
            sourceBase = args.baseDirA

        configFile = os.path.join(sourceBase, row['AssetName'], row['Frequency'], row['Param'], "config.xml")
        paramsFile = os.path.join(sourceBase, row['AssetName'], row['Frequency'], row['Param'], "params.xml")
        print('Copying file:', configFile, ' to:', outDir)
        print('Copying file:', paramsFile, ' to:', outDir)
        # uncomment for actual run
        shutil.copyfile(configFile, os.path.join(outDir, 'config.xml'))
        shutil.copyfile(paramsFile, os.path.join(outDir, 'params.xml'))


if __name__ == '__main__':
    main()