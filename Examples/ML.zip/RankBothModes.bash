#!/bin/bash 
# -b  to run function Test
startScript=$(date -u) 
echo "you have provided $# argument" 
echo "arguments are $@" 
echo "usage: GraphSim.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1"
echo "Alphas location, Weights location ,Input,Output are set in script based on -e arg"

#P0 
#FROM=2014XXXX 
#TO=20190823

#P1 
#FROM=20180824 
#TO=20190124

# GraphSim.bash -b TestB will call below function with arg 1=TestB
# Example commandline ./GraphSim.bash -b TestB

function Test {
#Common Params 
ROOT=/home/lanarayan/MyProjects/ML
DIRROOT=/big/svc_wqln/ML/BacktestsDailySim
FROM=20190210 
TO=20190212 
VERSION=V1
INPUTB=$1 
OUTPUTB=$1 
ALPHASB=${DIRROOT}/AlphaList/${VERSION}/alphasB.txt 
WEIGHTSB=${DIRROOT}/AlphaList/${VERSION}/weightsB.txt 

echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1
     ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1

}

#Common Params
NOAPPEND="-noappend"
ENABLEGRAPH=0
ROOT=/home/lanarayan/MyProjects/ML
DIRROOT=/big/svc_wqln/ML/BacktestsBothModes
FROM=20190129 
#TO=20190124 
TO=20190201 
VERSION=V1
INPUT=Fit-A-2019
INPUTB=Fit-B-2014 

#FOR Strat A
OUTPUT=Fit-A-2019
#OUTPUT=2018AssessMarch
#OUTPUT=2019_A_March
#ALPHAS=/big/svc_wqln/ML/Backtests/AlphaList/V0/alphasA.txt 
#WEIGHTS=/big/svc_wqln/ML/Backtests/AlphaList/V0/weightsA.txt 


#FOR Strat B
OUTPUTB=Fit-B-2019
#OUTPUTB=2019_B_March


#For AB
OUTPUTAB=Fit-AB-2019

LOGDIR=${DIRROOT}/Logs 
LOGFILE=${LOGDIR}/RankBothModes-$(date '+%d%m%Y-%H:%M:%S').txt; 
echo $LOGFILE
[ -d ${LOGDIR} ] || echo mkdir -p ${LOGDIR} 
[ -d ${LOGDIR} ] || mkdir -p ${LOGDIR}

while [[ $# -gt 0 ]]
do
key="$1"
echo "Key:$key Value:$2"
case $key in
    -f|--from)
      FROM="$2"
      shift # past argument
      shift # past value
    ;;
    -t|--to)
      TO="$2"
      shift # past argument
      shift # past value
    ;;
    -g|--graph)
      ENABLEGRAPH="$2"
      shift # past argument
      shift # past value
    ;;
    -v|--version)
      uppercase=${2^^}
          #uppercase=$2|awk '{print toupper($2)}'
      VERSION=${uppercase}
    shift # past argument
    shift # past value
    ;;
	-e|--execute)
	upperCaseArg=${2^^}
	EXECUTE=${upperCaseArg}
    shift # past argument
    shift # past value
    ;;
    -b|--basedir)
    EXECUTE="TEST"
    Test $2
    shift # past argument
    shift # past value
    ;;
    *)    # unknown option
    echo "unknown Argument $1"
	echo "usage: GraphSim.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1 -g|--graph 0|1"
   	echo "Alphas location, Weights location ,Input,Output are set in script based on -e arg"
   	exit

    ;;
esac
done

echo "Args values:"
echo FROM  = "${FROM}"
echo TO    = "${TO}"
echo VERSION  = "${VERSION}"
echo EXECUTE  = "${EXECUTE}"
#end

ALPHAS=${DIRROOT}/AlphaList/${VERSION}/alphasA.txt 
WEIGHTS=${DIRROOT}/AlphaList/${VERSION}/weightsA.txt

#FOR Strat B

#OUTPUTB=2019_B_March
ALPHASB=${DIRROOT}/AlphaList/${VERSION}/alphasB.txt 
WEIGHTSB=${DIRROOT}/AlphaList/${VERSION}/weightsB.txt 

#For AB

ALPHASAB=${DIRROOT}/AlphaList/${VERSION}/alphasAB.txt 
WEIGHTSAB=${DIRROOT}/AlphaList/${VERSION}/weightsAB.txt 

function ShowStatus {
if [ $? -eq 0 ]
 then
        echo PASS $1
        #echo PASS $1 >>${LOGFILE} 
 else
        echo FAIL $1 
        #echo FAIL $1 >>${LOGFILE} 
        exit 1
fi
}




function Period1AB
{
     echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASAB} -wt ${WEIGHTSAB} -baseOut ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1
     echo  ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASAB} -wt ${WEIGHTSAB} -baseOut ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1 >> ${LOGFILE}
       ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASAB} -wt ${WEIGHTSAB} -baseOut ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1

      ShowStatus SimPeriod1AB
      
     if [ ${ENABLEGRAPH}  == 1 ]
     then
        echo ./perf_calc.py -t -iA OutSim/${OUTPUTAB}/${VERSION}
        ./perf_calc.py -t -iA OutSim/${OUTPUTAB}/${VERSION}
     fi
    #echo ./perf calc.py -ae -iA OutSim/${OUTPUTAB}/${VERSION} -alpha ${ALPHASAB}
	# ./perf_calc.py -ae -iA OutSim/${OUTPUTAB}/${VERSION} -alpha ${ALPHASAB}
}

function Period1A
{
    echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/OutSim/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 1 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1
    echo  ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/OutSim/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 1 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1 >> ${LOGFILE}
  
    ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/OutSim/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 1 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1
    if [ ${ENABLEGRAPH}  == 1 ]
    then
        echo ./perf_calc.py -t -iA Outsim/${OUTPUT}/${VERSION}
        ./perf_calc.py -t -iA OutSim/${OUTPUT}/${VERSION}
	fi 
    #echo ./perf calc.py -ae -iA Outsim/${OUTPUT}/${VERSION} -alpha ${ALPHAS}
    # ./perf_calc.py -ae -iA Outsim/${OUTPUT}/${VERSION} -alpha ${ALPHAS}
}

function Period1B
{
echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1
echo  ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1 >> ${LOGFILE}
     ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHASB} -wt ${WEIGHTSB} -baseOut ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 15 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1

    if [ ${ENABLEGRAPH}  == 1 ]
     then
        echo ./perf_calc.py -t -iA Outsim/${OUTPUTB}/${VERSION}
        ./perf_calc.py -t -iA OutSim/${OUTPUTB}/${VERSION}
	 fi
     #echo ./perf calc.py -ae -iA Outsim/${OUTPUTB}/${VERSION} -alpha ${ALPHASB}
	 #./perf_calc.py -ae -iA Outsim/${OUTPUTB}/${VERSION} -alpha ${ALPHASB}
}

if [ "$EXECUTE" == "AB" ] 
		then
			echo "Executing AB"
			Period1AB
		elif [ "$EXECUTE" == "A" ]
		then
			echo "Executing A"
			Period1A
		elif [ "$EXECUTE" == "B" ]
		then
			echo "Executing B"
			Period1B
		elif [ "$EXECUTE" == "TEST" ]
		then
			echo "Executinged Test"    
		else
			echo "Incorrect Execute provided :$EXECUTE"
			echo "usage: GraphSim.bash -e|execute AB|A|B -f|from 20190101 -t|to 20190202 -v|--version V0|V1"
			echo "Alphas location, Weights location ,Input,Output are set in script based on -e arg"

	fi

echo 'StartTime RankBothModes.bash:' $startScript
endScript=$(date -u)
echo 'EndTime RankBothModes.bash:'$endScript

if [ "$EXECUTE" == "AB" ] 
then
  echo tail ${DIRROOT}/OutSim/Fit-AB-2019/${VERSION}/PortfolioExposure.csv
  tail ${DIRROOT}/OutSim/Fit-AB-2019/${VERSION}/PortfolioExposure.csv
elif [ "$EXECUTE" == "A" ]
then
  echo tail ${DIRROOT}/OutSim/${OUTPUT}/${VERSION}/PortfolioExposure.csv
  tail ${DIRROOT}/OutSim/${OUTPUT}/${VERSION}/PortfolioExposure.csv
elif [ "$EXECUTE" == "B" ]
then
  echo tail ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION}/PortfolioExposure.csv
  tail ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION}/PortfolioExposure.csv
else

  echo "No Portfolio Exposure for argument -e " ${EXECUTE}
 fi
exit 0

