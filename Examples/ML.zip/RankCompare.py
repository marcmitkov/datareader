#!/big/svc_wqln/projects/python/conda/bin/python3.6
#https://stackoverflow.com/questions/12393858/xpath-using-contains-with-a-wildcard
#https://stackoverflow.com/questions/12612648/python-element-tree-is-removing-the-xml-declaration
#

import pandas as pd
import argparse
import os
from datetime import datetime,timedelta
import logging


def CompareRanks(dfMaster,alphas,dfOld, dfNew):
    colAlphaList = ['name', 'frequency', 'pname']
    dfAlphas = pd.read_csv(alphas, names=colAlphaList)

    for index, row in dfAlphas.iterrows():
        alpha = row['name']+ '_' + row['frequency']+ '_' + row['pname']

        #old = dfOld.loc[dfOld['Alpha'] == alpha, 'Rank']
        #new = dfNew.loc[dfNew['Alpha'] == alpha, 'Rank']
        old = dfOld.loc[dfOld['Alpha'] == alpha]
        new = dfNew.loc[dfNew['Alpha'] == alpha]

        if len(old) > 0:
            #dfMaster = dfMaster.append({'Alpha': alpha, 'RankOld': int(old.values[0]), 'RankNew': int(new.values[0])}, ignore_index=True)
            dfMaster = dfMaster.append({'Alpha': alpha, 'RankOld': old.index[0] + 1 , 'RankNew': new.index[0] + 1}, ignore_index=True)

    return  dfMaster

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-alphas', '--alphas', default='/home/lanarayan/MLData/BacktestsV4/AlphaList/V5/alphasA.txt', help="base input Directory")

    parser.add_argument('-baseDirOld', '--baseDirOld', default='/home/lanarayan/MLData/Ranks',
                        help="base  Directory for old Rank files RankNew_1H.csv")
    parser.add_argument('-baseDirNew', '--baseDirNew', default='/home/lanarayan/MyProjects/Ranks',
                        help="base  Directory for new Rank files RankNew_1H.csv")
    parser.add_argument('-baseOut', '--baseOutDir', default='/home/lanarayan/MLData/Ranks',
                        help="base Out Directory")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath,'RankCompare-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)

    dfMaster = pd.DataFrame()
    for frequency in ['15m', '1H']:
        print("Reading rank file : ","RankOld_" + frequency + ".csv")
        dfOld = pd.read_csv(os.path.join(args.baseDirOld,"RankOld_" + frequency + ".csv"))
        print("Reading rank file : ", "RankNew_" + frequency + ".csv")
        dfNew = pd.read_csv(os.path.join(args.baseDirNew,"RankNew_" + frequency +  ".csv"))

        print("Comparing files : ", "RankOld_" + frequency + ".csv and RankNew_" + frequency + ".csv")
        dfMaster = CompareRanks(dfMaster, args.alphas, dfOld, dfNew)

    #making sure columns are positioned inorder below
    dfMaster = dfMaster[['Alpha', 'RankOld','RankNew']]
    print("Output in: ", os.path.join(args.baseOutDir, "RankCompare.csv"))
    dfMaster.to_csv(os.path.join(args.baseOutDir, "RankCompare.csv"), index=False)


if __name__ == '__main__':
    main()