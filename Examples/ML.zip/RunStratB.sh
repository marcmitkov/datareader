#!/bin/bash
export PROMPT_COMMAND="echo -ne '\033]0;Runs Prod B $HOSTNAME $PWD\007'"
echo "you have provide $# argument"
echo "arguments are $@"
function Test {
	echo cp Configs/config-${SPREAD}.xml config.xml
}
function RunAll {
      
        cp Configs/config-${SPREAD}.xml config.xml

        if [ $? -eq 0 ]; then
                 #./Combinator.py  -s ${FROM} -e ${TO} -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1  -r ${ROOT}/${RUN}/${SPREAD}/$TIME/ -ex ./ -baseDir ./  -ClearHistoryA 0 
                 #./RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/${SPREAD}/$TIME -baseOut ${ROOT}/${RUN}/${SPREAD}/${TIME} -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS} -ptable
                 #./PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/$TIME -groupBy Strategy -s ${SPREADGROUPS} -v True
                 echo ./CombinatorV3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./  -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0
          #./CombinatorV3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./  -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0
          echo ./RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLDATA/UATDev/Vishnu/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO}
         ./RunAlphaList.py -paramsDir ${ROOT}/${RUN}/ -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLDATA/UATDev/Vishnu/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO}
  
               
        else
                echo FAIL $INS
        fi
}
function RunOnly {
        #cp Configs/config-${SPREAD}-${TIME}.xml config.xml
        cp Configs/config-${SPREAD}.xml config.xml
        if [ $? -eq 0 ]; then
                 ./Combinator.py  -s ${FROM} -e ${TO} -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1  -r ${ROOT}/${RUN}/${SPREAD}/$TIME/ -ex ./ -baseDir ./  -ClearHistoryA 0 
        else
                echo FAIL $INS
        fi
}
function RunRisk {
        #./RiskReport.py -f ${FROM} -t ${TO} -p /home/lanarayan/MyProjects/${RUN}/${SPREAD}/$TIME -baseOut /home/lanarayan/MyProjects/${RUN}/${SPREAD}/$TIME -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS}
        ./RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/${SPREAD}/$TIME -baseOut ${ROOT}/${RUN}/${SPREAD}/${TIME} -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS} -ptable

        if [ $? -eq 0 ]; then
                echo PASS ${SPREAD}-${TIME}
        else
                echo FAIL ${SPREAD}-${TIME}
        fi
        echo    ./RiskReport.py -f ${FROM} -t ${TO} -p /home/lanarayan/MyProjects/${RUN}/$INS/$TIME -baseOut /home/lanarayan/MyProjects/${RUN}/${SPREAD}/${TIME} -s A -c $INS -suffix $TIME

}
function RunPos {
         #INS1=${INS:0:3}_${INS:3:3}
         #./PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/$TIME -groupBy Strategy -s ${SPREADGROUPS} -v True
        ./PosReport.py -f ${FROM} -t ${TO} -baseDir /home/lanarayan/MyProjects/${RUN}/${SPREAD}/$TIME -output /home/lanarayan/MyProjects/${RUN}/${SPREAD}/$TIME -groupBy Strategy -s ${SPREADGROUPS} -v True -strategyType B
        if [ $? -eq 0 ]; then
                echo PASS ${SPREAD}-${TIME}
        else
                echo FAIL ${SPREAD}-${TIME}
        fi
}
function TestRunAll {
        #echo cp Configs/config-${SPREAD}-${TIME}.xml config.xml
        echo cp Configs/config-${SPREAD}.xml config.xml
	if [ $? -eq 0 ]; then
		 echo ./Combinator.py  -s ${FROM} -e ${TO} -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1  -r ${ROOT}/${RUN}/${SPREAD}/$TIME/ -ex ./ -baseDir ./  -ClearHistoryA 0 
                 echo ./RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/${SPREAD}/$TIME -baseOut ${ROOT}/${RUN}/${SPREAD}/${TIME} -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS} -ptable
                 echo ./PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/$TIME -groupBy Strategy -s ${SPREADGROUPS} -v True
	else
		echo FAIL ${SPREAD}
	fi
}


#ROOT='/big/svc_wqln/ML/Backtests'
ROOT='/home/lanarayan/MLData/UNtests'
for arg in "$@"
do
    if [ "$arg" == "--help" ] || [ "$arg" == "-h" ]
    then
        echo "-t ROOT set to /big/svc_wqln/ML/Othertests"
    fi
    if [ "$arg" == "--test" ] || [ "$arg" == "-t" ]
    then
        ROOT='/big/svc_wqln/ML/Othertests'
        echo "ROOT set to $ROOT"
    fi
done
#RUN="Fit-B-2014"
RUN="TestRunB"
#RUN="RunJune21"
FROM="20180301"
TO="20190101"
EXCHANGE="CME_"
MULTIPLIER=2,3,4
REBALANCE=0,1
TIME="1m"
#SPREAD=Smith Hayek 
SPREADCONTRACTS=""
SPREADLEGS=""
SPREADGROUPS=""
#declare -a SPREADLIST=("Kondratiev")
declare -a SPREADLIST=("Marx")
#declare -a SPREADLIST=("Smith" "Buffet" "Hayek" "Nash" "Friedman" "Keynes" "Marx" "Kondratiev")

declare -A  CONTRACTSLEG1=( ["Smith"]="ES" ["Buffet"]="ES" ["Hayek"]="FV" ["Nash"]="TY" ["Friedman"]="TU" ["Keynes"]="TU" ["Marx"]="FV" ["Kondratiev"]="CL")
declare -A  CONTRACTSLEG2=( ["Smith"]="NQ" ["Buffet"]="1YM" ["Hayek"]="TY" ["Nash"]="US" ["Friedman"]="TY" ["Keynes"]="US" ["Marx"]="US" ["Kondratiev"]="LCO")
AFFIX="U7"
GROUPBY="Strategy"
SG="Spread Momentum"

for s in "${SPREADLIST[@]}"
  do
    #echo "QQQQQQQQQQQQQQxx"
    SPREAD=$s
    #echo "${CONTRACTS[Buffet]}"
    SPREADCONTRACTS="${CONTRACTSLEG1[$s]} ${CONTRACTSLEG2[$s]}"
    #echo "$SPREADCONTRACTS"
    SPREADLEGS="$EXCHANGE${CONTRACTSLEG1[$s]}$AFFIX $EXCHANGE${CONTRACTSLEG2[$s]}$AFFIX"
    SPREADGROUPS="$SPREADLEGS $EXCHANGE${CONTRACTSLEG1[$s]}$AFFIX$EXCHANGE${CONTRACTSLEG2[$s]}$AFFIX"
    #echo "$SPREADCONTRACTS"
    #RunOnly
    #RunRisk
    #RunPos
    #TestRunAll
    RunAll
  done
 
exit 0


# Sample combinator command
# ./CombinatorEx.py  -s 20140101 -e 20180701 -MultiplierB 2 -StopMultiplierB 2 -TargetMultiplierB 2 -RebalanceB 0 -OpenPassive 0 -ClosePassive 1 -r /home/lanarayan/MyProjects/Runs7/Hayek/1m -ex ./ -baseDir ./ -env prod


# Sample Risk and Pos Report Commands
#./RiskReportMinutesEx.py -p /home/lanarayan/MyProjects/Runs7/Buffet/1m/params-0 -s B -c ES 1YM -baseOut /home/lanarayan/MyProjects/Runs7/Buffet/ -suffix Buffet -legs CME_ESU7 CME_1YMU7 -f 20150101 -t 20171231
#./PosReportEx.py -baseDir /home/lanarayan/MyProjects/Runs7/Buffet/1m -output /home/lanarayan/MyProjects/Runs/Nash/1m -f 20090101 -t 20180501 -groupBy Strategy -s CME_ESU7 CME_ESU7CME_1YMU7 CME_1YMU7

#./RiskReportMinutesEx.py -p /home/lanarayan/MyProjects/Runs7/Smith/1m/params-0 -s B -c ES NQ -baseOut /home/lanarayan/MyProjects/Runs7/Smith/ -suffix Smith -legs CME_ESU7 CME_NQU7 -f 20150101 -t 20171231

#./RiskReportMinutesEx.py -p /home/lanarayan/MyProjects/Runs7/Hayek/1m/params-0 -s B -c FV TY -baseOut /home/lanarayan/MyProjects/Runs7/Hayek/ -suffix Hayek -legs CME_FVU7 CME_TYU7 -f 20150101 -t 20171231
#./PosReportEx.py -baseDir /home/lanarayan/MyProjects/Runs7/Hayek/1m -output /home/lanarayan/MyProjects/Runs/Hayek/1m -f 20090101 -t 20180501 -groupBy Strategy -s CME_FVU7  CME_FVU7CME_TYU7  CME_TYU7

#./RiskReportMinutesEx.py -p /home/lanarayan/MyProjects/Runs7/Nash/1m/params-0 -s B -c TY US -baseOut /home/lanarayan/MyProjects/Runs7/Nash/ -suffix Nash -legs CME_TYU7 CME_USU7 -f 20150101 -t 20171231
#./PosReportEx.py -baseDir /home/lanarayan/MyProjects/Runs7/Nash/1m -output /home/lanarayan /MyProjects/Runs/Nash/1m -f 20090101 -t 20180501 -groupBy Strategy -s CME_TYU7 CME_TYU7CME_USU7 CME_USU7

#./RiskReportMinutesEx.py -p /home/lanarayan/MyProjects/Runs7/Friedman/1m/params-0 -s B -c TU TY -baseOut /home/lanarayan/MyProjects/Runs7/Friedman/ -suffix Friedman -legs CME_TUU7 CME_TYU7 -f 20150101 -t 20171231
#./RiskReportMinutesEx.py -p /home/lanarayan/MyProjects/Runs7/Keynes/1m/params-0 -s B -c TU US -baseOut /home/lanarayan/MyProjects/Runs7/Keynes/ -suffix Keynes  -legs CME_TUU7 CME_USU7 -f 20150101 -t 20171231 
#./RiskReportMinutesEx.py -p /home/lanarayan/MyProjects/Runs7/Marx/1m/params-0 -s B -c FV US -baseOut /home/lanarayan/MyProjects/Runs7/Marx/1m -suffix Marx -legs CME_FVU7 CME_USU7 -f 20150101 -t 20171231 
