#!/big/svc_wqln/projects/python/conda/bin/python3.6
# Sync positions/openpositions (args.posFiles value)  between args.baseA and args.baseB
# args.startDate and args.endDate are for non prod folders
# if -prod param provided, baseDirA considered to be Prod dir, start and enddate incremented by a day for prod folders
import pandas as pd
import argparse
import os
from datetime import datetime,timedelta
import logging

StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7'], 'Bernanke': ['CME_TNU7', 'CME_AULU7']}

colnamesPosAll = ['Alpha', 'File','ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                   'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                   'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp']

colnamesPosAvgpxRound= ['Alpha', 'File','ID', 'TimeStamp', 'Size','Avgpx', 'AvgpxRound', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                   'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                   'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp']

colnamesPos = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                   'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                   'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp']

colnamesDiff = ['Debug','Alpha', 'File','ID', 'TimeStamp', 'Size', 'Avgpx', 'AvgpxRound', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                   'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                   'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp','SyncKey']

def GetTickSize(strategy):
    if strategy in ['USDJPY', 'EURJPY']:
        return 1
    elif strategy in ['TY', 'FV', 'US', 'TU']:
        return 0.015625
    elif strategy in ['CL']:
        return 0.01
    elif strategy in ['ES', 'NQ']:
        return 0.25
    elif strategy in ['1YM','1Y']:
        return 1
    elif strategy in ['GC', 'CL', 'LCO']:
        return 0.01
    else:  # all currencies
        return 0.00001

def consolidatePositions(alphas,baseDir, startDate, endDate,  baseOutDir,posFileList, fileSuffix, isProd):

    colAlphaList = ['name', 'frequency', 'pname']
    dfAlphas = pd.read_csv(alphas, names=colAlphaList)
    dfPosMaster = pd.DataFrame()
    for index, row in dfAlphas.iterrows():
        csvPath = os.path.join(baseDir, row['name'], row['frequency'], row['pname'])

        # 1YM is 1Y, URO is UR in prod
        if isProd and (row['name'] == '1YM' or row['name'] == 'URO'):
            csvPath = os.path.join(baseDir, row['name'][:2], row['frequency'], row['pname'])

        print("Traversing :", csvPath)
        logging.debug("Traversing {}".format(csvPath))
        csvPath = csvPath.replace('\\', '/')

        #csvPath e.g 'C:/MyProjects/BackTests/StratATest/EURUSD/4H/params-0'
        alphaName = csvPath.split('/')[-3] + '_' + csvPath.split('/')[-2]  # EURUSD_4H
        # path e.g C:\MyProjects\Backtests\StratA\EURUSD\4H\params-0\20170904\Momentum\FXOTC_EUR_USD
        asset = alphaName.split('_')[0] #EURUSD

        tickSize = GetTickSize(asset)


        #f = datetime.strptime(startDate, '%Y%m%d')
        #t = datetime.strptime(endDate, '%Y%m%d')
        #delta = t - f  # timedelta
        delta = endDate - startDate
        dateInputList = []
        logging.debug("From {} To {}".format(startDate,endDate))
        print("From ", startDate, "To ",endDate)

        for i in range(delta.days + 1):
            # print(d1 + timedelta(days=i))
            dateInputList.append((startDate + timedelta(days=i)).strftime("%Y%m%d"))

        if len(dateInputList) > 0:
            print("Date Range: ",dateInputList[0] , "to ", dateInputList[len(dateInputList) - 1])
            logging.debug("Date Range: {} to {}".format(dateInputList[0], dateInputList[len(dateInputList) - 1]))

        for pathDate in dateInputList:
            for dirpath, dirnames, filenames in os.walk(os.path.join(csvPath, pathDate)):
                for file in filenames:
                    print('Dirpath:', dirpath)
                    if file in posFileList:
                        posFilePath = os.path.join(dirpath, file)
                        print("Reading ", posFilePath)
                        dfPos = pd.read_csv(posFilePath, names=colnamesPos)
                        dfPos['Alpha']= alphaName
                        dfPos['File'] = file
                        dfPos['AvgpxRound'] = (round(dfPos['Avgpx']/tickSize )).astype(int)  #(round(df1.Avgpx)).astype(int)
                        dfPosMaster = dfPosMaster.append(dfPos)

    dfPosMasterAvgRound = dfPosMaster[colnamesPosAvgpxRound]
    # Rearrange columns so that Alpha is first column
    dfPosMaster = dfPosMaster[colnamesPosAll]



    dfPosMaster.to_csv(os.path.join(baseOutDir, "Positions_" + fileSuffix + ".csv"),index=False)
    dfPosMasterAvgRound.to_csv(os.path.join(baseOutDir, "PositionsRound_" + fileSuffix + ".csv"), index=False)

    return dfPosMasterAvgRound
def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-alphas', '--alphas', default='/home/lanarayan/MLData/BacktestsV4/AlphaList/V5/alphasA.txt', help="base input Directory")
    parser.add_argument('-f', '--startDate', default='20190901', help="from date for BacktestAlpha")
    parser.add_argument('-t', '--endDate', default='20190902', help="to date for BacktestAlpha")
    parser.add_argument('-baseDirA', '--baseDirA', default='/home/lanarayan/MLData/Builds/build',
                        help="base Prod Directory")
    parser.add_argument('-suffixA', '--suffixA', default='A',
                        help="output file suffix for baseDirA")
    parser.add_argument('-baseDirB', '--baseDirB', default='/home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019',
                        help="base non Prod Directory")
    parser.add_argument('-suffixB', '--suffixB', default='B',
                        help="output file suffix for baseDirB")
    parser.add_argument('-baseOut', '--baseOutDir', default='/home/lanarayan/MLData/',
                        help="base Out Directory")
    parser.add_argument('-prod', '--prod', action='store_true', help="if param provided baseDirA considered Prod dir")
    parser.add_argument('-posFiles', '--posFiles', default=["positions.txt", "openpositions.txt", "standingpositions.txt"], help="position files ",
                        nargs='*')
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath,'SyncPositions-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)

    posFileList = args.posFiles

    startDate = datetime.strptime(args.startDate, '%Y%m%d')
    endDate = datetime.strptime(args.endDate, '%Y%m%d')
    if args.prod:
        print("Prod is true. BaseDirA considered Prod dir")
        #increment a day for prod folders (Not required after prod folders creation synced with backtestalpha
        ''' prodStart = startDate + timedelta(1)
        prodEnd = endDate + timedelta(1)
        print("For Prod using dates- From: ", prodStart, " To: ", prodEnd);'''
        df1 = consolidatePositions(args.alphas, args.baseDirA, startDate, endDate, args.baseOutDir, posFileList,
                                   args.suffixA, args.prod)
    else:
        df1 = consolidatePositions(args.alphas, args.baseDirA, startDate, endDate,  args.baseOutDir,posFileList,args.suffixA,False)

    df2 = consolidatePositions(args.alphas, args.baseDirB, startDate,endDate, args.baseOutDir,posFileList, args.suffixB,False)


    df1['Debug']='A'
    df2['Debug'] = 'B'

    #df1['AvgpxRound'] = (round(df1.Avgpx)).astype(int)
    #df2['AvgpxRound'] = (round(df2.Avgpx)).astype(int)

    df1['SyncKey'] = df1['TimeStamp'].astype(str) + '_' + df1['Size'].astype(str) + '_' + df1['AvgpxRound'].astype(
        str) + '_' + df1['Status'].astype(str) + '_' + df1['CloseCode'].astype(str)
    df2['SyncKey'] = df2['TimeStamp'].astype(str) + '_' + df2['Size'].astype(str) + '_' + df2['AvgpxRound'].astype(
        str) + '_' + df2['Status'].astype(str) + '_' + df2['CloseCode'].astype(str)

    df = pd.concat([df1, df2]).drop_duplicates(['SyncKey'], keep=False)
    df = df[colnamesDiff]
    df.to_csv(os.path.join(args.baseOutDir, "PositionsDiff_" + args.startDate + 'To' + args.endDate+ ".csv"), index=False)

    if args.prod:
        print("Prod arg is true. BaseDirA considered Prod dir ")

    print("Output files A is :", os.path.join(args.baseOutDir, "Positions_" + args.suffixA + ".csv"))
    print("Output files B is :", os.path.join(args.baseOutDir, "Positions_" + args.suffixB + ".csv"))
    print("Diff file is:",os.path.join(args.baseOutDir, "PositionsDiff_" + args.startDate + 'To' + args.endDate+ ".csv"))

if __name__ == '__main__':
    main()