#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import logging
import argparse
#from pylab import *
import os


portfolioSimAllCols = ['Date','Pnl','Long','Short', 'BookSize','HoldingValue','Trading Value','HeldShares','TradedShares']

def main():
    logging.basicConfig(level=logging.INFO,
                      format='%(asctime)s %(levelname)s %(message)s')
    parser = argparse.ArgumentParser()

    parser.add_argument('-baseDir', '--baseDir', default='/big/svc_wqln/ML/Backtests/OutSim/Fit-AB-2019/V1', help="base Directory")
    parser.add_argument('-noHeader', '--noHeader', action="store_true", help="if param provided file has no header")
    parser.add_argument('-longLimit', '--longLimit', default="100000000", type=int, help="AbsLong greater than longLimit")
    parser.add_argument('-shortLimit', '--shortLimit', default="100000000", type=int, help="AbsShort greater than shortLimit")

    args = parser.parse_args()
    print(args)

    file = os.path.join(args.baseDir, "Bhaskar")
    #file = os.path.join(args.baseDir, "PortfolioExposure.csv")

    if args.noHeader:
        df = pd.read_csv(file, sep=' ', index_col=False,names=portfolioSimAllCols)
    else:
        df = pd.read_csv(file, sep=' ', index_col=False)

    df['AbsLong'] = abs(df['Long'])
    df['AbsShort'] = abs(df['Short'])
    df['AbsBookSize'] = abs(df['BookSize'])

    print("Max of AbsLong", df['AbsLong'].max())
    print("Max of AbsShort", df['AbsShort'].max())
    print("Max of AbsBookSize", df['AbsBookSize'].max())


    #df['Date'] = pd.to_datetime(df['Date'],format='%Y%m%d')
    # example of boolean indexing,  for an exhaustive list of indexing techniques look at:
    # https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html
    dfLong = df[df['AbsLong'] > args.longLimit]
    dfShort = df[df['AbsShort'] > args.shortLimit]

    #print(dfLong.head())
    print("long limit", dfLong.shape)
    print("short limit", dfShort.shape)


    print('Done')

if __name__ == '__main__':
    main()