#!/big/svc_wqln/projects/python/conda/bin/python3.6

# Useful links for dev:
#==========================
#https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html#timeseries-offset-aliases
#https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html#generating-ranges-of-timestamps
#https://www.youtube.com/watch?v=UO98lJQ3QGI&list=PL-osiE80TeTvipOqomVEeZ1HRrcEvtZB_
#-baseDir C:/MyProjects/Backtests/StratA/EURUSD/1H/params-0 -d 20171228 -baseOut C:/MyProjects/Temp/SplineOut -log C:/MyProjects/Temp/SplineOut -c 3 -p 40
#-baseDir C:/MyProjects/Backtests/StratA/EURUSD/1H/params-0 -d 20171228 -baseOut C:/MyProjects/Temp/SplineOut -log C:/MyProjects/Temp/SplineOut -c 3 -p 40 -useDates -dates "2019-Sep-23 03:00" "2019-Sep-23 04:00"


#Sample Commands:
#================
#1. read data from start of data file
    #-baseDir /home/lanarayan/MLData/Backtests/Fit-A-2019/EURUSD/1H/params-0 -d 20171228 -baseOut home/lanarayan/MLData/Backtests/Fit-A-2019/EURUSD/1H/params-0 -c 3 -p 100 -f 15min -dataRead start
#2. read data from end of data file (default)
    #-baseDir /home/lanarayan/MLData/Backtests/Fit-A-2019/EURUSD/1H/params-0 -d 20171228 -baseOut home/lanarayan/MLData/Backtests/Fit-A-2019/EURUSD/1H/params-0 -c 3 -p 100 -f 15min -dataRead end
#3. -useDates to use -dates provided
    #-baseDir /home/lanarayan/MLData/Backtests/Fit-A-2019/EURUSD/1H/params-0 -d 20171228 -baseOut home/lanarayan/MLData/Backtests/Fit-A-2019/EURUSD/1H/params-0 -c 3 -p 100 -f 15min -useDate -dates "2019-Sep-23 03:00" "2019-Sep-23 04:00"

# Common params:
#==============
# baseDir: base directory for date folder
# baseOut: base out dir
# d: date folder to read spline.txt
# c: number of curves to be plotted (ignored when useDates arg provided)
# p: period (i.e num of datapoints separated by commas)
# dates: date list used with useDates arg e.g --dates "2019-Sep-23 03:00" "2019-Sep-23 05:00"
# useDates: provide this arg to use date list  provided in -dates args
# dataRead: provide 'start' or 'end' to read data from start or end of data file. Data read using this to plot number of curves in -c arg
    # irrelevant when -useDates arg given
#f: frequency of data provided e.g 15min, 1H, 4H

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import argparse
import os
from datetime import datetime,timedelta
import logging
from matplotlib import dates as mpl_dates
import matplotlib.ticker as ticker


def main():
    parser = argparse.ArgumentParser()

    #parser.add_argument('-alpha', '--alpha', default='', help="alpha name")
    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MLData/BacktestsV6',
                        help="base  Directory")
    parser.add_argument('-baseOut', '--baseOutDir', default='/home/lanarayan/MLData/',
                        help="base Out Directory")
    parser.add_argument('-d', '--dirDate', default='20190901', help="date folder to read spline.txt")
    parser.add_argument('-c', '--curves', default='1', help="number of curves")
    #parser.add_argument('-dates', '--dateList', default=['2019-Sep-23 03:00', '2019-Sep-23 05:00'], help="if useDates given then list of timestamps to be plotted; in args separated by space",
                     #   nargs='*')
    #e.g -dates "2019-Sep-23 03:00" "2019-Sep-23 05:00"
    parser.add_argument('-dates', '--dateList', default=[],
                        help="if useDates given then list of timestamps to be plotted; in args separated by space",
                        nargs='*')
    parser.add_argument('-useDates', '--useDates', action='store_true', help="if param provided use dateList for plotting")
    parser.add_argument('-dataRead', '--dataRead', default='end',
                        help="start: to read data from start of datafile; end: to read data from end of datafile;")

    parser.add_argument('-p', '--periods', default='10', help="number of periods")
    parser.add_argument('-f', '--frequency', default='15min', help="Frequency 1H , 4H, 15min")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    if args.useDates and len(args.dateList) <=0:
        print (" Exitting . -useDates is ", args.useDates, "but no dates provided")
        print ( 'provide date args e.g -dates "2019-Sep-23 03:00" "2019-Sep-23 05:00" ')
        exit(1)

    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)
    fhLog = open(os.path.join(args.baseOutDir, "SplineLog.txt"), 'w')
    logging.basicConfig(filename=os.path.join(args.logPath, 'SplinePlot-' + dateForLog + '.log'), filemode='w',
                        level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    #alphs = args.alpha
    file = os.path.join(args.baseDir,args.dirDate,"spline.txt")
    f = open(file, "r")
    #for x in f:
        #print(x)

    counter=1
    #curves=2
    endCounter= 2* int(args.curves)
    dataMap ={}
    ydata=""

    dateCounter =1

    MainArray=[]

    if args.dataRead == 'start':
        print("Reading from start , useDates is ", args.useDates)
        for line in (open(file).readlines()):
            if args.useDates:
                if dateCounter > len(args.dateList):
                    print("Breaking date counter at val:", dateCounter)
                    break
            else:
                if counter > endCounter:
                    print("Breaking counter at val:", counter)
                    break
            #print(line.rstrip())
            if counter %2 != 0:
                key = line.rstrip()
                if args.useDates:
                    if key in args.dateList :
                        print("Inserting data for key: ", key)
                        dataMap[key] = ydata
                        dateCounter = dateCounter + 1
                else:
                    print("Inserting data for key: ", key)
                    dataMap[key] = ydata
                ydata = ""
            else:
                ydata = line.rstrip()
                ydata = ydata.rstrip(',')
            counter= counter + 1

    if args.dataRead == 'end':
        print("Reading from end , useDates is ", args.useDates)
        for line in reversed(open(file).readlines()):
            if args.useDates:
                if dateCounter > len(args.dateList):
                    print("Breaking date counter at val:", dateCounter)
                    break
            else:
                if counter > endCounter:
                    print("Breaking counter at val:", counter)
                    break
            #print(line.rstrip())
            if counter %2 == 0:
                key = line.rstrip()
                if args.useDates:
                    if key in args.dateList :
                        print("Inserting data for key: ", key)
                        dataMap[key] = ydata
                        dateCounter = dateCounter + 1
                else:
                    print("Inserting data for key: ", key)
                    dataMap[key] = ydata
                ydata = ""
            else:
                ydata = line.rstrip()
                ydata = ydata.rstrip(',')
            counter= counter + 1

    for key, val in dataMap.items():
        #print(key, "::", val)
        idx = pd.date_range(end=key, periods= int(args.periods), freq=args.frequency)

        tmp =[]
        subArray = []
        for v in idx:
            print(v)
            tmp.append(v)
        #tmp.reverse()
        subArray.append(tmp)
        subArray.append(val.split(','))
        MainArray.append(subArray)
    print("zz")

    #idx = pd.date_range('2018-01-01 13:00:00', periods=5, freq='15min')
    #ts = pd.Series(range(len(idx)), index=idx)
    fig, ax = plt.subplots()
    plt.style.use('seaborn')
    print("MainArray[0][0]:",MainArray[0][0])
    #print("MainArray[1][0]:",MainArray[1][0])

    for item in MainArray:
        fhLog.write("Number of Items:" + str(len(item[0])) + " \n")
        for i in range(0, int(args.periods) -1):
            fhLog.write(item[0][i].strftime("%Y-%m-%d %H:%M:%S") + ',' + item[1][i] + '\n')

    for item in MainArray:
        #convert all vals in list to floats else plot considers them as str values
        YList = [float(i) for i in item[1]]
        ax.plot_date(item[0], YList,linestyle='solid',marker=None)
        #ax.plot(item[0], item[1], linestyle='solid', marker=None)
    fig.autofmt_xdate()
    date_format= mpl_dates.DateFormatter('%b,%d %Y %H:%M:%S')
    ax.xaxis.set_major_formatter(date_format)
    ax.xaxis.set_major_locator(ticker.LinearLocator(10))
    ax.yaxis.set_major_locator(ticker.LinearLocator(10))
    plt.tight_layout()
    '''plt.gcf().autofmt_xdate()
    plt.gca().xaxis.set_major_formatter(date_format)
        plt.gca().xaxis.set_major_locator(ticker.LinearLocator(3))
        plt.gca().yaxis.set_major_locator(ticker.LinearLocator(5))
    '''

    #Testing
    '''df = pd.DataFrame(list(zip(MainArray[0][0], MainArray[0][1])),
                      columns=['Date', 'Price'])
    df['Date'] = df['Date'].dt.strftime('%Y-%m-%d %H:%M:%S')
    df['Price'] = pd.to_numeric(df['Price'])
    df = df.set_index('Date')
    plt.figure()
    df.plot()
    print(df)
    plt.show()'''
    # Testing end

    #for item in MainArray:
    #   ax.plot(item[0], item[1])
    #plt.xticks=
    #ax.set_xticks()
    ax.set(xlabel='time', ylabel='prices',
           title='Splines')
    ax.grid()
    print("Saving file: ",os.path.join(args.baseOutDir,"splineChart.png"))
    plt.savefig(os.path.join(args.baseOutDir,"splineChart.png"))
    #fig.savefig("test.png")
    plt.show()

if __name__ == '__main__':
    main()