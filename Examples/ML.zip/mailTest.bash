#!/bin/bash
OUTPUTFILE='/home/lanarayan/cronOutput.txt' 
#grep  "FAIL" $OUTPUTFILE

if grep -q "FAIL" $OUTPUTFILE
then
#echo "GREP success"

mail -s 'FAIL Daily Cron' lanarayan@worldquant.com < $OUTPUTFILE
fi

#echo "Mail DONE"