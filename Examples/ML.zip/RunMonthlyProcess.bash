#!/bin/bash 

startScript=$(date -u) 
#./MonthlyProcess.bash  -m run -e  all  -f 20190601 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA1H.txt -v V0 -o OutSimAug3M_1H
./MonthlyProcess.bash  -m run -e  all  -f 20190601 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA4H.txt -v V0 -o OutSimAug3M_4H
./MonthlyProcess.bash  -m run -e  all  -f 20190601 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA1D.txt -v V0 -o OutSimAug3M_1D
./MonthlyProcess.bash  -m run -e  all  -f 20190601 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA15m.txt -v V0 -o OutSimAug3M_15m

./MonthlyProcess.bash  -m run -e  all  -f 20170801 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA.txt -v V5 -o OutSimAug1M


./MonthlyProcess.bash  -m run -e  all  -f 20170701 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA1H.txt -v V0 -o OutSimAug2Y_1H
./MonthlyProcess.bash  -m run -e  all  -f 20170701 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA4H.txt -v V0 -o OutSimAug2Y_4H
./MonthlyProcess.bash  -m run -e  all  -f 20170701 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA1D.txt -v V0 -o OutSimAug2Y_1D
./MonthlyProcess.bash  -m run -e  all  -f 20170701 -t 20190831 -d /big/svc_wqln/ML/BacktestsV4 -a alphasA15m.txt -v V0 -o OutSimAug2Y_15m


echo 'StartTime MonthlyProcess:' $startScript
endScript=$(date -u)
echo 'EndTime MonthlyProcess:'$endScript
