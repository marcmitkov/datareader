import pandas as pd
#from IPython.display import display
#from IPython.display import Image
import datetime
import argparse
import numpy as np
import os
import glob

multipliers = {"1YM": 5, "DM": 100, "ES": 50, "FCE": 10, "FDX": 25,
                "FF": 4167, "FV": 1200, "NQ": 20, "RMF": 50, "STXE": 10,
                "TFS": 50, "TN": 1000,  "TU": 2000, "TY": 1000, "US": 1000,
                "AUDUSD": 1000000, "EURGBP": 1000000, "EURJPY": 10000,"EURUSD": 1000000, "GBPUSD": 1000000,
                "USDCAD": 1000000, "USDCHF": 1000000, "USDJPY": 10000, "CL":1000, "LCO":1000}


def ReadSeries(a):
    df1 = pd.read_csv(a)
    return df1

def CheckDuplicateDates(df1, verbose=True, name='D'):
    if len(df1[df1.duplicated([name],keep='last')]) > 0 and verbose:       
        print('duplicated 1', df1[df1.duplicated([name],keep='last')])
        print('# duplicated 1', len(df1[df1.duplicated([name],keep='last')]))

def CheckDuplicate(df1, verbose=True, name='A'):
    if len(df1[df1.duplicated(['Date'],keep='last')]) > 0 and verbose:       
        print('duplicated 1', df1[df1.duplicated(['Date'],keep='last')])
        print('# duplicated 1', len(df1[df1.duplicated(['Date'],keep='last')]))

def ProcessDate(df):
    # Create TimeFormat column in HH:MM:SS format
    df['HH'] = df.interval.astype(str).str[:2] + ':' 
    df['MM'] = df.interval.astype(str).str[2:4] + ':' 
    df['SS'] = df.interval.astype(str).str[4:6]  
    df['TimeFormat'] = df['HH'] + df['MM'] + df['SS']

    #print(df2.head())

    df['DateStr'] = pd.to_datetime(df.date[0:]) + pd.to_timedelta(((df.TimeFormat[0:])), unit='m')
    #print(df2.head())
    df['Date'] = pd.to_datetime(df.DateStr)
    return df

def doUnion(df1,df2,fh,verbose,baseOutDir):
    suffixdf1 = '_ESV'
    suffixdf2 = '_NQ'
    # outer join (union)
    mergedOuterDF = pd.merge(df1, df2, on='Date', how='outer',suffixes=('_ESV', '_NQ'))
    #mergedOuterDF.to_csv('C:/MyProjects/Data/CSV/mergedOuterDF.csv')
    #print(mergedOuterDF.head())

    mergeddf1 = mergedOuterDF.loc[: ,["Date", "interval" + suffixdf1 , "SYBL" + suffixdf1,  "LSTP" + suffixdf1,  "LSTS" + suffixdf1,  "INTF" + suffixdf1,  "INTH" + suffixdf1,  "INTL" + suffixdf1,  "INTV" + suffixdf1,  "NTRD" + suffixdf1, "LSTB" + suffixdf1,  "LSBS" + suffixdf1, "LSTA" + suffixdf1 ,"LSAS" + suffixdf1,  "HBID" + suffixdf1, "LBID" + suffixdf1,  "HASK" + suffixdf1,  "LASK" + suffixdf1, "HBSZ" + suffixdf1,  "LBSZ" + suffixdf1, "HASZ" + suffixdf1,  "LASZ" + suffixdf1,  "HLTS" + suffixdf1,  "IVAM" + suffixdf1]]
#df2 = df2.loc[: ,["Date", "interval", "SYBL", "LSTP", "LSTS", "INTF", "INTH",
#"INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK",
#"LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]
    mergeddf2 = mergedOuterDF.loc[: ,["Date", "interval" + suffixdf2 , "SYBL" + suffixdf2, "LSTP" + suffixdf2,  "LSTS" + suffixdf2,  "INTF" + suffixdf2,  "INTH" + suffixdf2,  "INTL" + suffixdf2,  "INTV" + suffixdf2,  "NTRD" + suffixdf2, "LSTB" + suffixdf2,  "LSBS" + suffixdf2, "LSTA" + suffixdf2 ,"LSAS" + suffixdf2,  "HBID" + suffixdf2, "LBID" + suffixdf2,  "HASK" + suffixdf2,  "LASK" + suffixdf2, "HBSZ" + suffixdf2,  "LBSZ" + suffixdf2, "HASZ" + suffixdf2,  "LASZ" + suffixdf2,  "HLTS" + suffixdf2,  "IVAM" + suffixdf2]]

    # for getting num of NA rows only - dropnadf1 and dropnadf2 not used
    dropnadf1 = mergeddf1.dropna(axis=0, how='any')
    dropnadf2 = mergeddf2.dropna(axis=0, how='any')

    print("len(dropnadf1)",len(dropnadf1))
    print("len(dropnadf2)",len(dropnadf2))

    #print(dropnadf2.head(20))

    # Note : to get all rows with na
    NARowsDf1 = mergeddf1[pd.isnull(mergeddf1).any(axis=1)]
    NARowsDf2 = mergeddf2[pd.isnull(mergeddf2).any(axis=1)]

    print("Nas in mergeddf1:" , len(mergeddf1) - len(dropnadf1))
    print("Nas in mergeddf2: " , len(mergeddf2) - len(dropnadf2))

    fh.write('Number of dates missing in DF1: ' + str(len(mergeddf1) - len(dropnadf1)) + '\n')
    fh.write('Number of dates missing in DF2: ' + str(len(mergeddf2) - len(dropnadf2)) + '\n')

    
    #if args.verbose == 'true':
    if  verbose == 'true':
        fh.write('Dates missing in DF1: ' + str(len(mergeddf1) - len(dropnadf1)) + '\n')

        for row in NARowsDf1.itertuples():
            fh.write(str(row.Date) + ', ')
        fh.write('\n \n')
        fh.write('Dates missing in DF2: ' + str(len(mergeddf2) - len(dropnadf2)) + '\n')
        for row in NARowsDf2.itertuples():
            fh.write(str(row.Date) + ', ')

        fh.write('\n \n')
        NADfPath = os.path.join(baseOutDir, args.outNA_A)
        NARowsDf1.to_csv(NADfPath)
        NADfPath = os.path.join(baseOutDir, args.outNA_B)
        NARowsDf2.to_csv(NADfPath)

    mergeddf1['Date'] = pd.to_datetime(mergeddf1['Date'])
    mergeddf2['Date'] = pd.to_datetime(mergeddf2['Date'])


    #print(mergeddf1.head())
    #Set index with date time value
    mergeddf1 = mergeddf1.set_index(['Date'])
    mergeddf2 = mergeddf2.set_index(['Date'])

    #print(mergeddf1.head())
   # mergeddf1 = mergeddf1.sort_values('Date')
   # sort on index before ffill
    mergeddf1 = mergeddf1.sort_index()
    mergeddf2 = mergeddf2.sort_index()
    #print(mergeddf1.head())

    #fill all nas
    mergeddf1.fillna(method='ffill',inplace=True)
    mergeddf1.fillna(method='bfill',inplace=True)
    mergeddf2.fillna(method='ffill',inplace=True)
    mergeddf2.fillna(method='bfill',inplace=True)

    return mergeddf1,mergeddf2

def doIntersection(df1,df2):
    suffixdf1 = '_ESV'
    suffixdf2 = '_NQ'
     # inner join (intersection)
    mergedInnerDF = pd.merge(df1, df2, on='Date', how='inner',suffixes=('_ESV', '_NQ'))

    #print(mergedInnerDF.head())

    mergeddf1 = mergedInnerDF.loc[: ,["Date","interval" + suffixdf1 , "SYBL" + suffixdf1, "LSTP" + suffixdf1,  "LSTS" + suffixdf1,  "INTF" + suffixdf1,  "INTH" + suffixdf1,  "INTL" + suffixdf1,  "INTV" + suffixdf1,  "NTRD" + suffixdf1, "LSTB" + suffixdf1,  "LSBS" + suffixdf1, "LSTA" + suffixdf1 ,"LSAS" + suffixdf1,  "HBID" + suffixdf1, "LBID" + suffixdf1,  "HASK" + suffixdf1,  "LASK" + suffixdf1, "HBSZ" + suffixdf1,  "LBSZ" + suffixdf1, "HASZ" + suffixdf1,  "LASZ" + suffixdf1,  "HLTS" + suffixdf1,  "IVAM" + suffixdf1]]
    mergeddf2 = mergedInnerDF.loc[: ,["Date","interval" + suffixdf2 , "SYBL" + suffixdf2,"LSTP" + suffixdf2,  "LSTS" + suffixdf2,  "INTF" + suffixdf2,  "INTH" + suffixdf2,  "INTL" + suffixdf2,  "INTV" + suffixdf2,  "NTRD" + suffixdf2, "LSTB" + suffixdf2,  "LSBS" + suffixdf2, "LSTA" + suffixdf2 ,"LSAS" + suffixdf2,  "HBID" + suffixdf2, "LBID" + suffixdf2,  "HASK" + suffixdf2,  "LASK" + suffixdf2, "HBSZ" + suffixdf2,  "LBSZ" + suffixdf2, "HASZ" + suffixdf2,  "LASZ" + suffixdf2,  "HLTS" + suffixdf2,  "IVAM" + suffixdf2]]
    
    #Set index with date time value
    mergeddf1 = mergeddf1.set_index(['Date'])
    mergeddf2 = mergeddf2.set_index(['Date'])
     
    # sort on index
    mergeddf1 = mergeddf1.sort_index()
    mergeddf2 = mergeddf2.sort_index()

    return mergeddf1,mergeddf2

def addHTMLHeadElement():
    htmlHead = """<!DOCTYPE html>
                <html><head>
                <style>table, th, td {
                        border: 1px solid black;
                        border-collapse: collapse;
                        padding:5px
                        
                }
                </style>
                </head>
                <body>"""

    return htmlHead

def addHTMLBodyEndTag():
     return "</body>"


def FuturesData(fromDate, toDate, baseDir, contract):
    # /big/svc_wqln/data/Futures/ES/2018/09/ESU8_20180904.csv
    f = datetime.datetime.strptime (fromDate, '%Y%m%d')
    t = datetime.datetime.strptime (toDate, '%Y%m%d')
    df1 =pd.DataFrame()
    years = (range(f.year, t.year + 1,1))
    searchRoot = os.path.join(baseDir, contract)
    for x in years:
        for folder in glob.glob(searchRoot + '/' + str(x) + '/*'):
            for datafile in glob.glob(folder + '/*.csv'):
                datestr = datafile[-12:-4]
                fileDate = (datetime.datetime.strptime(datestr, '%Y%m%d'))
                if f <= fileDate <= t:
                    #print("\n df1 (adding): ", datafile)
                    dftmp = pd. read_csv(datafile,index_col=False)
                    df1 = df1.append(dftmp)
    return df1

def FXDataOld(fromDate, toDate, baseDir,contract,outdir,inverse=False):
    # /big/svc_wqln/data/Futures/ES/2018/09/ESU8_20180904.csv
    f = datetime.datetime.strptime (fromDate, '%Y%m%d')
    t = datetime.datetime.strptime (toDate, '%Y%m%d')
    logFile = os.path.join(outdir, "Exception_" + contract + ".txt")
    fh = open(logFile, 'a')
    inverseColList = ["LSTP", "INTF", "INTH", "INTL", "LSTB", "LSTA", "HBID", "LBID", "HASK", "LASK"]
    df1 =pd.DataFrame()
    years = (range(f.year, t.year + 1,1))
    #searchRoot = os.path.join(baseDir, contract)
    searchRoot = baseDir
    for x in years:
        for folder in glob.glob(searchRoot + '/' + str(x) + '/*'):
            for datafile in glob.glob(folder + '/*.csv'):
                datestr = datafile[-12:-4]
                fileDate = (datetime.datetime.strptime(datestr, '%Y%m%d'))
                if f <= fileDate <= t:
                    print("\n df1 (adding): ", datafile)
                    dftmp = pd. read_csv(datafile,index_col=False)
                    df1 = df1.append(dftmp)

    if(inverse):
        for name, values in df1.iteritems():
            #print(name)
            if name in inverseColList:
                print("Taking Reciprocal of :",name)
                #df1[name] = np.where(df1[name] > 0, 1/df1[name],df1[name])
                try:
                    df1[name] = 1/df1[name]
                except ZeroDivisionError as e:
                    print(e)
                    fh.write("Taking Reciprocal of :"+ name + "\n")
                    fh.write(datetime.datetime.now() + "::" + e)

                if contract in ['USDJPY', 'EURJPY']:
                    df1[name] = round(df1[name], 3)
                else:
                    df1[name] = round(df1[name], 5)

                '''mask = df1[name] > 0
                if contract in ['USDJPY', 'EURJPY']:

                    df1.loc[mask, name] = round(1 / df1[name],3)
                else:
                    df1.loc[mask, name] = round(1 / df1[name], 5)'''
                '''if contract in ['USDJPY', 'EURJPY']:
                    df1[name] = round(1/df1[name],3)
                else:
                    df1[name] = round(1 / df1[name], 5)'''
    else:
        for name, values in df1.iteritems():
            #print(name)
            if name in inverseColList:
                if contract in ['USDJPY', 'EURJPY']:
                    df1[name] = round(df1[name], 3)
                else:
                    df1[name] = round(df1[name], 5)

    # compute LSTP if invalid derive from LSTB and LSTA
    df1['LSTP'] =  df1.fillna( (df1['LSTB'] + df1['LSTA'])/2.0 )
    return df1

def FXData(fromDate, toDate, baseDir,contract,outdir,inverse=False):
    # /big/svc_wqln/data/Futures/ES/2018/09/ESU8_20180904.csv
    f = datetime.datetime.strptime (fromDate, '%Y%m%d')
    t = datetime.datetime.strptime (toDate, '%Y%m%d')
    logFile = os.path.join(outdir, "Exception_" + contract + ".txt")
    fh = open(logFile, 'a')
    inverseColList = ["LSTP", "INTF", "INTH", "INTL", "LSTB", "LSTA", "HBID", "LBID", "HASK", "LASK"]
    # "LSTB", <=> "LSTA",
    # "HBID", <=> "HASK"
    # "LBID", <=>  "LASK"

    df1 =pd.DataFrame()
    years = (range(f.year, t.year + 1,1))
    #searchRoot = os.path.join(baseDir, contract)
    searchRoot = baseDir
    for x in years:
        for folder in glob.glob(searchRoot + '/' + str(x) + '/*'):
            for datafile in glob.glob(folder + '/*.csv'):
                datestr = datafile[-12:-4]
                if datestr == "20190115":
                    continue;
                fileDate = (datetime.datetime.strptime(datestr, '%Y%m%d'))
                if f <= fileDate <= t:
                    print("\n df1 (adding): ", datafile)
                    dftmp = pd. read_csv(datafile,index_col=False)
                    df1 = df1.append(dftmp)

    if(inverse):
        for name, values in df1.iteritems():
            #print(name)
            if name in inverseColList:
                print("Taking Reciprocal of :",name)
                #df1[name] = np.where(df1[name] > 0, 1/df1[name],df1[name])
                try:
                    if contract == 'USDJPY':
                        print(contract, ' Multiply by 100')
                        df1[name] = (1/df1[name])*100
                    else:
                        print(contract, 'Do Not Multiply by 100')
                        df1[name] = 1 / df1[name]
                except ZeroDivisionError as e:
                    print(e)
                    fh.write("Taking Reciprocal of :"+ name + "\n")
                    fh.write(datetime.datetime.now().strftime('%Y%m%d %H:%M:%S'))
                    fh.write(str(e))
                except TypeError as e:
                    print(e)
                    fh.write("Taking Reciprocal of :" + name + "\n")
                    fh.write(datetime.datetime.now().strftime('%Y%m%d %H:%M:%S') )
                    fh.write(str(e))
        #fh.write("OLD:")
        #fh.write(df1.head())
        #print(df1.head())
        #df1.to_csv(os.path.join(outdir,"Old.csv"))
        df1.rename(columns={'LSTB': 'LSTBNew', 'HBID': 'HBIDNew',
                                    'LBID': 'LBIDNew'}, inplace=True)
        df1.rename(columns={'LSTA': 'LSTB', 'HASK': 'HBID',
                            'LASK': 'LBID'}, inplace=True)
        df1.rename(columns={'LSTBNew': 'LSTA', 'HBIDNew': 'HASK',
                            'LBIDNew': 'LASK'}, inplace=True)

         # For 1m.csv and 1m_live .csv INTV is in position 4 (as shown here and in WQData) but in Resample files INTV is in position 9
         # D, T, SYBL, INTV, LSTP, LSTS, INTF, INTH, INTL, NTRD, LSTB, LSBS, LSTA, LSAS, HBID, LBID, HASK, LASK, HBSZ, LBSZ, HASZ, LASZ, HLTS, IVAM
        df1 = df1[['D','T','SYBL','INTV','LSTP','LSTS','INTF','INTH','INTL','NTRD','LSTB','LSBS','LSTA','LSAS','HBID','LBID','HASK','LASK','HBSZ','LBSZ','HASZ','LASZ','HLTS','IVAM']]

        #df1 = df1[['D', 'T', 'SYBL', 'LSTP', 'LSTS', 'INTF', 'INTH', 'INTL', 'INTV', 'NTRD', 'LSTB', 'LSBS', 'LSTA', 'LSAS','HBID', 'LBID', 'HASK', 'LASK', 'HBSZ', 'LBSZ', 'HASZ', 'LASZ', 'HLTS', 'IVAM']]

        #fh.write("NEW:")
        #fh.write(df1.head())
        #print(df1.head())
        #df1.to_csv(os.path.join(outdir, "New.csv"))


    #compute LSTP if invalid derive from LSTB and LSTA
    df1['LSTP'] =  df1['LSTP'].fillna( (df1['LSTB'] + df1['LSTA'])/2.0 )
    for name, values in df1.iteritems():
        if name in inverseColList:
            try:
                if contract in ['USDJPY', 'EURJPY']:
                    df1[name] = round(df1[name], 3)
                else:
                    df1[name] = round(df1[name], 5)
            except TypeError as e:
                df1[name].to_csv(os.path.join(outdir,"Exc_" + contract + "_" + name  + ".csv"))
                print(e)
                print("Rounding of:" + name)
                fh.write("Rounding of:" + name + "\n")
                fh.write(datetime.datetime.now().strftime('%Y%m%d %H:%M:%S'))
                fh.write(str(e))
    return df1

def IsFX(contract):
    print(len(contract))
    if len(contract) == 6:
        return True
    return False

def get_prices():
    """ Calculate normal returns from closing prices
    :return: returns dataframe"""
    #data_path = '/big/svc_wqln/data/'
    data_path = '/home/lanarayan/MLData/'

    prices = pd.DataFrame(columns=multipliers.keys())

    for types in os.listdir(data_path):
        type_path = os.path.join(data_path, types, 'Live')
        #if types == "FX":
            #type_path = "/home/lanarayan/WQData/FX/BacktestData"
        if os.path.isdir(type_path):
            for instrument in os.listdir(type_path):
                instruments_path = os.path.join(type_path, instrument)

                daily_path = os.path.join(instruments_path, '1D_resample.csv')
                if os. path.exists(daily_path):
                    inst_price = pd.read_csv(daily_path)
                    inst_price['D']=list(map(lambda x: x.split()[0],inst_price['D']))
                    inst_price['D']= pd.to_datetime(inst_price['D'])
                    prices = prices.join(inst_price[['D', 'LSTP']].set_index('D'),how = 'outer')
                    prices = prices.drop([instrument], axis = 1)
                    prices = prices.rename(columns={'LSTP': instrument})

    prices = prices.fillna(method= 'ffill')
    #Banku maybe print message if there are duplicates

    prices= prices[~prices.index.duplicated(keep='first')]
    prices = prices.fillna(0).drop_duplicates()

    return prices
    
def DeleteDatesAsset(df, datelist):
    df=df.set_index('Date')
    for d in datelist:
        if d in df.index:
            print("deleting ", d)
            df = df.drop(d)
    df = df.reset_index()
    return df

#delete dates from asset exposure report created by Sim.py      
def DeleteDates (idir, odir, colnames,datelist):
    tmpcols = colnames.copy()
    tmpcols.insert(0, 'Date')
    print(tmpcols)
    #df = pd. read_csvíos, path.join(idir, "AssetExposure. txt"), sep= index_col='Date', names = tmpcols)
    df = pd.read_csv (os.path.join(idir, "AssetExposure.txt"), sep=' ', names = tmpcols)
    df ['Date']= pd.to_datetime(df[ 'Date'], format="%Y%m%d")
    df= df.set_index ('Date')
    print(df.index)
    #datelist = ['2016-01-01', '2016-02-19', '2016-02-26', '2017-12-22']
    #datelist =['2018-11-09']
    #datelist =['20160101', '20160219', '20160226', '20171222')
    print(df.columns)
    # #print(df. index)
    print (pd.to_datetime (datelist))
    for d in datelist:
        df = df.drop(d)
        if d in df.index:
            print(df.loc[d])
    df=df.reset_index()
    print(df['Date'])
    print(type(df['Date']))
    print(df.columns)
    df ['Date']=df ['Date'].apply (lambda x: x.strftime ("%Y%m%d"))
    df.to_csv(os.path.join(odir, "AssetExposure4del.txt"), sep=' ',columns=tmpcols, index=False, header=False)


def DeleteWeekends(df,indexCol='Date', indexed=False):
    if not indexed:
        df.set_index(indexCol,inplace=True)
    dfWeekends = df[pd.to_datetime(df.index).dayofweek >= 5]
    print("num of weekends: ",len(dfWeekends))
    df = df[pd.to_datetime(df.index).dayofweek < 5]
    df=df.reset_index()

    return df
