#!/big/svc_wqln/projects/python/conda/bin/python3.6

#Sample
#SingleTestSimWrapper.py -alphas /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V5/alphasA.txt -baseDirA /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsAlpha -version V2 -inputDir /home/lanarayan/MyTests -copyPosDate 20170926 -simDate 20190929 -copyPos -exeDir /home/lana -wqStart 07:00:00 -norun
#SingleTestSimWrapper.py -alphas /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V5/alphasA.txt -baseDirA /home/lanarayan/MLData/BacktestsAlpha -baseDirB /home/lanarayan/MLData/BacktestsAlpha -version V2 -inputDir /home/lanarayan/MyTests -copyPosDate 20170929 -simDate 20190930 -copyPos -exeDir /home/lana -wqStart 07:00:00 -norun

import logging
import argparse
import os
import shutil
from datetime import datetime,timedelta
import pandas as pd
import xml.etree.ElementTree as et
import numpy as np
from pandas.tseries.offsets import BDay

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("-alphas", "--alphas", default='/big/svc_wqln/ML/BacktestsAlpha/AlphaList/V5/alphasA.txt',
                        help="alpha list file with path.")
    parser.add_argument('-simDate', '--simDate', default='', help="e.g 20190101 used with copyPos True option")
    parser.add_argument('-baseDirA', '--baseDirA', default='/home/lanarayan/MLData/BacktestsAlpha', help="")
    parser.add_argument('-baseDirB', '--baseDirB', default='', help="/home/MLData/BacktestsAlpha")
    parser.add_argument('-dataDir', '--dataDir', default='/home/lanarayan/MLData/Futures/Live', help="source Data dir;Fx for Futures;MLData/SimDaily for evening data")
    parser.add_argument('-inputDir', '--inputDir', default='/home/lanarayan/Tests', help="")
    parser.add_argument('-version', '--version', default='', help="V2")
    parser.add_argument('-wqStart', '--wqStart', default='', help="07:00:00")
    parser.add_argument('-copyPosDate', '--copyPosDate', default='',
                        help="e.g 20190801. Date used to create dir path to get openpositions.txt for coping ")

    parser.add_argument('-exeDir', '--exeDir', default='/home/lanarayan/MLData/UATDev/DaVinciWIP/build', help="exe dir for testSimulator")
    parser.add_argument('-norun', '--norun', action='store_true',
                        help="if param provided  do not run test SingleTestSimWrapper")
    parser.add_argument('-copyPos', '--copyPos', action='store_true',
                        help="if param provided copy openpositions.txt from folder date copyPosDate")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)


    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath, 'SingleTestSimWrapper-' + dateForLog + '.log'),
                        filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    colNamesList = ['name','frequency','pname']
    dfAlphas = pd.read_csv(args.alphas,names=colNamesList)

    # running on Sunday
    #singleTestSim.py -asset EURUSD -frequency 1H -params 0 -baseDirA /home/lanarayan -version V2 -inputDir /home/lanarayan/Tests -copyPosDate 20170926 -simDate 20190929 -copyPos -exeDir /home/lana -wqStart 07:00:00

    # running on Tuesday
    # singleTestSim.py -asset EURUSD -frequency 1H -params 0 -baseDirA /home/lanarayan -version V2 -inputDir /home/lanarayan/Tests -copyPosDate 20170929 -simDate 20190930 -copyPos -exeDir /home/lana -wqStart 07:00:00
    for index, row in dfAlphas.iterrows():
        simDate= pd.to_datetime(args.simDate)
        if simDate.dayofweek == 6:
            copyPosDate = simDate - timedelta(3)
            print("simDate ", simDate," is a Sunday. CopyPosDate should be Thursday.CopyPosDate is :", copyPosDate)
            logging.debug("simDate {} is a Sunday. CopyPosDate should be Thursday {}. CopyPosDate is:".format(simDate,copyPosDate))
        else:
            copyPosDate = simDate - timedelta(1)
            print("simDate ", simDate, " is not a Sunday. CopyPosDate should be day before simdate. CopyPosDate is:", copyPosDate)
            logging.debug("simDate {} is not a Sunday. CopyPosDate should be day before simdate {}. CopyPosDate is".format(simDate,copyPosDate))

        copyPosDateStr = copyPosDate.strftime('%Y%m%d')
        cmd = '-asset ' + row['name'] + ' -frequency ' + row['frequency'] + ' -params 0' + ' -baseDirA ' + args.baseDirA
        cmd = cmd  + ' -baseDirB ' + args.baseDirB + ' -dataDir ' + args.dataDir
        cmd = cmd + ' -version ' + args.version + ' -inputDir ' + args.inputDir + ' -copyPosDate ' + copyPosDateStr + ' -simDate ' + args.simDate
        cmd = cmd +  ' -exeDir ' + args.exeDir + ' -wqStart ' + args.wqStart

        if args.copyPos:
            cmd = cmd + " -copyPos "

        if args.norun:
            cmd = cmd + " -norun "

            print("Not running SingleTestSim.py ", cmd)
            logging.debug("Not running SingleTestSim.py {}".format(cmd))
        else:
            print("Invoking SingleTestSim.py ",cmd)
            logging.debug("Invoking SingleTestSim.py {}".format(cmd))
            os.system('/home/lanarayan/MyProjects/ML/SingleTestSim.py ' + cmd)

if __name__ == '__main__':
     main()