#!/big/svc_wqln/projects/python/conda/bin/python3.6

import logging
import argparse
from datetime import datetime, timedelta
import os
import shutil


StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Kondratiev':['CME_CLU7','CME_LCOU7']}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MLData/Backtests/Fit-B-2014', help="Source dir for Strat B")
    parser.add_argument('-f', '--fromDate', default='20180401', help="from date")
    parser.add_argument('-t', '--toDate', default='20190422', help="to date")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    # parser.add_argument('-log', '--logPath', default='C:/MyProjects/PyCharmProjects/HelloWorldProj',
    #                                   help="log file  path")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")

    args = parser.parse_args()
    print(args)

    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath, 'DeleteStratBDirs-' + dateForLog + '.log'),
                        filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    dateInputList=[]
    # date range
    # d1 = date(2017, 8, 15)  # start date
    # d2 = date(2017, 9, 15)  # end date
    d1 = datetime.strptime(args.fromDate, '%Y%m%d')
    d2 = datetime.strptime(args.toDate, '%Y%m%d')
    delta = d2 - d1  # timedelta

    for i in range(delta.days + 1):
        # print(d1 + timedelta(days=i))
        dateInputList.append((d1 + timedelta(days=i)).strftime("%Y%m%d"))
    #shutil.rmtree("C:\MyTemp\B")
    #/Backtests/Fit-B-2014/Smith/1m/params-0/20181230/Spread
    for spread in StrategyBMap.keys():
        logging.debug("Spread: {} ".format(spread))
        for x in range(26):
            for dt in dateInputList:
                param = 'params-' + str(x)
                path = os.path.join(args.baseDir,spread,'1m',param,dt,'Spread')
                print("Path: ",path)

                if os.path.isdir(path):
                    logging.debug("Checking: {} ".format(path))

                    dir_list = next(os.walk(path))[1]
                    print(dir_list)
                    logging.debug("Dir list: {} ".format(dir_list))


                    if len(dir_list) > 3:
                        combinedLegs = StrategyBMap[spread][0] + StrategyBMap[spread][1]
                        dirForRemove = os.path.join(path,combinedLegs)
                        print("Removing:", dirForRemove)
                        logging.debug("Removing: {} ".format(dirForRemove))
                        shutil.rmtree(dirForRemove)


if __name__ == '__main__':
     main()