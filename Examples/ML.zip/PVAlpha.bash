#!/bin/bash
FROM=20190822
TO=20190825
ALPHAS=/home/lanarayan/MLData/BacktestsAlpha/AlphaList/V5/alphasA.txt 
BASEA=/home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019
#ALPHAS=/home/lanarayan/MLData/BacktestsDailySim/AlphaList/V1/alphasA.txt 
#BASEA=/home/lanarayan/MLData/BacktestsDailySim/Fit-A-2019
#to select production area
#BASEA=/home/lanarayan/UAT/VishnuWIP/build
PRUNEFUTURES=0
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=$FROM end=$TO file=positions.txt alpha=/home/lanarayan/MLData/BacktestsTest/Alphas/alphas1HSmall.txt baseA=/home/lanarayan/MLData/BacktestsTest/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v"
gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=$FROM end=$TO file=positions.txt alpha=$ALPHAS baseA=$BASEA baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v prunefutures=$PRUNEFUTURES"


xdg-open file:///home/lanarayan/MyProjects/WQMaster/nodejsDev/PositionJQXClient.html

#/home/lanarayan/MyProjects/ML/GraphSimPV.bash -f $FROM  -t $TO -v V1 -e Test -g 1