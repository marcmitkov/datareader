#!/bin/bash
FROM=20190626
TO=20190828
PORT=5050
ALPHA=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasTest.txt
BASEA=/home/lanarayan/UAT/VishnuWIP/build
BASEB=/home/lanarayan/MLData/Backtests/Fit-B-2014 

#/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190618 end=20190630 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasA.txt baseA=/home/lanarayan/UAT/VishnuWIP/build baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v
echo gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=$FROM end=$TO file=positions.txt alpha=$ALPHA baseA=$BASEA baseB=$BASEB port=$PORT mode=v"
gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=$FROM end=$TO file=positions.txt alpha=$ALPHA baseA=$BASEA baseB=$BASEB port=$PORT mode=v"
##xdg-open file://home/lanarayan/MyProjects/WQMaster/nodejsDev/PositionJQXClient.html?port=$PORT
xdg-open file:///home/lanarayan/MyProjects/WQMaster/nodejsDev/PositionJQXClient.html

