#!/big/svc_wqln/projects/python/conda/bin/python3.6

# Sample Command : -baseDirA /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-B-2014 -inputDir /home/lanarayan/MyTestsNew   -asset ES -params 0 -frequency 1H -version V10 -exeDir /home/lanarayan/MLData/UATDev/DaVinciFinal/build



import logging
import argparse
import os
import shutil
from datetime import datetime
import xml.etree.ElementTree as et



# Sample Command : -baseDirA /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsAlpha/Fit-B-2014 -inputDir /home/lanarayan/MyTestsNew -outputDir /home/lanarayan/MyTestsNew  -asset ES -params 0 -frequency 1H -version V10

StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7'],'Bernanke':['CME_TNU7','CME_AULU7']}


def EditConfigFile(asset,inputDir):
    legs = []
    if asset in StrategyBMap:
        legsArr = StrategyBMap[asset]
        legs.append(legsArr[0].split('_')[1][:-2])
        legs.append(legsArr[1].split('_')[1][:-2])
    else:
        legs.append(asset)

    treeCfg = et.parse(os.path.join(inputDir, "config.xml"))
    rootCfg = treeCfg.getroot()
    for elem in rootCfg.iter('Instrument1'):
        # update File node
        node = elem.find('File')
        if asset in StrategyBMap:
            prodNode = elem.find('Product')
            if prodNode.text == legsArr[0].split('_')[1]:
                node.text = os.path.join(inputDir, legs[0]+ ".csv")
            else:
                node.text = os.path.join(inputDir, legs[1]+ ".csv")

        else:
            node.text = os.path.join(inputDir, legs[0]+ ".csv")
    for elem in rootCfg.iter('Instrument2'):
        # update File node
        node = elem.find('File')
        prodNode = elem.find('Product')
        if prodNode.text == legsArr[1].split('_')[1]:
            node.text = os.path.join(inputDir, legs[1]+ ".csv")
        else:
            node.text = os.path.join(inputDir, legs[0] + ".csv")

    shutil.copyfile(os.path.join(inputDir, 'config.xml'), os.path.join(inputDir, 'configOld.xml'))

    treeCfg.write(os.path.join(inputDir, 'config.xml'))

def main():

    #Note: If asset is StratA arguments with suffixA will be used else args with suffix B will be used
    #params,frequency and exeDir args used in both cases
    #config file copied has to be manually changed
    parser = argparse.ArgumentParser()

    parser.add_argument('-asset', '--asset', default='Smith', help="Smith , 1YM etc")
    parser.add_argument('-params', '--params', default='0', help="param number e.g 0 1 2 ")
    parser.add_argument('-frequency', '--frequency', default='1m', help="1m or 1H or 4H or 15m or 1D")
    parser.add_argument('-baseDirA', '--baseDirA', default='/home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019', help="Source dir for Strat A")
    parser.add_argument('-baseDirB', '--baseDirB', default='/home/lanarayan/MLData/BacktestsAlpha/Fit-B-2014', help="Source dir for Strat B")
    parser.add_argument('-version', '--version', default='V1', help="V , V1 etc ")
    parser.add_argument('-inputDir', '--inputDir', default='/home/lanarayan/MyTestsNew', help="StratA: Destination dir for copying config,data files")
    parser.add_argument('-outputDir', '--outputDir', default='/home/lanarayan/MyTestsNew', help="StratA: Output positions dir for testSimulator")
    parser.add_argument('-nocopy', '--nocopy', action='store_true', help="if param provided run test Sim only, no copying done")
    parser.add_argument('-norun', '--norun', action='store_true', help="if param provided  do not run test Sim; only copying done")
    parser.add_argument('-exeDir', '--exeDir', default='/home/lanarayan/MLData/UATDev/DaVinciFinal/build', help="Strategy: A or B")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    #May 29
    # make this the output -o /home/lanarayan/MyTests/V10/OutputsA/ES/15m/params-0
    #parser.add_argument('-log', '--logPath', default='C:/MyProjects/PyCharmProjects/HelloWorldProj',
    #                                   help="log file  path")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)


    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath, 'SingleTestSim-' + dateForLog + '.log'),
                        filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    if args.asset in StrategyBMap:
        inputSimDir = os.path.join(args.inputDir,args.version,"InputsB")
        outputSimDir = os.path.join(args.inputDir,args.version,"OutputsB",args.asset,args.frequency,"params-" + args.params)
    else:
        inputSimDir = os.path.join(args.inputDir, args.version, "InputsA")
        outputSimDir = os.path.join(args.inputDir, args.version, "OutputsA",args.asset,args.frequency,"params-" + args.params)

    if not args.nocopy:
        if not os.path.exists(inputSimDir):
            print("Creating input folder :" + inputSimDir)
            os.makedirs(inputSimDir)
        if not os.path.exists(outputSimDir):
            print("Creating output folder :" + outputSimDir)
            os.makedirs(outputSimDir)

        if args.asset in StrategyBMap:
            #path for getting params, config
            path = os.path.join(args.baseDirB, args.asset, args.frequency)
            param = "params-" + args.params # param name
            paramsFile = os.path.join(path, param, "params.xml")
            configFile = os.path.join(path, param, "config.xml")

            #path for getting data files
            legs = StrategyBMap[args.asset]
            legs0 = legs[0].split('_')[1][0:-2]  # TU
            legs1 = legs[1].split('_')[1][0:-2]  # TY
            dataFile1 = os.path.join(path,legs0 +".csv")
            dataFile2 = os.path.join(path,legs1 +".csv")

            #Copy params,config and data files
            print("Copying ", paramsFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(paramsFile,inputSimDir))
            shutil.copy(paramsFile,inputSimDir)

            print("Copying ", configFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(configFile,inputSimDir))
            shutil.copy(configFile, inputSimDir)

            print("Copying ", dataFile1, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(dataFile1,inputSimDir))
            shutil.copy(dataFile1,inputSimDir)

            print("Copying ", dataFile2, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(dataFile2,inputSimDir))
            shutil.copy(dataFile2,inputSimDir)
            EditConfigFile(args.asset, inputSimDir)

        else:
            # path for getting params, config and datafiles
            path = os.path.join(args.baseDirA, args.asset, args.frequency)
            param = "params-" + args.params

            paramsFile = os.path.join(path, param, "params.xml")
            configFile = os.path.join(path, param, "config.xml")
            dataFile = os.path.join(path,args.asset + ".csv")

            # Copy params,config and data file
            print("Copying ", paramsFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(paramsFile,inputSimDir))
            shutil.copy(paramsFile, inputSimDir)

            print("Copying ", configFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(configFile,inputSimDir))
            shutil.copy(configFile, inputSimDir)

            print("Copying ", dataFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(dataFile,inputSimDir))
            shutil.copy(dataFile, inputSimDir)

            EditConfigFile(args.asset, inputSimDir)


    if not args.norun:
        cmd = " -r " + inputSimDir + " -o " + outputSimDir

        exePath = os.path.join(args.exeDir, "TestSimulator")
        print("Executing " + exePath + cmd)
        logging.debug("Executing {}".format(exePath + cmd))

        os.chdir(args.exeDir)

        os.system(exePath + cmd)

    print("SingleTestSim done with norun=",args.norun, " and nocopy=",args.nocopy)



if __name__ == '__main__':
     main()