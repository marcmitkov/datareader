#!/bin/bash
#baseB=DaVinci 
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js  start=20190521 end=20190525 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasTest.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/UATDev/DaVinciLatest/build"

#baseB=backtests
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190530 end=20190604 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasTest3.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v"

#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20150101 end=20160604 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasTestA.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v"

#baseA=MyTests/V10
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190101 end=20190531 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasTest2.txt baseA=/home/lanarayan/MyTests/V10/OutputsA baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=q"


#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190101 end=20190525 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasTest3.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014"
# Added for BacktestsTest dir
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20150101 end=20160604 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasTestA.txt baseA=/home/lanarayan/MLData/BacktestsTest/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v"

FROM=20190628
TO=20191231
ALPHAS=/home/lanarayan/MLData/BacktestsDailySim/AlphaList/V1/alphasA.txt 
BASEA=/home/lanarayan/MLData/BacktestsDailySim/Fit-A-2019
#ALPHAS=/home/lanarayan/MLData/BacktestsAlpha/AlphaList/V1/alphasA.txt 
#BASEA=/home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019
PRUNEFUTURES=0
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=$FROM end=$TO file=positions.txt alpha=/home/lanarayan/MLData/BacktestsTest/Alphas/alphas1HSmall.txt baseA=/home/lanarayan/MLData/BacktestsTest/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v"
gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=$FROM end=$TO file=positions.txt alpha=$ALPHAS baseA=$BASEA baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014 mode=v prunefutures=$PRUNEFUTURES"


xdg-open file:///home/lanarayan/MyProjects/WQMaster/nodejsDev/PositionJQXClient.html

#/home/lanarayan/MyProjects/ML/GraphSimPV.bash -f $FROM  -t $TO -v V1 -e Test -g 1