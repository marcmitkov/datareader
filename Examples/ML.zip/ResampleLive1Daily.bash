#!/bin/bash
export PROMPT_COMMAND="echo -ne '\033]0;Resample $HOSTNAME $PWD\007'"

#FROMDATE=`date +%Y%m%d`

#echo $FROMDATE

#ASSETTYPE=Futures
#Change OFFSET to run for prior days 0 will run for today
USEOFFSET=""
OFFSET=0
BASE=/home/lanarayan/WQData
BASEOUTMAIN=/home/lanarayan/MLData
BASEOUT=/home/lanarayan/MLData/SimDaily
LOGFILE=${BASEOUT}/ResampleLive1Sim.log
ROOT=/home/lanarayan/MyProjects/ML

[ -e ${LOGFILE} ] && cp ${BASEOUT}/ResampleLive1Sim.log ${BASEOUT}/ResampleLive1Sim_bkup.log
[ -e ${LOGFILE} ] && rm ${LOGFILE}
#[ -e ${LOGFILE} ] && cp ${BASEOUT}/ResampleLive1Sim.log ${BASEOUT}/ResampleLive1Sim_bkup.log
#[ -e ${LOGFILE} ] && rm ${LOGFILE}
#for i in ES NQ 1YM CL EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF EURGBP
#for i in ES NQ 1YM CL FV TY TU US LCO EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF EURGBP
for i in ES NQ 1YM CL FV TY TU US LCO TN AUL JY URO BP SF CD AD EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF EURGBP AUDUSD GC
#for i in ES
do
  if [ "$i" == "ES" ] || [ "$i" == "NQ" ] || [ "$i" == "1YM" ] || [ "$i" == "CL" ] || [ "$i" == "FV" ]|| [ "$i" == "TY" ]|| [ "$i" == "TU" ]|| [ "$i" == "US" ]|| [ "$i" == "LCO" ] || [ "$i" == "TN" ]|| [ "$i" == "AUL" ] || [ "$i" == "JY" ] || [ "$i" == "URO" ] || [ "$i" == "BP" ] || [ "$i" == "SF" ] || [ "$i" == "CD" ] || [ "$i" == "AD" ] || [ "$i" == "GC" ];
  then
  ASSETTYPE=Futures
  else
  ASSETTYPE=FX
  fi
  #STEP1: generate 1m data from original daily 1m source files in WQData($BASE) for the current date 8am to 10 PM (3am to 5 pm est)
  # 	  output: 1m_live.csv in ${BASEOUT}/${ASSETTYPE}/Live
  #cp ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live_bak.csv
  echo ${ROOT}/LiveDataFilterDaily.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET} ${USEOFFSET}
  ${ROOT}/LiveDataFilterDaily.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET} ${USEOFFSET}
  
  if [ $? -eq 0 ]
  then
	echo "PASS LiveDataFilter ${i}" 
	echo "PASS LiveDataFilter ${i}" >>${LOGFILE} 
  else
	echo "FAIL $? - ${i}"
	echo "FAIL $?  ${ROOT}/LiveDataFilterDaily.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET}" >>${LOGFILE} 
	exit 1
	
  fi

  #STEP2: resample the 1m_live.csv output from Step1; output ${j}_live.csv e.g 1H_live.csv , 4H_live.csv etc in ${BASEOUT}
  for j in 1D 4H 1H 15m
  do
        FREQ=${j}
        if [ "$j" == "15m" ]; then
                FREQ=15min
        fi
        #UN code       
        echo ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}
        ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}
		if [ $? -eq 0 ]
		then
			echo "PASS Resampling ${i} ${j}" 
			echo "PASS Resampling ${i} ${j}">>${LOGFILE} 
		else
			echo "FAIL $? - ${i} ${j}"
			echo "FAIL $? ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}" >>${LOGFILE} 
			exit 1 
		fi	
			
		#Eliminate header from xx_live.csv and append to ${j}_100.csv 
		#output : ${j}_resample.csv in ${BASEOUT}
		echo ' ed "${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv" <<<$'1d\nwq\n' '
		echo "cat ${BASEOUTMAIN}/${ASSETTYPE}/Live/${i}/${j}_100.csv	${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv"
		ed "${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv" <<<$'1d\nwq\n' 
                cat ${BASEOUTMAIN}/${ASSETTYPE}/Live/${i}/${j}_100.csv    ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv

  done
  
  
done
	
exit  0

#WQData has minutes date from 00:00:00 to 23:59:00
#1) ResampleLive1.bash
#Change baseout MLData/Futures/Sim

#2) LiveDataFilter.py
#Change snip time to currentdate 8am to 10 PM ( 3am EST to 5 pm est)

#3) RunAlphaList.py
# create Data file : Read 100_files from MLdata/Futures/Live/ES add 4H_live.csv created in MLData/Futures/Sim/ES etc
 
# B
# 1)just align ES and NQ fr0m MLData/Futures/Sim/ES into Sim/ESNQ
 #2) Read _2 files from MLdata/Futures/Live/ES and add output file from step1 above