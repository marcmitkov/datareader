#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import argparse
import glob
from datetime import date, timedelta
from datetime import datetime
import os
import logging

portfolioSimCols = ['Date','Pnl', 'Long', 'Short', 'BookSize', 'HoldingValue', 'Trading Value', 'HeldShares', 'TradedShares']

stratAList =["US", "ES", "NQ", "1YM", "CL", "LCO", "TY","AUL","GC", "TN", "FV","TU","JY","URO","EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]
def CheckDuplicates(df1, baseOutDir,file):
    if len(df1[df1.duplicated(['Date'],keep='first')]) > 0 :
        dftmp = df1[df1.duplicated(['Date'],keep='first')]
        #print('duplicated:', dftmp)
        logging.debug('duplicated \n {}:'.format(dftmp))
        print('# duplicated :', len(dftmp))
        logging.debug('# duplicated :', len(dftmp))
        dftmp.to_csv(os.path.join(baseOutDir, "Duplicates_" + file + ".csv"), index=False)


def main():
    parser = argparse.ArgumentParser(description="Create Positions Reports Script")

    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MLData/BacktestsAlpha/OutSim',
                            help="base Directory")
    #parser.add_argument('-f', '--fromDate', default='19991001', help="from date")
    #parser.add_argument('-t', '--toDate', default='20201021', help="to date")
    parser.add_argument('-baseOut', '--baseOutDir', default='/home/lanarayan/MLData/BacktestsAlpha/OutSim',
                            help="output Directory")
    parser.add_argument('-sep', '--separator', default=' ',
                        help="separator/delimiter for input PortfolioExposure.csv and output file")
    parser.add_argument('-r', '--reportType', default='PE',
                        help="PE for PortfolioExposure; asset for asset Reports")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                            choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                            help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")
    args, unknown = parser.parse_known_args()
    print(args)

    parser.print_help()
    args = parser.parse_args()
    print(args)

    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath, 'ProcessPEDate-' + dateForLog + '.log'),
                        filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)

    fileList=[]

    if args.reportType == "PE":
        fileList.append("PortfolioExposure")
        dateFormat = '%Y%m%d'
    elif args.reportType == "asset":
        fileList = stratAList
        dateFormat = '%Y-%m-%d'
    else:
        print("Incorrect report type")
        exit(1)

    for file in fileList:
        filePath = os.path.join(args.baseDir,file + ".csv")

        if not os.path.exists(os.path.join(filePath)):
            print("File does not exist: ", filePath)
            logging.debug("File does not exist: {} ".format(filePath))
            continue;
        dfFile = pd.read_csv(filePath,sep=args.separator)

        dfFile["Date"] = pd.to_datetime(dfFile['Date'], format=dateFormat)
        #dfFileNew = pd.DataFrame()
        #increment all dates by a day
        for index, row in dfFile.iterrows():
            date = row["Date"]
            print("date: ",date)
            date += timedelta(days=1)
            print("date +1 : ",date)
            print("weekday : ", date.weekday())
            dfFile.loc[index,"Date"] = date

        #print first duplicate
        CheckDuplicates(dfFile,args.baseOutDir,file)

        dfFile.set_index("Date", inplace=True)
        dfFile.sort_index(inplace=True)
        # if duplicated dates keep first
        dfNew = dfFile[~dfFile.index.duplicated(keep='first')]

        #Get weekends and log df
        dfWeekends = dfNew[pd.to_datetime(dfNew.index).dayofweek >= 5]
        print("num of weekends in ", file, " :", len(dfWeekends))
        logging.debug("num of weekends in {}: {} ".format(file,len(dfWeekends)))
        #print("Weekends in ",file, " :", dfWeekends)
        logging.debug("Weekends in {} \n {}".format(file,dfWeekends))
        dfWeekends.to_csv(os.path.join(args.baseOutDir,"Weekends_" + file + ".csv"),index=True,sep=args.separator)

        #get df of week days only
        dfNew = dfNew[pd.to_datetime(dfNew.index).dayofweek < 5]
        #print("Aligned df for ",file, " :",dfNew)
        logging.debug("Aligned df for {}:  \n {}".format(file,dfNew))

        dfNew.to_csv(os.path.join(args.baseOutDir, file +"New.csv"), index=True, sep=args.separator,
                     date_format=dateFormat)
        print("Aligned file output for ",file, " in: ", os.path.join(args.baseOutDir, file,"New.csv"))
        logging.debug("Aligned file output for {} in: {}".format(file, os.path.join(args.baseOutDir, file,"New.csv")))

if __name__ == '__main__':
    main()