#!/bin/bash
export PROMPT_COMMAND="echo -ne '\033]0;Resample $HOSTNAME $PWD\007'"

#FROMDATE=`date +%Y%m%d`

#echo $FROMDATE

#ASSETTYPE=Futures
OFFSET=1
BASE=/home/lanarayan/WQData
BASEOUT=/home/lanarayan/MLData
LOGFILE=${BASEOUT}/ResampleLive1.log
ROOT=/home/lanarayan/MyProjects/ML


[ -e ${LOGFILE} ] && cp ${BASEOUT}/ResampleLive1.log ${BASEOUT}/ResampleLive1_bkup.log
[ -e ${LOGFILE} ] && rm ${LOGFILE}
for i in JY URO BP SF CD AD
#for i in ES NQ 1YM CL FV TY TU US LCO EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF EURGBP
#for i in TN AUL
#for i in ES NQ 1YM CL FV TY TU US LCO TN AUL EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF EURGBP AUDUSD
do
  if [ "$i" == "ES" ] || [ "$i" == "NQ" ] || [ "$i" == "1YM" ] || [ "$i" == "CL" ] || [ "$i" == "FV" ]|| [ "$i" == "TY" ]|| [ "$i" == "TU" ]|| [ "$i" == "US" ]|| [ "$i" == "LCO" ] || [ "$i" == "TN" ] || [ "$i" == "AUL" ] || [ "$i" == "JY" ] || [ "$i" == "URO" ] || [ "$i" == "BP" ] || [ "$i" == "SF" ] || [ "$i" == "CD" ] || [ "$i" == "AD" ];
  then
  ASSETTYPE=Futures
  else
  ASSETTYPE=FX
  fi
  # generate 1m data for the last 24 hrs
  cp ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live_bak.csv
  echo ${ROOT}/LiveDataFilter.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET}
  ${ROOT}/LiveDataFilter.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET}
  if [ $? -eq 0 ]
  then
	echo "PASS LiveDataFilter ${i}" 
	echo "PASS LiveDataFilter ${i}" >>${LOGFILE} 
  else
	echo "FAIL $? - ${i}"
	echo "FAIL $?  ${ROOT}/LiveDataFilter.py -contract ${i} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live -offset ${OFFSET}" >>${LOGFILE} 
	exit 1
	
  fi
  cp ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_liveCopy.csv
  ed "${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_liveCopy.csv" <<<$'1d\nwq\n'
  #concatenate to existing master file
  cat  ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_liveCopy.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m1.csv
  mv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_bak.csv
  mv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m1.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv

  # resample the last 24 hrs
  for j in 1D 4H 1H 15m
  do
        FREQ=${j}
        if [ "$j" == "15m" ]; then
                FREQ=15min
        fi
        #UN code       
        echo ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}
         ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}
		if [ $? -eq 0 ]
		then
			echo "PASS Resampling ${i} ${j}" 
			echo "PASS Resampling ${i} ${j}">>${LOGFILE} 
		else
			echo "FAIL $? - ${i} ${j}"
			echo "FAIL $? ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m_live.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv  -t ${FREQ}" >>${LOGFILE} 
			exit 1 
		fi
		if [ "$j" == "1D" ]; then
			sed -i '$ d' ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv
                
		fi
        # back up the current resample file if it exists
        cp ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample_bak.csv
        # delete header from the newly resampled file
        ed "${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv" <<<$'1d\nwq\n'
        
        if [ "$j" != "1D" ]; then
                 sed -i '1d' ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv
                
         fi
        
        #concatenate to existing resample file
        cat  ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_live.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample1.csv
        mv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample1.csv ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv
        # get the last 100 lines
        FILEMASTER="${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv"
        a=($(wc ${FILEMASTER}))
        LINECOUNT=${a[0]}
        echo  line count is $LINECOUNT
        # make sure lines are > 100
        if [ "${LINECOUNT}" -gt 100 ]; then
                head -1 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv
                tail -100 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv >> ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv
        fi
  done

done
	
exit  0