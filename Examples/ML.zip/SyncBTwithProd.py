#!/big/svc_wqln/projects/python/conda/bin/python3.6

#sample: -alphas C:/MyProjects/Backtests/Temp/alphas.txt -copyDate 20171212 -source C:/MyProjects/Backtests/StratATest -dest C:/MyProjects/temp/
#sample:-alphas /home/lanarayan/MLData/BacktestsAlpha/AlphaList/V8/alphasA.txt -copyDate 20171212 -source /home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019 -dest /home/lanarayan/UAT/VishnuWIP/build
import pandas as pd
import logging
import argparse
import numpy as np

import os

import shutil
from datetime import datetime,timedelta
import errno

prodExchangeMap = {"1YM": "CBOT", "ES": "CME", "FV": "CBOT", "NQ": "CME", "TN": "CME", "TU": "CBOT", "TY": "CBOT", "US": "CBOT",
                    "AUL": "CBOT","CL": "NYMEX", "LCO": "ICE", "JY": "CMEFX", "URO": "CMEFX", "GC": "COMEX",
                   "AUDUSD": "HOTSPOT", "EURGBP": "HOTSPOT", "EURJPY":"HOTSPOT", "EURUSD": "HOTSPOT", "GBPUSD": "HOTSPOT",
                   "USDCAD": "HOTSPOT", "USDCHF": "HOTSPOT", "USDJPY": "HOTSPOT"}

'''prodSuffixMap = {"1YM": "Z9", "ES": "Z9", "FV": "Z9", "NQ": "Z9", "TN": "Z9", "TU": "Z9", "TY": "Z9", "US": "Z9",
                    "AUL": "Z9","CL": "F0", "LCO": "F0", "JY": "Z9", "URO": "Z9", "GC": "G0"}'''

prodSuffixMap = {"1YM": "Z9", "ES": "Z9", "FV": "H0", "NQ": "Z9", "TN": "H0", "TU": "H0", "TY": "H0", "US": "H0",
                    "AUL": "H0","CL": "F0", "LCO": "G0", "JY": "Z9", "URO": "Z9", "GC": "G0"}

'''BTExchangeMap = {"1YM": "CME", "ES": "CME", "FV": "CBOT", "NQ": "CME", "TN": "CME", "TU": "CBOT", "TY": "CBOT", "US": "CBOT",
                    "AUL": "CBOT","CL": "NYMEX", "LCO": "CME", "JY": "CMEFX", "URO": "CMEFX", "GC": "COMEX",
                   "AUDUSD": "HOTSPOT", "EURGBP": "HOTSPOT", "EURJPY":"HOTSPOT", "EURUSD": "HOTSPOT", "GBPUSD": "HOTSPOT",
                   "USDCAD": "HOTSPOT", "USDCHF": "HOTSPOT", "USDJPY": "HOTSPOT",  "UN":"XXX"}'''

currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]
def copyRecursive(src, dest):
    try:
        shutil.copytree(src, dest)
    except OSError as e:
        # If the error was caused because the source wasn't a directory
        if e.errno == errno.ENOTDIR:
            shutil.copy(src, dest)
        else:
            print('Directory not copied. Error: %s' % e)

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-alphas', '--alphas', default='/home/lanarayan/MLData/BacktestsAlpha/AlphaList/V8/alphasA.txt', help="alphas file")
    parser.add_argument('-copyDate', '--copyDate', default='20190901', help="date folder for copying")
    parser.add_argument('-source', '--source', default='/home/lanarayan/MLData/BacktestsAlpha/Fit-A-2019',
                        help="source  Directory")
    parser.add_argument('-dest', '--dest', default='/home/lanarayan/UAT/VishnuWIP/build',
                        help="destination dir")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath,'SyncBTwithProd-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    '''args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.dest):
        print("Creating output folder :" + args.dest)
        os.makedirs(args.dest)'''
    prodShortNamesMap = {"1YM": "1Y", "URO": "UR"}

    colNamesList = ['name', 'frequency', 'pname']
    dfAllAlphas = pd.read_csv(args.alphas,names=colNamesList)

    for index, row in dfAllAlphas.iterrows():
        asset = row["name"] # GC
        freq = row["frequency"] # 1H
        srcpath = os.path.join(args.source,asset,freq,'params-0',args.copyDate)

        #zz = os.listdir(path=os.path.join(srcpath,'Momentum'))
        #srcpath= os.path.join(srcpath,'Momentum',zz[0])
        if asset in currencyList:
            srcpath = os.path.join(srcpath, 'Momentum',  'FXOTC_' +asset[:3] + '_' + asset[3:])
        else:
            srcpath = os.path.join(srcpath, 'Momentum', 'CME_' + asset + 'U7')
        print("Source path :" + srcpath)
        logging.debug("Source path : {}".format(srcpath))
        if asset in currencyList:
            prodExDir = prodExchangeMap[asset] + '_' +asset[:3] + '_' + asset[3:]
        else:
            prodExDir = prodExchangeMap[asset] +'_' + asset + prodSuffixMap[asset]
        if asset in prodShortNamesMap.keys():  # for name, age in dictionary.iteritems():  (for Python 2.x)
           asset = prodShortNamesMap[asset]

        destPath = os.path.join(args.dest,asset,freq,'params-0',args.copyDate,'Momentum',prodExDir)
        print("Destination path :" + destPath)
        logging.debug("Destination path : {}".format(destPath))
        if not os.path.exists(destPath):
            print("Creating  folder :" + destPath)
            logging.debug("Creating  folder : {}".format(destPath))
            os.makedirs(destPath)

        posFile = os.path.join(srcpath,"positions.txt")
        openposFile = os.path.join(srcpath,"openpositions.txt")
        standposFile = os.path.join(srcpath,"standingpositions.txt")
        minutesFile = os.path.join(srcpath, "minutes.txt")

        print("Copy file ", posFile, " to ", destPath)
        logging.debug("Copy file {} to {}".format(posFile, destPath))
        shutil.copy(posFile, destPath)

        print("Copy file ", openposFile, " to ", destPath)
        logging.debug("Copy file {} to {}".format(openposFile, destPath))
        shutil.copy(openposFile, destPath)

        print("Copy file ", standposFile, " to ", destPath)
        logging.debug("Copy file {} to {}".format(standposFile, destPath))
        shutil.copy(standposFile, destPath)

        print("Copy file ", minutesFile, " to ", destPath)
        logging.debug("Copy file {} to {}".format(minutesFile, destPath))
        shutil.copy(minutesFile, destPath)
        #copyRecursive(srcpath,destPath)




if __name__ == '__main__':
    main()