#!/big/svc_wqln/projects/python/conda/bin/python3.6

import os


os.system("{ cat ./A.csv; sed '1d' ./B.csv; } > ./B.csv")