#!/bin/bash 

#script for running BacktestAlpha for a specific past date. NOTE: -useDates needs to be added to command 

FROM=20191223 #date for which folder is to be created
TO=${FROM}

NEXTDAY= date -d  "$TO next day" +%Y%m%d
echo $NEXTDAY
/home/lanarayan/MyProjects/ML/RunAlphaListDailySim.py -paramsDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseOutDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -alpha /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -ex /home/lanarayan/MLData/UATDev/TestSimulatorWIP/build -baseDataDir /home/lanarayan/MLData -masterParams /home/lanarayan/MyProjects/ML/paramsPROD.xml -configSrcDir /home/lanarayan/MyProjects/ML/Configs -s ${NEXTDAY} -e ${NEXTDAY} -daily -test -useDates
/home/lanarayan/MyProjects/ML/Sim.py -baseDir /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -f ${FROM} -t ${TO} -alphas /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -wt /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/weightsA.txt -baseOut /big/svc_wqln/ML/BacktestsAlpha/OutSim/Fit-A-2019/V8 -sliceFactor 0 -sliceDate 20160301 -tcFactorA 0 -tcFactorB 10 -arA 0 -arB 0 -factorA 0.4 -factorB 0.1 -varFactorA 0.4 -varFactorB 1 -backtestAlpha -unrealizedpnl
/home/lanarayan/MyProjects/ML/PosReportAlphaNew.py -baseDirA /big/svc_wqln/ML/BacktestsAlpha/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsAlpha/Fit-B-2014 -baseOut /big/svc_wqln/ML/BacktestsAlpha/PosOut/Fit-A-2019/V8 -f ${FROM} -t ${TO} -alphaFile /big/svc_wqln/ML/BacktestsAlpha/AlphaList/V8/alphasA.txt -groupBy Strategy -mode v
