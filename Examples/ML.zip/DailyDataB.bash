#!/bin/bash
/home/lanarayan/MyProjects/ML/AlignLive.bash
/home/lanarayan/MyProjects/ML/MergeTwoDays.bash
echo StratB |mail -s 'Done B' lanarayan@worldquant.com