#!/bin/bash


cd /home/lanarayan/MyProjects/ML/Configs

cp config-ES-15m.xml config-JY-15m.xml
cp config-ES-15m.xml config-URO-15m.xml
cp config-ES-15m.xml config-BP-15m.xml
cp config-ES-15m.xml config-SF-15m.xml
cp config-ES-15m.xml config-CD-15m.xml
cp config-ES-15m.xml config-AD-15m.xml


cp config-ES-1H.xml config-JY-1H.xml
cp config-ES-1H.xml config-URO-1H.xml
cp config-ES-1H.xml config-BP-1H.xml
cp config-ES-1H.xml config-SF-1H.xml
cp config-ES-1H.xml config-CD-1H.xml
cp config-ES-1H.xml config-AD-1H.xml

cp config-ES-4H.xml config-JY-4H.xml
cp config-ES-4H.xml config-URO-4H.xml
cp config-ES-4H.xml config-BP-4H.xml
cp config-ES-4H.xml config-SF-4H.xml
cp config-ES-4H.xml config-CD-4H.xml
cp config-ES-4H.xml config-AD-4H.xml


cp config-ES-1D.xml config-JY-1D.xml
cp config-ES-1D.xml config-URO-1D.xml
cp config-ES-1D.xml config-BP-1D.xml
cp config-ES-1D.xml config-SF-1D.xml
cp config-ES-1D.xml config-CD-1D.xml
cp config-ES-1D.xml config-AD-1D.xml  