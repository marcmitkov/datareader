
#/home/lanarayan/clion-2017.3.4/bin/cmake/bin/cmake --build /home/lanarayan/MLData/UATDev/DaVinciFinal/build --target DaVinci -- -j 24
gedit ~/MyProjects/ML/ok.bash ~/UAT/VishnuWIP/build/configLive.xml ~/UAT/VishnuWIP/build/params.xml &
exit
FREQ=1H
DATE=20190710
ADIR=EUR_GBP
TICKER=HOTSPOT_EUR_GBP

kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
exit
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt&
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt&
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt&
kate ~/UAT/VishnuWIP/build/StratA_${TICKER}_60.txt&
exit


ADIR=1Y
TICKER=CBOT_1YMU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/build/StratA_$TICKER_60.txt
ADIR=NQ
TICKER=CME_NQU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/build/StratA_$TICKER_60.txt
ADIR=ES
TICKER=CME_ESU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/build/StratA_$TICKER_60.txt
ADIR=TY
TICKER=CBOT_TYU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/build/StratA_$TICKER_60.txt
ADIR=US
TICKER=CBOT_USU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/build/StratA_$TICKER_60.txt
ADIR=FV
TICKER=CBOT_FVU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/build/StratA_$TICKER_60.txt
ADIR=CL
TICKER=NYMEX_CLQ9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/build/StratA_$TICKER_60.txt
ADIR=GC
TICKER=NYMEX_GCQ9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/bui  ld/StratA_$TICKER_60.txt
ADIR=JY
TICKER=CMEFX_JYU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/bui  ld/StratA_$TICKER_60.txt
ADIR=UR
TICKER=CMEFX_UROU9
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/openpositions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/positions.txt
kate ~/UAT/VishnuWIP/build/$ADIR/$FREQ/params-0/$DATE/Momentum/$TICKER/standingpositions.txt
kate ~/UAT/VishnuWIP/bui  ld/StratA_$TICKER_60.txt


