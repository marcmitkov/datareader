#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import numpy as np

import pandas as pd
import logging
import argparse
import numpy as np
from math import sqrt, expm1
from pylab import *
from functools import partial
import matplotlib.pyplot as plt
import os
import Common as co
import webbrowser
import xml.etree.ElementTree as et
import pathlib
#<timestamp>, <pnl realized>, <pnl unrealized>, <number of contacts open>
#< timestamp>,< _realizedPnL >,< unrealizedPnL>,< _realizedPnLlegs0><,<
#unrealized0 >,
#< _realizedPnLlegs1> ,"<unrealized1> ,< numC0 > ,< numC1>
def getDataMinutes(csvPath,strategy, endDate, startDate):
    colnames2 = ['t','pnlRealized', 'pnlUnrealized', 'contractsOpenLong','contractsOpenShort']
    colnamesB = ['t','pnlRealized', 'pnlUnrealized', 'realizedPnLlegs0','unrealized0', 'realizedPnLlegs1','unrealized1','numC0','numC1']
    colnamesPos = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                   'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                   'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp']
    if strategy == 'A':
        strategyType = 'Momentum'
        colNamesList = colnames2
    else:
        strategyType = 'Spread'
        colNamesList = colnamesB

    #list of csvs contained in the directory
    csvs = []  
    minutes = pd.DataFrame()
    csvsPositions =[]
    posDF = pd.DataFrame()
    csvsOpenPositions = []
    openPosDF = pd.DataFrame()

    # collect csv filenames and paths
    for dirpath, dirnames, filenames in os.walk(csvPath):
        #print('dirpath1:', dirpath)
        #print('dirnames1:', dirnames)
        #print('filenames1:', filenames)
        for file in filenames:
            print('file2:', dirpath)
            if os.path.splitext(file)[-1] == ".txt":
                if file == "minutes.txt" and dirpath.find(strategyType) != -1:

                    myPath = dirpath.replace('\\','/')
                    tmp = myPath.split('/')[-3]
                    if pd.to_datetime(tmp) > pd.to_datetime(endDate) or pd.to_datetime(tmp) < pd.to_datetime(startDate):
                        continue
                    print('dirpath3:', dirpath)
                    filePath = os.path.join(dirpath,file)
                    print('filePath',filePath)
                    csvs.append(filePath)
                    posFilePath = os.path.join(myPath, "positions.txt")
                    if os.path.exists(posFilePath):
                        csvsPositions.append(posFilePath)
                    openPosFilePath = os.path.join(myPath, "openpositions.txt")
                    if os.path.exists(openPosFilePath):
                        csvsOpenPositions.append(openPosFilePath)
    print(csvs)
    for f in csvs:
        dftmp = pd.read_csv(f,names=colNamesList)
        #dftmp['t'] = dftmp['d'] + ' ' + dftmp['ts']
        dftmp['t'] = pd.to_datetime(dftmp['t'], format='%Y-%b-%d %H:%M:%S')
        dftmp = dftmp.set_index('t')
        print("length df :", len(dftmp))
        minutes = minutes.append(dftmp)
        print("length total df :", len(minutes))

    for f in csvsPositions:
        # read positions.txt into df
        print('file: ', f)
        f = f.replace('\\', '/')
        # get date from file path and change to datetime
        d = f.split('/')[-4]
        dt = pd.to_datetime(d)
        if os.stat(f).st_size == 0:
            posDF = posDF.append({'t': dt, 'Count': int(0)}, ignore_index=True)
            continue;
        dftmpPos = pd.read_csv(f,names=colnamesPos)

        # append to posDf
        #posDF = posDF.append({'t': dt, 'Count': int(len(dftmpPos))}, ignore_index=True)
        sizeSum = dftmpPos['Size'].sum()
        pnlRealizedSum =  dftmpPos['PnlRealized'].sum()
        posDF = posDF.append({'t': dt, 'Count': sizeSum, 'pnlRealized': pnlRealizedSum}, ignore_index=True)

    for f in csvsOpenPositions:
        # read positions.txt into df
        print('file: ', f)
        f = f.replace('\\', '/')
        # get date from file path and change to datetime
        d = f.split('/')[-4]
        dt = pd.to_datetime(d)
        if os.stat(f).st_size == 0:
            openPosDF = openPosDF.append({'t': dt, 'Count': int(0)}, ignore_index=True)
            continue;
        dftmpPos = pd.read_csv(f, names=colnamesPos)

        # append to posDf
        #openPosDF = openPosDF.append({'t': dt, 'Count': int(len(dftmpPos))}, ignore_index=True)
        sizeSum = dftmpPos['Size'].sum()
        openPosDF = openPosDF.append({'t': dt, 'Count': sizeSum}, ignore_index=True)

        #print("length total df :", len(minutes))

    ''''# change to series
    posSeries = pd.Series()
    if len(posDF) > 0:
        posSeries = pd.Series(posDF['Count'].values, index=posDF['t'])
    else:
        print('Empty Series for posCount')'''
    minutes = minutes.sort_index()
    #minutes=minutes.drop(['d', 'ts','vol'],axis=1)
    minutes = minutes.reset_index()
    print(minutes.head())
    return minutes, posDF, openPosDF

def getDataMinutesB(csvPath,strategy, endDate, startDate,legs):
    colnames2 = ['t','pnlRealized', 'pnlUnrealized', 'contractsOpenLong','contractsOpenShort']
    colnamesB = ['t','pnlRealized', 'pnlUnrealized', 'realizedPnLlegs0','unrealized0', 'realizedPnLlegs1','unrealized1','numC0','numC1']
    colnamesPos = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp']

    if strategy == 'A':
        strategyType = 'Momentum'
        colNamesList = colnames2
    else:
        strategyType = 'Spread'
        colNamesList = colnamesB

    #list of csvs contained in the directory
    csvs = []
    minutes = pd.DataFrame()
    csvsPositions1 =[]
    posDF1 = pd.DataFrame()
    csvsOpenPositions1 = []
    openPosDF1 = pd.DataFrame()
    csvsPositions2 = []
    posDF2 = pd.DataFrame()
    csvsOpenPositions2 = []
    openPosDF2 = pd.DataFrame()

    # collect csv filenames and paths
    for dirpath, dirnames, filenames in os.walk(csvPath):
        #print('dirpath1:', dirpath)
        #print('dirnames1:', dirnames)
        #print('filenames1:', filenames)
        dirpathNew = dirpath.replace('\\','/')
        for file in filenames:
            print('file2:', dirpath)

            if os.path.splitext(file)[-1] == ".txt":
                legname = os.path.basename(os.path.normpath(dirpath))
                print("LEG NAME: ", legname)
                if file == "minutes.txt" and dirpath.find(strategyType) != -1:

                    myPath = dirpath.replace('\\','/')
                    tmp = myPath.split('/')[-3]
                    if pd.to_datetime(tmp) > pd.to_datetime(endDate) or pd.to_datetime(tmp) < pd.to_datetime(startDate):
                        continue
                    #print('dirpath3:', dirpath)
                    filePath = os.path.join(dirpath,file)
                    print('Reading ', file, 'in', dirpath)
                    csvs.append(filePath)
                    posFilePath = os.path.join(myPath, "positions.txt")
                    '''if os.path.exists(posFilePath):
                        csvsPositions.append(posFilePath)
                    openPosFilePath = os.path.join(myPath, "openpositions.txt")
                    if os.path.exists(openPosFilePath):
                        csvsOpenPositions.append(openPosFilePath)'''
                if file in ["positions.txt", "openpositions.txt" ]and dirpath.find(strategyType) != -1 and legname == legs[0]:
                    myPath = dirpath.replace('\\', '/')
                    tmp = myPath.split('/')[-3]
                    if pd.to_datetime(tmp) > pd.to_datetime(endDate) or pd.to_datetime(tmp) < pd.to_datetime(startDate):
                        continue
                    print('Reading ', file, 'in', dirpath)
                    filePath = os.path.join(dirpath, file)
                    #print('filePath', filePath)
                    if file == "positions.txt":
                        csvsPositions1.append(filePath)
                    if file == "openpositions.txt":
                        csvsOpenPositions1.append(filePath)
                if file in ["positions.txt", "openpositions.txt" ]and dirpath.find(strategyType) != -1 and legname == legs[1]:
                    myPath = dirpath.replace('\\', '/')
                    tmp = myPath.split('/')[-3]
                    if pd.to_datetime(tmp) > pd.to_datetime(endDate) or pd.to_datetime(tmp) < pd.to_datetime(startDate):
                        continue
                    print('Reading ', file, 'in', dirpath)
                    filePath = os.path.join(dirpath, file)
                    #print('filePath', filePath)
                    if file == "positions.txt":
                        csvsPositions2.append(filePath)
                    if file == "openpositions.txt":
                        csvsOpenPositions2.append(filePath)

    #print(csvs)
    for f in csvs:
        dftmp = pd.read_csv(f,names=colNamesList)
        #dftmp['t'] = dftmp['d'] + ' ' + dftmp['ts']
        dftmp['t'] = pd.to_datetime(dftmp['t'], format='%Y-%b-%d %H:%M:%S')
        dftmp = dftmp.set_index('t')
        #print("length df :", len(dftmp))
        minutes = minutes.append(dftmp)
        print("length total df :", len(minutes))

    for f in csvsPositions1:
        # read positions.txt into df
        #print('file: ', f)
        f = f.replace('\\', '/')
        # get date from file path and change to datetime
        d = f.split('/')[-4]
        dt = pd.to_datetime(d)
        if os.stat(f).st_size == 0:
            posDF1 = posDF1.append({'t': dt, 'Count': int(0)}, ignore_index=True)
            continue;
        #dftmpPos = pd.read_csv(f,header=None)
        dftmpPos = pd.read_csv(f,names=colnamesPos)

        # append to posDf
        #posDF1 = posDF1.append({'t': dt, 'Count': int(len(dftmpPos))}, ignore_index=True)
        sizeSum = dftmpPos['Size'].sum()
        posDF1 = posDF1.append({'t': dt, 'Count': sizeSum}, ignore_index=True)

    for f in csvsOpenPositions1:
        # read openpositions.txt into df
        #print('file: ', f)
        f = f.replace('\\', '/')
        # get date from file path and change to datetime
        d = f.split('/')[-4]
        dt = pd.to_datetime(d)

        if os.stat(f).st_size == 0:
            openPosDF1 = openPosDF1.append({'t': dt, 'Count': int(0)}, ignore_index=True)
            continue;
        dftmpPos = pd.read_csv(f, names=colnamesPos)

        # append to posDf
        #openPosDF1 = openPosDF1.append({'t': dt, 'Count': int(len(dftmpPos))}, ignore_index=True)
        sizeSum = dftmpPos['Size'].sum()
        openPosDF1 = openPosDF1.append({'t': dt, 'Count': sizeSum}, ignore_index=True)

    for f in csvsPositions2:
            # read positions.txt into df
            #print('file: ', f)
            f = f.replace('\\', '/')
            # get date from file path and change to datetime
            d = f.split('/')[-4]
            dt = pd.to_datetime(d)
            if os.stat(f).st_size == 0:
                posDF2 = posDF2.append({'t': dt, 'Count': int(0)}, ignore_index=True)
                continue;
            dftmpPos = pd.read_csv(f, names=colnamesPos)

            # append to posDf
            #posDF2 = posDF2.append({'t': dt, 'Count': int(len(dftmpPos))}, ignore_index=True)
            sizeSum = dftmpPos['Size'].sum()
            posDF2 = posDF2.append({'t': dt, 'Count': sizeSum}, ignore_index=True)

    for f in csvsOpenPositions2:
            # read openpositions.txt into df
            #print('file: ', f)
            f = f.replace('\\', '/')
            # get date from file path and change to datetime
            d = f.split('/')[-4]
            dt = pd.to_datetime(d)
            if os.stat(f).st_size == 0:
                openPosDF2 = openPosDF2.append({'t': dt, 'Count': int(0)}, ignore_index=True)
                continue;
            dftmpPos = pd.read_csv(f, names=colnamesPos)

            # append to posDf
            #openPosDF2 = openPosDF2.append({'t': dt, 'Count': int(len(dftmpPos))}, ignore_index=True)
            sizeSum = dftmpPos['Size'].sum()
            openPosDF2 = openPosDF2.append({'t': dt, 'Count': sizeSum}, ignore_index=True)

        #print("length total df :", len(minutes))

    ''''# change to series
    posSeries = pd.Series()
    if len(posDF) > 0:
        posSeries = pd.Series(posDF['Count'].values, index=posDF['t'])
    else:
        print('Empty Series for posCount')'''
    minutes = minutes.sort_index()
    #minutes=minutes.drop(['d', 'ts','vol'],axis=1)
    minutes = minutes.reset_index()
    print(minutes.head())
    return minutes, posDF1, openPosDF1,posDF2, openPosDF2

def getData(csvPath):
    colnames2 = ['d','ts','open','high','low','close','vol']
    #list of csvs contained in the directory
    csvs = []  
    minutes = pd.DataFrame()

    # collect csv filenames and paths
    for dirpath, dirnames, filenames in os.walk(csvPath):
        for file in filenames:
            if os.path.splitext(file)[-1] == ".csv":
                csvs.append(dirpath + '\\' + file)
    
    for f in csvs:
        dftmp = pd.read_csv(f,names=colnames2)
        dftmp['t'] = dftmp['d'] + ' ' + dftmp['ts']
        dftmp['t'] = pd.to_datetime(dftmp['t'], format='%Y.%m.%d %H:%M')
        dftmp = dftmp.set_index('t')
        minutes = minutes.append(dftmp)


    minutes = minutes.sort_index()
    minutes = minutes.drop(['d', 'ts','vol'],axis=1)
    minutes = minutes.reset_index()
    return minutes

def CreateHtmlReport(consolidatedDF, outputPath):
    htmlHeaders = 't,' + 'ann_return,' + 'ann_sharpe,' + 'params'
    htmlHeadersList = htmlHeaders.split(',')
    htmlStr = co.addHTMLHeadElement() + '<Table><tr>'

    for i in range(len(htmlHeadersList)):
        htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
        print('<th>' + htmlHeadersList[i] + '</th>')
    htmlStr += '</tr>'



    for index, row in consolidatedDF.iterrows():
        htmlStr += '<tr>'
        htmlStr += '<td>' + str(index) + '</td>'
        htmlStr += '<td>' + str(row["ann_return"]) + '</td>'
        htmlStr += '<td>' + str(row["ann_sharpe"]) + '</td>'
        htmlStr += '<td>' + str(row["pval"]) + '</td>'
        htmlStr += '</tr>'

    htmlStr += '</Table>'
    htmlStr += co.addHTMLBodyEndTag()
    combolHtml = os.path.join(outputPath, 'ConsolidatedRetSharpe.html')
    fCombo = open(combolHtml, 'w')
    fCombo.write(htmlStr)
    fCombo.close()
    webbrowser.open_new_tab(combolHtml)

def CreateInceptionHtmlReport(consolidatedDF, outputPath):
    htmlHeaders = 'Total Return,' + 'Sharpe Ratio,' + 'params'
    htmlHeadersList = htmlHeaders.split(',')
    htmlStr = co.addHTMLHeadElement() + '<Table><tr>'

    for i in range(len(htmlHeadersList)):
        htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
        print('<th>' + htmlHeadersList[i] + '</th>')
    htmlStr += '</tr>'

    paramsPath = os.path.join(outputPath, 'ConsolidatedParams.html')
    paramsPathUrl = pathlib.Path(paramsPath).as_uri()

    for index, row in consolidatedDF.iterrows():
        htmlStr += '<tr>'
        #htmlStr += '<td>' + str(index) + '</td>'
        htmlStr += '<td>' + str(row["TotalReturn"]) + '</td>'
        htmlStr += '<td>' + str(row["SharpeRatio"]) + '</td>'
        htmlStr += '<td>'+ '<a href=' + paramsPathUrl +  ' target="_blank">' + str(row["pname"])  + '</a>' +'</td>'
        htmlStr += '</tr>'

    htmlStr += '</Table>'
    htmlStr += co.addHTMLBodyEndTag()
    combolHtml = os.path.join(outputPath, 'ConsolidatedInceptRetSharpe.html')
    fCombo = open(combolHtml, 'w')
    fCombo.write(htmlStr)
    fCombo.close()
    webbrowser.open_new_tab(combolHtml)

def CreateInceptionAndParamsHtmlReport(mergedRetParamsConsolDF,outputPath):
     htmlHeaders = 'pname,' +'Total Return,' + 'Sharpe Ratio,' +'Holding,' + 'Rebalance,' + 'Multiplier,' + 'MultiplierTarget,' +'MultiplierStop'
     htmlHeadersList = htmlHeaders.split(',')
     htmlStr = co.addHTMLHeadElement() + '<Table><tr>'

     for i in range(len(htmlHeadersList)):
         htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
         print('<th>' + htmlHeadersList[i] + '</th>')
     htmlStr += '</tr>'

     for index, row in mergedRetParamsConsolDF.iterrows():
         htmlStr += '<tr>'
         # htmlStr += '<td>' + str(index) + '</td>'
         htmlStr += '<td>' + str(row["pname"]) + '</td>'
         htmlStr += '<td>' + str(row["TotalReturn"]) + '</td>'
         htmlStr += '<td>' + str(row["SharpeRatio"]) + '</td>'
         htmlStr += '<td>' + str(row["HoldingPeriod"]) + '</td>'
         htmlStr += '<td>' + str(row["RebalanceB"]) + '</td>'
         htmlStr += '<td>' + str(row["MultiplierB"]) + '</td>'
         htmlStr += '<td>' + str(row["TargetMultiplierB"]) + '</td>'
         htmlStr += '<td>' + str(row["StopMultiplierB"]) + '</td>'
         htmlStr += '</tr>'

     htmlStr += '</Table>'
     htmlStr += co.addHTMLBodyEndTag()
     combolHtml = os.path.join(outputPath, 'ConsolidatedParamsAndIncept.html')
     fCombo = open(combolHtml, 'w')
     fCombo.write(htmlStr)
     fCombo.close()
     webbrowser.open_new_tab(combolHtml)


def CreateparamsHtmlReport(paramsConsolidatedDF, outputPath):
    htmlHeaders = 'Holding,' + 'Rebalance,' + 'Multiplier,' + 'MultiplierTarget,' +'MultiplierStop,' + 'pname'
    htmlHeadersList = htmlHeaders.split(',')
    htmlStr = co.addHTMLHeadElement() + '<Table><tr>'

    for i in range(len(htmlHeadersList)):
        htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
        print('<th>' + htmlHeadersList[i] + '</th>')
    htmlStr += '</tr>'



    for index, row in paramsConsolidatedDF.iterrows():
        htmlStr += '<tr>'
        #htmlStr += '<td>' + str(index) + '</td>'
        htmlStr += '<td>' + str(row["HoldingPeriod"]) + '</td>'
        htmlStr += '<td>' + str(row["RebalanceB"]) + '</td>'
        htmlStr += '<td>' + str(row["MultiplierB"]) + '</td>'
        htmlStr += '<td>' + str(row["TargetMultiplierB"]) + '</td>'
        htmlStr += '<td>' + str(row["StopMultiplierB"]) + '</td>'

        htmlStr += '<td>'  + str(row["pname"])+  '</td>'
        htmlStr += '</tr>'

    htmlStr += '</Table>'
    htmlStr += co.addHTMLBodyEndTag()
    combolHtml = os.path.join(outputPath, 'ConsolidatedParams.html')
    fCombo = open(combolHtml, 'w')
    fCombo.write(htmlStr)
    fCombo.close()
    #webbrowser.open_new_tab(combolHtml)
###############################################################
def getColumnsList(colLabels):
    colLabelsList = []
    for label in colLabels:
        print(label)
        colLabelsList.append(label)
    return colLabelsList

def daily_log_ret(df):
    return _aggregated_log_ret(df)


def _to_simple_ret(logret):
    return expm1(logret)


def _percent_format(n):
    return '{:{width}.{prec}f} %'.format(n, width=5, prec=2)


def _double_format(n):
    return '{:{width}.{prec}f}'.format(n, width=5, prec=2)


def _to_simple_ret_str(logret):
    return _double_format(_to_simple_ret(logret))


def _sharpe(df):
    aa = df.agg(['mean','std'])
    return sqrt(252) * aa['lret'][0] / aa['lret'][1]


def _updown_months(df):
    m = df.groupby(pd.Grouper(freq='M'))['lret'].sum()
    n = float(len(m[m.values > 0]))
    d = float(len(m[m.values < 0]))
    r=12
    if d != 0:
        r=n/d
    return r


def _updown_month_rets(df):
    m = df.groupby(pd.Grouper(freq='M'))['lret'].sum()
    up_ret = m[m.values > 0].mean() * 100
    down_ret = m[m.values < 0].mean() * 100
    return _double_format(up_ret) + " / " + _double_format(down_ret) + " %"


def _winloss_days(df):
    t = float(len(df))
    w = float(len(df[df['lret'] > 0]))
    l = float(len(df[df['lret'] < 0]))
    f = t - (w + l)
    return _double_format(100 * w / t) + " / " + \
           _double_format(100 * l / t) + \
           " [" + _double_format(100 * f / t) + " ]"


def _risk_of_ruin(df):
    m = df.agg('mean').lret
    s = df.agg('std').lret
    r = sqrt(m ** 2 + s ** 2)
    return ((2 / (1 + (m / r))) - 1) ** (s / r)


# defining sharpe as something annualised
def max_dd(r):
    return np.max(r.expanding().sum().expanding().max() - r.expanding().sum())


def _n_day_analysis(n, df):
    r = df.rolling(n, min_periods=n).sum()
    best = _to_simple_ret(r.max().lret) * 100
    worst = _to_simple_ret(r.min().lret) * 100
    avg = _to_simple_ret(r.mean().lret) * 100
    curr = _to_simple_ret(r.tail(1).lret.values[0]) * 100
    return [_percent_format(best), _percent_format(worst),
            _percent_format(avg), _percent_format(curr)]


def best_21(series):
    r = series.rolling(21, min_periods=21).sum()
    return _percent_format(_to_simple_ret(r.max()) * 100)


def worst_21(series):
    r = series.rolling(21, min_periods=21).sum()
    return _percent_format(_to_simple_ret(r.min()) * 100)



def ann_return(series):
    a = _to_simple_ret(np.sum(series)) * 100
    return _percent_format(a)


def ann_sharpe(series):
    a=0
    if np.std(series) != 0:
        a = sqrt(252) * (np.mean(series) / np.std(series))
    return _double_format(a)


def depth_dd(series):
    return -100 * _to_simple_ret(np.max(series))


def start_dd(series):
    return series.head(1).index.date


def end_dd(series):
    return series.tail(1).index.date


def length_dd(series):
    return len(series)


def _draw_drawdowns_table(df, axis):
    df['expanding_sum'] = df['lret'].expanding().sum()
    df['expanding_max'] = df['expanding_sum'].expanding().max()
    df['drawdowns'] = df['expanding_max'] - df['expanding_sum']
    g = df.drawdowns[df['drawdowns'] > 0].groupby(df['expanding_max'])
    dds = g.agg([depth_dd, start_dd, end_dd, length_dd])
    print('dds:',dds)
    dds = dds.sort_values(by='depth_dd')
    print('dds2:',dds)
    dds['depth_dd'] = dds['depth_dd'].apply(_percent_format)
    data = dds.head(6).as_matrix()
    print('data:',len(data))
    print('Draw')
    print(data)
    colLabels = ('Depth', 'Start', 'End', 'Length (days)')
    axis.axis('off')
    axis.axis('tight')
    axis.set_title('Time Analysis                                                                Drawdown Report')

    colorscell = []
    for i in range(len(data)):
        tmpList = []
        for x in range(4):
            if x%2 == 0:
                tmpList.append("#D0DDAF")
            else:
                tmpList.append("#E6E9E9")
        colorscell.append(tmpList)
    colorscolumn = colorscell[0]
    #colorsrow = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]
    #colorscolumn = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]#plt.cm.BuPu(np.linspace(0,0.5, len(colLabels)))
   
    the_table = axis.table(cellText=data,
                           colLabels=colLabels,
                           cellColours = colorscell,
                           colColours = colorscolumn,
                           loc='right',
                           bbox=[0.52, -0.2, 0.5, 1.0])
                           #bbox=[0.52, -0.2, 0.5, 1.5])
                           #bbox=[0.52, -0.2, 0.5, 1.5])

def _draw_day_analysis_table(df, axis):
    days = [1, 5, 21, 63, 126, 252]
    rowLabels = list(map(lambda x: str(x) + " days", days))
    colLabels = ['Best', 'Worst', 'Avg', 'Curr']
    f = partial(_n_day_analysis, df=df)
    data = list(map(f, days))
    print('DAY')
    print(data)
    axis.axis('off')
    axis.axis('tight')
    axis.set_title('Time analysis')

    #set styles for rows, cols and cells
    colorscell = []
    colorsrow =[]
    for i in range(len(rowLabels)):
        tmpList = []
        for x in range(len(colLabels)):
            if x%2 == 0:
                tmpList.append("#D0DDAF")
            else:
                tmpList.append("#E6E9E9")
        colorscell.append(tmpList)
        if i%2 == 0:
             colorsrow.append("#D0DDAF")
        else:
             colorsrow.append("#E6E9E9")
    colorscolumn = colorscell[0]
    #colorscell = [["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]]
    #colorsrow = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]
    #colorscolumn = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]

    #owLabels = getColumnsList(rowLabels)
    the_table = axis.table(cellText=data,
                           rowLabels=rowLabels,
                           colLabels=colLabels,
                           cellColours = colorscell,
                           rowColours = colorsrow,
                           colColours = colorscolumn,
                           loc='center',
                           bbox=[0.0, -0.2, 0.5, 1.0])
                           #bbox=[0.0, -0.2, 0.5, 1.5])
                           #bbox=[0.0, -0.2, 0.5, 1.5])

def _draw_year_analysis(df, axis,dirname):
    rowLabels = ('Annual return',
                 'Best 21 days',
                 'Worst 21 days',
                 '1 year sharpe')
    g = df.groupby(pd.Grouper(freq='A'))
    v = g.agg([np.mean, np.std, ann_return, best_21, worst_21, ann_sharpe])
    v['lret','sharpe'] = sqrt(252) * (v['lret','mean'] / v['lret','std'])

    # Create Annual Return Sharpe dataframe
    retSharpeDF = v['lret'][['ann_return', 'ann_sharpe']]
    retSharpeDF['pval'] = dirname
    ###
    colLabels = list(map(lambda x:x.year, v['lret'].index.tolist()))
    data = v['lret'][['ann_return', 'best_21', 'worst_21', 'ann_sharpe']].T.as_matrix()
    print('YA:')
    print(colLabels)
    print(data)
    axis.axis('off')
    #axis.axis('tight')
    axis.set_title('Annual Return')
    colLabelsTemp = colLabels
    ############
    colorscell = []
    colorsrow =[]
    for i in range(len(rowLabels)):
        tmpList = []
        for x in range(len(colLabels)):
            if x%2 == 0:
                tmpList.append("#D0DDAF")
            else:
                tmpList.append("#E6E9E9")
        colorscell.append(tmpList)
        if i%2 == 0:
             colorsrow.append("#D0DDAF")
        else:
             colorsrow.append("#E6E9E9")
    colorscolumn = colorscell[0]
    ###############
    
    #axis.text(0.5, 1.5,'Annual Returns',fontsize=12)
    #axis.set_title('Year Analysis')
    #colorscell = [["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"],["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]]
    #colorsrow = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]
    #colorscolumn = ["#D0DDAF","#E6E9E9", "#D0DDAF","#E6E9E9"]#plt.cm.BuPu(np.linspace(0,0.5, len(colLabels)))
    '''colLabelsList =[]
    for label in colLabels:
        print(label)
        colLabelsList.append(label)'''

    the_table = axis.table(cellText=data,
                           rowLabels=rowLabels,
                           colLabels= colLabels,
                           cellColours= colorscell,
                           colColours= colorscolumn,
                           rowColours = colorsrow,
                           loc='left',
                           bbox=[0.0, -0.0, 1.0, 0.8])
                           #bbox=[0.0, -0.2, 1.0, 1.1])
                           #bbox=[0.0, -0.1, 1.0, 1.5])
    table_props = the_table.properties()
    table_cells = table_props['children']
    print('YAzzz:')
    return retSharpeDF
    #for cell in table_cells: cell.set_width(0.1)
def _draw_table1(df, axis,dirname):
    colLabels = ('', '')
    rowLabels = ('Start Date - End Date',
                 'Total Return since inception',
                 'Average Annual ROR',
                 'Winning / Losing Months',
                 'Winning Month Gain / Losing Month Loss',
                 'Sharpe Ratio',
                 'Risk of Ruin',
                 'Return to Drawdown (Calmar)',
                 '% Winning / Losing Days [Flat Days]')
    data = [[pd.to_datetime(df.head(1).index.values[0]).strftime('%Y-%m-%d') + " - " + pd.to_datetime(df.tail(1).index.values[0]).strftime('%Y-%m-%d')],
            [_percent_format((df.agg('sum').lret) * 100)],
            [_percent_format(_to_simple_ret(252 * df.agg('mean').lret) * 100)],
            [_double_format(_updown_months(df))],
            [_updown_month_rets(df)],
            [_double_format(_sharpe(df))],
            [_double_format(_risk_of_ruin(df))],
            [_double_format(252 * df.agg('mean').lret / max_dd(df.lret))],
            [_winloss_days(df)]]
    #print('Mytable:')
    #print(data)
    #Return and Sharpe Ratio since inception
    RetAndSharpeList =[]
    totReturnStr ='{:{width}.{prec}f}'.format((df.agg('sum').lret * 100), width=5, prec=2)
    #RetAndSharpeList.append([data[1][0],data[5][0],dirname])
    RetAndSharpeList.append([float(totReturnStr),float(data[5][0]),dirname])
    RetAndSharpeDF = pd.DataFrame(RetAndSharpeList,columns=['TotalReturn', 'SharpeRatio','pname'])
    #pd.DataFrame(lst, columns=cols)
    axis.axis('off')
    #axis.axis('tight')
    #axis.get_frame_on()
    #plt.subplots_adjust(bottom=0.1, right=0.8, top=2.9)
    axis.set_title('Performance Analysis')
    #Styles for rows and cells
    colorsrow=[]
    colorscell = []
    for x in range(len(data)):
        tmpList = []
        if x%2 == 0:
            tmpList.append("#D0DDAF")
            colorsrow.append("#D0DDAF")
        else:
            tmpList.append("#E6E9E9")
            colorsrow.append("#E6E9E9")
        colorscell.append(tmpList)
   
    #colorscell = [["#D0DDAF"],["#E6E9E9"],["#D0DDAF"],["#E6E9E9"],["#D0DDAF"],["#E6E9E9"],["#D0DDAF"],["#E6E9E9"],["#D0DDAF"]]
    #colorsrow = ["#D0DDAF", "#E6E9E9", "#D0DDAF", "#E6E9E9", "#D0DDAF", "#E6E9E9", "#D0DDAF", "#E6E9E9", "#D0DDAF"]
    the_table = axis.table(cellText=data,
                             rowLabels=rowLabels,
                             colLabels=None,
                             loc='center right',
                             cellColours=colorscell,
                             rowColours=colorsrow,
                             #bbox=[0.3, -0.6, 0.5, 1.5])
                             #bbox=[0.3, -0.2, 0.5, 1.5])
                             bbox=[0.25, -0.2, 0.7, 1.1])
    '''the_table._cells[(0, 0)].set_facecolor("#56b5fd")
    the_table._cells[(2, 0)].set_facecolor("#1ac3f5")'''
    table_props = the_table.properties()
    #table_cells = table_props['children']
    #for cell in table_cells: cell.set_width(0.5)
    return RetAndSharpeDF


def _draw_returns_hist(daily_returns, axis,baseOutDir,name):
    axis.hist(daily_returns.values, bins=50, facecolor='b', alpha=0.5, ec='black')
    axis.set_ylabel('Days')
    # plt.set_xlabel('% Returns')
    axis.set_title('# Daily Returns')
    plt.rc('grid', linestyle=":", color='gray')
    plt.grid(True)

    #figurePath = os.path.join(baseOutDir, 'charts_' + name + '.png')
    #plt.savefig(figurePath)

def _draw_pnldiff_hist(pnldiffSeries, axis):
    pnldifflist = pnldiffSeries.tolist()
    axis.hist(pnldifflist, bins=50, facecolor='b', alpha=0.5, ec='black')
    axis.set_ylabel('Days')
    # plt.set_xlabel('% Returns')
    axis.set_title('# pnl')
    plt.rc('grid', linestyle=":", color='gray')
    plt.grid(True)

def _draw_cum_returns(daily_returns, axis):
    #xs = daily_returns.values.cumsum()
    xs = daily_returns['lret'].cumsum()
    # helpful for max dd
    i = np.argmax(np.maximum.accumulate(xs) - xs)
    j = np.argmax(xs[:i])
    axis.plot(xs, linewidth=0.8, linestyle='-', c='black')
    # max dd red dots
    axis.plot([i, j], [xs[i], xs[j]], 'o', color='Red', markersize=5)
    axis.set_title('Cumulative Daily Returns')
    axis.set_ylabel('Cumulative % Returns')
    plt.rc('grid', linestyle=":", color='gray')

    plt.grid(True)


# Plots 4x4 cumulative and distributions of returns
def plot_returns(df,baseOutDir,name,mode,dirname):
    f, axarr = plt.subplots(3)
    print(type(axarr))
    print((axarr[0]))
    #f.patch.set_visible(False)
    retSharpeInceptionDF = _draw_table1(df, axarr[0],dirname)
    retSharpeDF = _draw_year_analysis(df, axarr[1],dirname)
    _draw_day_analysis_table(df, axarr[2])
    _draw_drawdowns_table(df, axarr[2])
    #_draw_cum_returns(df, axarr[3])
    #_draw_returns_hist(df, axarr[4])
    #f.suptitle('test title', fontsize=20)
    #plt.subplots_adjust(left=0.1, bottom=0.1,top=1.5)
    plt.subplots_adjust(hspace=0.6,left=0.1, bottom=0.1,top=0.9)
    #f.tight_layout()
    if mode == 'q':
        figurePath = os.path.join(baseOutDir, 'tables_' + name + '.png')
        plt.savefig(figurePath,dpi=300, bbox_inches = "tight")
    else:
        plt.show()

    return retSharpeDF, retSharpeInceptionDF

def plot_returns2(df,pnldiffSeries,pnlhist,baseOutDir,name,mode):
    if pnlhist == 'True':
        f, axarr = plt.subplots(3)
    else:
        f, axarr = plt.subplots(2)
    print(type(axarr))
    print((axarr[0]))
    #f.patch.set_visible(False)
    '''_draw_table1(df, axarr[0])
    _draw_year_analysis(df, axarr[1])
    _draw_day_analysis_table(df, axarr[2])
    _draw_drawdowns_table(df, axarr[2])'''
    _draw_cum_returns(df, axarr[0])
    _draw_returns_hist(df, axarr[1],baseOutDir,name)
    if pnlhist == 'True':
        _draw_pnldiff_hist(pnldiffSeries, axarr[2])
    plt.subplots_adjust(left=0.1, bottom=0.1,top=1.5)
    f.tight_layout()
    if mode == 'q':
        figurePath = os.path.join(baseOutDir, 'charts' + name + '.png')
        plt.savefig(figurePath,dpi=300, bbox_inches = "tight")
    else:
        plt.show()


# All these functions assume a pandas dataframe with timestamp column t.
# works on log rets columns only and returns aggregated log returns only.
# Groups by day and returns a series (sum of lret for each daily group series)
def _aggregated_log_ret(df, freq='D', log_ret_col='lret', time_col='t'):
    return df.set_index(time_col).groupby(pd.TimeGrouper(freq))[log_ret_col].sum()

def _daily_pnlrealized(df,leg_col='pnlRealized', freq='D', time_col='t'):
    return df.set_index(time_col).groupby(pd.TimeGrouper(freq))[leg_col].last()

def _daily_pnlunrealized(df,leg_col='pnlUnrealized', freq='D', time_col='t'):
    return df.set_index(time_col).groupby(pd.TimeGrouper(freq))[leg_col].last()

def _net_contracts_open(df, freq='D', time_col='t'):
    return df.set_index(time_col).groupby(pd.TimeGrouper(freq))['netContractsOpen'].max()

def _print_year(r):
    raw_vals = r[1].apply(lambda x: x * 100).values
    total = raw_vals.sum()
    raw_vals = np.append(raw_vals, np.repeat(0.0, 12 - raw_vals.size))
    display = (r[0].year,) + tuple(raw_vals) + (total,)
    print("%8s %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f" % display)


def print_returns_table(r):
    month_list = ('Year', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Total')
    print("%8s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %7s" % month_list)
    monthly_ret = r.apply(expm1).groupby(pd.TimeGrouper(freq='M')).sum()
    map(_print_year, list(monthly_ret.groupby(pd.TimeGrouper(freq='A'))))


# Data loading functions
def load_file(csvfilepath, strategy,endDate, startDate,contracts,baseoutDir):
    #df= getData(csvfilepath)
    minutesDF ,posCountDF, openPosDF = getDataMinutes(csvfilepath,strategy,endDate, startDate)
    return _process_frame(minutesDF,strategy,contracts,baseoutDir),posCountDF,openPosDF

def load_fileB(csvfilepath, strategy,endDate, startDate,contracts,baseoutDir,legs):
    #df= getData(csvfilepath)
    minutesDF ,posCountDF1, openPosDF1 ,posCountDF2, openPosDF2 = getDataMinutesB(csvfilepath,strategy,endDate, startDate,legs)
    return _process_frame( minutesDF,strategy,contracts,baseoutDir),posCountDF1,openPosDF1,posCountDF2,openPosDF2

class Contract:
    def __init__(self, n, pp, m):
        self.name = n
        self.pointvalue = pp
        self.margin = m

# positions file has position size denominated in number of contracts
# so for EURUSD, for example,  position size is 1 (by default)  and hence 
# implicit notional value is 1000,000 (per unit position), for JPY the equivalent number 
# should be  10,000
# for StratB, default positon size is 100, point value for futures is slef explanatory
contractsTable = {
        'ES': Contract('ES', 50, 6000),
        'NQ': Contract('NQ', 20, 6000),
        'TY': Contract('TY', 1000, 2500),
        'FV': Contract('FV', 1000, 2500),
        'US': Contract('US', 1000, 2500),
        'TU': Contract('TU', 2000, 500),
        '1YM': Contract('1YM', 5, 5000),
        'EURUSD': Contract('EURUSD', 1000000, 100000),
        'USDJPY': Contract('USDJPY', 100, 100000), # point value 100 as opposed to 10,000 because price quoted in ~/WQData/FX/USDJPY/1m-new.csv 9085.00
        'EURGBP': Contract('EURGBP', 1300000, 130000),
        'EURJPY': Contract('EURJPY', 100, 100000), # point value 100 as opposed to 10,000 because price quoted in ~/WQData/FX/USDJPY/1m-new.csv 9085.00
        'GBPUSD': Contract('GBPUSD', 1000000, 100000),
        'AUDUSD': Contract('AUDUSD', 1000000, 100000),
        'USDCHF': Contract('USDCHF', 1000000, 100000),        
        'USDCAD': Contract('USDCAD', 1000000, 100000),
        'FCE': Contract('FCE', 1000000, 100000),
        'FDX': Contract('FDX', 1000000, 100000),
        'CL': Contract('CL', 1000, 2550),
        'LCO': Contract('LCO', 1000, 2550),
    }

#  for return on margin computation
def capital_utilized(df,contact_name):
    max_contracts =df['contractsOpen'].max()
    c = contractsTable[contact_name]
    return abs(max_contracts * c.margin)

# for var based computations,  
# note this is not the same as WQ methodology which does the following:
# 1) takes the 95th percentile of open positins of each day (over a specified look back period, fixed or rolling)
# 2) takes the worst number from 1) and reports as vaR
def capital_utilized_var(pnldiff):
    return abs(pnldiff[pnldiff < 0].quantile(0.05)*100)
#  Banku:  reconcile with log in WQVaRAnalysis.py

# Perform core calculations required for the data. Maybe move it to the data layer
def _basic_calculations(minutesDF,strategy,contracts,baseoutDir):
    #fh = open(os.path.join(baseoutDir, 'logReturnPercentile.txt'), 'a')
    if strategy == 'A':
        minutesDF['contractsOpen'] = abs(minutesDF['contractsOpenLong']) + abs(minutesDF['contractsOpenShort'])
        minutesDF['netContractsOpen'] = minutesDF['contractsOpenLong'] - minutesDF['contractsOpenShort']
        maxContractVal = capital_utilized(minutesDF,contracts[0])
        minutesDF['dollarPnL'] = minutesDF['pnlRealized']*contractsTable[contracts[0]].pointvalue + minutesDF['pnlUnrealized']*contractsTable[contracts[0]].pointvalue
    else:
        minutesDF['contractsOpen'] = abs(minutesDF['numC0']) + abs(minutesDF['numC1'])
        minutesDF['netContractsOpen'] = abs(minutesDF['numC0'] + minutesDF['numC1'])
        minutesDF['pnlRealizedComputed'] = minutesDF['realizedPnLlegs0']*contractsTable[contracts[0]].pointvalue \
                                               + minutesDF['realizedPnLlegs1']*contractsTable[contracts[1]].pointvalue
        minutesDF['pnlUnRealizedComputed'] = minutesDF['unrealized0']*contractsTable[contracts[0]].pointvalue \
                                                 + minutesDF['unrealized1']*contractsTable[contracts[1]].pointvalue
        maxContractVal = capital_utilized(minutesDF, contracts[0])
        maxContractVal += capital_utilized(minutesDF, contracts[1])
        print('maxContractVal:', maxContractVal)
        minutesDF['dollarPnL'] = minutesDF['pnlRealizedComputed'] + minutesDF['pnlUnRealizedComputed']

    # this series is the MINUTELY $ PnL generated with defailt position sizes for StratA (1)  and StratB (100)
    minutesDF['dollarPnL'] = minutesDF.dollarPnL.diff().dropna()
    capitalUsage = capital_utilized_var(minutesDF['dollarPnL'])
    minutesDF['sret'] = minutesDF['dollarPnL']/capitalUsage
    # save sret series
    # this should be idential to the return_ file since this is simple return
    # TBD: Banku, please comment out later
    minutesDF_tmp = minutesDF[ ['t','sret']]
    minutesDF_tmp.to_csv()

    if strategy == 'A':
        sretFilePath = os.path.join(baseoutDir, contracts[0] + '.csv')
    else:
        sretFilePath = os.path.join(baseoutDir, contracts[0]+ contracts[1]   + '.csv')

    minutesDF_tmp.to_csv(sretFilePath, index=False)
    # convert simple returns to log returns 
    minutesDF['lret'] = np.log(1 + minutesDF.sret)

    debugFilepath = os.path.join(baseoutDir, 'RiskReportDiagnostics.csv')
    minutesDF.to_csv(debugFilepath, index=False)
    return minutesDF

# Adds or fixes types
def _process_frame(minutesDF,strategy,contracts,baseoutDir):
    print(type(minutesDF))
    print(minutesDF.head())
    #minutesDF.drop(['grp', 'volume', 'duration(s)'], inplace=True, axis=1)
    ####minutesDF['t'] = pd.to_datetime(minutesDF['t'],
    ####format='%Y-%m-%d %H:%M:%S')
    # minutesDF.t.tz_localize('UTC')
    return _basic_calculations(minutesDF,strategy,contracts,baseoutDir)


def test():
    dat = load_file("F://temp//fx_test.csv")
    daily_returns = daily_log_ret(dat)
    df = pd.DataFrame(daily_returns.dropna())
    plot_returns(df)




def main():
    logging.basicConfig(level=logging.INFO,
                      format='%(asctime)s %(levelname)s %(message)s')
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--pnl_file", default='C:/MyProjects/FXData/EURGBP',
                        help="PNL file. Defaults to: "
                             "C:/MyProjects/FXData/EURGBP")
    parser.add_argument('-suffix','--suffix',default='',help="suffix for ")
    parser.add_argument('-s','--strategy',default='A',help="Strategy: A or B")
    parser.add_argument('-f', '--startDate', default='20090101', help="from date")
    parser.add_argument('-t', '--endDate', default='20190101', help="to date")
    parser.add_argument('-c', '--contracts', default=['ES', 'NQ'], help="1 for strat A, 2 for start B", nargs='*')
    parser.add_argument('-baseOut','--baseOutDir', default='C:/MyProjects/WQMaster/output/xxxx',help="base Directory")
    parser.add_argument('-pnlhist', '--pnlhist', default='True', help="True: show pndiff histo")
    parser.add_argument('-legs', '--legs', default=['Smith1','Smith2'], help="list of Spread legs", nargs='*')
    parser.add_argument('-ptable', '--paramsTable', action='store_true', help="true if arg supplied")
    parser.add_argument('-mode', '--mode', default='q', help="q or v")
    parser.add_argument('-varMode', '--varEstimateMode', action='store_true', help="generate pnldiff_ only and skip return_")
    parser.add_argument('-capitalBase', '--capitalBase', default=0, help="optionally supply if not runnig in varMode")


    #parser.add_argument('-baseOut','--baseOutDir',
    #default='/home/lanarayan/MyProjects/WQMaster/output/',help="base
    #Directory")


    args = parser.parse_args()
    print(args)
    path = os.path.abspath(args.pnl_file)
    strategy = args.strategy
    print("CSV path:" + path)

    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)
    # Total Dataframes
    consolidatedDF = pd.DataFrame()
    consolidatedInceptionDF = pd.DataFrame()
    paramsConsolidatedDF = pd.DataFrame()
    mergedRetParamsConsolDF = pd.DataFrame()
    inceptionPnlDF = pd.DataFrame()
    mergedPnLParamsConsolDF =pd.DataFrame()
    '''totalPosCountDF = pd.DataFrame()
    totalOpenPosDF = pd.DataFrame()
    totalPosCountDF2 = pd.DataFrame()
    totalOpenPosDF2 = pd.DataFrame()
    totalLogReturn = pd.DataFrame()'''

    for dirpath, dirnames, filenames in os.walk(path):
        for dirname in dirnames:
            if not dirname.startswith('params-'):
                continue;
            paramDir = os.path.join(dirpath,dirname)

            #create output folder for each params-0, params-1 etc
            outParamDir = os.path.join(args.baseOutDir,dirname)
            if not os.path.exists(outParamDir):
                print("Creating output folder :" + outParamDir)
                os.makedirs(outParamDir)
            
            # load the minutes
            if args.strategy == 'A':
                print("Traversing :",paramDir)
                dat,posCountDF,openPosCountDF = load_file(paramDir,strategy,args.endDate, args.startDate, args.contracts,outParamDir)
            else:
                print("Traversing :", paramDir)
                dat, posCountDF, openPosCountDF, posCountDF2, openPosCountDF2 = load_fileB(paramDir, strategy, args.endDate, args.startDate, args.contracts,
                                                                                           outParamDir, args.legs)

            # get the daily (end of day) pnl from the minutes dataframe
            if args.strategy == 'A':
                pnlSeries = (_daily_pnlrealized(dat) + _daily_pnlunrealized(dat))*contractsTable[args.contracts[0]].pointvalue
            else:
                pnlSeries = (_daily_pnlrealized(dat,'realizedPnLlegs0') + _daily_pnlunrealized(dat, 'unrealized0'))\
                            *contractsTable[args.contracts[0]].pointvalue
                pnlSeries += (_daily_pnlrealized(dat,'realizedPnLlegs1') + _daily_pnlunrealized(dat, 'unrealized1'))\
                            *contractsTable[args.contracts[1]].pointvalue

            pnlSeries = pnlSeries.dropna()
            # take first difference to get daily pPnLs  (Important for WQ VaR report)
            pnldiff = pnlSeries.diff().dropna()


            print(len(pnldiff[pnldiff < 0]))

            name = ''.join(args.contracts)
            name = name if len(args.suffix) == 0 else name + '_' + args.suffix

            if not args.varEstimateMode:           
                if args.strategy == 'A':
                    capitalbase =  capital_utilized(dat, args.contracts[0])
                else:
                    capitalbase =  capital_utilized(dat, args.contracts[0]) +  capital_utilized(dat, args.contracts[1])
                
                # use capiitalbase specified in command line (which most commanly will be, after the pass 1 in varMode), if not 0
                if args.capitalBase == 0:
                    capitalbaseVaR = capital_utilized_var(pnldiff)
                else:
                    capitalbaseVaR = args.capitalBase
                print('Margin based capital base is ', capitalbase)
                print('VaR based capital base is ', capitalbaseVaR)
                # here we choose to use VaR based capital  to compute returns
                capitalSeries = pd.Series(capitalbaseVaR, index=pnlSeries.index)
                totalCapital = (pnlSeries + capitalSeries)
                returnSeries = totalCapital.dropna().pct_change().dropna()
                returnSeries = returnSeries.dropna()
                returnSeries_df = pd.DataFrame({'t':returnSeries.index, 'sret':returnSeries.values})
                returnSeries_df.to_csv(os.path.join(args.baseOutDir, dirname, 'return_' + name +'.csv'), index=False)

            #pnlSeries_df = pd.DataFrame({'t':pnlSeries.index, 'pnl':pnlSeries.values})
            pnlSeries_df = pd.DataFrame({'t': pnlSeries.index, 'pnl': pnlSeries.values, 'pname':dirname})
            pnldiff_df = pd.DataFrame({'t':pnldiff.index, 'pnldiff':pnldiff.values})
            # note these returns are different from the return plotted in risk report (TBD)
        

            pnlSeries_df.to_csv(os.path.join(args.baseOutDir, dirname, 'pnl_' + name + '.csv'), index=False)
            # Banku: this can be input to weighted series to get daily PnL for the weighted portfolio
            pnldiff_df.to_csv(os.path.join(args.baseOutDir, dirname , 'pnldiff_' + name + '.csv'), index=False)

            # Banku: this should closely match pnldiff_
            posCountDF.to_csv(os.path.join(args.baseOutDir, dirname, 'pnlRealized_' + name +'.csv'), columns=['pnlRealized'], index=False)

            pcsuffix1 =name
            pcsuffix2 ='Not Assigned'
            # choose suffix for strategy B  positions counts
            if args.strategy == 'B':
                pcsuffix1 = args.legs[0] + '_' + args.suffix
                pcsuffix2 = args.legs[1] + '_' + args.suffix

            # write to file strategy A or first leg for strategy B
            posCountDF.to_csv(os.path.join(outParamDir, 'positionCount_' + pcsuffix1 + '.csv'), index=False)
            openPosCountDF.to_csv(os.path.join(outParamDir, 'openPositionCount_' + pcsuffix1 + '.csv'), index=False)

            #Append to total Count Dataframes
            #totalPosCountDF = totalPosCountDF.append(posCountDF)
            #totalOpenPosDF = totalOpenPosDF.append(openPosCountDF)


            # write to file second leg for strategy B
            if args.strategy == 'B':
                posCountDF2.to_csv(os.path.join(outParamDir, 'positionCount2_' + pcsuffix2 + '.csv'), index=False)
                openPosCountDF2.to_csv(os.path.join(outParamDir, 'openPositionCount2_' + pcsuffix2 + '.csv'), index=False)
                # Append to total Count Dataframes
                #totalPosCountDF2 = totalPosCountDF2.append(posCountDF2)
                #totalOpenPosDF2 = totalOpenPosDF2.append(openPosCountDF2)

            fh = open(os.path.join(outParamDir, 'report_' + name +'.txt'),'w')
            # report
            if not args.varEstimateMode:
                fh.write('Capital base is ' + str(capitalbase))
            fh.write('\n\nDescribe daily pnl\n' + str(pnldiff.describe()))
            fh.write('\n\nMax pnl date\n' + str(pnldiff.argmax()) + '\n' + str(pnldiff.max()))
            fh.write('\n\nMin pnl date\n' + str(pnldiff.argmin()) + '\n' + str(pnldiff.min()))

            if not args.varEstimateMode:
                fh.write('\n\nDescribe daily return\n' + str(returnSeries.describe()))
                OUTSIZED = 0.02
                fh.write('\n\nOutsized daily +ive return\nsize is \n' + str(returnSeries[returnSeries > OUTSIZED].size) + '\n' + str(returnSeries[returnSeries > OUTSIZED]))
                fh.write('\n\nOutsized daily -ive return\nsize is \n' + str(returnSeries[returnSeries < -OUTSIZED].size) + '\n' + str(returnSeries[returnSeries < -OUTSIZED]))
                # Banku  please put a histogram of pnldiff here optionally  (May 21, 2018)

                # Banku: daily log return stats from the minutes df;  
                # ONLY for comparison with returns computed using daily pnls and VaR base capital 
                # should closely track logReturnSeries_df below (differences due to capital base differences)
                logReturnSeriesFomMinutelyPnL_df = daily_log_ret(dat)

                # subsequently plot_returns accepts daily_returns in a specific format
                logReturnSeries = np.log(1+returnSeries)
                #logReturnSeries_df = pd.DataFrame({'t':returnSeries.index, 'lret':returnSeries.values})
                #typo corrected based on testcase that assigns 100% weight to individual series
                logReturnSeries_df = pd.DataFrame({'t': logReturnSeries.index, 'lret': logReturnSeries.values})
                daily_returns = logReturnSeries_df.set_index('t')
                print("type",daily_returns.index.dtype)
                print("columns",daily_returns.columns)
                print(daily_returns.index.dtype)

                fh.write('\n\n5% bottom quantile for -ive days is : \n' + str(daily_returns[daily_returns.lret < 0].quantile(0.05)))
                fh.write('\n\nDescribe daily log return\n' + str(daily_returns.describe()))

                fh.write('\nMargin based capital base is '+ str(capitalbase))
                fh.write('\nVaR based capital base is ' + str(capitalbaseVaR))

                retSharpDF, inceptionDF = plot_returns(daily_returns,outParamDir,name,args.mode,dirname)
                consolidatedDF = consolidatedDF.append(retSharpDF)
                consolidatedInceptionDF=consolidatedInceptionDF.append(inceptionDF)
                inceptionDF['PnL']= pnlSeries_df[-1:].iloc[0]['pnl']
                plot_returns2(daily_returns,pnldiff,args.pnlhist,outParamDir,name,args.mode)
            else:
                # get last record of pnlseries
                inceptionPnlDF = inceptionPnlDF.append(pnlSeries_df[-1:])


            #all_data = _kickoff(args)
            xml_file = os.path.join(paramDir, "params.xml")
            tree = et.parse(xml_file)
            root = tree.getroot()

            values = root.find('.//item')
            print(values)
            colList = []
            valList = []
            for value in values:
                colList.append(value.tag)
                valList.append(value.text)

            print(colList)
            print(valList)

            paramsDF = pd.DataFrame(valList)
            paramsDF = paramsDF.T
            paramsDF.columns = colList
            paramsDF['pname']= dirname

            #select columns required only
            paramsDF = paramsDF[['pname','HoldingPeriod','RebalanceB','MultiplierB','TargetMultiplierB','StopMultiplierB']]

            paramsConsolidatedDF=paramsConsolidatedDF.append(paramsDF)
            #paramsConsolidatedDF = paramsConsolidatedDF[['pname','HoldingPeriod','RebalanceB','MultiplierB','TargetMultiplierB','StopMultiplierB']]
            if not args.varEstimateMode:
                mergedRetParamsDF = pd.merge(paramsDF, inceptionDF, right_on='pname', left_on='pname')
                mergedRetParamsConsolDF = mergedRetParamsConsolDF.append(mergedRetParamsDF)
            else:
                mergedPnLParamsDF = pd.merge(paramsDF, inceptionPnlDF, right_on='pname', left_on='pname')
                mergedPnLParamsConsolDF = mergedPnLParamsConsolDF.append(mergedPnLParamsDF)


#main for loop ended
    if not args.varEstimateMode:
        # Write to csv all Total dataframes
        consolidatedDF.to_csv(os.path.join(args.baseOutDir, 'ConsolidatedRetSharpe.csv'),index=True)

        # Return and Sharpe ratio since inception
        consolidatedInceptionDF=consolidatedInceptionDF.sort_values(['TotalReturn'], ascending=False)
        consolidatedInceptionDF.to_csv(os.path.join(args.baseOutDir, 'ConsolidatedInceptRetSharpe.csv'),index=True)

        #to csv merged df of params and inception Return  plus Sharpe
        mergedRetParamsConsolDF=mergedRetParamsConsolDF.sort_values(['TotalReturn'], ascending=False)
        #mergedRetParamsConsolDF.to_csv(os.path.join(args.baseOutDir, 'ConsolidateParamsRetSharpe.csv'),index=False)
        mergedRetParamsConsolDF.to_csv(os.path.join(args.baseOutDir, 'ConsolidatedParamsAndIncept.csv'),index=False)

        CreateHtmlReport(consolidatedDF, args.baseOutDir)
        CreateInceptionHtmlReport(consolidatedInceptionDF, args.baseOutDir)
        CreateInceptionAndParamsHtmlReport(mergedRetParamsConsolDF,args.baseOutDir)
    else:
        mergedPnLParamsConsolDF = mergedPnLParamsConsolDF.sort_values(['pnl'], ascending=False)
        mergedPnLParamsConsolDF.to_csv(os.path.join(args.baseOutDir, 'ConsolidatedParamsInceptPnL.csv'),index=False)
    if args.paramsTable:
        CreateparamsHtmlReport(paramsConsolidatedDF,args.baseOutDir)
    '''totalPosCountDF.to_csv(os.path.join(args.baseOutDir, 'TotalpositionCount_' + pcsuffix1 + '.csv'),index=False)
    totalOpenPosDF.to_csv(os.path.join(args.baseOutDir, 'TotalopenPositionCount_' + pcsuffix1 + '.csv'),index=False)
    if args.strategy == 'B':
        totalPosCountDF2.to_csv(os.path.join(args.baseOutDir, 'TotalpositionCount2_' + pcsuffix2 + '.csv'), index=False)
        totalOpenPosDF2.to_csv(os.path.join(args.baseOutDir, 'TotalopenPositionCount2_' + pcsuffix2 + '.csv'), index=False)
    totalLogReturn.to_csv(os.path.join(args.baseOutDir,'Totallog_return_' + '.csv'),index=True)'''

if __name__ == '__main__':
    main()

