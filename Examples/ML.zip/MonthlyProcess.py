#!/big/svc_wqln/projects/python/conda/bin/python3.6

# Create a table with following:
#alpha name, PnL (Sum Pnl from alphaexposure report e.g 1YM_15m_params-0.csv), link to Sim Files( 1YM_15m_params-0.csv, Weighted_ 1YM_15m_params-0.csv
# UnWtd_ 1YM_15m_params-0.csv), Link to alpha exposure Graph (from perf_calc -ae option), Total for Portfolio line(PortfolioExposure.csv),
# Link to portfolio exposure Graph (from perf_calc -pe option)

#sample:-alphas /home/lanarayan/MLData/BacktestsV16/AlphaList/V16/alphasA.txt  -simDir /home/lanarayan/MLData/BacktestsAlphaV16/OutSim/Fit-A-2019 -baseOut /home/lanarayan/MLData/BacktestsAlphaV16/MonthlyProcess

#test pnlUnrealized: -f 20171219 -t 20171219 -alphaFile C:/MyProjects/data/alphasPosA.txt -baseDirA C:/MyProjects/BackTests/StratA/ -baseDirB C:/MyProjects/BackTests/StratB/ -baseOut C:/MyProjects/output/temp/Alpha2 -groupBy Strategy -mode v
import pandas as pd
import argparse
import numpy as np
from datetime import date, timedelta
from datetime import datetime
import sys
import os
import webbrowser
import Common as co
import matplotlib.pyplot as plt
import pathlib
import logging
import platform


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-alphas', '--alphas', default='/home/lanarayan/MLData/BacktestsV4/AlphaList/V5/alphasA.txt', help="alphas file")
    parser.add_argument('-simDir', '--simDir', default='/home/lanarayan/MLData/Builds/build',
                        help="sim base Directory")
    parser.add_argument('-peGraphDir', '--peGraphDir', default='/home/lanarayan/MLData/Builds/build',
                        help="Portfolio Exposure Graph Directory")
    parser.add_argument('-aeGraphDir', '--aeGraphDir', default='/home/lanarayan/MLData/Builds/build',
                        help="Alpha Exposure Graph Directory")
    parser.add_argument('-baseOut', '--baseOut', default='/home/lanarayan/MLData/',
                        help="base Out Directory")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath,'MonthlyProcess-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    if not os.path.exists(args.baseOut):
        print("Creating output folder :" + args.baseOut)
        os.makedirs(args.baseOut)

    #1. Iterate alphas list
    #2. Create dataframe using info from the simDir dir
    #3. Write dataframe to MonthlyTable.csv

    colNamesList = ['name', 'frequency', 'pname']
    dfAlphas = pd.read_csv(args.alphas, names=colNamesList)

    dfConsolidated = pd.DataFrame(columns=['Alpha', 'Pnl', 'AEFiles', 'AEGraphs', 'PEFile', 'PEGraphs'])
    for index, row in dfAlphas.iterrows():
        #alphaName column
        alpha = row['name'] + '_' + row['frequency'] + '_' + row['pname']

        # PnL (Sum Pnl from alphaexposure report e.g 1YM_15m_params-0.csv)
        alphaExpReport = os.path.join(args.simDir, alpha + '.csv')
        dfAE = pd.read_csv(alphaExpReport)
        pnlSum = dfAE['Pnl'].sum()

        #link to Sim Files( 1YM_15m_params-0.csv, Weighted_ 1YM_15m_params-0.csv UnWtd_ 1YM_15m_params-0.csv)
        alphaExpWtdReport = os.path.join(args.simDir, 'Weighted_' + alpha + '.txt')
        alphaExpUnWtdReport = os.path.join(args.simDir, 'UnWtd_' + alpha + '.csv')
        linkAEReport = '<a href=file:///' + alphaExpReport + ' target="_blank">AE</a>'
        linkAEWtdReport = '<a href=file:///' + alphaExpWtdReport + ' target="_blank">AEWt</a>'
        linkAEUnWtdReport = '<a href=file:///' + alphaExpUnWtdReport + ' target="_blank">AEUnWt</a>'
        linkAllAEReports = linkAEReport + '&nbsp;&nbsp;' + linkAEWtdReport + '&nbsp;&nbsp;' + linkAEUnWtdReport

        #Link to alpha exposure Graph (from perf_calc -ae option)
        # e.g charts are DD1YM_15m_params-0.png and DDChart1YM_15m_params-0.png
        aeGraph1 = os.path.join(args.aeGraphDir, 'DD' + alpha + '.png')
        aeGraph2 = os.path.join(args.aeGraphDir, 'DDChart' + alpha + '.png')
        linkAEGraphs = '<a href=file:///' + aeGraph1 + ' target="_blank">AETbl</a>&nbsp;&nbsp;<a href=file:///'+ aeGraph2 + ' target="_blank">AEChart</a>'

        #Total for Portfolio line(PortfolioExposure.csv)
        portfolioExpReport = os.path.join(args.simDir,  'PortfolioExposure.csv')
        linkPEReport = '<a href=file:///' + portfolioExpReport + ' target="_blank">PE</a>'

        # Link to portfolio exposure Graph (from perf_calc -pe option)
        peGraph1 = os.path.join(args.simDir, 'DD.png')
        peGraph2 = os.path.join(args.simDir, 'DDChart.png')
        linkPEGraphs = '<a href=file:///' + peGraph1 + ' target="_blank">PETbl</a>&nbsp;&nbsp;<a href=file:///' + peGraph2 + ' target="_blank">PEChart</a>'

        #'Alpha', 'PnL', 'AEFiles', 'AEGraphs', 'PEFile', 'PEGraphs'
        dfConsolidated=dfConsolidated.append({'Alpha':alpha, 'Pnl':pnlSum, 'AEFiles':linkAllAEReports, 'AEGraphs': linkAEGraphs, 'PEFile':linkPEReport, 'PEGraphs':linkPEGraphs}, ignore_index=True)

    dfConsolidated.sort_values(['Pnl'], ascending=False, inplace=True)
    pd.set_option('display.max_colwidth', 500)

    dfConsolidated.to_html(os.path.join(args.baseOut, 'MonthlyReport.html'),escape=False,index=False)
if __name__ == '__main__':
    main()