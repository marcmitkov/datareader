#!/bin/bash
/home/lanarayan/MyProjects/ML/ResampleLive1.bash &
/home/lanarayan/MyProjects/ML/ResampleLive2.bash &
/home/lanarayan/MyProjects/ML/ResampleLive3.bash &
/home/lanarayan/MyProjects/ML/ResampleLive4.bash &