#!/big/svc_wqln/projects/python/conda/bin/python3.6
# PURPOSE: After MonthlyDeploy.process creates params.xml for prod, use this script to do required changes
# for using in backtestAlpha

#-inFile C:/MyProjects/PyCharmProjects/HelloWorldProj/paramsOut.xml -outFile C:/MyProjects/PyCharmProjects/HelloWorldProj/paramsOutNew.xml -oldSuffix U9 V9 Z9

#### FOR BACKTESTALPHA ############
#CBOT_ to CME_
#HOTSPOT  to FXOTC
#CMEFX to CME
#NYMEX to CME
#COMEX to CME
# U9 to U7, V9 to U7, Z9 to U7

import pandas as pd
import argparse
import xml.etree.ElementTree as et
import shutil
import os
from datetime import datetime,timedelta
import logging
import copy

exchangeReplaceMap ={"CBOT_": "CME_", "CMEFX_": "CME_", "COMEX_": "CME_", "NYMEX_": "CME_", "HOTSPOT_": "FXOTC_"}

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-inFile', '--inFile', default='/home/lanarayan/MLData/Futures/BacktestV4', help="base input Directory")
    parser.add_argument('-oldSuffix', '--oldSuffix', default=['U9', 'V9','Z9'], help="file location input series a",
                        nargs='*')
    parser.add_argument('-newSuffix', '--newSuffix', default=['U7', 'U7','U7'], help="file location input series a",
                        nargs='*')
    parser.add_argument('-outFile', '--outFile', default='/home/lanarayan/MLData/Futures/BacktestV4', help="base input Directory")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath,'ReplaceText-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    inputFile = args.inFile
    outputFile= args.outFile
    oldSuffixList = args.oldSuffix
    newSuffixList = args.newSuffix
    with open(inputFile, "rt") as fin:
        with open(outputFile, "wt") as fout:
            for line in fin:
                '''fout.write(line.replace('Z9', 'Q9'))
                fout.write(line.replace('HOTSPOT_', 'FXOTC_'))'''
                #newLineSuffix =line.replace('Z9', 'Q9').replace('U7', 'Q9')
                #newLineExchange =   newLineSuffix.replace('CBOT_', 'CME_').replace('CMEFX_', 'CME_').replace('COMEX_', 'CME_')
                '''line1 =line1.replace('CBOT_', 'CME_')
                '''
                for key, val in exchangeReplaceMap.items():
                    print("Replace ", key , " with ", val)
                    logging.debug("Replace {} with {}".format( key , val))
                    line = line.replace(key, val)

                for i, val in enumerate(oldSuffixList):
                    print("Replace ", val, " with ", newSuffixList[i])
                    logging.debug("Replace {} with {}".format(val,newSuffixList[i]))
                    line = line.replace(val,newSuffixList[i])

                fout.write(line)

if __name__ == '__main__':
    main()