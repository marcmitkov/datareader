#!/big/svc_wqln/projects/python/conda/bin/python3.6
#https://www.datacamp.com/community/tutorials/python-xml-elementtree

import argparse
import os
import shutil
from datetime import datetime,timedelta
import xml.etree.ElementTree as et
import logging

currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]
StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':['zz','zz'],'Kondratiev':['CME_CLU7','CME_LCOU7']}

def StratBkey(key):
    for val in StrategyBMap:
        print (val)

        keyArr = StrategyBMap[val]
        print(keyArr)
        comboKey = keyArr[0] + ',' + keyArr[1]
        if key == comboKey:
            return val
    return ' '
def main():
    parser = argparse.ArgumentParser()

    # Note: paramDir is input dir and also the output dir
    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MyProjects/ML', help="Base Directory for alphas params.xml and config.xml")
    parser.add_argument('-baseOutDir', '--baseOutDir', default='/home/lanarayan/MyProjects/ML', help="output Directory if specified will be used for output")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    #parser.add_argument('-log', '--logPath', default='C:/MyProjects/PyCharmProjects/HelloWorldProj',
    #                 help="log file  path")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")

    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath,'EditConfigsLog-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    #args.paramsDir="C:/MyProjects/Temp"

    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)

    shutil.copyfile(os.path.join(args.baseDir, 'params.xml'), os.path.join(args.baseDir, 'paramsOld.xml'))
    file = os.path.join(args.baseDir,"params.xml")

    tree = et.parse(file)

    root = tree.getroot()
    #retval=""
    #retval = StratBkey('CME_ESU7,CME_1YMU7')



    for elem in root.iter('item'):
        #count = len(elem.getchildren()) + 1
        retval=' '
        Key = elem.find('Key').text

        retval = StratBkey(Key)
        node = elem.find('Symbol')
        print(node)
        if node == None:
            print("Adding Symbol ", retval , "for key ", Key)
            FrequencyEl = et.Element("Symbol")
            FrequencyEl.text = retval
            elem.insert(1,FrequencyEl)
        else:
            print("Symbol exists for Instrument1")

        count = len(elem.getchildren())

        node = elem.find('ReplaceModeB')
        if node == None:
            print("Adding ReplaceModeB for key ", Key)
            FrequencyEl = et.Element("ReplaceModeB")
            FrequencyEl.text = '0'
            elem.insert(count,FrequencyEl)
            count = count +1
        else:
            print("ReplaceModeB exists for Instrument1")

        node = elem.find('MaxPositionsB')
        if node == None:
            print("Adding MaxPositionsB for key ", Key)
            FrequencyEl = et.Element("MaxPositionsB")
            if retval != ' ':
                FrequencyEl.text = '1'
            else:
                FrequencyEl.text = '2'
            elem.insert(count, FrequencyEl)
            count = count + 1
        else:
            print("MaxPositionsB exists for Instrument1")

        node = elem.find('HedgedSeries2B')
        if node == None:
            print("Adding HedgedSeries2B for key ", Key)
            FrequencyEl = et.Element("HedgedSeries2B")
            if retval != ' ':
                FrequencyEl.text = '0'
            else:
                FrequencyEl.text = '1'
            elem.insert(count, FrequencyEl)
            count = count + 1
        else:
            print("HedgedSeries2B exists for Instrument1")
        node = elem.find('Contracts')
        if node == None:
            print("Adding Contracts for key ", Key)

            #elem.SubElement(elem, 'Contracts')
            FrequencyEl = et.Element("Contracts")
            if retval != ' ':
                if Key.startswith('FXOTC'):
                    FrequencyEl.text = '1000000'
                else:
                    FrequencyEl.text = '0'
            else:
                FrequencyEl.text = '10'
            elem.insert(count, FrequencyEl)
        else:
            print("HedgedSeries2B exists for Instrument1")

    tree.write(os.path.join(args.baseOutDir, "paramsEdited2.xml"))
    print("done")

if __name__ == '__main__':
    main()