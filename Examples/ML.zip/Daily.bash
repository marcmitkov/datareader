#!/bin/bash

FROM=$(date '+%Y%m%d')
TO=$(date --date yesterday '+%Y%m%d')

echo $FROM
echo $TO

echo /home/lanarayan/MyProjects/ML/Test.bash -f ${FROM} -t ${TO} -e all
#/home/lanarayan/MyProjects/ML/RunA.bash -f ${FROM} -t ${TO} -e all

DAYOFWEEK=$(date '+%A')
echo $DAYOFWEEK

if [ ${DAYOFWEEK}=='Tuesday' ]
then
  echo 'itis' ${DAYOFWEEK}
  TO=$(date --date='2 day ago' '+%Y%m%d')
 fi
echo $TO


DAYOFWEEK=$(date --date yesterday '+%A')
echo $DAYOFWEEK