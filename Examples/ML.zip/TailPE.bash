#!/bin/bash 

DIRROOT=/big/svc_wqln/ML/BacktestsDailySim
VERSION=V1
NUMLINES=5
OUTPUTA=Fit-A-2019
OUTPUTB=Fit-B-2019
OUTPUTAB=Fit-AB-2019



 echo tail -${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTA}/${VERSION}/PortfolioExposure.csv
  tail -${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTA}/${VERSION}/PortfolioExposure.csv

 # echo tail -${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION}/PortfolioExposure.csv
 # tail -${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTB}/${VERSION}/PortfolioExposure.csv

  #echo tail -${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION}/PortfolioExposure.csv
  #tail -${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTAB}/${VERSION}/PortfolioExposure.csv
  
#google-chrome file:///home/lanarayan/MLData/Backtests/PosOut/Fit-AB-2019/V1/ConsolidatedPosRpt.html &  
google-chrome file:///home/lanarayan/MLData/Backtests/PosOut/Fit-A-2019/V1/ConsolidatedPosRpt.html &
#google-chrome file:///home/lanarayan/MLData/Backtests/PosOut/Fit-B-2014/V1/ConsolidatedPosRpt.html &