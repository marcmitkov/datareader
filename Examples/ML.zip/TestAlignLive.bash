#!/bin/bash
# Usage: if onetime arg provided run onetime else by default runs incremental
export PROMPT_COMMAND="echo -ne '\033]0;Resample $HOSTNAME $PWD\007'"

BASEOUT=/home/lanarayan/MLData
LOGFILE=${BASEOUT}/AlignLive.log
ROOT=/home/lanarayan/MyProjects/ML

declare -a SPREADLIST=("Smith" "Buffet" "Hayek" "Nash" "Friedman" "Keynes" "Marx" "Kondratiev")

declare -A CONTRACTSLEG1=( ["Smith"]="ES" ["Buffet"]="ES" ["Hayek"]="FV" ["Nash"]="TY" ["Friedman"]="TU" ["Keynes"]="TU" ["Marx"]="FV" ["Kondratiev"]="CL") 
declare -A CONTRACTSLEG2=( ["Smith"]="NQ" ["Buffet"]="1YM" ["Hayek"]="TY" ["Nash"]="US" ["Friedman"]="TY" ["Keynes"]="US" ["Marx"]="US" ["Kondratiev"]="LCO") 



for s in "${SPREADLIST[@]}"
do
  

       #STEP6:
        echo  ${ROOT}/LiveDataFilterB.py  -fileA ${CONTRACTSLEG1[$s]}.csv -fileB ${CONTRACTSLEG2[$s]}.csv  -baseDir ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]} 

          ${ROOT}/LiveDataFilterB.py  -fileA ${CONTRACTSLEG1[$s]}.csv -fileB ${CONTRACTSLEG2[$s]}.csv  -baseDir ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]} 

done
