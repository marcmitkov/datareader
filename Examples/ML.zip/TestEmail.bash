#!/bin/bash 

DIRROOT=/home/lanarayan/MLData/BacktestsAlpha
VERSION=V8
NUMLINES=1
OUTPUTA=Fit-A-2019
OUTPUTB=Fit-B-2019
OUTPUTAB=Fit-AB-2019



echo tail - n ${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTA}/${VERSION}/PortfolioExposure.csv
ZZ=$(tail -n ${NUMLINES} ${DIRROOT}/OutSim/${OUTPUTA}/${VERSION}/PortfolioExposure.csv)

echo $ZZ |mail -s 'PE line Test' lanarayan@worldquant.com