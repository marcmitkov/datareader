#!/big/svc_wqln/projects/python/conda/bin/python3.6

import pandas as pd
import argparse
import logging
import os
import shutil
import xml.etree.ElementTree as et

StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}

def AddNodesToConfig(filepath, file,baseOut):

    asset = file.split('-')[1]

    if '.' in asset:
        asset = asset.split('.')[0]
    legs = []
    if asset in StrategyBMap:
        #legsArr = StrategyBMap[asset]
        #legs.append(legsArr[0].split('_')[1][:-2])
        #legs.append(legsArr[1].split('_')[1][:-2])
        frequency = '1m'
    else:
        #legs.append(asset)
        fileSplit = file.split('.')[0]
        frequency = fileSplit.split('-')[-1]

    treeCfg = et.parse(os.path.join(filepath,file))
    rootCfg = treeCfg.getroot()
    for elem in rootCfg.iter('Instrument1'):
        #Add frequency node if missing
        node = elem.find('Frequency')
        print(node)
        if node == None:
            print("Adding Frequency")
            FrequencyEl = et.Element("Frequency")
            FrequencyEl.text = frequency
            elem.append(FrequencyEl)
        else:
            print("Frequency exists for Instrument1")

    for elem in rootCfg.iter('Instrument2'):
        # Add frequency node if missing
        node = elem.find('Frequency')
        print(node)
        if node == None:
            # elem.append('Frequency')
            FrequencyEl = et.Element("Frequency")
            FrequencyEl.text = frequency
            elem.append(FrequencyEl)
        else:
            print("Frequency exists for Instrument2")

    #filenoExt = file.split('.')[0]
    #shutil.move(os.path.join(filepath,file), os.path.join(filepath,filenoExt + "_bkup.xml"))

    #treeCfg.write(os.path.join(filepath,file))
    treeCfg.write(os.path.join(baseOut,file))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MyProjects/ML/Configs', help="base Directory")
    parser.add_argument('-baseOut', '--baseOut', default='/home/lanarayan/MyProjects/ML/ConfigsOut',
                        help="base Directory")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")

    args = parser.parse_args()
    print(args)

    logging.basicConfig(filename=os.path.join(args.logPath, "CreateConfigsLog.log"), filemode='w',
                        level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    args.baseOut = os.path.abspath(args.baseOut)
    if not os.path.exists(args.baseOut):
        print("Creating output folder :" + args.baseOut)
        os.makedirs(args.baseOut)

    #Read all configs from baseDir
    for dirpath, dirnames, filenames in os.walk(args.baseDir):
        for file in filenames:
            if file.startswith('config-'):
                AddNodesToConfig(args.baseDir,file,args.baseOut)



if __name__ == '__main__':
     main()