#!/bin/bash 

echo "you have provide $# argument" 
echo "arguments are $@" 
echo "usage: RunDailySim.bash  -m|--mode test|run -e|execute all" 

MODE='test'
EXECUTE='allz'
VERSION='V5'

while [[ $# -gt 0 ]]
do
key="$1"
echo "Key is $key"
echo "Value is $2"
case $key in
    -m|--mode)
    MODE="$2"
    shift # past argument
    shift # past value
    ;;   
    -e|--execute)
        lowerCaseArg="${2,,}"
    EXECUTE=${lowerCaseArg}
    shift # past argument
    shift # past value
    ;;
    *)    # unknown option
    echo "unknown Argument $1"
        echo "usage: RunDailySim.bash  -m|--mode test|run -e|execute all" 
     exit
    ;;
esac
done

echo Mode is ${MODE}
echo  Execute is ${EXECUTE}

ROOTDIR='/home/lanarayan/MyProjects/ML'
LOGROOT='/big/svc_wqln/ML/Backtests'

LOGDIR=${LOGROOT}/Logs 
LOGFILE=${LOGDIR}/RunDailySimNewDaVinciWIP-$(date '+%d%m%Y-%H:%M:%S').txt; 

function GenerateData {
    #Generate daily data for StratA
    echo ${ROOTDIR}/ResampleLive1Daily.bash
    if [ ${MODE} == 'run' ]
    then
      echo ${ROOTDIR}/ResampleLive1Daily.bash >> ${LOGFILE}
      ${ROOTDIR}/ResampleLive1Daily.bash
      if [ $? -eq 0 ]; 
            then
                    echo PASS ResampleLive1Daily
                    echo PASS ResampleLive1Daily >> ${LOGFILE}
            else 
                    echo FAIL ResampleLive1Daily
                    echo FAIL ResampleLive1Daily >> ${LOGFILE}
            fi
    fi
# Remove duplicates generated after Resampling and concatenating
echo ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live -removeDups
if [ ${MODE} == 'run' ]
then
echo ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live -removeDups >>${LOGFILE}

  ${ROOTDIR}/RemoveDataDuplicates.py -strategy A -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live -removeDups
  if [ $? -eq 0 ]; 
          then
                  echo PASS RemoveDataDuplicates
                  echo PASS RemoveDataDuplicates >> ${LOGFILE}
          else 
                  echo FAIL RemoveDataDuplicates
                  echo FAIL RemoveDataDuplicates >> ${LOGFILE}
          fi
fi

#Generate daily data for StratB
echo ${ROOTDIR}/AlignLiveDaily.bash
if [ ${MODE} == 'run' ]
then
  echo ${ROOTDIR}/AlignLiveDaily.bash >> ${LOGFILE}
  ${ROOTDIR}/AlignLiveDaily.bash
  if [ $? -eq 0 ]; 
          then
                  echo PASS AlignLiveDaily
                  echo PASS AlignLiveDaily >> ${LOGFILE}
          else 
                  echo FAIL AlignLiveDaily
                  echo FAIL AlignLiveDaily >> ${LOGFILE}
          fi
fi

#Optional: just checking for dups
#${ROOTDIR}/RemoveDataDuplicates.py -strategy B -baseDir /home/lanarayan/MLData/SimDaily/Futures/Live



}

function RunTestSimulator {
  
  echo ${ROOTDIR}/RunDailySimAlphaADaVinciWIP.bash  -e all
  
  
    if [ ${MODE} == 'run' ]
    then
      echo ${ROOTDIR}/RunDailySimAlphaADaVinciWIP.bash  -e all >> ${LOGFILE}
      ${ROOTDIR}/RunDailySimAlphaADaVinciWIP.bash  -e all
      if [ $? -eq 0 ]; 
              then
                      echo PASS RunDailySimAlphaA
                      echo PASS RunDailySimAlphaA >> ${LOGFILE}
              else 
                      echo FAIL RunDailySimAlphaA
                      echo FAIL RunDailySimAlphaA >> ${LOGFILE}
              fi
    fi
    
    
    
    echo ${ROOTDIR}/RunDailySimAlphaB.bash  -e all
  
  
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/RunDailySimAlphaB.bash  -e all >> ${LOGFILE}
    #  ${ROOTDIR}/RunDailySimAlphaB.bash  -e all
      if [ $? -eq 0 ]; 
              then
                      echo PASS RunDailySimAlphaB
                      echo PASS RunDailySimAlphaB >> ${LOGFILE}
              else 
                      echo FAIL RunDailySimAlphaB
                      echo FAIL RunDailySimAlphaB >> ${LOGFILE}
              fi
    fi
    
  }

function RunTestSimulatorOld {
    # Run Combinator, RunAlpha and Test Simulator for daily data
    echo ${ROOTDIR}/RunADaily.bash  -e all
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/RunADaily.bash  -e all >> ${LOGFILE}
      ${ROOTDIR}/RunADaily.bash  -e all
      if [ $? -eq 0 ]; 
              then
                      echo PASS RunADaily
                      echo PASS RunADaily >> ${LOGFILE}
              else 
                      echo FAIL RunADaily
                      echo FAIL RunADaily >> ${LOGFILE}
              fi
    fi

    echo ${ROOTDIR}/RunBDaily.bash  -e all
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/RunBDaily.bash  -e all >> ${LOGFILE}
    #${ROOTDIR}/RunBDaily.bash  -e all
      if [ $? -eq 0 ]; 
              then
                      echo PASS RunBDaily
                      echo PASS RunBDaily >> ${LOGFILE}
              else 
                      echo FAIL RunBDaily
                      echo FAIL RunBDaily >> ${LOGFILE}
              fi
    fi

}


# Date generation for GraphSim and PosReportAlpha

FROM=$(date --date='1 day ago' '+%Y%m%d')
TO=$(date '+%Y%m%d')

DAYOFWEEK=$(date '+%A')
echo $DAYOFWEEK

if [ ${DAYOFWEEK} == 'Monday' ]
then
  echo 'itis' ${DAYOFWEEK}
  FROM=$(date --date='3 day ago' '+%Y%m%d')
 fi
 
echo For GraphSimAlpha From: $FROM
echo For GraphSimAlpha To:$TO

function RunGraphSim {
    echo ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e AB
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e AB >> ${LOGFILE}
      ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e AB
      if [ $? -eq 0 ]; 
              then
                      echo PASS GraphSimAlphaAB
                      echo PASS GraphSimAlphaAB >> ${LOGFILE}
              else 
                      echo FAIL GraphSimAlphaAB
                      echo FAIL GraphSimAlphaAB >> ${LOGFILE}
              fi
    fi

}

function RunGraphSimA {
    echo ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e A
    
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e A >> ${LOGFILE}
      ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e A
      if [ $? -eq 0 ]; 
              then
                      echo PASS GraphSimAlphaA
                      echo PASS GraphSimAlphaA >> ${LOGFILE}
              else 
                      echo FAIL GraphSimAlphaA
                      echo FAIL GraphSimAlphaA >> ${LOGFILE}
              fi
    fi

}


function RunGraphSimB {
    echo ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e B
   
    if [ ${MODE} == 'run' ]
    then
    echo ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e B >> ${LOGFILE}
      ${ROOTDIR}/GraphSimAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e B
      if [ $? -eq 0 ]; 
              then
                      echo PASS GraphSimAlphaB
                      echo PASS GraphSimAlphaB >> ${LOGFILE}
              else 
                      echo FAIL GraphSimAlphaB
                      echo FAIL GraphSimAlphaB >> ${LOGFILE}
              fi
    fi

}

function RunPosAlphaA {
echo ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e A

if [ ${MODE} == 'run' ] 
        then
        echo ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e A >> ${LOGFILE}
        ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e A 
        if [ $? -eq 0 ];
        then
                echo PASS RunPosAlphaDailyA
                echo PASS RunPosAlphaDailyA >> ${LOGFILE} 
        else
                echo FAIL RunPosAlphaDailyA 
                echo FAIL RunPosAlphaDailyA >> ${LOGFILE}
        fi
fi
}


function RunPosAlphaB {

echo ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e B

if [ ${MODE} == 'run' ] 
        then
        echo ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e B >> ${LOGFILE}
        ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e B 
        if [ $? -eq 0 ]; 
        then
                echo PASS RunPosAlphaDailyB
                echo PASS RunPosAlphaDailyB >> ${LOGFILE} 
        else
                echo FAIL RunPosAlphaDailyB 
                echo FAIL RunPosAlphaDailyB >> ${LOGFILE}
        fi
fi
}
function RunPosAlphaAB {
echo ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e AB

if [ ${MODE} == 'run' ] 
        then
        echo ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e AB >> ${LOGFILE}
        ${ROOTDIR}/PosAlphaAlpha.bash -f ${FROM} -t ${TO} -v ${VERSION} -e AB        
        if [ $? -eq 0 ]; 
        then
                echo PASS RunPosAlphaDailyAB
                echo PASS RunPosAlphaDailyAB >> ${LOGFILE} 
        else
                echo FAIL RunPosAlphaDailyAB 
                echo FAIL RunPosAlphaDailyAB >> ${LOGFILE}
        fi
fi
}



if [ "$EXECUTE" == "all" ] 
then
        echo "Executing all in mode " ${MODE}
        RunTestSimulator
        #RunGraphSim
        #RunGraphSimA
        #RunGraphSimB
        #RunPosAlphaA
        #RunPosAlphaB
        #RunPosAlphaAB
  elif [ "$EXECUTE" == "data" ]
  then
	echo "Executing GenerateData in mode" ${MODE} 
        GenerateData
  elif [ "$EXECUTE" == "testsim" ]
  then
	echo "Executing RunTestSimulator in mode" ${MODE} 
	RunTestSimulator	
  elif [ "$EXECUTE" == "simab" ]
  then
	echo "Executing RunGraphSim in mode" ${MODE} 
                        RunGraphSim
  elif [ "$EXECUTE" == "sima" ]
  then
	echo "Executing RunGraphSimA in mode" ${MODE} 
                        RunGraphSimA
  elif [ "$EXECUTE" == "simb" ]
  then
        echo "Executing RunGraphSimB in mode" ${MODE} 
                        RunGraphSimB
  elif [ "$EXECUTE" == "pos" ]
  then
	echo "Executing PosAlpha A,B and AB in mode" ${MODE} 
	RunPosAlphaA
	#RunPosAlphaB
	#RunPosAlphaAB
   else
	echo "Invalid Execute option"
   fi


OUTPUTFILE='/home/lanarayan/cronOutput2.txt' 
#grep  "FAIL" $OUTPUTFILE

if grep -q "FAIL" $OUTPUTFILE
then
echo "send mail"

mail -s 'Daily Evening Cron failed' lanarayan@worldquant.com < $OUTPUTFILE
fi
#Run GraphSim and PosReportAlpha (e.g for running on 03/19)
#./GraphSim.bash -f 20190318 -t 20190319 -v V1 -e AB
#PosReportAlphaNew.py -baseDirA /home/lanarayan/MLData/Backtests/Fit-A-2019 -baseDirB /home/lanarayan/MLData/Backtests/Fit-B-2014 -baseOut /home/lanarayan/MLData/PosOutTest3/ -f 20190318 -t 20190319 -alphaFile /big/svc_wqln/ML/Backtests/AlphaList/V1/alphasAB.txt -groupBy Strategy -mode v

