#!/bin/bash
export PROMPT_COMMAND="echo -ne '\033]0;Runs Prod B $HOSTNAME $PWD\007'" 

echo "you have provide $# argument" 
echo "arguments are $@" 

function Test {
echo cp ${SCRIPTDIR}/Configs/config-${SPREAD}.xml config.xml
}

function RunAll {
        echo cp ${SCRIPTDIR}/Configs/config-${SPREAD}.xml config.xml
        cp ${SCRIPTDIR}/Configs/config-${SPREAD}.xml config.xml

        if [ $? -eq 0 ]; then
                echo ${SCRIPTDIR}/Combinatorv3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./ -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0
                echo ${SCRIPTDIR}/Combinatorv3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./ -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0 >> ${LOGFILE}
                 ${SCRIPTDIR}/CombinatorV3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./ -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0   
                #echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 
                #echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} >> ${LOGFILE}
                 #${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 

  #Different baseout VishnuWIP
                #echo ${SCRIPTDIR}/RunAlphaListDebug.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseOutDir /big/svc_wqln/ML/Backtests/TestWIPStratB -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 
                #echo ${SCRIPTDIR}/RunAlphaListDebug.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseOutDir /big/svc_wqln/ML/Backtests/TestWIPStratB -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} >> ${LOGFILE}
                 #${SCRIPTDIR}/RunAlphaListDebug.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseOutDir /big/svc_wqln/ML/Backtests/TestWIPStratB -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 

#Different baseout DaVinci
                echo ${SCRIPTDIR}/RunAlphaListDebug.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinci/build -baseOutDir /big/svc_wqln/ML/Backtests/TestDaVinciStratB -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 
                echo ${SCRIPTDIR}/RunAlphaListDebug.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinci/build -baseOutDir /big/svc_wqln/ML/Backtests/TestDaVinciStratB -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} >> ${LOGFILE}
                 ${SCRIPTDIR}/RunAlphaListDebug.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinci/build -baseOutDir /big/svc_wqln/ML/Backtests/TestDaVinciStratB -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 

        else
                echo FAIL ${INS}
        fi
}


function RunOnly {      
        #cp Configs/config-${SPREAD} -${TIME}.xml config.xml 
        cp ${SCRIPTDIR}/Configs/config-${SPREAD}.xml config.xml 
        if [ $? -eq 0 ]; 
                then
                        echo ${SCRIPTDIR}/Combinatorv3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./ -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0
                        echo ${SCRIPTDIR}/Combinatorv3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./ -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0 >> ${LOGFILE}
                        ${SCRIPTDIR}/Combinatorv3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./ -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0   
                        echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 
                        echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} >> ${LOGFILE}
                        ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 
                else
                        echo FAIL ${INS}
        fi
}
        
function RunRisk {
        #./RiskReport.py -f ${FROM} -t ${TO} -p /home/lanarayan/MyProjects/${RUN}/${SPREAD}/$TIME -baseOut /home/lanarayan/MyProjects/${RUN}/$ {SPREAD}/$TIME -S B-C ${SPREADCONTRACTS} -suffix $ {SPREAD} -legs $ {SPREADLEGS} 
        echo ${SCRIPTDIR}/RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}${RUN}/${SPREAD}/$TIME -baseOut ${ROOT}${RUN}/${SPREAD}/${TIME} -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS} -ptable 
        echo ${SCRIPTDIR}/RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}${RUN}/${SPREAD}/$TIME -baseOut ${ROOT}${RUN}/${SPREAD}/${TIME} -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS} -ptable >> ${LOGFILE}
        ${SCRIPTDIR}/RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}${RUN}/${SPREAD}/$TIME -baseOut ${ROOT}${RUN}/${SPREAD}/${TIME} -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS} -ptable 
        if [ $? -eq 0 ]; 
                then
                        echo PASS ${SPREAD}-${TIME} 
                else
                        echo FAIL ${SPREAD}-${TIME} 
        fi 
}

function RunPos {
        #INS1=${INS:0:3} ${INS:3:3} 
        #./PosReport.py - f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/${TIME} -groupBy Strategy -s ${SPREADGROUPS} -v True 
        echo ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/${TIME} -groupBy Strategy -s ${SPREADGROUPS} -v True -strategyType B 
        echo ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/${TIME} -groupBy Strategy -s ${SPREADGROUPS} -v True -strategyType B >> ${LOGFILE}
        echo ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/${TIME} -groupBy Strategy -s ${SPREADGROUPS} -v True -strategyType B 
        if [ $? -eq 0 ]; 
                then
                        echo PASS ${SPREAD}-${TIME}
                else
                        echo FAIL ${SPREAD}/${TIME}
        fi
}

function TestRunAll {
        #echo cp Configs/config-${SPREAD}-${TIME}.xml config.xml
        echo cp ${SCRIPTDIR}/Configs/config-${SPREAD}-${TIME}.xml config.xml 
        if [ $? -eq 0 ]; 
                then
                        echo ${SCRIPTDIR}/Combinatorv3.py -r ${ROOT}/${RUN}/$SPREAD/$TIME/ -baseDir ./ -MultiplierB ${MULTIPLIER} -StopMultiplierB ${MULTIPLIER} -TargetMultiplierB ${MULTIPLIER} -RebalanceB ${REBALANCE} -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0
                        echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${SPREAD}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/VishnuWIP/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} 
                        echo ${SCRIPTDIR}/RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}${RUN}/${SPREAD}/$TIME -baseOut ${ROOT}${RUN}/${SPREAD}/${TIME} -s B -c ${SPREADCONTRACTS} -suffix ${SPREAD} -legs ${SPREADLEGS} -ptable 
                        echo ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/${SPREAD}/$TIME -output ${ROOT}/${RUN}/${SPREAD}/${TIME} -groupBy Strategy -s ${SPREADGROUPS} -v True -strategyType B 

                else
                        echo FAIL ${SPREAD}
        fi
}

ROOT='/big/svc_wqln/ML/Backtests' 
SCRIPTDIR='/home/lanarayan/MyProjects/ML'

#for arg in "$@" 
#do
#       if [ "$arg" == "--help" ] || [ "$arg" == "-h" ] 
#       then
#               echo "-t ROOT set to /big/svc_wqln/ML/Othertests"
#       fi
#       if [ "$arg" == "--test" ] | [ "$arg" == "-t" ] 
#       then
#               ROOT='/big/svc wqln/ML/Othertests'
#               echo "ROOT set to $ROOT" 
#       fi 
#done 

LOGDIR=${ROOT}/Logs 
LOGFILE=${LOGDIR}/RunB-$(date '+%d%m%Y-%H:%M:%S').txt; 
echo $LOGFILE
[ -d ${LOGDIR} ] || echo mkdir -p ${LOGDIR} 
[ -d ${LOGDIR} ] || mkdir -p ${LOGDIR}

RUN="Fit-B-2014" 
#RUN="RunJune21" 
#FROM="20190109" 
#FROM="20180824" 
#TO="20190124" 
FROM="20190131" 
TO="20190201" 
EXCHANGE="CME_" 
#MULTIPLIER=2,3,4 
MULTIPLIER=2 
REBALANCE=0
TIME="1m" 
#SPREAD=Smith Hayek 
SPREADCONTRACTS="" 
SPREADLEGS="" 
SPREADGROUPS="" 

#Start
while [[ $# -gt 0 ]]
do
key="$1"
#echo "Key is $key"
#echo "Value is $2"

case $key in
    -f|--from)
    FROM="$2"
    shift # past argument
    shift # past value
    ;;
    -t|--to)
    TO="$2"
    shift # past argument
    shift # past value
    ;;
    -m|--multiplier)
    MULTIPLIER="$2"
    shift # past argument
    shift # past value
    ;;
        -r|--rebalance)
    REBALANCE="$2"
    shift # past argument
    shift # past value
    ;;
        -e|--execute)
        lowerCaseArg="${2,,}"
    EXECUTE=${lowerCaseArg}
    shift # past argument
    shift # past value
    ;;
        -b|--basedir)
    RUN="$2"
    shift # past argument
    shift # past value
    ;;       
    *)    # unknown option
    echo "unknown Argument $1"
        echo "usage: RunStratB.bash -e all|risk|pos|test -f|from 20190101 -t|to 20190202 -r|--rebalance 0,1 -m|--multiplier 2,3,4"
        echo "usage: RunStratB.bash -e all|risk|pos|test -f 20190101 -t 20190202 -r 0,1 -m 2,3,4"
        exit 1
    ;;
esac
done

echo ROOT = ${ROOT}
echo RUN = ${RUN}
echo FROM = "${FROM}"
echo TO = "${TO}"
echo MULTIPLIER = "${MULTIPLIER}"
echo REBALANCE = "${REBALANCE}"
echo EXECUTE = "${EXECUTE}"

#end
declare -a SPREADLIST=("Smith") 
#declare -a SPREADLIST=("Smith" "Buffet" "Hayek" "Nash" "Friedman" "Keynes" "Marx" "Kondratiev")

declare -A CONTRACTSLEG1=( ["Smith"]="ES" ["Buffet"]="ES" ["Hayek"]="FV" ["Nash"]="TY" ["Friedman"]="TU" ["Keynes"]="TU" ["Marx"]="FV" ["Kondratiev"]="CL") 
declare -A CONTRACTSLEG2=( ["Smith"]="NQ" ["Buffet"]="1YM" ["Hayek"]="TY" ["Nash"]="US" ["Friedman"]="TY" ["Keynes"]="US" ["Marx"]="US" ["Kondratiev"]="LCO") 
AFFIX="U7" 
GROUPBY="Strategy" 
SG="Spread Momentum"

for s in "${SPREADLIST[@]}"
do
#echo "QQQQQQQQQQQQQQxx" 
SPREAD=$s 
#echo "${CONTRACTS[Buffet]}" 
SPREADCONTRACTS="${CONTRACTSLEG1[$s]} ${CONTRACTSLEG2[$s]}"
#echo "$SPREADCONTRACTS" 
SPREADLEGS="$EXCHANGE${CONTRACTSLEG1[$s]}$AFFIX $EXCHANGE${CONTRACTSLEG2[$s]}$AFFIX" 
SPREADGROUPS="$SPREADLEGS $EXCHANGE${CONTRACTSLEG1[$s]}$AFFIX$EXCHANGE${CONTRACTSLEG2[$s]}$AFFIX" 
#echo "$SPREADCONTRACTS" 
#RunOnly 
#RunRisk 
#RunPos 
#TestRunAll
#RunAll 
if [ "$EXECUTE" == "all" ] 
                then
                        echo "Executing RunAll"
                        RunAll
                elif [ "$EXECUTE" == "risk" ]
                then
                        echo "Executing RunRisk"
                        RunRisk
                elif [ "$EXECUTE" == "pos" ]
                then
                        echo "Executing RunPos"
                        RunPos
                elif [ "$EXECUTE" == "test" ]
                then
                        echo "Executing TestRunAll"
                        TestRunAll
                else
                        echo "Executing Default TestRunAll"
                        TestRunAll
        fi

done
exit 0
