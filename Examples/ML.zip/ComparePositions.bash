#!/bin/bash 

/home/lanarayan/MyProjects/ML/ComparePositions.py -baseDir /home/lanarayan/MLData/BacktestsV4/Fit-A-2019/NQ/1H -f 20181022 -t 20181024 -s CME_NQU7 -sg Momentum -output /home/lanarayan/MLData/BacktestsV4/Fit-A-2019/NQ -param 4



/home/lanarayan/MyProjects/ML/ComparePositions.py -baseDir /home/lanarayan/MLData/Backtests1H/Fit-A-2019/NQ/1H -f 20181022 -t 20181024 -s CME_NQU7 -sg Momentum -output /home/lanarayan/MLData/Backtests1H/Fit-A-2019/NQ -param 2


diff /home/lanarayan/MLData/BacktestsV4/Fit-A-2019/NQ/1H/Maindf.csv /home/lanarayan/MLData/Backtests1H/Fit-A-2019/NQ/1H/Maindf.csv > /home/lanarayan/MyProjects/ML/ComparePositionsDiff.txt