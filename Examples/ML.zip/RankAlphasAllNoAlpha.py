#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import numpy as np
import argparse
import Common as co
import webbrowser
import shutil
import os

#basedir is the ouputdir from RiskReport
# Will produce RankAlphasReport.csv in baseOut and copy return_xx and openPositionCount_xx to p1, p2 and  p3 folders under -pdir

dictionary = {
               'Smith' : ['ES', 'NQ'],'Buffet' : ['ES','1YM'] , 'Hayek':['FV','TY'], 'Nash':['TY','US'], 'Friedman':['TU','TY'], 'Keynes':['TU','US'], 'Marx':['FV','US'],'Kondratiev':['CL','LCO']
             }

# baseout - spreadsheet output
# portfoliodir - p1 created in this dir; return_xx and openPositionCount copied to each dir

listStrategyB = ['Keynes', 'Buffet', 'Smith', 'Nash', 'Friedman', 'Hayek', 'Marx', 'Tinbergen','Kondratiev']
def RankAlphasNew(baseDir, baseOutDir,portfolioDir,rankCount,rankBy,selectCriteria,rank):
    rankDF = pd.DataFrame()

    dirs = os.listdir(baseDir)

    totalDF = pd.DataFrame()
    for d in dirs:
        # Hayek
        dftmp = pd.DataFrame()
        if os.path.isdir(os.path.join(baseDir, d)):
            subdirs = os.listdir(os.path.join(baseDir, d))

            # determine whether is strat a or strat b
            if d in listStrategyB:
                lst = ['1m']
            else:
                lst = ['15m', '1H', '4H', '1D']

            for d1 in subdirs:
                if d1 in lst:
                    print("Reading file:",os.path.join(baseDir, d, d1, 'ConsolidatedParamsAndIncept.csv'))
                    csvPath = os.path.join(baseDir, d, d1, 'ConsolidatedParamsAndIncept.csv')
                    dirpath = os.path.join(baseDir, d, d1)
                    dftmp = pd.read_csv(csvPath)
                    alpha = os.path.split(os.path.split(dirpath)[0])[1] + os.path.basename(dirpath)
                    dftmp['alpha'] = alpha
                    # Get first ranks
                    # dftmp= dftmp.iloc[0:1]
                    if len(dftmp) < rank:
                        print("WARNING: Rank value is greater than number of records")
                    #dftmp = dftmp.iloc[(rank - 1):rank]
                    dftmp = dftmp.iloc[0:rank]
                    dftmp = dftmp[
                        ['alpha', 'pname', 'TotalReturn', 'SharpeRatio', 'HoldingPeriod', 'RebalanceB', 'MultiplierB',
                         'TargetMultiplierB', 'StopMultiplierB']]
                    print(dirpath)
                    # Get first row from each file
                    dftmp['Dirpath'] = dirpath
                    totalDF = totalDF.append(dftmp)

    totalDF = totalDF.sort_values([rankBy], ascending=False)
    totalRankCountDF = totalDF.iloc[0:rankCount]
    counter = 0
    alphaList =[]  # list of alphas for generating weights file
    for index, row in totalRankCountDF.iterrows():
        #outDir = os.path.join(portfolioDir, 'p' + str(counter + 1))
        outDir = os.path.join(portfolioDir, selectCriteria)
        if not os.path.exists(outDir):
                print('making dir:', outDir)
                os.makedirs(outDir)
        dirpathFromDF = row['Dirpath']
        strat = os.path.split(os.path.split(dirpathFromDF)[0])[1]

        if strat in listStrategyB:
            strategy = 'B'
        else:
            strategy = 'A'
        if strategy == 'A':
            alphaList.append(os.path.split(os.path.split(dirpathFromDF)[0])[1] + '_' + os.path.basename(dirpathFromDF))
            fileSuffix = os.path.split(os.path.split(dirpathFromDF)[0])[1] + '_' + os.path.basename(dirpathFromDF) + '.csv'
            #returnFile = os.path.join(dirpathFromDF, dftmp.loc[counter, 'pname'], 'return_' + fileSuffix)
            #posCountFile = os.path.join(dirpathFromDF, dftmp.loc[counter, 'pname'], 'openPositionCount_' + fileSuffix)
            returnFile = os.path.join(dirpathFromDF, row['pname'], 'return_' + fileSuffix)
            posCountFile = os.path.join(dirpathFromDF, row['pname'], 'openPositionCount_' + fileSuffix)

            print('returnFile:', returnFile)
            print('posCountFile:', posCountFile)
            print('Copying file:', returnFile, ' to:', os.path.join(outDir, 'return_' + fileSuffix))
            print('Copying file:', posCountFile, ' to:',
                  os.path.join(outDir, 'openPositionCount_' + fileSuffix))

            shutil.copyfile(returnFile, os.path.join(outDir, 'return_' + fileSuffix))
            shutil.copyfile(posCountFile, os.path.join(outDir, 'openPositionCount_' + fileSuffix))
        elif strategy == 'B':
            alphaName = os.path.split(os.path.split(dirpathFromDF)[0])[1]
            alphaList.append(alphaName)
            returnfileName = "return_" + dictionary[alphaName][0] + dictionary[alphaName][1] + "_" + alphaName + ".csv"
            # openPositionCount_CME_ESU7_Smith
            posCountFileName = "openPositionCount_CME_" + dictionary[alphaName][0] + "U7" + "_" + alphaName + ".csv"
            posCountFileName2 = "openPositionCount2_CME_" + dictionary[alphaName][1] + "U7" + "_" + alphaName + ".csv"
            returnFile = os.path.join(dirpathFromDF, row['pname'], returnfileName)
            posCountFile = os.path.join(dirpathFromDF, row['pname'], posCountFileName)
            posCountFile2 = os.path.join(dirpathFromDF, row['pname'], posCountFileName2)
            print('Copying file:', returnFile, ' to:', os.path.join(outDir, returnfileName))
            print('Copying file:', posCountFile, ' to:', os.path.join(outDir, posCountFileName))
            print('Copying file:', posCountFile2, ' to:', os.path.join(outDir, posCountFileName2))
            shutil.copyfile(returnFile, os.path.join(outDir, returnfileName))
            shutil.copyfile(posCountFile, os.path.join(outDir, posCountFileName))
            shutil.copyfile(posCountFile2, os.path.join(outDir, posCountFileName2))

    dfAlpha = pd.DataFrame([alphaList])
    # file used by GenerateWeightsNew script to create the weights file
    dfAlpha.to_csv(os.path.join(portfolioDir,selectCriteria, 'WeightsAlphaList.csv'), index=False)
    totalRankCountDF.to_csv(os.path.join(portfolioDir,selectCriteria,  'Top' + str(rankCount) + 'AlphaList.csv'), index=False)

    return totalDF

def RankAlphas(baseDir, baseOutDir,portfolioDir,rankCount,rankBy,selectCriteria,rank):
    rankDF = pd.DataFrame()
    totalDF = pd.DataFrame()
    #alphaCount = 0 # For creating weightsfile
    for dirpath, dirnames, filenames in os.walk(baseDir):
        '''if (os.path.basename(dirpath)).startswith("params"):
            continue;
        npath = os.path.normpath(dirpath)
        pathList = npath.split(os.sep)
        result = any("params" in word for word in pathList)
        if result:
            continue;'''
        for file in filenames:
            if file.startswith('ConsolidatedParamsAndIncept.csv'):
                #alphaCount = alphaCount +1
                dftmp = pd.DataFrame()
                csvPath = os.path.join(dirpath, file)
                dftmp = pd.read_csv(csvPath)
                alpha = os.path.split(os.path.split(dirpath)[0])[1] + os.path.basename(dirpath)
                dftmp['alpha'] = alpha
                # Get first ranks
                #dftmp= dftmp.iloc[0:1]
                if len(dftmp) < rank:
                    print("WARNING: Rank value is greater than number of records")
                dftmp = dftmp.iloc[(rank-1):rank]
                dftmp = dftmp[['alpha','pname','TotalReturn','SharpeRatio','HoldingPeriod','RebalanceB','MultiplierB','TargetMultiplierB','StopMultiplierB']]
                print(dirpath)
                #Get first row from each file
                dftmp['Dirpath'] = dirpath
                totalDF = totalDF.append(dftmp)
                break;

    #totalDF =totalDF.sort_values(['TotalReturn'], ascending=False)
    totalDF = totalDF.sort_values([rankBy], ascending=False)
    totalDF = totalDF.iloc[0:rankCount]
    counter = 0
    alphaList =[]  # list of alphas for generating weights file
    for index, row in totalDF.iterrows():
        #outDir = os.path.join(portfolioDir, 'p' + str(counter + 1))
        outDir = os.path.join(portfolioDir, selectCriteria)
        if not os.path.exists(outDir):
                print('making dir:', outDir)
                os.makedirs(outDir)
        dirpathFromDF = row['Dirpath']
        strat = os.path.split(os.path.split(dirpathFromDF)[0])[1]

        if strat in listStrategyB:
            strategy = 'B'
        else:
            strategy = 'A'
        if strategy == 'A':
            alphaList.append(os.path.split(os.path.split(dirpathFromDF)[0])[1] + '_' + os.path.basename(dirpathFromDF))
            fileSuffix = os.path.split(os.path.split(dirpathFromDF)[0])[1] + '_' + os.path.basename(dirpathFromDF) + '.csv'
            #returnFile = os.path.join(dirpathFromDF, dftmp.loc[counter, 'pname'], 'return_' + fileSuffix)
            #posCountFile = os.path.join(dirpathFromDF, dftmp.loc[counter, 'pname'], 'openPositionCount_' + fileSuffix)
            returnFile = os.path.join(dirpathFromDF, row['pname'], 'return_' + fileSuffix)
            posCountFile = os.path.join(dirpathFromDF, row['pname'], 'openPositionCount_' + fileSuffix)

            print('returnFile:', returnFile)
            print('posCountFile:', posCountFile)
            print('Copying file:', returnFile, ' to:', os.path.join(outDir, 'return_' + fileSuffix))
            print('Copying file:', posCountFile, ' to:',
                  os.path.join(outDir, 'openPositionCount_' + fileSuffix))

            shutil.copyfile(returnFile, os.path.join(outDir, 'return_' + fileSuffix))
            shutil.copyfile(posCountFile, os.path.join(outDir, 'openPositionCount_' + fileSuffix))
        elif strategy == 'B':
            alphaName = os.path.split(os.path.split(dirpathFromDF)[0])[1]
            alphaList.append(alphaName)
            returnfileName = "return_" + dictionary[alphaName][0] + dictionary[alphaName][1] + "_" + alphaName + ".csv"
            # openPositionCount_CME_ESU7_Smith
            posCountFileName = "openPositionCount_CME_" + dictionary[alphaName][0] + "U7" + "_" + alphaName + ".csv"
            posCountFileName2 = "openPositionCount2_CME_" + dictionary[alphaName][1] + "U7" + "_" + alphaName + ".csv"
            returnFile = os.path.join(dirpathFromDF, row['pname'], returnfileName)
            posCountFile = os.path.join(dirpathFromDF, row['pname'], posCountFileName)
            posCountFile2 = os.path.join(dirpathFromDF, row['pname'], posCountFileName2)
            print('Copying file:', returnFile, ' to:', os.path.join(outDir, returnfileName))
            print('Copying file:', posCountFile, ' to:', os.path.join(outDir, posCountFileName))
            print('Copying file:', posCountFile2, ' to:', os.path.join(outDir, posCountFileName2))
            shutil.copyfile(returnFile, os.path.join(outDir, returnfileName))
            shutil.copyfile(posCountFile, os.path.join(outDir, posCountFileName))
            shutil.copyfile(posCountFile2, os.path.join(outDir, posCountFileName2))

    dfAlpha = pd.DataFrame([alphaList])
    # file used by GenerateWeightsNew script to create the weights file
    dfAlpha.to_csv(os.path.join(portfolioDir,selectCriteria, 'WeightsAlphaList.csv'), index=False)
    return totalDF

    #rankDF.to_csv(os.path.join(baseOutDir, 'AlphasRankReport.csv'), index=False)
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-baseDir', '--baseDir', default='C:/MyProjects/WQMaster/posdataTestWQ', help="base Directory")

    parser.add_argument('-baseOut', '--baseOutDir', default='C:/MyProjects/WQMaster/posdataTestWQ', help="output Directory")
    parser.add_argument('-pdir', '--portfolioDir', default='C:/MyProjects/WQMaster/posdataTestWQ/UN', help="output Directory")
    #parser.add_argument('-s', '--strategy', default='', help="A for strategy A , B for Strategy B")
    parser.add_argument('-rankCount', '--rankCount', default='10', help="Rank Count")
    parser.add_argument('-rankBy', '--rankBy', default='SharpeRatio', help="Rank by") # or SharpeRatio
    parser.add_argument('-rank', '--rank', default='1', help="Rank 1 or 2 or 3 etc (top or second or third etc)")
    parser.add_argument('-sc', '--selectCriteria', default='', help="e.g:top10equalWtSharpe")

    args = parser.parse_args()
    args.baseDir = os.path.abspath(args.baseDir)

    if not os.path.exists(args.portfolioDir):
        os.makedirs(args.portfolioDir)

    if not os.path.exists(args.baseOutDir):
        os.makedirs(args.baseOutDir)

    rankDFTotal = pd.DataFrame()

    rankCount = int(args.rankCount)
    rank = int(args.rank)
    '''if args.strategy == 'zz':
        rankDFA = RankAlphas(os.path.join(args.baseDir,'StratA'), args.baseOutDir, args.portfolioDir, 'A',rankCount,args.rankBy,args.selectCriteria,rank)
        rankDFB = RankAlphas(os.path.join(args.baseDir,'StratB'), args.baseOutDir, args.portfolioDir, 'B',rankCount,args.rankBy,args.selectCriteria,rank)
        rankDFTotal = rankDFTotal.append(rankDFA)
        rankDFTotal = rankDFTotal.append(rankDFB)
    else:'''
    rankDF = RankAlphasNew(args.baseDir, args.baseOutDir, args.portfolioDir,rankCount,args.rankBy,args.selectCriteria,rank)
    rankDFTotal =rankDFTotal.append(rankDF)

    rankDFTotal.to_csv(os.path.join(args.baseOutDir, 'AlphasRankReport-' + args.selectCriteria +'.csv'), index=False)

if __name__ == '__main__':
    main()