#!/bin/bash

#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejs/scripts/positionServer.js start=20130901 end=20171201 base=/big/svc_wqln/ML/Backtests/StratA/ES/1D/params-0"
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20180101 end=20181201 base=/home/lanarayan/MLData/Backtests/Fit-A-2019/ES/1D/params-0"
# Test url
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190101 end=20191201 base=/home/lanarayan/UAT/VishnuWIP/build/ES/15m/params-0 file=openpositions.txt"

#Using alphaList
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190101 end=20190303 file=positions.txt alpha=/big/svc_wqln/ML/Backtests/AlphaList/V1/alphasAB.txt baseA=/big/svc_wqln/ML/Backtests/Fit-A-2019 baseB=/big/svc_wqln/ML/Backtests/Fit-B-2014"
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190101 end=20190303 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasAB.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014"

#Debug using alphalist
#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190101 end=20190105 file=positions.txt alpha=/home/lanarayan/MLData/Backtests/AlphaList/V1/alphasHayek.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014"

#gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190318 end=20190321 file=positions.txt alpha=/home/lanarayan/MyProjects/ML/alphasUN.txt baseA=/home/lanarayan/MLData/Backtests/Fit-A-2019 baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014"
gnome-terminal -e "/home/lanarayan/MyProjects/nodejsinstall/node-v8.11.2-linux-x64/bin/node /home/lanarayan/MyProjects/WQMaster/nodejsDev/scripts/positionServer.js start=20190318 end=20190321 file=positions.txt alpha=/home/lanarayan/MyProjects/ML/alphasUN.txt baseA=/home/lanarayan/MLData/Backtests/TestWIPStratA baseB=/home/lanarayan/MLData/Backtests/Fit-B-2014"


xdg-open file:///home/lanarayan/MyProjects/WQMaster/nodejsDev/PositionJQXClient.html

