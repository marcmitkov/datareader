#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
from datetime import datetime
import argparse
import logging
import os
from functools import reduce

StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7'], 'Bernanke':['CME_TNU7','CME_AULU7']}

def main():
    parser = argparse.ArgumentParser(description="Create Positions Reports Script")

    parser.add_argument('-assets', '--assets', default=['Keynes', 'Nash', 'Friedman', 'Hayek', 'Marx','Kondratiev', 'Bernanke' ], help="file location input series a",
                        nargs='*')
    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MLData/Futures/Live', help="base Directory")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")

    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath, 'MergeTwoDays' + dateForLog + '.log'),
                        filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    #Read csv files
    assetList = args.assets

    dfMap ={} # will store dict with key (e.g TY) and value(df of TU_2d.csv)

    # put xx_2d.csv files in dfMap
    for item in assetList:
        legs = StrategyBMap[item]
        legs0 = legs[0].split('_')[1][0:-2] #TU
        legs1 = legs[1].split('_')[1][0:-2]  # TY

        print("legs for " , item , " are: ", legs0, " and ", legs1)
        logging.debug("legs for {} are: {} and {}".format(item, legs0,legs1))

        #only add to map if file not already read
        if legs0 not in dfMap.keys():
            path = os.path.join(args.baseDir, legs0 + legs1, legs0 + "_2d.csv")
            print("Adding Key to map: ", legs0)
            dfMap[legs0] = pd.read_csv(path)#path
        if legs1 not in dfMap.keys():
            print("Adding Key to map: ", legs1)
            path = os.path.join(args.baseDir, legs0 + legs1, legs1 + "_2d.csv")
            dfMap[legs1]= pd.read_csv(path)#path

    #Create master date list
    dateList = []
    for s, df in dfMap.items():
        dfx = df[['date']]
        for item in list(dfx['date']):
            dateList.append(item)

    #remove duplicate dates from date list
    dateListNoDups = list(dict.fromkeys(dateList))

    # Convert date list to dataframe to merge with dfs in dfMap
    dfDate = pd.DataFrame(dateListNoDups, columns=['date'])

    # convert date column to datetime and sort; reset index
    dfDate['date'] = pd.to_datetime(dfDate['date'])
    dfDate.sort_values(by='date',inplace=True)
    dfDate.reset_index(inplace=True, drop=True)

    for assetName, df in dfMap.items():
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values(by='date')
        mergeddf = pd.merge(dfDate, df, on='date', how='outer')
        mergeddf.fillna(method='ffill', inplace=True)
        mergeddf.fillna(method='bfill', inplace=True)
        print("Asset: ",assetName)
        for item in assetList:
            legs = StrategyBMap[item]
            legs0 = legs[0].split('_')[1][0:-2]  # TU
            legs1 = legs[1].split('_')[1][0:-2]  # TY
            if assetName == legs0 or assetName == legs1:
                file = os.path.join(args.baseDir, legs0+legs1 , assetName +"_2dx.csv")
                print("Writing file :", file)
                mergeddf.to_csv(file,index=False)


if __name__ == '__main__':
     main()