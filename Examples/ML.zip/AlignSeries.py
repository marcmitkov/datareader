#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
#from IPython.display import display
#from IPython.display import Image
import datetime
import argparse
import numpy as np
import Common as co
import glob
import dateutil.relativedelta
from datetime import date, timedelta
from datetime import datetime
from pathlib import Path
import platform
import os
import logging

def ReadSeries(a,b):
    df1 = pd.read_csv(a)
    df2 = pd.read_csv(b)
    return df1,df2

def CheckMergedDuplicates(mergeddf1,fhLog,logPath,contract):
    if len(mergeddf1[mergeddf1.duplicated(['date'], keep='last')]) > 0:
        # print('duplicated mergeddf1', mergeddf1[mergeddf1.duplicated(['date'], keep='last')])
        # print('# duplicated mergeddf1', len(mergeddf1[mergeddf1.duplicated(['date'], keep='last')]))
        dupDF = mergeddf1[mergeddf1.duplicated(['date'], keep='last')]
        fhLog.write(datetime.now().strftime("%Y%m%d %H:%M:%S") + ' # duplicated mergeddf1: ' + contract + "::" + str(
            len(df1[df1.duplicated(['date'], keep='last')])) + '\n')
        dupDF.to_csv(os.path.join(logPath, "Duplicates" + contract + ".txt"))
   
#TODO:
# Check production default settings fot outbasedir, outA, outB
# Remove args not required

#NOTES:
# -r  option is created in baseoutdir

parser = argparse.ArgumentParser(description="Data Cleanup for Series Alignment Script")

parser.add_argument('-f','--fromDate', default='20150101',help="from date")
parser.add_argument('-t','--toDate', default='20150705',help="to date")
parser.add_argument('-contractA','--contractA', default='ES',help="contractA")
parser.add_argument('-contractB','--contractB', default='NQ',help="contractB")
parser.add_argument('-m','--mergeType',default='union',help="merge type (union or intersect)")
parser.add_argument('-v','--verbose',default='false',help="verbose")
parser.add_argument('-e','--env', default='dev',help="dev environ")
parser.add_argument('-resample','--resample', default='',help="resample folder")
parser.add_argument('-fileToAlign','--fileToAlign', default='',help="fileToAlign")
parser.add_argument('-log','--log', default='/home/lanarayan/MLData',help="log for duplicates")


args, unknown = parser.parse_known_args()
print(args)

environment = args.env
currentPlatform = platform.system()

print('Environment: ',environment)
print('Platform: ',currentPlatform)

# banku:  why this?  can't you just parse args 2 times,  once here and then later? and decide on prod/dev based on first parse?
if (platform.system() =='Windows'):
    #parser.add_argument('-a','--fileA',default='C:/MyProjects/WQMaster/data/ES-Sep2017.csv',help="file location input series a")
    #parser.add_argument('-b','--fileB',default='C:/MyProjects/WQMaster/data/NQ-Sep2017.csv',help="file location input series a")
    parser.add_argument('-outA','--outfileA',default='C:/MyProjects/WQMaster/output/mergeddf1.csv',help="file location output file a")
    parser.add_argument('-outB','--outfileB',default='C:/MyProjects/WQMaster/output/mergeddf2.csv',help="file location output file b")
    parser.add_argument('-r','--report',default='reportSummary.txt',help="file location report summary")
    parser.add_argument('-outNA_A','--outNA_A',default='NAdf1.csv',help="file location output file a for NA after Union")
    parser.add_argument('-outNA_B','--outNA_B',default='NAdf2.csv',help="file location output file b for NA after Union")
    parser.add_argument('-base','--baseDir', default='C:/MyProjects/WQMaster/data/Futures/',help="base Directory")
    parser.add_argument('-baseOut','--baseOutDir', default='C:/MyProjects/WQMaster/output/',help="base Directory")

elif (environment == 'prod') :
    # banku: do according to scan sent
    #parser.add_argument('-a','--fileA',default='/home/svc_wqln/big/data/Futures/TY/2015/01/TYH5_20150125.csv',help="file location input series a")
    #parser.add_argument('-b','--fileB',default='/home/svc_wqln/big/data/Futures/FV/2015/01/FVH5_20150125.csv',help="file location input series a")
    parser.add_argument('-outA','--outfileA',default='./output/mergeddf1.csv',help="file location output file a")
    parser.add_argument('-outB','--outfileB',default='./output/mergeddf2.csv',help="file location output file b")
    parser.add_argument('-r','--report',default='reportSummary.txt',help="file location report summary")
    parser.add_argument('-outNA_A','--outNA_A',default='NAdf1.csv',help="file location output file a for NA after Union")
    parser.add_argument('-outNA_B','--outNA_B',default='NAdf2.csv',help="file location output file b for NA after Union")
    parser.add_argument('-base','--baseDir', default='/home/svc_wqln/big/data/Futures/',help="base Directory")
    parser.add_argument('-baseOut','--baseOutDir', default='C:/MyProjects/WQMaster/output/',help="base Directory")
else:
    #parser.add_argument('-a','--fileA',default='/home/lanarayan/MyProjects/WQMaster/data/Futures/TY/2015/01/TYH5_20150125.csv',help="file location input series a")
    #parser.add_argument('-b','--fileB',default='/home/lanarayan/MyProjects/WQMaster/data/Futures/FV/2015/01/FVH5_20150125.csv',help="file location input series a")
    parser.add_argument('-outA','--outfileA',default='/home/lanarayan/MyProjects/WQMaster/output/mergeddf1.csv',help="file location output file a")
    parser.add_argument('-outB','--outfileB',default='/home/lanarayan/MyProjects/WQMaster/output/mergeddf2.csv',help="file location output file b")
    parser.add_argument('-r','--report',default='reportSummary.txt',help="file location report summary")
    parser.add_argument('-outNA_A','--outNA_A',default='/home/lanarayan/MyProjects/WQMaster/output/NAdf1.csv',help="file location output file a for NA after Union")
    parser.add_argument('-outNA_B','--outNA_B',default='/home/lanarayan/MyProjects/WQMaster/output/NAdf2.csv',help="file location output file b for NA after Union")
    parser.add_argument('-base','--baseDir', default='/home/lanarayan/MyProjects/WQMaster/data/Futures/',help="base Directory")
    parser.add_argument('-baseOut','--baseOutDir', default='/home/lanarayan/MyProjects/WQMaster/output/',help="base Directory")

#parser.print_help()
args = parser.parse_args()
print(args)

# Gets absolute path even if all path folders dont exist, first do this then do os.path.exists to create if required
args.baseOutDir = os.path.abspath(args.baseOutDir)
args.baseDir = os.path.abspath(args.baseDir)
#args.outNA_A = os.path.abspath(args.outNA_A)
#args.outNA_B = os.path.abspath(args.outNA_B) #Create in baseoutdir/temp
#print (args.baseOutDir)

if not os.path.exists(args.baseOutDir):
        os.makedirs(args.baseOutDir)

debugTmpPath = os.path.join(args.baseOutDir,"temp")
if not os.path.exists(debugTmpPath):
       print("Creating temp folder :"+ debugTmpPath) 
       os.makedirs(debugTmpPath)

logFile = os.path.join(args.log,'AlignSeriesLog.log')
fhLog= open(logFile, 'a')

args.outfileA = os.path.join(args.baseOutDir, args.contractA + '.csv') 
args.outfileB = os.path.join(args.baseOutDir, args.contractB + '.csv') 
#C:/MyProjects/WQMaster/data/Futures/TY/2017/01/TY01.csv
#C:\MyProjects\WQMaster\data\Futures\ES\2015\01\ESH5_20150101.csv
baseDir = args.baseDir

dateInputList = []

#date range
#d1 = date(2017, 8, 15)  # start date
#d2 = date(2017, 9, 15)  # end date
d1 = datetime.strptime(args.fromDate, '%Y%m%d')
d2 = datetime.strptime(args.toDate, '%Y%m%d')
'''delta = d2 - d1  

for i in range(delta.days + 1):
    #print(d1 + timedelta(days=i))
    dateInputList.append((d1 + timedelta(days=i)).strftime("%Y%m%d"))'''

df1 =pd.DataFrame()
df2 =pd.DataFrame()

years =(range(d1.year,d2.year + 1,1))
#banku: \ doesn't work with unix  while /  works with windows, doesn't it?  test on unix before release in the future...
searchRoot = os.path.join(args.baseDir, args.contractA)
#If one min resample available then args.resample is set to this file name
if args.resample != '':
    resampleDir = args.resample
    fileA = os.path.join(args.baseDir,args.contractA,resampleDir +'_resample.csv')
    fileB = os.path.join(args.baseDir, args.contractB, resampleDir + '_resample.csv')
    print('FileA: ',fileA)
    print('FileB: ',fileB)

    df1 = pd.read_csv(fileA)
    df2 = pd.read_csv(fileB)

elif args.fileToAlign != '':
    datafileA = os.path.join(searchRoot, args.fileToAlign)
    datafileB = datafileA.replace(args.contractA,args.contractB)
    df1 = pd.read_csv(datafileA, index_col=False)
    df2 = pd.read_csv(datafileB, index_col=False)

else:
    for x in years:
        #for folder in glob.glob(baseDir + args.contractA + '/' +str(x) +'/*' ):
        for folder in glob.glob(searchRoot + '/' +str(x) +'/*' ):
         print('Dir: ',folder)
         for datafile in glob.glob(folder + '/*.csv'):
            #print('File: ',datafile)
            datestr = datafile[-12:-4]
            #print(datestr)
            fileDate = (datetime.strptime(datestr, '%Y%m%d'))
            if d1<= fileDate <= d2:
              datafileB = datafile.replace(args.contractA,args.contractB)
              datafileBpath = Path(datafileB)
              #print(datafile)
              #print(datafileB)

              #Only add contractA file if correponding ContractB file exists
              if datafileBpath.exists():
                  print("\n df1 (adding): ", datafile)
                  dftmp = pd.read_csv(datafile,index_col=False)
                  #print("len dftmp: ",len(dftmp))
                  #print (dftmp.head())
                  df1 = df1.append(dftmp)
                  #print("len df1: ",len(df1))
                  #print (df1 .head())
                  #Process second File
                  print("\n df2 (adding): ", datafileB)
                  #banku,  critical and important overlook cost time
                  dftmp = pd.read_csv(datafileB,index_col=False)
                  #print("len dftmp: ",len(dftmp))
                  #print (dftmp.head())
                  df2 = df2.append(dftmp)
                  #print("len df2: ",len(df2))
              else:
                  print("ContractA file exists but ContractB missing: ",datafile)

unAlignedA = os.path.join(debugTmpPath, 'df1UnAligned.csv') 
unAlignedB = os.path.join(debugTmpPath, 'df2UnAligned.csv') 
if currentPlatform == 'Windows':
     df1.to_csv(unAlignedA, index=False)
     df2.to_csv(unAlignedB, index=False)
elif environment == 'prod':
    #df1.to_csv("./output/df1Align.csv", index=False)
    #df2.to_csv("./output/df2Align.csv", index=False)
    df1.to_csv(unAlignedA, index=False)
    df2.to_csv(unAlignedB, index=False)
else:
    df1.to_csv(unAlignedA, index=False)
    df2.to_csv(unAlignedB, index=False)

'''try:
 	df1 ,df2 = ReadSeries(args.fileA,args.fileB)
except Exception as e: 
	print("ReadeSeries", e)'''

df1DateProcess = True
df2DateProcess = True

#Rename columns 'D' and 'T' if present as  date and interval to work with existing script
if 'D' in df1.columns:
    print('Renaming D and T columns to date and interval')
    df1.rename(columns={'D':'date'},inplace=True)
    df1.rename(columns={'T':'interval'},inplace=True)
    df1DateProcess = False

if 'D' in df2.columns:
    print('Renaming D and T columns to date and interval')
    df2.rename(columns={'D':'date'},inplace=True)
    df2.rename(columns={'T':'interval'},inplace=True)
    df2DateProcess = False

#df1 = df1.loc[: ,["date", "interval", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]
#df2 = df2.loc[: ,["date", "interval", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]

df1 = df1.loc[: ,["date", "interval", "SYBL","LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]
df2 = df2.loc[: ,["date", "interval", "SYBL", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]

#index	date	interval	SYBL	INTV	LSTP	LSTS	INTF	INTH	INTL	INTV	NTRD	LSTB	LSBS	LSTA	LSAS	HBID	LBID	HASK	LASK	HBSZ	LBSZ	HASZ	LASZ	HLTS	IVAM

#print(df1.head())
#print(df2.head())
#df1.rename(columns={df1.columns[3]:'INTV1'},inplace=True)
reportSumPath = os.path.join(args.baseOutDir,args.report)
fh = open(reportSumPath, 'w')  

fh.write('length of dataframe (DF1) from ' + args.contractA + '.csv : ')

fh.write(str(len(df1)) + '\n')
fh.write('length of dataframe (DF2) from ' + args.contractB + '.csv: ')
fh.write(str(len(df2)) + '\n \n')

fh.write('Merge Type: ' + args.mergeType + '\n')


################ Date processing for df1 ################
df1['A'] =df1.interval.astype(str)

# Get interval column as 6 digit column -prefix zeros
df1['interval']=df1.apply(lambda x: x.A.zfill(6), axis=1)

#print(df1.head())
#print(df2.head())

if df1DateProcess:
    df1 = co.ProcessDate(df1)
    print(df1.head())
else:
    df1['Date'] = pd.to_datetime(df1.date)

df1 = df1.drop_duplicates(['Date'])
#df1 = df1.loc[: ,["Date", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]
df1 = df1.loc[: ,["Date", "interval", "SYBL","LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]

co.CheckDuplicate(df1)
df1.fillna(method='ffill',inplace=True)
#df1.to_csv('C:/MyProjects/Data/CSV/EStmp.csv')
#df1 = df1.set_index(['Date'])

#print( df1.head())

################ Date processing for df2 ################
df2['A'] =df2.interval.astype(str)

# Get interval column as 6 digit column -prefix zeros
#cat example
df2['interval']=df2.apply(lambda x: x.A.zfill(6), axis=1)

if df2DateProcess:
    df2 = co.ProcessDate(df2)
    print(df2.head())
else:
    df2['Date'] = pd.to_datetime(df2.date)

df2 = df2.drop_duplicates(['Date'])
#df2 = df2.loc[: ,["Date", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]
df2 = df2.loc[: ,["Date", "interval", "SYBL", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]

co.CheckDuplicate(df2)
df2.fillna(method='ffill',inplace=True)
#df2 = df2.set_index(['Date'])
#print('length of processed df2 before merge: ', len(df2))

#print(df2.head())

print('length of df1 and df2 before merge: ', len(df1) , " and", len(df2))

suffixdf1 = '_ESV'
suffixdf2 = '_NQ'

if args.mergeType == 'union':
    print('Merge type Union' )

    mergeddf1, mergeddf2 = co.doUnion(df1,df2,fh, args.verbose, args.baseOutDir)
else:
    print('Merge type Inner' )
    mergeddf1,mergeddf2 = co.doIntersection(df1,df2)


#rename columns to original names in both df
mergeddf1 = mergeddf1.rename(columns=lambda x: x.replace(suffixdf1, ''))
mergeddf2 = mergeddf2.rename(columns=lambda x: x.replace(suffixdf2, ''))

#print(mergeddf1.head())
#print(mergeddf2.head())

#add index column to match C++ column position
mergeddf1 = mergeddf1.reset_index()
mergeddf1.index.rename('index', inplace=True)
mergeddf2 = mergeddf2.reset_index()
mergeddf2.index.rename('index', inplace=True)

#rename Date to date
mergeddf1.rename(columns={'Date':'date'},inplace=True)
mergeddf2.rename(columns={'Date':'date'},inplace=True)

CheckMergedDuplicates(mergeddf1,fhLog,args.log,args.contractA)
CheckMergedDuplicates(mergeddf2,fhLog,args.log, args.contractB)

mergeddf1 = mergeddf1.drop_duplicates(['date'])
mergeddf2 = mergeddf2.drop_duplicates(['date'])

print("mergeddf1 final length:" , len(mergeddf1) )
print("mergeddf2 final length: " , len(mergeddf2) )


fh.write('Final length DF1: ' + str(len(mergeddf1))  + '\n')
fh.write('Final length DF2: ' + str(len(mergeddf2))  + '\n')

fh.close()
fhLog.close()

mergeddf1.to_csv(args.outfileA,index=False)
mergeddf2.to_csv(args.outfileB,index=False)