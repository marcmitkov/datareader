#!/bin/bash
export PROMPT_COMMAND="echo -ne '\033]0;Resample $HOSTNAME $PWD\007'"
FROMDATE=20140601
TODATE=20190911 #NOTE: LiveData.py will use this date till 07:00 to filter data so if running on June 14 set thisto June 14 to get data till 7 only
BASE=/home/lanarayan/WQData
BASEOUT=/home/lanarayan/MLData
LOGFILE=${BASEOUT}/ResampleLive00.log
ROOT=/home/lanarayan/MyProjects/ML

[ -e ${LOGFILE} ] && cp ${BASEOUT}/ResampleLive0.log ${BASEOUT}/ResampleLive0_bkup.log
[ -e ${LOGFILE} ] && rm ${LOGFILE}

#for i in JY URO BP SF CD AD
#for i in ES NQ 1YM CL FV TY TU US LCO TN AUL JY URO GC EURJPY EURGBP EURUSD GBPUSD USDJPY USDCHF AUDUSD
#for i in ES NQ 1YM CL FV TY TU US
#for i in NQ 1YM CL FV TY TU US LCO TN AUL EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF EURGBP AUDUSD JY
#for i in EURJPY EURUSD GBPUSD USDCAD USDJPY USDCHF EURGBP AUDUSD GC
#for i in EURUSD GBPUSD USDCAD USDJPY USDCHF AUDUSD
for i in ES NQ 1YM CL FV TY TU US LCO TN AUL JY URO GC EURJPY EURGBP EURUSD GBPUSD USDJPY USDCHF AUDUSD
do
echo test
  if [ "$i" == "AUL" ] || [ "$i" == "TN" ] || [ "$i" == "ES" ] || [ "$i" == "NQ" ] || [ "$i" == "1YM" ] || [ "$i" == "CL" ] || [ "$i" == "FV" ]|| [ "$i" == "TY" ]|| [ "$i" == "TU" ]|| [ "$i" == "US" ]|| [ "$i" == "LCO" ] || [ "$i" == "JY" ] || [ "$i" == "URO" ] || [ "$i" == "BP" ] || [ "$i" == "SF" ] || [ "$i" == "CD" ] || [ "$i" == "AD" ] || [ "$i" == "GC" ] ;
  then
	ASSETTYPE=Futures
	echo test2
  else
	ASSETTYPE=FX
  fi
  # generate 1m data for the last say 100 days; #Eliminate data with interval > 07:00:00
  #One time generation of 1m data till todate  upto 7 am
  echo $i
  echo ${ROOT}/LiveData.py -contract ${i} -f ${FROMDATE} -t ${TODATE} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live
  #${ROOT}/LiveData.py -contract ${i} -f ${FROMDATE} -t ${TODATE} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live
  #if [ $? -eq 0 ]
  #then
#	echo "PASS LiveData ${i}" 
	#echo "PASS $? LiveData ${i}" >>${LOGFILE} 
  #else
	#echo "FAIL $? - ${i}"
	#echo "FAIL $?   ${ROOT}/LiveData.py -contract ${i} -f ${FROMDATE} -t ${TODATE} -base ${BASE}/${ASSETTYPE} -baseOut ${BASEOUT}/${ASSETTYPE}/Live" >>${LOGFILE} 
	#exit 1
  #fi
	
  #if [ "$i" == "ES" ] || [ "$i" == "NQ" ] || [ "$i" == "1YM" ] || [ "$i" == "CL" ]  || [ "$i" == "FV" ]|| [ "$i" == "TY" ]|| [ "$i" == "TU" ]|| [ "$i" == "US" ]|| [ "$i" == "LCO" ];
  #then
  #echo ./LiveData.py -contract ${i} -f ${FROMDATE} -t ${TODATE} -base ${BASE}/Futures -baseOut ${BASEOUT}/Futures/Live
  #./LiveData.py -contract ${i} -f ${FROMDATE} -t ${TODATE} -base ${BASE}/Futures -baseOut ${BASEOUT}/Futures/Live
  #else
  #echo ./LiveData.py -contract ${i} -f ${FROMDATE} -t ${TODATE} -base ${BASE}/FX -baseOut ${BASEOUT}/FX/Live
  #./LiveData.py -contract ${i} -f ${FROMDATE} -t ${TODATE} -base ${BASE}/FX -baseOut ${BASEOUT}/FX/Live
  
  #fi
  
  # resample the the last say 100 days
  for j in 1D
  do
	FREQ=${j}
	if [ "$j" == "15m" ]; then
		FREQ=15min
	fi
	echo ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv  -t ${FREQ}
    ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv  -t ${FREQ}
	if [ $? -eq 0 ]
		then
			echo "PASS Resampling ${i} ${j}" 
			echo "PASS Resampling ${i} ${j}">>${LOGFILE} 
		else
			echo "FAIL $? - ${i}${j}"
			echo "FAIL $? ${ROOT}/Resampling.py -a ${BASEOUT}/${ASSETTYPE}/Live/${i}/1m.csv -o ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv  -t ${FREQ}" >>${LOGFILE} 
			exit 1 
		fi
	#Remove last record because it is till 7 am only. This date will be taken from 1D_live.csv generated in next incremental run 
	# which will have this date last LSTP 
    if [ "$j" == "1D" ]; then
		sed -i '$ d' ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv
	fi
	#Create _100 files to be used by evening daily data generation
	FILEMASTER="${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv"
        a=($(wc ${FILEMASTER}))
        LINECOUNT=${a[0]}
        echo  line count is $LINECOUNT
        # make sure lines are > 100
        if [ "${LINECOUNT}" -gt 100 ]; then
                echo "head -1 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv"
                head -1 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv > ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv
                 echo "tail -100 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv >> ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv"
                tail -100 ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_resample.csv >> ${BASEOUT}/${ASSETTYPE}/Live/${i}/${j}_100.csv
        fi
	#if [ "$i" == "ES" ] || [ "$i" == "NQ" ] || [ "$i" == "1YM" ] || [ "$i" == "CL" ] || [ "$i" == "FV" ]|| [ "$i" == "TY" ]|| [ "$i" == "TU" ]|| [ "$i" == "US" ]|| [ "$i" == "LCO" ];
    #    then
    #      echo ./Resampling.py -a ${BASEOUT}/Futures/Live/${i}/1m.csv -o ${BASEOUT}/Futures/Live/${i}/${j}_resample.csv  -t ${FREQ}
     #     ./Resampling.py -a ${BASEOUT}/Futures/Live/${i}/1m.csv -o ${BASEOUT}/Futures/Live/${i}/${j}_resample.csv  -t ${FREQ}
	#else
    #     echo ./Resampling.py -a ${BASEOUT}/FX/Live/${i}/1m.csv -o ${BASEOUT}/FX/Live/${i}/${j}_resample.csv  -t ${FREQ}
    #     ./Resampling.py -a ${BASEOUT}/FX/Live/${i}/1m.csv -o ${BASEOUT}/FX/Live/${i}/${j}_resample.csv  -t ${FREQ}
	#fi
  done
done