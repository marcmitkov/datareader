#!/big/svc_wqln/projects/python/conda/bin/python3.6
# PURPOSE: After MonthlyDeploy.process creates params.xml for prod, use this script to do required changes
# to ConfigLive and params.xml (suffix changes)

#-inFile /home/lanarayan/MLData/DeployStaging/V16/paramsOut.xml -outFile /home/lanarayan/MLData/DeployStaging/V16/paramsForProd.xml -alpha /home/lanarayan/MyProjects/Ranks/V16/SelectedV16.csv
#-inFile C:/MyProjects/PyCharmProjects/HelloWorldProj/paramsOut.xml -outFile C:/MyProjects/PyCharmProjects/HelloWorldProj/paramsOutNew.xml -alpha /home/lanarayan/MLData/BacktestsV6/OutSim/Fit-A-2019/V6/RankedAlphas.txt

import pandas as pd
import argparse
import xml.etree.ElementTree as et
import shutil
import os
from datetime import datetime,timedelta
import logging
import copy

#exchangeReplaceMap ={"CBOT_": "CME_", "CMEFX_": "CME_", "COMEX_": "CME_", "NYMEX_": "CME_", "HOTSPOT_": "FXOTC_"}
currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD", "USDCHF", "USDJPY"]

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-inFile', '--inFile', default='/home/lanarayan/MLData/Futures/BacktestV4', help="base input Directory")
    parser.add_argument('-alpha', '--alpha', default='/home/lanarayan/MLData/Futures/BacktestV4',
                        help="base input Directory")

    '''parser.add_argument('-oldSuffix', '--oldSuffix', default=['U9', 'V9','Z9'], help="file location input series a",
                        nargs='*')
    parser.add_argument('-newSuffix', '--newSuffix', default=['U7', 'U7','U7'], help="file location input series a",
                        nargs='*')'''
    parser.add_argument('-outFile', '--outFile', default='/home/lanarayan/MLData/Futures/BacktestV4', help="base input Directory")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)
    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

    logging.basicConfig(filename=os.path.join(args.logPath,'ReplaceText-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    dfAllAlphas = pd.read_csv(args.alpha)
    # dfSelectedAlphas = pd.read_csv(args.alphas)
    # get all alphas that have 1 in Selected Column
    dfSelectedAlphas = dfAllAlphas[dfAllAlphas.Selected == 1]
    inputFile = args.inFile
    outputFile = args.outFile
    for index, row in dfSelectedAlphas.iterrows():
        alpha = row["Alpha"]  # GC_1H_params-0
        alphaSplit = alpha.split('_')  # e.g [GC, 1H, params-0]
        asset = alphaSplit[0]  # GC
        if asset not in currencyList:
            textToReplace = asset + row["Suffix"]
            replaceBy = asset + row["SuffixNew"]

            if textToReplace != replaceBy and row["SuffixNew"] != "":
                with open(inputFile, "rt") as fin:
                    with open(outputFile, "wt") as fout:
                        for line in fin:
                            if line.count(textToReplace):
                                print("Replace ", textToReplace, " with ", replaceBy)
                                line = line.replace(textToReplace, replaceBy)
                            fout.write(line)

if __name__ == '__main__':
    main()