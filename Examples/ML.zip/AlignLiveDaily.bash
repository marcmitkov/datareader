#!/bin/bash
# Usage: if onetime arg provided run onetime else by default runs incremental
export PROMPT_COMMAND="echo -ne '\033]0;Resample $HOSTNAME $PWD\007'"
FROMDATE=20140101
TODATE=20180925
ONETIMERUN=0
BASE=/home/lanarayan/WQData
BASEOUT=/home/lanarayan/MLData/SimDaily
LOGFILE=${BASEOUT}/AlignLive.log
ROOT=/home/lanarayan/MyProjects/ML
BASEOUTMAIN=/home/lanarayan/MLData
# check if onetime arg provided run onetime 
for arg in "$@"
do
echo "$arg" 
#a="$arg" | tr '[:upper:]' '[:lower:]' 
lowerCaseArg="${arg,,}"
echo ${lowerCaseArg}
if [ ${lowerCaseArg} == "-onetime" ] 
then
	ONETIMERUN=1 
fi
done 
#echo $ONETIMERUN


[ -e ${LOGFILE} ] && cp ${BASEOUT}/AlignLive.log ${BASEOUT}/AlignLive_bkup.log
[ -e ${LOGFILE} ] && rm ${LOGFILE}

declare -a SPREADLIST=("Smith" "Buffet" "Hayek" "Nash" "Friedman" "Keynes" "Marx" "Kondratiev" "Bernanke")
#declare -a SPREADLIST=("Smith")

declare -A CONTRACTSLEG1=( ["Smith"]="ES" ["Buffet"]="ES" ["Hayek"]="FV" ["Nash"]="TY" ["Friedman"]="TU" ["Keynes"]="TU" ["Marx"]="FV" ["Kondratiev"]="CL" ["Bernanke"]="TN" ) 
declare -A CONTRACTSLEG2=( ["Smith"]="NQ" ["Buffet"]="1YM" ["Hayek"]="TY" ["Nash"]="US" ["Friedman"]="TY" ["Keynes"]="US" ["Marx"]="US" ["Kondratiev"]="LCO" ["Bernanke"]="AUL" ) 

	


for s in "${SPREADLIST[@]}"
do
if [ ${ONETIMERUN} == 1 ]
then
	echo 'Doing OneTime Strat B run' $s
	echo  ${ROOT}/AlignSeries.py  -base ${BASEOUT}/Futures/Live/ -contractA ${CONTRACTSLEG1[$s]} -contractB ${CONTRACTSLEG2[$s]} -fileToAlign 1m.csv -e prod -baseOut ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}
    echo ${ROOT}/AlignSeries.py  -base ${BASEOUT}/Futures/Live/ -contractA ${CONTRACTSLEG1[$s]} -contractB ${CONTRACTSLEG2[$s]} -fileToAlign 1m.csv -e prod -baseOut ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}
    if [ $? -eq 0 ]
	then
		echo "PASS AlignSeries ${s}" 
		echo "PASS AlignSeries ${s}" >>${LOGFILE} 
	else
		echo "FAIL $? - ${s}"
		echo "FAIL $? ${ROOT}/AlignSeries.py -f ${FROMDATE} -t ${TODATE} -base ${BASEOUT}/Futures/Live/ -contractA ${CONTRACTSLEG1[$s]} -contractB ${CONTRACTSLEG2[$s]} -fileToAlign 1m.csv -e prod -baseOut ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}" >>${LOGFILE} 
		exit 1	
	fi
else
	TODATE=`date +%Y%m%d`
	echo 'Doing Incremental Strat B run' $s
    #STEP1: take bkup of  master files(if exist) <contractA>.csv and <contractB>.csv
    [ -e ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv ]&& echo cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_bkup.csv
	[ -e ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv ]&& echo cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_bkup.csv

	[ -e ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv ]&& cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_bkup.csv
	[ -e ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv ]&& cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_bkup.csv

	 #STEP2: Align <contractA> and <contractB> incremental 1m_live.csv ;output files are <contractA>.csv and <contractB>.csv
     # adding file name param -fileToAlign 1m_live.csv 
	 # AlignSeries output files are args.baseout/<contractA>.csv and args.baseout/<contractB>.csv
	 # Align 1m_live.csv for contractA and contractB and output in ${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]} folder
	echo  ${ROOT}/AlignSeries.py  -base ${BASEOUT}/Futures/Live/ -contractA ${CONTRACTSLEG1[$s]} -contractB ${CONTRACTSLEG2[$s]} -fileToAlign 1m_live.csv -e prod -baseOut ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}
        ${ROOT}/AlignSeries.py -base ${BASEOUT}/Futures/Live/ -contractA ${CONTRACTSLEG1[$s]} -contractB ${CONTRACTSLEG2[$s]} -fileToAlign 1m_live.csv -e prod -baseOut ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}
	if [ $? -eq 0 ]
	then
		echo "PASS AlignSeries ${s}" 
		echo "PASS AlignSeries ${s}" >>${LOGFILE} 
	else
		echo "FAIL $? - ${s}"
		echo "FAIL $? ${ROOT}/AlignSeries.py -f ${FROMDATE} -t ${TODATE} -base ${BASEOUT}/Futures/Live/ -contractA ${CONTRACTSLEG1[$s]} -contractB ${CONTRACTSLEG2[$s]} -fileToAlign 1m_live.csv -e prod -baseOut ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}" >>${LOGFILE} 
		exit 1
	fi
	
	#STEP3: cp <contractA>.csv and <contractB>.csv to <contractA>_AlignedLive.csv and <contractB>_AlignedLive.csv
	echo "cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_AlignedLive.csv"
	echo "cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_AlignedLive.csv"
	
	cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_AlignedLive.csv
	cp ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_AlignedLive.csv
	
	
	#STEP4:
	# delete header from the newly Aligned files
	echo ' ed "${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_AlignedLive.csv" <<<$'1d\nwq\n' '
	echo ' ed "${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_AlignedLive.csv" <<<$'1d\nwq\n' '

        ed "${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_AlignedLive.csv" <<<$'1d\nwq\n'
	ed "${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_AlignedLive.csv" <<<$'1d\nwq\n'
	

	#Remove STEP5:cat <contractA>_bkup.csv and <contractA>_AlignedLive.csv  ; output to master file <contractA>.csv
	#Remove      cat <contractB>_bkup.csv and <contractB>_AlignedLive.csv  ; output to master file <contractB>.csv
	#concat ES_2d.csv and <contractA>_AlignedLive.csv ;output <contractA>.csv to ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}
	echo "cat ${BASEOUTMAIN}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_2d.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_AlignedLive.csv > ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv"
	echo "cat ${BASEOUTMAIN}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_2d.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_AlignedLive.csv > ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv"
	
	cat ${BASEOUTMAIN}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_2d.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}_AlignedLive.csv > ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG1[$s]}.csv
	cat ${BASEOUTMAIN}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_2d.csv ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}_AlignedLive.csv > ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]}/${CONTRACTSLEG2[$s]}.csv
	
	#STEP6:
	#echo  ${ROOT}/LiveDataFilterB.py  -fileA ${CONTRACTSLEG1[$s]}.csv -fileB ${CONTRACTSLEG2[$s]}.csv  -baseDir ${BASEOUT}/Futures/Live/${CONTRACTSLEG1[$s]}${CONTRACTSLEG2[$s]} >> ${LOGFILE}

fi
done
