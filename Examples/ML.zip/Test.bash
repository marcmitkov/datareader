#!/bin/bash
ROOT='/home/lanarayan/MLData/Backtests'
echo "In test,bash"
j=1D

echo "head -1 ${ROOT}_resample.csv > ${ROOT}/Live/_100.csv "

if [ "$j" != "1D" ]; then
echo "Not"
fi

#UC=${1^^}
UC=$1|awk '{print toupper($1)}'

echo $UC
for arg in "$@"
do
    echo $arg
    echo $arg | awk '{print toupper($0)}'
done