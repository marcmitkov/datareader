#!/big/svc_wqln/projects/python/conda/bin/python3.6
#Incremental process to generate 1 minute candles - to be run daily
# Source data WQData is in UTC
# WQData runs at 3 am EST (approx 7:54 am utc jan)
# Data im resampled files is in UTC

#OUTPUT: args.baseOutDir/1m_live.csv
import pandas as pd
import datetime
import argparse
import numpy as np
import os
import Common as co
from pandas.tseries.offsets import BDay

parser = argparse.ArgumentParser(description="Incremental process to generate 1 minute candles - to be run daily")
#parser.add_argument('-f','--fromDate', default='20180904',help="from date")
parser.add_argument('-t','--toDate', default='20190907',help="to date")
parser.add_argument('-contract','--contract', default='ES',help="contract")
#parser.add_argument('-input','--inputFile', default= '/home/svc_wqln/big/data/Futures/Live/ES/1m.csv',help="base Directory")
parser.add_argument('-base','--baseDir', default= '/big/svc_wqln/data/Futures',help="base Directory")
parser.add_argument('-baseOut','--baseOutDir', default='/big/svc_wqln/ML/Sim/Futures/Live',help="base output Directory")
parser.add_argument('-offset','--offset', default= 0, type=int ,help="Business day offset")
parser.add_argument('-useoffset', '--useoffset', action='store_true',
                        help="if flag provided create daily data file")
#parser.print_help()
args = parser.parse_args()
print(args)

fxList = ['EURGBP', 'EURJPY']
fxInverseDict =	{
  "AUDUSD": "USDAUD=R",
  "USDCHF": "CHFUSD=R",
  "EURUSD": "USDEUR=R",
  "USDCAD": "CADUSD=R",
  "USDJPY": "JPYUSD=R",
  "GBPUSD": "USDGBP=R"
}

# first phase
outdir =  os.path.join(args.baseOutDir, args.contract)
if not os.path.exists(outdir):
        os.makedirs(outdir)
outFile = os.path.join(outdir, '1m_live.csv')

#fromDate = datetime.datetime.strftime( (datetime.date.today() -BDay(args.offset)), '%Y%m%d')
#toDate = datetime.datetime.strftime( (datetime.date.today() -BDay(args.offset))+ BDay(1), '%Y%m%d')

#UNChange
if (args.offset !=0):
    fromDate = datetime.datetime.strftime( (datetime.date.today() -BDay(args.offset)), '%Y%m%d')
    toDate = datetime.datetime.strftime( (datetime.date.today() -BDay(args.offset)), '%Y%m%d')
else:
    fromDate = datetime.datetime.strftime( (datetime.date.today() ), '%Y%m%d')
    toDate = datetime.datetime.strftime( (datetime.date.today() ), '%Y%m%d')

print("from: ", fromDate, " to:", toDate)

df = pd.DataFrame()

if not co.IsFX(args.contract):
    df = co.FuturesData(fromDate, toDate, args.baseDir, args.contract)
    if (df.empty):
        print("Empty dataframe for Futures: ", args.contract)
        exit(1)
    #previousDate = str(datetime.date.today() - datetime.timedelta(1))
elif co.IsFX(args.contract):
     #df = co.FuturesData(args.fromDate, args.toDate, args.baseDir, args.contract, True)
     # if EURGBP=R  then exactly the same thing with False => EURGBP
     # if USDAUD=R with True to take reciprocal of all price fields upto 5 significant figure => AUDUSD
     # if JPYUSD=R with True to take reciprocal of all price fields upto 3 significant figure => USDJPY
     #3 sig digit:USDJPY EURJPY; 5 significant digits:EURGBP AUDUSD USDCHF EURUSD USDCAD GBPUSD
     if args.contract in fxList:
         baseDir = os.path.join(args.baseDir , args.contract + "=R")
         df = co.FXData(fromDate, toDate,baseDir,args.contract,outdir, False)
         if(df.empty):
             print("Empty dataframe for FX: ", args.contract)
             exit(1)

     else:
         contract = fxInverseDict[args.contract]
         baseDir = os.path.join(args.baseDir , contract)
         df = co.FXData(fromDate, toDate, baseDir,args.contract,outdir, True)
         if (df.empty):
             print("Empty dataframe for FX: ", args.contract)
             exit(1)
         df["SYBL"] = args.contract
else:
    factor = 100000
    if 'JPY' in args.contract:
        factor=1000
    print('./TestBinaryCreator', 'FX', args.contract[0:3] + '/' + args.contract[3:6],
          "/dat/mdwarehouse/public/NEX/EBSL1", fromDate, toDate, outFile, factor, 0)
    cmd = '/home/lanarayan/MyProjects/ML/TestBinaryCreator FX ' + args.contract[0:3] + '/' + args.contract[3:6] + " /dat/mdwarehouse/public/NEX/EBSL1 " + fromDate + ' ' + toDate + ' ' + outFile + ' ' + str(factor) + ' 0'
    print(cmd)
    os.system(cmd)
    #subprocess.call['./TestBinaryCreator', 'FX', args.contract[0:2] + '/' args.contract[3:5], "/dat/mdwarehouse/public/NEX/EBSL1", args.fromDate, args.toDate, outFile, factor, 0]
        # example command
        # ./TestBinaryCreator "FX" "${INS}" "/dat/mdwarehouse/public/NEX/EBSL1" ${FROMDATE} "20191231" "${i}.txt" 1000 0
    df=pd.read_csv(outFile)

# second phase
#UNChange
#previousDate = str(datetime.date.today() - BDay(args.offset))
#currentDate =  str(datetime.date.today() - BDay(args.offset)  + BDay(1))

if (args.offset !=0):
    print('Using offset value: ', args.offset)
    previousDate = str(datetime.date.today() -BDay(args.offset))
    currentDate = previousDate
else:
    print('NO offset ')
    previousDate = str(datetime.date.today())
    currentDate = previousDate

#print(previousDate)
#UTC is 8 during Sep - March 10, 2019 when system comes up at 3 AM EST; then Nov 3,2019 2 AM EST DST ends
#filterDateA = pd.to_datetime(currentDate + ' 07:00:00')
#filterDateB = pd.to_datetime(previousDate + ' 07:00:00')
#UNChange
#filterDateA = pd.to_datetime(currentDate + ' 08:00:00')
#filterDateB = pd.to_datetime(previousDate + ' 08:00:00')

#for the current date UTC 8am to 10 PM (3am to 5 pm est) OR  7 am to 9 PM UTC (3am to 5 pm dst)
#Critical:  change if evening data process changes
# changed from 4 to 5 on Nov 4, 2019  to reflect DST
utcOffset=5
wqEndTime=' 17:00:00'  # in EST
filterDateA = pd.to_datetime(currentDate + wqEndTime)
filterDateA = filterDateA + datetime.timedelta(hours=utcOffset)
#filterDateB = pd.to_datetime(previousDate + ' 07:00:00')

#  bugfix: on Sep 29  from 7:00 am to 1:00 am  (essentially snip 100  candles from the min(<Start> tag in params.xml)
# same done in SingleTestSim.py
#Critical:  change when we go 22x5
# Nov 12: current WQ starts at 3 am EST irrespective of DST ( so 1 hr later  when DST is off  i.e.  Nov -Mar)
wqStartTime=' 02:00:00' # in EST  # change to 03:00:00
filterDateB = pd.to_datetime(currentDate + wqStartTime)
filterDateB = filterDateB + datetime.timedelta(hours=utcOffset)

print('Filter Dates: ', filterDateB,' to ', filterDateA)
#print(filterDateB)

# Get last row; change D and T ; Add changed row as last row
#Not required for daily
'''lastrow = df.iloc[-1]
lastrow.D = filterDateA
lastrow.T = '70000'
df = df.append(lastrow, ignore_index=True)'''

#df = pd.read_csv(args.inputFile)
df['D'] = pd.to_datetime(df['D'], format='%Y-%m-%d %H:%M:%S')
df = df.sort_values(['D'], ascending=True)
df = df.drop_duplicates(subset=['D'])

#mask = (df['D'] > filterDateB) | (df['D'] < filterDateA)
mask = (df['D'] > filterDateB) & (df['D'] <= filterDateA)
df =df[mask]

#Remove rows where both LSTA and LSTB are 0; Also drop rows where LSTA and LSTB are empty filelds in csv(i.e NaN in df)
maskDel = (df.LSTA == 0) & (df.LSTB == 0)
df = df[~maskDel]
df = df.dropna(subset=['LSTA', 'LSTB'])

#Remove weekends
df = df[df.D.dt.dayofweek < 5]

df.to_csv(outFile, index=False)
print("output in ", outFile)
#print(df.head())
#print(filterDateA)
#print(filterDateB)