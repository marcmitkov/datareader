#!/big/svc_wqln/projects/python/conda/bin/python3.6
# 1. Script reads pnl files (e.g ES_4H_params-0 or Smith_1m_params_5) for each alpha in args.alpha
# 2. applies the date filter to pnl df for alpha
# 3. Sums the pnl for alpha and adds to ConsolidatedPnl df
# 4. Gets params fo each alph and adds columns to df
# 5. Create the csv and html report of ranked alphas

### SAMPLE COMMAND ###
#-outSimA /home/lanarayan/MLData/BacktestsV16/OutSim/Fit-A-2019/V16 -outSimB /home/lanarayan/MLData/BacktestsV16/OutSim/Fit-B-2019/V16 -f 20090101 -t 20190101 -alphas /big/svc_wqln/ML/BacktestsV16/AlphaList/V0/alphasA1H.txt
# -baseDirA /home/lanarayan/MLData/BacktestsV16/Fit-A-2019/ -baseDirB /home/lanarayan/MLData/BacktestsV16/Fit-B-2019/

import pandas as pd
import logging
import argparse
import os
import datetime
import xml.etree.ElementTree as et


StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7'], 'Bernanke': ['CME_TNU7', 'CME_AULU7']}

currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]


def GetParamsFileKey(asset):
    #Hayek,1m,params-0 key=CME:FVU7,CME:TYU7
    #GBPUSD,15m,params-0 key=FXOTC:GBP/USD
    #ES,4H,params-3 key=CME:ESU7
    if asset in StrategyBMap:
        #key = StrategyBMap[asset][0].replace('_',':') + ',' + StrategyBMap[asset][1].replace('_',':')
        key = StrategyBMap[asset][0] + ',' + StrategyBMap[asset][1]
    elif asset in currencyList:
        #key = "FXOTC:" + asset[:3] + '/' + asset[3:]
        #key = "FXOTC_" + asset[:3] + '/' + asset[3:]
        key = "FXOTC_" + asset[:3] + '_' + asset[3:]
    else:
        #key = "CME:" + asset + "U7"
        key = "CME_" + asset + "U7"

    return key

def GetParams(dfPnl, baseDirA, baseDirB):
    paramsColsList = ['HoldingPeriod', 'RebalanceB','MultiplierB','TargetMultiplierB','ModeA','StopMultiplierB', 'Start','End','OpenPassive','ClosePassive']
    dfPnl = pd.concat([dfPnl, pd.DataFrame(columns=paramsColsList)])

    for index, row in dfPnl.iterrows():
        alpha = row['Alpha']
        alphaSplit = alpha.split('_')
        paramKey = GetParamsFileKey(alphaSplit[0])
        logging.debug("GetParams - Param key to match: {}".format(paramKey))
        print("GetParams - Param key to match: ", paramKey)
        if alphaSplit[0] in StrategyBMap:
            paramDir = os.path.join(baseDirB,alphaSplit[0],alphaSplit[1],alphaSplit[2])
        else:
            paramDir = os.path.join(baseDirA, alphaSplit[0], alphaSplit[1], alphaSplit[2])

        xml_file = os.path.join(paramDir, "params.xml")
        print("GetParams - Reading Param file:",xml_file)
        logging.debug("GetParams - Reading Param file: {}".format(xml_file))
        tree = et.parse(xml_file)
        root = tree.getroot()

        for node in root.findall("./npVector/m_npVector"):
            for item in node.findall("item"):
                Key = item.find('Key').text
                #Remove all whitespaces from key
                Key = Key.replace(" ", "")
                if Key != paramKey:
                    print("Skipping Key: ", Key)
                    logging.debug("Skipping Key: ".format(Key))
                else:
                    print("Reading parameters for Key: ", Key)
                    logging.debug("Reading parameters for Key {}: ".format(Key))
                    # iterate child elements of item
                    for child in item:
                        print("param:value" ,child.tag, ":",child.text)
                        logging.debug("param:{}, value {} ".format(child.tag,child.text))
                        if child.tag in paramsColsList:
                         dfPnl.loc[index,child.tag] = child.text

    #print(dfPnl)
    dfPnl= dfPnl[['Alpha', 'Pnl', 'HoldingPeriod', 'RebalanceB','MultiplierB','TargetMultiplierB','ModeA','StopMultiplierB', 'Start','End','OpenPassive','ClosePassive']]

    return dfPnl
def main():

    parser = argparse.ArgumentParser()
    parser.add_argument('-baseDirA', '--baseDirA', default='/big/svc_wqln/ML/Backtests/Fit-A-2019', help="base Directory for getting params for the alpha")
    parser.add_argument('-baseDirB', '--baseDirB', default='/big/svc_wqln/ML/Backtests/Fit-B-2019', help="base Directory for getting params for the alpha")
    parser.add_argument('-outSimA','--outSimA', default='/big/svc_wqln/ML/Backtests/OutSim/Fit-A-2019/V1',
                        help="Dir where pnl files located; also output dir for Ranked alpha afile")
    parser.add_argument('-outSimB', '--outSimB', default='/big/svc_wqln/ML/Backtests/OutSim/Fit-B-2019/V1',
                        help="Dir where pnl files located; also output dir for Ranked alpha file")
    parser.add_argument("-alphas", "--alphas", default='/big/svc_wqln/ML/Backtests/AlphaList/V0/alphasA.txt',
                        help="alpha list file with path.")
    parser.add_argument('-baseOut', '--baseOut', default='/home/lanarayan/MLData/',
                        help="base Out Directory")
    parser.add_argument('-f', '--startDate', default='20090101', help="from date")
    parser.add_argument('-t', '--endDate', default='20190101', help="to date")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                    choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                    help="Set the logging level")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")

    args = parser.parse_args()
    print(args)
    dateForLog = datetime.datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath, 'RankFromSim-' + dateForLog + '.log'), filemode='w',
                        level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    if not os.path.exists(args.baseOut):
        print("Creating output folder :" + args.baseOut)
        os.makedirs(args.baseOut)

    baseOutDir = args.baseOut


    colNamesList = ['name', 'frequency', 'pname']
    dfAlphas = pd.read_csv(args.alphas, names=colNamesList)

    dfConsolidatedPnl = pd.DataFrame()
    for index, row in dfAlphas.iterrows():
        alpha = row['name'] + '_' + row['frequency'] + '_' + row['pname']

        # read alpha exposure files created by Sim e.g GC_1H_params-0.csv
        if row['name'] in StrategyBMap:
            pnlAlphaFile = os.path.join(args.outSimB, row['name'] + '_' + row['frequency'] + '_' + row['pname'] + '.csv')
            #baseOutDir = args.args.outSimB
        else:
            pnlAlphaFile = os.path.join(args.outSimA, row['name'] + '_' + row['frequency'] + '_' + row['pname'] + '.csv')
            #baseOutDir = args.args.outSimA

        print("Reading file: ",pnlAlphaFile)
        logging.debug("Reading file: {} ".format(pnlAlphaFile))

        dfPnl = pd.read_csv(pnlAlphaFile)

        dfPnl['Date'] = pd.to_datetime(dfPnl['Date'], format='%Y-%m-%d')
        dfPnl = dfPnl.sort_values(['Date'], ascending=True)
        start = pd.to_datetime(args.startDate)
        end = pd.to_datetime(args.endDate)

        print("Applying date filter")
        print("Start: ", start, "End: ",end)
        logging.debug("Start: {} End: {}".format(start,end))

        mask = (dfPnl['Date'] >= start) & (dfPnl['Date'] <= end)
        dfPnl = dfPnl[mask]

        # Get alphas Pnl Sum and append a row to dfConsolidatedPnl
        dfConsolidatedPnl = dfConsolidatedPnl.append({'Alpha': alpha,
                 'Pnl': dfPnl['Pnl'].sum()}, ignore_index=True)
        print("Alpha : " , alpha , " Pnl Sum: ",dfPnl['Pnl'].sum())
        logging.debug("Alpha: {} Pnl Sum: {}" .format(alpha,dfPnl['Pnl'].sum()))

    #dfConsolidatedPnl - each row corresponds to an alpha read from alphas file
    dfConsolidatedPnl = dfConsolidatedPnl.sort_values(['Pnl'], ascending=False)
    # add params used for each alpha to dataframe
    dfConsolidatedPnl = GetParams(dfConsolidatedPnl, args.baseDirA, args.baseDirB)

    #baseOutDir is same from which pnl files are read
    dfConsolidatedPnl.to_csv(os.path.join(baseOutDir, 'RankedAlphas_' + args.startDate + '-' + args.endDate + '.csv'), index=False)
    dfConsolidatedPnl.to_html(os.path.join(baseOutDir, 'RankedAlphas_' + args.startDate + '-' + args.endDate + '.html'), float_format='%.8f',
                  index=False)

    print("Generating file: ", os.path.join(baseOutDir, 'RankedAlphas_' + args.startDate + '-' + args.endDate + '.csv'))
    print("Generating file: ", os.path.join(baseOutDir, 'RankedAlphas_' + args.startDate + '-' + args.endDate + '.html'))

    print("Ranking Done")


if __name__ == '__main__':
     main()