#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas  as pd
import datetime
import argparse
import numpy as np
import os
import logging


parser = argparse.ArgumentParser(description="Resampling Script")
parser.add_argument('-a','--fileA',default='C:/MyProjects/WQMaster/data/ESSep2017Clean.csv',help="file location series a")
parser.add_argument('-o','--outFile',default='C:/MyProjects/WQMaster/Output/Resample.csv',help="file location output file")
parser.add_argument('-t','--candle',default='5min',help="t min Candle e.g 5min OR D for Calendar day")
parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")

#parser.print_help()
args = parser.parse_args()
print(args)

startScriptTime = datetime.datetime.now()

dateForLog = datetime.datetime.now().strftime("%Y%m%d-%H%M%S.%f")

logging.basicConfig(filename=os.path.join(args.logPath,'Resampling-' + dateForLog + '.log'), filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')
logging.debug('Resampling Script args: {}'.format(args))
print('Resampling Script start:' ,datetime.datetime.now())
logging.debug('Resampling Script start: {}'.format(datetime.datetime.now()))
resampleTS = args.candle

#print(resampleTS)
def ReadSeries():
    df1 = pd.read_csv(args.fileA)
    return df1


def CheckDuplicate(df1, verbose=True, name='A'):
    if len(df1[df1.duplicated(['D'],keep='last')]) > 0 and verbose:       
        print('duplicated 1', df1[df1.duplicated(['D'],keep='last')])
        print('# duplicated 1', len(df1[df1.duplicated(['D'],keep='last')]))
    # print("df2",len(pd.to_timedelta((pd.to_numeric(df1.interval[1:]) /
    # 100))), len(df1))
    
   
try:
	df1 = ReadSeries()
except Exception as e: 
	print("ReadeSeries", e)

print('ReadSeries done:' ,datetime.datetime.now())
logging.debug('ReadSeries done: {}'.format(datetime.datetime.now()))
	
if df1.empty:
    print('Empty dataframe. Exiting.')
    logging.debug('Empty dataframe. Exiting.')
    exit()

#Rename columns in ES & NQ files that are named date and interval
if 'date' in df1.columns:
    print('Renaming date and interval columns to D and T')
    df1.rename(columns={'date':'D'},inplace=True)
    df1.rename(columns={'interval':'T'},inplace=True)

#print(df1.head())
df1 = df1.loc[: ,["D", "T", "SYBL", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]

#df1 = df1.loc[: ,["date", "interval", "SYBL","LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]
#print(df1.head())

df1['A'] =df1['T'].astype(str)

print('Start lambda:' ,datetime.datetime.now())
logging.debug('Start lambda: {}'.format(datetime.datetime.now()))
# Get interval column as 6 digit column -prefix zeros
df1['T']=df1.apply(lambda x: x.A.zfill(6), axis=1)
#print(df1.head())

print('End lambda:' ,datetime.datetime.now())
logging.debug('End lambda: {}'.format(datetime.datetime.now()))

'''
#Not required with cleaned data
# Create TimeFormat column in HH:MM:SS format 
df1['HH'] = df1.interval.astype(str).str[:2] +':' 
df1['MM'] = df1.interval.astype(str).str[2:4] +':' 
df1['SS'] = df1.interval.astype(str).str[4:6]  
df1['TimeFormat']=df1['HH'] +df1['MM']+df1['SS']
print(df1.head())
df1['DateStr'] = pd.to_datetime(df1.date[0:]) + pd.to_timedelta(((df1.TimeFormat[0:])), unit='m')
'''
#print(df1.head())
#df1['Date'] = pd.to_datetime(df1.DateStr)
#df1 = df1.drop_duplicates(['Date'])
df1 = df1.drop_duplicates(['D'])
#print(df1.tail(5))
#df1 = df1.loc[: ,["date", "interval", "SYBL", "LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]
#df1 = df1.loc[: ,["date", "interval", "SYBL","LSTP", "LSTS", "INTF", "INTH", "INTL", "INTV", "NTRD","LSTB", "LSBS","LSTA" ,"LSAS", "HBID","LBID", "HASK", "LASK","HBSZ", "LBSZ","HASZ", "LASZ", "HLTS", "IVAM"]]

CheckDuplicate(df1)
df1.fillna(method='ffill',inplace=True)
#df1 = df1.set_index(['Date'])

#get columns where LBID, LSTA, LSTB, LASK, LSTP is not zero
df1 = df1[(df1.LBID != 0) & (df1.LSTA != 0 ) & (df1.LSTB != 0) & (df1.LSTP != 0)]

df1['D'] = pd.to_datetime(df1.D)
df1 = df1.set_index(['D'])
#print(df1.head())

print('Apply resample:' ,datetime.datetime.now())
logging.debug('Apply resample: {}'.format(datetime.datetime.now()))
#Resample
dfNew = pd.DataFrame()
dfNew['T'] = df1['T'].resample(resampleTS).first()
dfNew['SYBL'] = df1['SYBL'].resample(resampleTS).last()
dfNew['LSTP'] = df1['LSTP'].resample(resampleTS).last()

dfNew['LSTS'] = df1['LSTS'].resample(resampleTS).last()

dfNew['INTF'] = df1['INTF'].resample(resampleTS).first()
dfNew['INTH'] = df1['INTH'].resample(resampleTS).max()

dfNew['INTL'] = df1['INTL'].resample(resampleTS).min()

dfNew['INTV'] = df1['INTV'].resample(resampleTS).sum()

dfNew['NTRD'] = df1['NTRD'].resample(resampleTS).sum()

dfNew['LSTB'] = df1['LSTB'].resample(resampleTS).last()
dfNew['LSBS'] = df1['LSBS'].resample(resampleTS).last()
dfNew['LSTA'] = df1['LSTA'].resample(resampleTS).last()

dfNew['LSAS'] = df1['LSAS'].resample(resampleTS).last()
dfNew['HBID'] = df1['HBID'].resample(resampleTS).max()
dfNew['LBID'] = df1['LBID'].resample(resampleTS).min()
dfNew['HASK'] = df1['HASK'].resample(resampleTS).max()
dfNew['LASK'] = df1['LASK'].resample(resampleTS).min()
dfNew['HBSZ'] = df1['HBSZ'].resample(resampleTS).max()
dfNew['LBSZ'] = df1['LBSZ'].resample(resampleTS).min()
dfNew['HASZ'] = df1['HASZ'].resample(resampleTS).max()
dfNew['LASZ'] = df1['LASZ'].resample(resampleTS).min()
dfNew['HLTS'] = df1['HLTS'].resample(resampleTS).last()
dfNew['IVAM'] = df1['IVAM'].resample(resampleTS).last()

print('Apply resample done:' ,datetime.datetime.now())
logging.debug('Apply resample done: {}'.format(datetime.datetime.now()))

#add index column to match C++ column position
dfNew = dfNew.reset_index()
dfNew.index.rename('index', inplace=True)

#Remove rows where both LSTA and LSTB are 0; Also drop rows where LSTA and LSTB are empty filelds in csv(i.e NaN in df)
maskDel = (dfNew.LSTA == 0) & (dfNew.LSTB == 0)
dfNew = dfNew[~maskDel]
dfNew = dfNew.dropna(subset=['LSTA', 'LSTB'])

dfNew.to_csv(args.outFile,index=False, date_format='%Y-%m-%d %H:%M:%S')

endScriptTime = datetime.datetime.now()
print('Resampling Script done:' ,datetime.datetime.now())
logging.debug('Resampling Script done: {}'.format(datetime.datetime.now()))

print('Total run time: ', endScriptTime - startScriptTime)
logging.debug('Total run time: {} '.format(endScriptTime - startScriptTime))
#Resample
#never append
#if not os.path.isfile(args.outFile):
	#dfNew.to_csv(args.outFile,index=False)
# else:
	#dfNew.to_csv(args.outFile,index=False,header=False,mode='a')
    #dfNew.to_csv(args.outFile,index=False,header=False,mode='a',date_format='%Y-%m-%d %H:%M:%S')
#print ('Resampled Data:')
#print (dfNew.head())

