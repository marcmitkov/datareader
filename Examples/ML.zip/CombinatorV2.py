#!/big/svc_wqln/projects/python/conda/bin/python3.6
# example usage:  Combinator.py  -MinLengthA 100,125 -RhoA 6.0,8.0,4.0 
# this will script will generate example comandlines to invoke TestSimulator (C++ program)
# probably use https://linux.die.net/man/3/getopt  to get optional args in C++
# https://www.gnu.org/software/libc/manual/html_node/Example-of-Getopt.html
#cmd = 'TestSimulator -r /home/lanarayan/output -s "2015-1-1 17:00:00" -e  "2015-3-3
#python Combinator.py -MinLengthA 100 -RhoA 6.0,8.0

import sys
import itertools
import argparse
import os
import xml.etree.ElementTree as et
import shutil
import platform
import multiprocessing
#from multiprocessing import Pool
from functools import partial
import pandas as pd
import snipFile as snip
import numpy as np


simulatorExeDir = ''
currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]
StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}

def get_params_input(paramsDict,fhLog,arguments):
    print("\nCreating list of input params to Combinator for modifying Master params.xml")
    fhLog.write("Creating list of input params to Combinator for modifying Master params.xml\n")
    excludeList= []
    excludeList.append('fromDate')
    excludeList.append('toDate')
    excludeList.append('env')
    excludeList.append('filePath')
    excludeList.append('exeDir')
    excludeList.append('baseDirectory')
    excludeList.append('ignoreTOD')
    excludeList.append('test')
    excludeList.append('snip')
    excludeList.append('baseDataDir')


    fhLog.write('overridden params\n')
    for key,val  in paramsDict.items():
        #print(key, '::', val)
        #if not (key in excludeList):
            #print(key)
        if val != None and not (key in excludeList):
            arguments.append([key])
            arguments.append(val.split(','))
            fhLog.write(key + '::' + val + '\n')

    # printing the list using loop
    #for x in range(len(arguments)):
        #print (arguments[x])
    return arguments


def add_XMLheaders(outpath, fhLog):
    print("Adding xml headers to params.xml in location: ",outpath)
    fhLog.write("Adding xml headers to params.xml in location: "+ outpath + "\n")
    xml_file = os.path.join(outpath, "params.xml")
    tree = et.parse(xml_file)

    root = tree.getroot()
    xml_str = et.tostring(root).decode()
    #print(xml_str)

    xml_strNew = '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><!DOCTYPE boost_serialization>' + xml_str
    xml_strNew
    fh = open(xml_file, 'w')  
    fh.write(xml_strNew)
    fh.close()
def GetParamsFileKey(asset):
    #Hayek,1m,params-0 key=CME:FVU7,CME:TYU7
    #GBPUSD,15m,params-0 key=FXOTC:GBP/USD
    #ES,4H,params-3 key=CME:ESU7
    if asset in StrategyBMap:
        key = StrategyBMap[asset][0].replace('_',':') + ',' + StrategyBMap[asset][1].replace('_',':')
    elif asset in currencyList:
        key = "FXOTC:" + asset[:3] + '/' + asset[3:]
    else:
        key = "CME:" + asset + "U7"

    return key

def EditParamsFile(asset,paramDir, frequency,sourceParamsDir):
    paramKey = GetParamsFileKey(asset)
    print("Param key to match: ",paramKey)
    #file = os.path.join("C:/Temp","params.xml")

    file = os.path.join(sourceParamsDir,"params.xml")
    print("Source params file: ",file)
    shutil.copyfile(file, os.path.join(paramDir, 'params.xml'))

    shutil.copyfile(os.path.join(paramDir, 'params.xml'), os.path.join(paramDir, 'paramsOld.xml'))
    tree = et.parse(os.path.join(paramDir, 'params.xml'))

    root = tree.getroot()
    #print(root.tag)
    #print(root[0][0][0].text)
    #for child in root:
        #print(child.tag)

    for elem in root.findall("./npVector/m_npVector"):
        node = elem.find("count")
        node.text = str(1)
    for node in root.findall("./npVector/m_npVector"):
        for item in node.findall("item"):
            Key = item.find('Key').text
            #print("Key: ", paramKey)
            if Key != paramKey:
                node.remove(item)
            else:
                print("Keeping Key: ", paramKey)
    #root[0][0][0].text = str(1)
    '''for item in root.iter('item'):
        Key = item.find('Key').text
        print("Key: ", Key)
        if Key != "CME:ESU7":
            root.remove(item)'''
    for elem in root.iter('item'):
        node = elem.find('Frequency')
        print(node)
        if node == None:
            print("Adding Frequency")
            FrequencyEl = et.Element("Frequency")
            FrequencyEl.text = frequency
            elem.insert(1,FrequencyEl)
        else:
            print("Frequency exists for key: ",paramKey)
   # tree.write(os.path.join("C:/Temp","paramsNew.xml"),xml_declaration=True,encoding="UTF-8")
    #tree.write(os.path.join("C:/Temp","paramsNew.xml"))
    print("Saving modified params file  to: " , paramDir)
    tree.write(os.path.join(paramDir, "params.xml"))
    #f = open(os.path.join("C:/Temp","paramsNew.xml"), "r")
    f = open(os.path.join(paramDir,"params.xml"), "r")
    contents = f.readlines()
    f.close()

    contents.insert(0, "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>")

    contents.insert(1, "<!DOCTYPE boost_serialization>")

    f = open(os.path.join(paramDir,"params.xml"), "w")
    contents = "".join(contents)
    f.write(contents)
    f.close()

def CreateDataFile(asset, frequency, dataDir,paramDir,sDate, eDate):
    #fromDate= '20170903 22:03:00'
    #toDate = '20170904 01:38:00'
    filePath =[]
    legs=[]

    if asset in StrategyBMap:
        legsArr = StrategyBMap[asset]
        legs.append(legsArr[0].split('_')[1][:-2])
        legs.append(legsArr[1].split('_')[1][:-2])
        filePath.append(os.path.join(dataDir, "Futures", "Live", legs[0] + legs[1], legs[0] + ".csv"))
        filePath.append(os.path.join(dataDir, "Futures", "Live", legs[0] + legs[1], legs[1] + ".csv"))
    else:
        if asset in currencyList:
            filePath.append(os.path.join(dataDir,  "FX","Live",asset, frequency + "_resample.csv"))
        else:
            filePath.append(os.path.join(dataDir, "Futures","Live",asset, frequency + "_resample.csv"))
        legs.append(asset)

    for idxFile, val in enumerate(filePath):
        #now = datetime.now()
        #print(now.strftime("%Y%m%d"))
        #startDate = now - timedelta(2)
        ##startDate = now - BDay(2)
        #print(startDate.strftime("%Y%m%d"))
        #endDate= now - timedelta(1)
        ##endDate = now - BDay(1)
        print("Data Source file: ", idxFile, " : ", val)
        startDate = pd.to_datetime(sDate)
        endDate = pd.to_datetime(eDate)

        fromDate = startDate.strftime("%Y%m%d") + ' 21:00:00'
        toDate =  endDate.strftime("%Y%m%d") + ' 21:00:00'

        print("fromDate: ",fromDate)
        print("toDate: ",toDate)

        df = pd.read_csv(filePath[idxFile])
        print(df.head())
        df.rename(columns={'date':'D'},inplace=True)
        df['D'] = pd.to_datetime(df.D)
        #start = fromDate
        #end = toDate
        #print(start, '::::', end)

        df=df.set_index('D')
        df.sort_index(inplace=True)
        start = pd.to_datetime(fromDate)
        end = pd.to_datetime(toDate)
        print(start, '::::', end)
        #print(fromDate, '::::', toDate)

        if start in df.index:
            idx = df.index.get_loc(start)
        else:
            idx = np.argmax(df.index > start)
        dfSlice = df.iloc[idx -100:idx]
        # dfNew = df[(df['date'] > '2017-9-2') & (df['date'] <= '2017-9-10')]
        #dfNew = df[(df['D'] > start) & (df['D'] <= end)]
        dfNew = df[(df.index >= start) & (df.index <= end)]
        print(dfNew.head())

        dfConcatenated = pd.concat([dfSlice,dfNew])
        dfConcatenated.sort_index(inplace=True)

        print(dfConcatenated.head())

        file = os.path.join(paramDir, legs[idxFile] + ".csv")
        print("Snipped fie: ", file)
        dfConcatenated.to_csv(file, index=True)

def AddNodesToConfig(asset,paramDir, frequency, sourceConfigDir):
    legs = []
    if asset in StrategyBMap:
        legsArr = StrategyBMap[asset]
        legs.append(legsArr[0].split('_')[1][:-2])
        legs.append(legsArr[1].split('_')[1][:-2])
    else:
        legs.append(asset)

    print("Getting source config .xml  from : " , sourceConfigDir)

    treeCfg = et.parse(os.path.join(sourceConfigDir,"config.xml"))
    rootCfg = treeCfg.getroot()
    for elem in rootCfg.iter('Instrument1'):
        #Add frequency node if missing
        node = elem.find('Frequency')
        print(node)
        if node == None:
            print("Adding Frequency")
            FrequencyEl = et.Element("Frequency")
            FrequencyEl.text = frequency
            elem.append(FrequencyEl)
        else:
            print("Frequency exists for Instrument1")

        # update File node
        node = elem.find('File')
        if asset in StrategyBMap:
            prodNode = elem.find('Product')
            if prodNode.text == legsArr[0].split('_')[1]:
                node.text = os.path.join(paramDir, legs[0]+ ".csv")
            else:
                node.text = os.path.join(paramDir, legs[1]+ ".csv")

        else:
            node.text = os.path.join(paramDir, legs[0]+ ".csv")
    for elem in rootCfg.iter('Instrument2'):
        # Add frequency node if missing
        node = elem.find('Frequency')
        print(node)
        if node == None:
            # elem.append('Frequency')
            FrequencyEl = et.Element("Frequency")
            FrequencyEl.text = frequency
            elem.append(FrequencyEl)
        else:
            print("Frequency exists for Instrument2")

        # update File node
        node = elem.find('File')
        prodNode = elem.find('Product')
        if prodNode.text == legsArr[1].split('_')[1]:
            node.text = os.path.join(paramDir, legs[1]+ ".csv")
        else:
            node.text = os.path.join(paramDir, legs[0] + ".csv")


    shutil.copyfile(os.path.join(sourceConfigDir, 'config.xml'), os.path.join(paramDir, 'configOld.xml'))

    print("Saving config.xml  to : " , paramDir)

    treeCfg.write(os.path.join(paramDir, 'config.xml'))


def processData():

    parser = argparse.ArgumentParser(description="Combinator")

    # NOTE: Any new arg added should be added too get_params_input methods excludelist so its not considered a param for paramsfile input
    parser.add_argument('-s','--fromDate', default='20170815',help="from date")
    parser.add_argument('-ignore', '--ignoreTOD', action='store_true',help="ignore time of day, for example, for daily candles")
    parser.add_argument('-test', '--test', action='store_true',help="enable verbose message by passing -g flag to TestSimulator")
    parser.add_argument('-e','--toDate', default='20170904',help="to date")
    parser.add_argument('-env','--env', default='dev',help="dev environ")
    parser.add_argument('-snip','--snip', action='store_true',help="bool flag, specify to snip data for date range")
    parser.add_argument('-baseDataDir', '--baseDataDir', default='/home/lanarayan/MLData/', help="base Directory containing Futures and FX data")

    
    #args = parser.parse_args()
    args, unknown = parser.parse_known_args()

    #print(args)
    environment = args.env
    currentPlatform = platform.system()

    print('Environment: ',environment)
    print('Platform: ',currentPlatform)

    #4. Set correct paths  for current platform/environment
    # NOTE: Any new arg added should be added too get_params_input methods excludelist so its not considered a param for paramsfile input
    prodBase = '/home/lanarayan/MyProjects/TestSimulator/'
    winBase = 'c:/MyProjects/WQMaster/python/'
    #prodBase = '/home/svc_wqln/MyProjects/WQMaster/cpp/cmake-build-debug/'
    if (currentPlatform =='Windows'):
        parser.add_argument('-r','--filePath', default='C:/MyProjects/WQMaster/outputzz/',help="file path for config,params and output")
        parser.add_argument('-ex','--exeDir', default='C:/MyProjects/WQMaster/cpp/x64/Debug/',help="C=++ Exe Dir")
        #parser.add_argument('-log','--logFile',default='C:/MyProjects/WQMaster/output/CombinatorLog.txt',help="log file path")
        parser.add_argument('-baseDir','--baseDirectory', default=winBase,help="base Directory")

    elif (environment == 'prod') :
        parser.add_argument('-r','--filePath', default=prodBase +'output/',help="file path for config, params, output")
        parser.add_argument('-ex','--exeDir', default=prodBase,help="C=++ exe dir")
        #parser.add_argument('-log','--logFile',default=prodBase + 'output/CombinatorLog.txt',help="log file path")
        parser.add_argument('-baseDir','--baseDirectory', default=prodBase,help="base Directory")

    else:
        parser.add_argument('-r','--filePath', default='/home/lanarayan/MyProjects/WQMaster/output/',help="file path for config,params and output")
        parser.add_argument('-ex','--exeDir', default='/home/lanarayan/MyProjects/WQMaster/cpp/cmake-build-debug/',help="C=++ Exe Dir")
        #parser.add_argument('-log','--logFile',default='/home/lanarayan/MyProjects/WQMaster/output/CombinatorLog.txt',help="log file path")
        parser.add_argument('-baseDir','--baseDirectory', default='/home/lanarayan/MyProjects/WQMaster/data/Positions/',help="base Directory")

    #args = parser.parse_args()
    args, unknown = parser.parse_known_args()
    print("\nArguments - argparser:")
    print(args)

    if not os.path.exists(args.filePath):
        os.makedirs(args.filePath)

        ########################################################################
    #1. Read params file to get <item> child elements to add to args . Read config file to copy to params-xx dir created

    #base_path = os.path.dirname(os.path.realpath(__file__))
    base_path = args.baseDirectory
    print("Read Master params file from :", base_path)

    xml_file = os.path.join(base_path, "params.xml")

    print("Read config file from :", base_path)

    cfg_file = os.path.join(base_path, "config.xml")

    frequency = os.path.basename((args.filePath).rstrip('/'))
    asset = (args.filePath).rstrip('/').split('/')[-2]

    CreateDataFile(asset, frequency, args.baseDataDir, args.filePath, args.fromDate, args.toDate)

    AddNodesToConfig(asset, args.filePath, frequency ,base_path)


    ####################################################################
    #2. parse master params.xml to load to element tree and get all elements under <item>
    tree = et.parse(xml_file)

    root = tree.getroot()
    #xml_str = et.tostring(root).decode()
    #print(xml_str)
    item_children =[]
    for child in root:
      #print (child.tag)
      item_children = {t.tag for t in root.findall('.//item/*')}
      #item_children_list = list(item_children)
      #print(item_children_list)
      #print((tag_names_list[3]))

    #3. Add all child elements of <item> to argument parser as these could be params supplied to combinator
    for tagname in item_children:
       arg1 = '-'+ tagname
       arg2 = '--' + tagname
       parser.add_argument(arg1,arg2)

    args, unknown = parser.parse_known_args()
    print("\nArguments3 - argparser:")
    print(args)
#################################################################################################
    fhLog = open(args.filePath + 'CombinatorLog.txt', 'w')  
    #5. put all args/values as key/value pairs in dictionary
    dictParams = vars(args)

    #6. Get list of args/values supplied as Combinator args for modifying params file
    arguments = []
    arguments = get_params_input(dictParams,fhLog,arguments)
    #cmd = 'TestSimulator -r ' + args.filePath + ' -s ' + args.fromDate +' -e ' + args.toDate
    cmd = 'TestSimulator  -s ' + args.fromDate +' -e ' + args.toDate
    if args.ignoreTOD:
        cmd += ' -i'
    
    if args.test:
        cmd += ' -g'

    '''arguments.append(['-MinLengthA'])
    arguments.append(args.MinLengthA.split(','))
    arguments.append(['-RhoA'])
    arguments.append(args.RhoA.split(','))'''
    instances=[]
    try:
        dirDict = dict()
        product =list(itertools.product(*arguments))
        #print(product[0][2])
        #print(product[0][4])
        for (i,productItem) in enumerate(product):


            dirName = 'params-' + str(i)
            if dirName in dirDict:
                raise ValueError('Duplicate key :' + dirName)
            dirDict[dirName] = ""
            outDir = os.path.join(args.filePath, dirName)
            if not os.path.exists(outDir):
                 os.makedirs(outDir)

            EditParamsFile(asset, outDir, frequency, base_path)

            treeParams = et.parse(os.path.join(outDir,"params.xml"))
            rootParams = treeParams.getroot()

            zz = iter(productItem)
            #Convert list to dictionary
            b = dict(zip(zz, zz))
            for key,val  in b.items():
                print(key+ "::"+val)
                for elem in rootParams.iter('item'):
                    node = elem.find(key)
                    node.text = val
                #print(RhoAElement.text)

            #args.filePath = os.path.abspath(args.filePath)
            #outDir = os.path.join(args.filePath, dirName)

            #if not os.path.exists(outDir):
            #    os.makedirs(outDir)
            print("Writing xml tree to params.xml in location: ",outDir)
            fhLog.write("Writing xml tree to params.xml in location: " + outDir + "\n")
            #tree.write(outDir + '/params.xml')
            treeParams.write(os.path.join(outDir,'params.xml'))

            # Add headers for boost serialization to work
            add_XMLheaders(outDir,fhLog)
            #tree.write(outDir + '/params.xml', xml_declaration=True, method='xml', encoding='UTF-8')
            # New Code
            # Handle Params
            asset = (args.filePath).rstrip('/').split('/')[-2]
            #EditParamsFile(asset, outDir, frequency)

            #add copy config file to dir
            print("Copy ",os.path.join(args.filePath,'config.xml'), " to ", outDir)
            fhLog.write("Copy " + os.path.join(args.filePath,'config.xml')+ outDir + "\n")
            #shutil.copy(cfg_file, outDir)
            shutil.copyfile(os.path.join(args.filePath,'config.xml'), os.path.join(outDir,'config.xml'))
            # when invoked through galt -r and  -o should are same
            #instances.append(cmd + ' -r ' + args.filePath + dirName  + ' -o ' + args.filePath + dirName)
            instances.append(cmd + ' -r ' + outDir + ' -o ' + outDir)
        #instances = list(map(lambda s: ' '.join(s), product))
        global simulatorExeDir
        simulatorExeDir = args.exeDir
        #fhLog.close() close in main
        '''for j in instances:
            #print("\nExecuting " + args.exeDir + j.replace(': ',':'))
            print("\nExecuting " + args.exeDir + j)
            fhLog.write("Executing " + args.exeDir + j+ "\n")'''

            #os.system(args.exeDir + j)
        return instances, fhLog

    except IOError as e:
        print("Unable to copy file. %s" % e)
    except ValueError as e:
        print("Dir name already exists:%s" % e)
    except:
        print("Unexpected error:", sys.exc_info())

def invokeSimulator(instance, mycmd):
    print("In invokeSimulator")

    #print("simulatorExeDir in invokeSimulator:" + mycmd)
    #print("simulatorExeDirArg:" + instance)
    #fhLog = open(args.logFile, 'a')  
    print("\nExecuting " + mycmd + instance)
    #myfh.write("Executing " + mycmd  + instance+ "\n")
    #myfh.close()
    os.system(mycmd + instance)


if __name__ == "__main__":
    #print("simulatorExeDir1: " +simulatorExeDir)
    instances, fhLog = processData()
   #print("simulatorExeDir2: " +simulatorExeDir)
    simulatorExeDir='/home/lanarayan/MLData/UATDev/VishnuWIP/build/'
    for i in instances:
        print("Executing main",simulatorExeDir,i)
        test = "Executing:" + simulatorExeDir + i + "\n"
        fhLog.write(test)
    fhLog.close()
    num = multiprocessing.cpu_count()
    p = multiprocessing.Pool(num -1)
    prod_x=partial(invokeSimulator, mycmd=simulatorExeDir )
    result = p.map(prod_x,instances)