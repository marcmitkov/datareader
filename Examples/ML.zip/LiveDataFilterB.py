#!/big/svc_wqln/projects/python/conda/bin/python3.6

import pandas as pd
import argparse
from datetime import datetime
import os
from pandas.tseries.offsets import BDay
import logging


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-baseDir', '--baseDir', default='/home/lanarayan/MLData/Futures', help="base Directory")

    parser.add_argument('-fileA', '--fileA', default='', help="fileA")
    parser.add_argument('-fileB', '--fileB', default='', help="fileB")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    args = parser.parse_args()
    print(args)
    logging.basicConfig(filename='LiveDataFilterB.log', filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')


    #Read file1
    df1 = pd.read_csv(os.path.join(args.baseDir,args.fileA))
    df1['date'] = pd.to_datetime(df1['date'])
    df1.sort_values(by='date',inplace=True)

    #Read file 2
    df2 = pd.read_csv(os.path.join(args.baseDir,args.fileB))
    df2['date'] = pd.to_datetime(df2['date'])
    df2.sort_values(by='date',inplace=True)


    #Thursday 0 hrs utc  to Tuesday 8 am utc (Mon holiday)
    end = datetime.now()
    toDate = end.strftime("%Y-%m-%d") + ' 08:00:00'

    start = end - BDay(2)
    fromDate = start.strftime("%Y-%m-%d") + ' 00:00:00'

    start=pd.to_datetime(fromDate)
    end = pd.to_datetime(toDate)

    #startTwoDAgo = datetime.datetime.now() - BDay(2)
    #startStr = startTwoDAgo.strftime("%Y%m%d")\
               #+ ' 21:00:00'
    df1New = df1[(df1.date >= start) & (df1.date <= end)]
    df2New = df2[(df2.date >= start) & (df2.date <= end)]

    fileA= args.fileA.split('.')[0]
    fileB= args.fileB.split('.')[0]

    df1New.to_csv(os.path.join(args.baseDir,fileA + '_2d.csv'),index=False)
    df2New.to_csv(os.path.join(args.baseDir,fileB + '_2d.csv'),index=False)


    print("Done")







if __name__ == '__main__':
    main()