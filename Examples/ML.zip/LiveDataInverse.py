#!/big/svc_wqln/projects/python/conda/bin/python3.6
# One time process to generate 1 minute candles
import pandas as pd
import datetime
import argparse
import numpy as np
import os
import CommonInverse as co
import subprocess
import logging

parser = argparse.ArgumentParser(description="One time process to generate 1 minute candles")
parser.add_argument('-f','--fromDate', default='20180904',help="from date")
parser.add_argument('-t','--toDate', default='20190907',help="to date")
parser.add_argument('-contract','--contract', default='ES',help="contract")
parser.add_argument('-base','--baseDir', default= '/big/svc_wqln/data/Futures',help="base Directory")
parser.add_argument('-baseOut','--baseOutDir', default='/big/svc_wqln/data/Futures/Live',help="base output Directory")
parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                    help="log file  path")

#parser.print_help()
args = parser.parse_args()
print(args)

dateForLog = datetime.datetime.now().strftime("%Y%m%d-%H%M%S.%f")

logging.basicConfig(filename=os.path.join(args.logPath, 'LiveData-' + dateForLog + '.log'),
                    filemode='w', level=getattr(logging, args.logLevel),
                    format='%(asctime)s %(levelname)s %(message)s')

fxList = ['EURGBP', 'EURJPY']
fxInverseDict =	{
  "AUDUSD": "USDAUD=R",
  "USDCHF": "CHFUSD=R",
  "EURUSD": "USDEUR=R",
  "USDCAD": "CADUSD=R",
  "USDJPY": "JPYUSD=R",
  "GBPUSD": "USDGBP=R"
}

outdir =  os.path.join(args.baseOutDir, args.contract)
if not os.path.exists(outdir):
        os.makedirs(outdir)
outFile = os.path.join(outdir, '1m.csv')
df = pd.DataFrame()

print("Processing contract ",args.contract)
print("From: ", args.fromDate, " To: ", args.toDate)
logging.debug("Processing contract {}".format(args.contract))
logging.debug("From: {}  To: {}".format(args.fromDate, args.toDate))
if not co.IsFX(args.contract):
    df = co.FuturesData(args.fromDate, args.toDate, args.baseDir, args.contract)
    if (df.empty):
        print("Empty dataframe for Futures: ", args.contract)
        logging.debug("Exitting. Empty dataframe for Futures: {} ".format( args.contract))
        exit(1)
elif co.IsFX(args.contract):
     # if EURGBP=R  then exactly the same thing with False => EURGBP
     # if USDAUD=R with True to take reciprocal of all price fields upto 5 significant figure => AUDUSD
     # if JPYUSD=R with True to take reciprocal of all price fields upto 3 significant figure => USDJPY
     #3 sig digit:USDJPY EURJPY; 5 significant digits:EURGBP AUDUSD USDCHF EURUSD USDCAD GBPUSD
     if args.contract in fxList:
         baseDir = os.path.join(args.baseDir , args.contract + "=R")
         df = co.FXData(args.fromDate, args.toDate,baseDir,args.contract,outdir, False)
         if (df.empty):
             print("Empty dataframe for FX: ", args.contract)
             logging.debug("Exitting. Empty dataframe for FX: {} ".format(args.contract))
             exit(1)
     else:
         contract = fxInverseDict[args.contract]
         baseDir = os.path.join(args.baseDir , contract)
         df = co.FXData(args.fromDate, args.toDate, baseDir,args.contract,outdir, True)
         if (df.empty):
             print("Empty dataframe for FX: ", args.contract)
             logging.debug("Exitting. Empty dataframe for FX: {} ".format(args.contract))
             exit(1)
         df["SYBL"] = args.contract

else:
    factor = 100000
    
    if 'JPY' in args.contract:
        factor=1000  
    print('./TestBinaryCreator', 'FX', args.contract[0:3] + '/' + args.contract[3:6], "/dat/mdwarehouse/public/NEX/EBSL1", args.fromDate, args.toDate, outFile, factor, 0)
    cmd = '/home/lanarayan/MyProjects/ML/TestBinaryCreator FX '+ args.contract[0:3] + '/' + args.contract[3:6]+ " /dat/mdwarehouse/public/NEX/EBSL1 " + args.fromDate + ' ' + args.toDate+ ' ' +outFile + ' '+ str(factor) + ' 0'
    print(cmd)
    os.system(cmd)
    #subprocess.call(cmd)
    #subprocess.call('./TestBinaryCreator', 'FX', args.contract[0:2] + '/' + args.contract[3:5], "/dat/mdwarehouse/public/NEX/EBSL1", args.fromDate, args.toDate, outFile, factor, 0,shell=True)
    df=pd.read_csv(outFile)

filterDate = pd.to_datetime(args.toDate + ' 07:00:00')

print(filterDate)


#df = pd.read_csv(args.inputFile)
df['D'] = pd.to_datetime(df['D'], format='%Y-%m-%d %H:%M:%S')

df = df.sort_values(['D'], ascending=True)
mask = (df['D'] <= filterDate)
print("Filter applied ",filterDate)
logging.debug("Filter applied <= {}".format(filterDate))
df =df[mask]

#Remove rows where both LSTA and LSTB are 0; Also drop rows where LSTA and LSTB are empty filelds in csv(i.e NaN in df)
maskDel = (df.LSTA == 0) & (df.LSTB == 0)
df = df[~maskDel]
df = df.dropna(subset=['LSTA', 'LSTB'])
df = df.drop_duplicates(['D'])

#Remove weekends
df = df[df.D.dt.dayofweek < 5]

df.to_csv(outFile, index=False)
print("output in ", outFile)
logging.debug("output in {}".format( outFile))
