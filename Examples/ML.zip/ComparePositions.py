#!/big/svc_wqln/projects/python/conda/bin/python3.6

# e.g:/home/lanarayan/ComparePositions.py -baseDir /home/lanarayan/MLData/Backtests1H/Fit-A-2019/NQ/1H -f 20181022 -t 20181024 -s CME_NQU7 -sg Momentum -output /home/lanarayan/MLData/Backtests1H/Fit-A-2019/NQ -param 2
import pandas as pd
import argparse
import glob
from datetime import date, timedelta
from datetime import datetime
import os
import logging


parser = argparse.ArgumentParser(description="Create Positions Reports Script")

parser.add_argument('-baseDir', '--baseDirectory', default='/home/lanarayan/MyProjects/WQMaster/data/Positions',
                        help="base Directory")
parser.add_argument('-f', '--fromDate', default='19991001', help="from date")
parser.add_argument('-t', '--toDate', default='20201021', help="to date")
parser.add_argument('-sg', '--strategyGroup', default=['Spread', 'Momentum'], help="file location input series a",
                    nargs='*')
parser.add_argument('-s', '--strategy', default='Smith', help="e.g For B Smith, For A : CME_FVU7")
parser.add_argument('-posFile', '--posFile', default='positions.txt', help="positions input file name")
parser.add_argument('-debug', '--debugFile', default='debugLogNew.txt', help="Debug file name")

parser.add_argument('-param', '--param', default='', help="select a specific param")
parser.add_argument('-output', '--output', default='/home/lanarayan/MyProjects/WQMaster/output/',
                        help="output Directory")
parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                    help="log file  path")
args, unknown = parser.parse_known_args()
print(args)

parser.print_help()
args = parser.parse_args()
print(args)

dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

logging.basicConfig(filename=os.path.join(args.logPath, 'PosReport-' + dateForLog + '.log'),
                    filemode='w', level=getattr(logging, args.logLevel),
                    format='%(asctime)s %(levelname)s %(message)s')

colnames = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
            'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
            'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp', 'ParentID', 'Key',
            'ExternalKey']

debugFile = os.path.join(args.output,'temp', args.debugFile)
if not os.path.exists(os.path.join(args.output,'temp')):
    os.makedirs(os.path.join(args.output,'temp'))

fh = open(debugFile, 'w')
d1 = datetime.strptime(args.fromDate, '%Y%m%d')
d2 = datetime.strptime(args.toDate, '%Y%m%d')
delta = d2 - d1  # timedelta

dateInputList = []
StrategyGroupInputList = []
# ['Spread','Momentum']
StrategyInputList = []
# ['ESNQ']
# positions file name
datafile = args.posFile
for i in range(delta.days + 1):
    # print(d1 + timedelta(days=i))
    dateInputList.append((d1 + timedelta(days=i)).strftime("%Y%m%d"))
# Strategy Group
StrategyGroupInputList = args.strategyGroup;
baseDir = args.baseDirectory
# Strategy
StrategyInputList.append(args.strategy)
for paramFolder in glob.glob(baseDir + '/*'):
    maindf = pd.DataFrame()
    paramFolder = paramFolder.replace('\\', '/')
    paramfolderSubstr = paramFolder.split('/')[-1]
    if not paramfolderSubstr.startswith('params-'):
        continue;

    if args.param:
        selectedparam = "params-" + args.param
        if paramfolderSubstr != selectedparam:
            continue
    # if not paramfolderSubstr.startswith( 'param' ):
    #   paramfolderSubstr = ''
    paramDir = os.path.join(baseDir, paramfolderSubstr)
    #paramsConsolidatedDF = paramsConsolidatedDF.append(CreateParamsTable(paramfolderSubstr, paramDir))
    for x in dateInputList:
        for sgfolder in glob.glob(baseDir + '/' + paramfolderSubstr + '/' + x + '/*'):
            # print("Traversing Strategy Group:" + sgfolder)
            fh.write("\nTraversing Strategy Group:" + sgfolder)
            # In Win we get \\ before strategyGroup folder, Unix we get /, so replace done to work in both envs
            sgfolder = sgfolder.replace('\\', '/')
            sgfolderSubstr = sgfolder.split('/')[-1]
            if sgfolderSubstr not in StrategyGroupInputList and len(StrategyGroupInputList) != 0:
                # print("Skipping Strategy Group folder" + sgfolder + " not in StrategyGroupInputList")
                fh.write("\nSkipping Strategy Group folder" + sgfolder + " not in StrategyGroupInputList")
                continue;
            else:
                for sfolder in glob.glob(sgfolder + '/*'):
                    # print("Checking Strategy  folder: "  + sfolder)
                    fh.write("\nChecking Strategy  folder: " + sfolder)
                    sfolder = sfolder.replace('\\', '/')
                    sfolderSubstr = sfolder.split('/')[-1]
                    if sfolderSubstr not in StrategyInputList and len(StrategyInputList) != 0:
                        # print("Skipping Strategy" + sfolder + " not in StrategyInputList")
                        fh.write("\nSkipping Strategy" + sfolder + " not in StrategyInputList")
                        continue;
                    else:
                        print("Reading Strategy folder: " + sfolder)
                        fh.write("\nReading Strategy folder: " + sfolder)
                        if os.path.isfile(os.path.join(sfolder, datafile)):
                            print("Reading " + datafile + " in Strategy folder: " + sfolder)
                            fh.write("\nReading " + datafile + "Strategy folder: " + sfolder)
                            df = pd.read_csv(os.path.join(sfolder, datafile), names=colnames, index_col=False)
                            lastPosDirRead = sfolder
                            df['StrategyGroup'] = sgfolderSubstr
                            df['Strategy'] = sfolderSubstr
                            maindf = maindf.append(df)
                        else:
                            # print(datafile  + " does not exist in Strategy folder: "  + sfolder)
                            fh.write("\n" + datafile + " does not exist in Strategy folder: " + sfolder)

    print(maindf)
    print("Output: ",os.path.join(baseDir, "Maindf.csv") )
    maindf.to_csv(os.path.join(baseDir, "Maindf.csv"),index=False)

