#!/big/svc_wqln/projects/python/conda/bin/python3.6

'''https://stackoverflow.com/questions/20110170/turn-pandas-multi-index-into-column
to_html pandas example
dataframe style to html
https://stackoverflow.com/questions/14899818/format-output-data-in-pandas-to-html'''
# NOte: CreatePlot, maxExp and groupbyyear not functioning (fix later)
import pandas as pd
import argparse
import numpy as np
from datetime import date, timedelta
from datetime import datetime
import sys
import os
import webbrowser
import Common as co
import matplotlib.pyplot as plt
import pathlib
import logging
import platform

class Contract:
    def __init__(self, n, pp, m):
        self.name = n
        self.pointvalue = pp
        self.margin = m

# positions file has position size denominated in number of contracts
# so for EURUSD, for example,  position size is 1 (by default)  and hence
# implicit notional value is 1000,000 (per unit position), for JPY the equivalent number
# should be  10,000
# for StratB, default positon size is 100, point value for futures is slef explanatory
# NOTE: Contracts table key changed in this report to match index value(Strategy - taken from dirpath Futures Momentum/CME_ESU7  and for FX Momentum/FXOTC_EUR_USD)
# in statistics df.Point value from table used in calculation of TotalPnl

contractsTable = {
        'CME_ESU7': Contract('ES', 50, 6000),
        'CME_NQU7': Contract('NQ', 20, 6000),
        'CME_TYU7': Contract('TY', 1000, 2500),
        'CME_FVU7': Contract('FV', 1000, 2500),
        'CME_USU7': Contract('US', 1000, 2500),
        'CME_TUU7': Contract('TU', 2000, 500),
        'CME_1YMU7': Contract('1YM', 5, 5000),
        'FXOTC_EUR_USD': Contract('EURUSD', 1000000, 100000),
        'FXOTC_USD_JPY': Contract('USDJPY', 100, 100000), # point value 100 as opposed to 10,000 because price quoted in ~/WQData/FX/USDJPY/1m-new.csv 9085.00
        'FXOTC_EUR_GBP': Contract('EURGBP', 1300000, 130000),
        'FXOTC_EUR_JPY': Contract('EURJPY', 100, 100000), # point value 100 as opposed to 10,000 because price quoted in ~/WQData/FX/USDJPY/1m-new.csv 9085.00
        'FXOTC_GBP_USD': Contract('GBPUSD', 1000000, 100000),
        'FXOTC_AUD_USD': Contract('AUDUSD', 1000000, 100000),
        'FXOTC_USD_CHF': Contract('USDCHF', 1000000, 100000),
        'FXOTC_USD_CAD': Contract('USDCAD', 1000000, 100000),
        'CME_FCEU7': Contract('FCE', 1000000, 100000),
        'CME_FDXU7': Contract('FDX', 1000000, 100000),
        'CME_CLU7': Contract('CL', 1000, 2550),
        'CME_LCOU7': Contract('LCO', 1000, 2550),
        'CME_TNU7': Contract('TN', 1000, 2500),
        'CME_AULU7': Contract('AUL', 1000, 2500)
    }
colnames =['ID','TimeStamp','Size','Avgpx','PnlRealized','PnlUnRealized','FillPx','Open','ClosePx','CloseTimeStamp','Remaining','EntryCriteriaTypeValStrength','Status','ECStopSizeTgtSizeExpiry','CloseCode','CloseRemaining','CloseFillPx','CloseFillTimeStamp','FillTimeStamp','ParentID','Key','ExternalKey']

# Columns sequence for dfConsolidatedColumns; append any new stats columns to this list ie any cols added to df
statsColumnNames = ['Alpha', 'Category', 'pnlRealizedStat', 'pnlUnRealizedStat','TotalPnl', 'TotalTrades', 'averageHoldingPeriodStat', 'averageLossStat', 'averageWinStat', 'avgLossTicks', 'avgWinTicks', 'flatCountStat', 'losersCountStat', 'winnersCountStat']
StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}

def GetTickSize(strategy):
    if strategy in ['FXOTC_USD_JPY', 'FXOTC_EUR_JPY']:
        return 1
    elif strategy in ['CME_TYU7','CME_FVU7','CME_USU7','CME_TUU7']:
        return 0.015625
    elif strategy in ['CME_CLU7']:
        return 0.01
    elif strategy in ['CME_ESU7','CME_NQU7']:
        return 0.25
    elif strategy in ['CME_1YMU7']:
        return 1
    else: #all currencies
        return 0.00001

def writeOutliersToFile(maindf,baseOut):
        debugFile = os.path.join(baseOut, 'Outliers.txt')
        fh = open(debugFile, 'w')
        dfOutlier = pd.DataFrame()
        if len(maindf[maindf.PnlRealized < -0.1000]) > 0:
            msg = "Unusually large numbers in realized pnl 1:"
            dfOutlier = maindf[maindf.PnlRealized < -0.1000]
            print(msg)
            print(dfOutlier)
            fh.write('\n' + msg + '\n')
            for row in dfOutlier.itertuples():
                fh.write(str(row) + '\n')
            # print (maindf[maindf.PnlRealized < -0.0009])
        if len(maindf[maindf.PnlRealized > 0.1000]) > 0:
            msg = "Unusually large numbers in realized pnl 2:"
            dfOutlier = (maindf[maindf.PnlRealized > 0.1000])
            print(msg)
            print(dfOutlier)
            fh.write('\n' + msg + '\n')
            for row in dfOutlier.itertuples():
                fh.write(str(row) + '\n')
        if len(maindf[maindf.PnlUnRealized < -0.1000]) > 0:
            msg = "Unusually large numbers in unrealized pnl 1:"
            dfOutlier = (maindf[maindf.PnlUnRealized < -0.1000])
            print(msg)
            print(dfOutlier)
            fh.write('\n' + msg + '\n')
            for row in dfOutlier.itertuples():
                fh.write(str(row) + '\n')
        if len(maindf[maindf.PnlUnRealized > 0.1000]) > 0:
            msg = "Unusually large numbers in unrealized pnl 2:"
            print(msg)
            print(dfOutlier)
            dfOutlier = (maindf[maindf.PnlUnRealized > 0.1000])
            fh.write('\n' + msg + '\n')
            for row in dfOutlier.itertuples():
                fh.write(str(row) + '\n')

def funcCloseExpireTS(maindf):
        #print(df['a'])
    if maindf['CloseTimeStamp'] == 'not-a-date-time':
        return maindf['ExpiryDate']
    else:
        return maindf['CloseTimeStamp']

def funcWinnersCount(df):
        return sum((df['PnlRealized'] + df['PnlUnRealized']) > 0)

def funcLosersCount(df):
        return sum((df['PnlRealized'] + df['PnlUnRealized']) < 0)

def funcAverageWin(x):
    return x[x >0].mean()

def funcAverageWinTicks(x):
    return x[x > 0].mean()

def funcAverageLossTicks(x):
    return x[x < 0].mean()


def funcAverageLoss(x):
    return x[x < 0].mean()


def funcAvgHoldPeriod(x):
    print('funcAvgHoldPeriod-closeExpireTimeStamp :', x['closeExpireTimeStamp'])
    print('funcAvgHoldPeriod-TimeStamp :', x['TimeStamp'])
    return (pd.to_datetime(x['closeExpireTimeStamp']) - pd.to_datetime(x['TimeStamp'])).astype(
        'timedelta64[s]').mean()


def interval_overlaps(a, b):
    # print(type(a), type(b))
    # print(a["end"], b["end"], ' ', min(a["end"], b["end"]))
    # print(a["start"], b["start"], ' ', max(a["start"], b["start"]))
    # return (min(a["end"], b["end"]) - max(a["start"], b["start"]) ) >np.timedelta64(0,s)
    return a["Size"] * (
            min(a["ExpiryDate"], b["ExpiryDate"]) - max(a["TimeStamp"], b["TimeStamp"]) > np.timedelta64(0,
                                                                                                         's'))
def count_overlaps(df1):
    return pd.Series(
        [df1.apply(lambda x: interval_overlaps(x, df1.iloc[i]), axis=1).sum() for i in range(len(df1))])

def GetMaxExposure(maindf,grouped, yearGroup,groupByParam):
        maindf['TimeStamp'] = pd.to_datetime(maindf.TimeStamp)
        maindf['ExpiryDate'] = pd.to_datetime(maindf.ExpiryDate)
        if yearGroup:
            groupedNew = maindf.groupby([groupByParam, 'Y'])
        else:
            groupedNew = maindf.groupby(groupByParam)

        # print(groupedNew)
        df1 = grouped.apply(count_overlaps)
        if not isinstance(df1, pd.Series):
            maindf["count"] = df1.iloc[0]
        else:
            maindf["count"] = df1.values

        # maindf["count"] = groupedNew.apply(count_overlaps).values
        maindf["countabs"] = abs(maindf["count"])
        maxExposureStat = groupedNew['countabs'].max()
        # maindf["overlapCount"] = groupedNew.apply(count_overlaps).values
        return maindf, maxExposureStat


def CreateDateColumn(maindf):
        dateTimeSeries = maindf['TimeStamp'].str.split(' ', 1)
        dateList = [el[0] for el in dateTimeSeries]
        maindf['D'] = dateList
        return maindf

def CreateYearColumn(maindf):
        mySeries = maindf['TimeStamp'].str.split('-', 1)
        yearList = [el[0] for el in mySeries]
        maindf['Y'] = yearList

        return maindf

def CreatePositionsReport(alphaFileSuffix,output, maxExp, yearGroup,averageWinStat,pnlRealizedStat,pnlUnRealizedStat,winnersCountStat,
                    losersCountStat,flatCountStat,averageLossStat,averageHoldingPeriodStat,totalTradesStat,avgWinTicks
                    ,avgLossTicks,maxExposureStat):
    try:
        #fhNew = open(args.report, 'w')
        #Note:this csv gets overwritten in every loop, gets added to  combined dataframe (dfTotal)
        posReportPath = os.path.join(output + '/PositionsReport-' +alphaFileSuffix +'.csv')
        fhNew = open(posReportPath, 'w')
    except Exception as err:
        print('Error in file open')
        print ( str(err))
        sys.exit(1)
    if maxExp:
        #if args.yearGroup == 'False':
        if not yearGroup:
                fhNew.write('Category,'+'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' +'averageHoldingPeriodStat,' + 'TotalTrades,' + 'avgWinTicks,'  + 'avgLossTicks,'+  'MaxExposure' +'\n')
        else:
            fhNew.write('Category,'+ 'Year,'+'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' +'averageHoldingPeriodStat,' + 'TotalTrades,' + 'avgWinTicks,'  + 'avgLossTicks,' +  'MaxExposure' +'\n')
    else:
        if not yearGroup:
            fhNew.write('Category,'+'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' +'averageHoldingPeriodStat,' + 'TotalTrades,'+ 'avgWinTicks,'  + 'avgLossTicks' +'\n')
        else:
            fhNew.write('Category,'+ 'Year,' +'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' +'averageHoldingPeriodStat,' + 'TotalTrades,'+ 'avgWinTicks,'  + 'avgLossTicks' + '\n')

    for x in range(len(averageWinStat)):
        if not yearGroup:
            fhNew.write(str(averageWinStat.index[x]) + ',')
        else:
            fhNew.write(str(averageWinStat.index[x][0]) + ',')
            fhNew.write(str(averageWinStat.index[x][1]) + ',')
        fhNew.write(str(pnlRealizedStat.iloc[x]) + ',')
        fhNew.write(str(pnlUnRealizedStat.iloc[x])+ ',')
        fhNew.write(str(winnersCountStat.iloc[x])+ ',')
        fhNew.write(str(losersCountStat.iloc[x])+ ',')
        fhNew.write(str(flatCountStat[x]) + ',')
        fhNew.write(str(averageWinStat.iloc[x,0]) + ',')
        fhNew.write(str(averageLossStat.iloc[x,0]) + ',')
        fhNew.write(str(averageHoldingPeriodStat.iloc[x]) + ',')
        fhNew.write(str(totalTradesStat.iloc[x])+ ',' )
        fhNew.write(str(avgWinTicks.iloc[x, 0]) + ',')
        fhNew.write(str(avgLossTicks.iloc[x, 0]))
        if maxExp:
            fhNew.write(',' +str(maxExposureStat.iloc[x]))
        fhNew.write('\n')

    fhNew.close()


def CreatePlot(grouped,alphaSuffix,histogramAuto,histoBinWidth,output):
    for name,group in grouped:
        #print (name)
        #print (group)
        grp = grouped.get_group(name)
        pnlList = list(grp['pnl'])
        plt.xlabel('pnl')
        plt.ylabel('Occurences')
        plt.title('Pnl Analysis')
        if histogramAuto == 'True':
            plt.hist(pnlList, rwidth =0.9, histtype='bar',color='green')
        else:
            binwidth =  histoBinWidth
            print(np.arange(min(pnlList), max(pnlList) + binwidth, binwidth))
            binsList = np.arange(min(pnlList), max(pnlList) + binwidth, binwidth)
            plt.hist(pnlList, bins =binsList, rwidth =0.9, histtype='bar',color='green')
        figurePath = os.path.join(output , 'histo-' + alphaSuffix  + '_' + name + '.png')
        plt.savefig(figurePath)


def CreateHtmlReport(yearGroup,maxExp,roundOff,output,alphaSuffix,averageWinStat,pnlRealizedStat,pnlUnRealizedStat,winnersCountStat,
                    losersCountStat,flatCountStat,averageLossStat,averageHoldingPeriodStat,totalTradesStat,avgWinTicks
                    ,avgLossTicks,maxExposureStat):
    if  not yearGroup:
        htmlHeaders ='Category,'+'pnlRealized,' + 'pnlUnRealized,' + 'winnersCount,' + 'losersCount,' + 'flatCount,' + 'averageWin,' + 'averageLoss,' +'averageHoldingPeriod,' + 'TotalTrades,' + 'WinTicks,'  + 'LossTicks,'+ 'Histogram'
    else:
        htmlHeaders ='Category,' + 'Year,'+'pnlRealized,' + 'pnlUnRealized,' + 'winnersCount,' + 'losersCount,' + 'flatCount,' + 'averageWin,' + 'averageLoss,' +'averageHoldingPeriod,' + 'TotalTrades,' + 'WinTicks,'  + 'LossTicks,'+ 'Histogram'

    if maxExp:
            htmlHeaders = htmlHeaders +  ',MaxExposure'

    htmlHeadersList = htmlHeaders.split(',')
    htmlStr = co.addHTMLHeadElement() + '<Table><tr>'

    roundOffVal = roundOff
    for i in range(len(htmlHeadersList)):
        htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
        print('<th>' + htmlHeadersList[i] + '</th>')
    htmlStr += '</tr>'
    for x in range(len(averageWinStat)):
        htmlStr += '<tr>'
        if not yearGroup:
            htmlStr += '<td>' + str(averageWinStat.index[x]) + '</td>'
        else:
            htmlStr += '<td>' +  str(averageWinStat.index[x][0]) + '</td>'
            htmlStr += '<td>' +  str(averageWinStat.index[x][1]) + '</td>'
        htmlStr += '<td>' + str(round(pnlRealizedStat.iloc[x],roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(pnlUnRealizedStat.iloc[x],roundOffVal))+ '</td>'
        htmlStr += '<td>' + str(round(winnersCountStat.iloc[x],roundOffVal))+ '</td>'
        htmlStr += '<td>' + str(round(losersCountStat.iloc[x],roundOffVal))+ '</td>'
        htmlStr += '<td>' + str(round(flatCountStat[x],roundOffVal)) +'</td>'
        htmlStr += '<td>' + str(round(averageWinStat.iloc[x,0],roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(averageLossStat.iloc[x,0],roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(averageHoldingPeriodStat.iloc[x],roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(totalTradesStat.iloc[x],roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(avgWinTicks.iloc[x,0],roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(avgLossTicks.iloc[x,0],roundOffVal)) + '</td>'
        #htmlStr += '<td><a href="file:///C:/MyProjects/WQMaster/python/histo-' + paramfolderSubstr + '.png">img'  + '</a></td>'

        histoPath = os.path.join(output,'histo-' + alphaSuffix + '.png')
        histoPathUrl = pathlib.Path(histoPath).as_uri()
        htmlStr += '<td><a href=' +histoPathUrl + '>img'  + '</a></td>'
        #htmlStr += '<td><a href="file:///' + args.output + 'histo-' + paramfolderSubstr + '.png">img'  + '</a></td>'

        if maxExp :
            htmlStr += '<td>' + str(round(maxExposureStat.iloc[x],roundOffVal)) + '</td>'
        htmlStr += '</tr>'
    htmlStr += '</Table>'
    htmlStr += co.addHTMLBodyEndTag()
    #print(htmlStr)
    poshtml = os.path.join(output +'/positions' + '-' + alphaSuffix + '.html')
    f = open(poshtml,'w')
    f.write(htmlStr)
    f.close()

    return poshtml

def CreateDataFrameOld(alphaFileSuffix, baseOut, maxExp, yearGroup, averageWinStat,
                              pnlRealizedStat, pnlUnRealizedStat, winnersCountStat,
                              losersCountStat, flatCountStat, averageLossStat, averageHoldingPeriodStat,
                              totalTradesStat, avgWinTicks
                              , avgLossTicks, maxExposureStat):
    #pd.DataFrame({'r': r, 's': s})
    if maxExp:
        if not yearGroup:
            df = pd.DataFrame({'Category': averageWinStat['pnl'], 'pnlRealizedStat': pnlRealizedStat,
                      'pnlUnRealizedStat': pnlUnRealizedStat, 'winnersCountStat': winnersCountStat,
                      'losersCountStat': losersCountStat, 'flatCountStat': flatCountStat,
                      'averageWinStat': averageWinStat, 'averageLossStat': averageLossStat,
                      'averageHoldingPeriodStat': averageHoldingPeriodStat, 'TotalTrades': totalTradesStat,
                      'avgWinTicks': avgWinTicks['PnLTicks'], 'avgLossTicks': avgLossTicks['PnLTicks'],'MaxExposure':maxExposureStat})
        else:

            df = pd.DataFrame({'Category': averageWinStat['pnl'], 'pnlRealizedStat': pnlRealizedStat,
                          'pnlUnRealizedStat': pnlUnRealizedStat, 'winnersCountStat': winnersCountStat,
                          'losersCountStat': losersCountStat, 'flatCountStat': flatCountStat,
                          'averageWinStat': averageWinStat, 'averageLossStat': averageLossStat,
                          'averageHoldingPeriodStat': averageHoldingPeriodStat, 'TotalTrades': totalTradesStat,
                          'avgWinTicks': avgWinTicks['PnLTicks'], 'avgLossTicks': avgLossTicks['PnLTicks'],
                          'MaxExposure': maxExposureStat})

    else:
        if not yearGroup:
            df = pd.DataFrame({'Category': averageWinStat.index.values, 'pnlRealizedStat': pnlRealizedStat,
                      'pnlUnRealizedStat': pnlUnRealizedStat, 'winnersCountStat': winnersCountStat,
                      'losersCountStat': losersCountStat, 'flatCountStat': flatCountStat,
                      'averageWinStat': averageWinStat['pnl'], 'averageLossStat': averageLossStat['pnl'],
                      'averageHoldingPeriodStat': averageHoldingPeriodStat, 'TotalTrades': totalTradesStat,
                      'avgWinTicks': avgWinTicks['PnLTicks'], 'avgLossTicks': avgLossTicks['PnLTicks']})
        else:
            df = pd.DataFrame({'Category': averageWinStat.index.values, 'pnlRealizedStat': pnlRealizedStat,
                          'pnlUnRealizedStat': pnlUnRealizedStat, 'winnersCountStat': winnersCountStat,
                          'losersCountStat': losersCountStat, 'flatCountStat': flatCountStat,
                          'averageWinStat': averageWinStat['pnl'], 'averageLossStat': averageLossStat['pnl'],
                          'averageHoldingPeriodStat': averageHoldingPeriodStat, 'TotalTrades': totalTradesStat,
                          'avgWinTicks': avgWinTicks['PnLTicks'], 'avgLossTicks': avgLossTicks['PnLTicks']})

    return df


def CreateDataFrame(averageWinStat,pnlRealizedStat, pnlUnRealizedStat, winnersCountStat,losersCountStat,
                    flatCountStat, averageLossStat, averageHoldingPeriodStat,totalTradesStat, avgWinTicks
                    , avgLossTicks):
    #pd.DataFrame({'r': r, 's': s})
    df = pd.DataFrame({'Category': averageWinStat.index.values, 'pnlRealizedStat': pnlRealizedStat,
                       'pnlUnRealizedStat': pnlUnRealizedStat, 'winnersCountStat': winnersCountStat,
                       'losersCountStat': losersCountStat, 'flatCountStat': flatCountStat,
                       'averageWinStat': averageWinStat['pnl'], 'averageLossStat': averageLossStat['pnl'],
                       'averageHoldingPeriodStat': averageHoldingPeriodStat, 'TotalTrades': totalTradesStat,
                       'avgWinTicks': avgWinTicks['PnLTicks'], 'avgLossTicks': avgLossTicks['PnLTicks']})


    return df

def ReadPositionsFiles(strategyGroup,posFilePath,startDate,endDate):
    currentPlatform = platform.system()
    startDate = datetime.strptime(startDate, '%Y%m%d')
    endDate = datetime.strptime(endDate, '%Y%m%d')
    delta = endDate - startDate  # timedelta
    dateInputList = []
    for i in range(delta.days + 1):
        # print(d1 + timedelta(days=i))
        dateInputList.append((startDate + timedelta(days=i)).strftime("%Y%m%d"))
    maindf = pd.DataFrame()

    #for dirpath, dirnames, filenames in os.walk(posFilePath):
    for pathDate in dateInputList:

        for dirpath, dirnames, filenames in os.walk(os.path.join(posFilePath,pathDate)):
            for file in filenames:
                if file == "positions.txt":
                    if currentPlatform == "Windows":
                        dirpath = dirpath.replace('\\','/')
                    ts = dirpath.split('/')[-3]
                    if pd.to_datetime(ts) > pd.to_datetime(endDate) or pd.to_datetime(ts) < pd.to_datetime(startDate):
                        continue
                    print("Reading " + file + " in path: " + dirpath )
                    strategy = dirpath.split('/')[-1]
                    df = pd.read_csv(os.path.join(dirpath, file), names=colnames, index_col=False)
                    df['StrategyGroup'] = strategyGroup
                    df['Strategy'] = strategy
                    #if len(df) == 0:
                    #   print("df is empty for ", os.path.join(posFilePath,pathDate))
                    #   logging.debug("df is empty for {}".format(os.path.join(posFilePath,pathDate)))
                    maindf = maindf.append(df)

    return maindf


def main():
    parser = argparse.ArgumentParser()
    # parser.add_argument("-baseDirA", "--baseDirA", default='C:/MyProjects/BackTests/StratA', help="Base dir")
    parser.add_argument("-baseDirA", "--baseDirA", default='/home/lanarayan/MLData/Backtests/Fit-A-2019',
                        help="Base dir")
    # parser.add_argument("-baseDirB", "--baseDirB", default='C:/MyProjects/BackTests/StratB',help="Base dir")
    parser.add_argument("-baseDirB", "--baseDirB", default='/home/lanarayan/MLData/Backtests/Fit-B-2014',
                        help="Base dir")
    #parser.add_argument('-baseOut', '--baseOut', default='C:/MyProjects/WQMaster/output/xxxx', help="base Directory")
    parser.add_argument('-baseOut', '--baseOut', default='/home/lanarayan/MLData/output/xxxx', help="base Directory")
    parser.add_argument('-v', '--verbose', default='False', help="verbose")
    parser.add_argument('-yearGroup', '--yearGroup', action='store_true', help="True - group by year else False")
    parser.add_argument('-histAuto', '--histogramAuto', default='True',
                        help="True: use auto bins or False: set values using histBin arg value")
    parser.add_argument('-histBin', '--histoBinWidth', default=0.0005, help="binwidth for histogram")
    parser.add_argument('-mode', '--mode', default='q',
                        help="q - not display  or v - display each alpha HTML report on browser")

    parser.add_argument("-l", "--logLevel", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-f', '--startDate', default='19991001', help="from date")
    parser.add_argument('-t', '--endDate', default='20201021', help="to date")
    #parser.add_argument('-alphaFile', '--alphaFile', default='C:/MyProjects/data/alphasPos.txt',
    #                  help="location of alpha file")
    parser.add_argument('-alphaFile', '--alphaFile', default='/home/lanarayan/MLData/Backtests/data/alphasPos.txt',
                        help="location of alpha file")
    parser.add_argument('-log', '--log', default='/home/lanarayan/MLData/Backtests/Logs', help="log file  path")
    parser.add_argument('-maxExp', '--maxExp', action='store_true', help="To compute Max exposure provide maxExp")
    parser.add_argument('-groupBy', '--groupByParam', default='StrategyGroup',
                        help="group by parameter- Strategy, StrategyGroup or D")
    parser.add_argument('-round', '--roundOff', default=5, type=int,
                        help="round hedge ratio to decimal places specified as parameter")

    # parser.add_argument('-baseOut','--baseOutDir',
    # default='/home/lanarayan/MyProjects/WQMaster/output/',help="base
    # Directory")
    print('PosReport Start: ', datetime.today().strftime('%Y-%m-%d %HH:%MM:%SS'))
    startTime = datetime.today()

    args = parser.parse_args()
    print(args)
    if not os.path.exists(args.log):
        print("Creating log folder :" + args.log)
        os.makedirs(args.log)
    logging.basicConfig(filename=os.path.join(args.log, "PosReportLog.log"), filemode='w',
                        level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    args.baseOut= os.path.abspath(args.baseOut)
    if not os.path.exists(args.baseOut):
        print("Creating output folder :" + args.baseOut)
        os.makedirs(args.baseOut)

    dfAlphas = pd.read_csv(args.alphaFile, names=['name', 'frequency', 'pname', 'weight'], index_col=False)
    dfConsolidated = pd.DataFrame()
    for index, row in dfAlphas.iterrows():

        outParamDir = os.path.join(args.baseOut, row['name'], row['frequency'], row["pname"])
        if not os.path.exists(outParamDir):
            print("Creating outParamDir folder :" + outParamDir)
            os.makedirs(outParamDir)

        if row['name'] in StrategyBMap:
            legs = StrategyBMap[row['name']]
            asset0 = legs[0].split('_')[1][:-2]
            asset1 = legs[1].split('_')[1][:-2]

            posFilePath = os.path.join(args.baseDirB,row['name'], row['frequency'], row["pname"])
            maindf = ReadPositionsFiles("Spread",posFilePath,args.startDate,args.endDate)
        else:
            posFilePath = os.path.join(args.baseDirA,row['name'], row['frequency'], row["pname"])

            maindf = ReadPositionsFiles("Momentum",posFilePath,args.startDate,args.endDate)

        if len(maindf) > 0:
            print("Maindf length is ", len(maindf), " for ", posFilePath)
            logging.debug("Maindf length is {} for {}".format(len(maindf), posFilePath))
        else:
            print("Maindf length is zero for ", posFilePath)
            logging.debug("Maindf length is zero for {}".format(posFilePath))
            # No need to exit here. Other params-x folders may have positions data , instead loop again
            # sys.exit("Exitting program dataframe length is zero")
            continue;

        maindf = maindf.fillna(0)

        writeOutliersToFile(maindf, args.baseOut)

        maindf[['StopSize', 'TargetSize', 'ExpiryDate']] = maindf.ECStopSizeTgtSizeExpiry.str.split(';', expand=True)

        maindf['closeExpireTimeStamp'] = maindf.apply(funcCloseExpireTS, axis=1)

        # For sorting by 'D'
        maindf = CreateDateColumn(maindf)


        # Create year column for sorting by 'Y' year
        maindf = CreateYearColumn(maindf)


        # Create a column for sum of PnlRealized and PnlUnRealized
        maindf['pnl'] = maindf['PnlRealized'] + maindf['PnlUnRealized']

        maindf['PnLTicks'] = maindf.apply(lambda df: df.pnl / (abs(df.Size) * GetTickSize(df.Strategy)), axis=1)

        if args.verbose == 'True':
            #mainDfCSV = os.path.join(args.output, 'temp')
            mainDfCSV = os.path.join(args.baseOut, 'mainDataFrame.csv')
            maindf.to_csv(mainDfCSV, index=False)

        if args.yearGroup:
            grouped = maindf.groupby([args.groupByParam, 'Y'])
        else:
            grouped = maindf.groupby([args.groupByParam])

        print(grouped.groups)
        # 1. Stats Realized P&L = Sum of pnl
        pnlRealizedStat = grouped['PnlRealized'].agg(np.sum)
        # print(type(pnlRealizedStat))

        # 2. Stats Unrealized P&L = sum of unpl
        pnlUnRealizedStat = grouped['PnlUnRealized'].agg(np.sum)

        # 3. Winners = count of positions that have  realized + unrealized > 0
        #winnersCountStat = grouped.apply(lambda df: sum((df['PnlRealized'] + df['PnlUnRealized']) > 0))
        winnersCountStat = grouped.apply(funcWinnersCount)

        # 4. Losers = count of positions that have  realized + unrealized < 0
        #losersCountStat = grouped.apply(lambda df: sum((df['PnlRealized'] + df['PnlUnRealized']) < 0))
        losersCountStat = grouped.apply(funcLosersCount)

        # 5. Flat = count of positions that have  realized + unrealized == 0
        flatCountStat = grouped.apply(lambda df: sum((df['PnlRealized'] + df['PnlUnRealized']) == 0))

        # 6. Average Win = Sum of realized + unrealized >0 / num of winners
        averageWinStat = grouped.agg({'pnl': funcAverageWin})
        print(averageWinStat)
        avgWinTicks = grouped.agg({'PnLTicks': funcAverageWinTicks})
        avgLossTicks = grouped.agg({'PnLTicks': funcAverageLossTicks})

        # 7. Average Loss = Sum of positions that have  realized + unrealized < 0/ num of losers
        averageLossStat = grouped.agg({'pnl': funcAverageLoss})
        # print(averageLossStat)

        # 8 .Average holding period = closed time stamp - timestamp/ num of positions
        averageHoldingPeriodStat = grouped.apply(funcAvgHoldPeriod)

        # 9. Trades = Total number of positions
        totalTradesStat = grouped.size()

        # 10 max exposure
        maxExposureStat =0;
        if args.maxExp:
            maindf, maxExposureStat = GetMaxExposure(maindf,grouped,args.yearGroup,args.groupByParam)

        alphaFileSuffix = row['name'] + '-' +     row['frequency'] + '-' + row["pname"]
        CreatePositionsReport(alphaFileSuffix, args.baseOut, args.maxExp,args.yearGroup,averageWinStat,pnlRealizedStat,pnlUnRealizedStat,winnersCountStat,
                    losersCountStat,flatCountStat,averageLossStat,averageHoldingPeriodStat,totalTradesStat,avgWinTicks
                    ,avgLossTicks,maxExposureStat)

        posReportPath = os.path.join(args.baseOut + '/PositionsReport-' + alphaFileSuffix + '.csv')
        #dfTotal = pd.read_csv(posReportPath, index_col=False)

        df = CreateDataFrame( averageWinStat, pnlRealizedStat, pnlUnRealizedStat, winnersCountStat,
                              losersCountStat, flatCountStat, averageLossStat, averageHoldingPeriodStat,
                              totalTradesStat, avgWinTicks
                              , avgLossTicks )

        '''df = CreateDataFrame(alphaFileSuffix, args.baseOut, args.maxExp, args.yearGroup, averageWinStat,
                             pnlRealizedStat, pnlUnRealizedStat, winnersCountStat,
                             losersCountStat, flatCountStat, averageLossStat, averageHoldingPeriodStat,
                             totalTradesStat, avgWinTicks
                             , avgLossTicks, maxExposureStat)'''
        # Add alpha name to distinguish same Strat A strategy
        df['Alpha'] = row['name'] + '-' +  row['frequency'] + '-' + row["pname"]

        if row['name'] in StrategyBMap:
            df['TotalPnl'] = 0
            legs = StrategyBMap[row['name']]
            #leg0 = legs[0].split('_')[1][:-2]
            #leg1 = legs[1].split('_')[1][:-2]
            c = contractsTable[legs[0]]
            pointVal1 = c.pointvalue
            c = contractsTable[legs[1]]
            pointVal2 = c.pointvalue
            df['TotalPnl'] = df.loc[legs[0]]['pnlRealizedStat'] * pointVal1 + df.loc[legs[1]]['pnlRealizedStat'] * pointVal2
        else:
            # Note dir naming : Futures Momentum/CME_ESU7  and for FX Momentum/FXOTC_EUR_USD
            # df index (Strategy)is CME_ESU7, FXOTC_EUR_USD etc
            df['TotalPnl'] = 0
            asset = list(df.index)[0]
            c = contractsTable[asset]
            pointVal = c.pointvalue
            df['TotalPnl'] = df.loc[asset]['pnlRealizedStat']*pointVal

        dfConsolidated = dfConsolidated.append(df)
        # CreatePlot Not required for now
        #CreatePlot(grouped, alphaFileSuffix, args.histogramAuto, args.histoBinWidth, args.baseOut)

        #replaced by to_html
        '''posHtmlReport = CreateHtmlReport(args.yearGroup, args.maxExp, args.roundOff, args.baseOut,
                         alphaFileSuffix, averageWinStat, pnlRealizedStat, pnlUnRealizedStat, winnersCountStat,
        losersCountStat, flatCountStat, averageLossStat, averageHoldingPeriodStat, totalTradesStat, avgWinTicks
        , avgLossTicks, maxExposureStat)'''


    print(dfConsolidated)
    #colList = dfConsolidated.columns.tolist()
    #colList = colList[-1:] + colList[:-1]
    #Columns rearranged as per dfConsolColumns; append any new stats columns to this list ie any cols added to df
    #statsColumnNames
    #dfConsolidated = dfConsolidated[colList]  # OR    df = df.ix[:, colList]
    dfConsolidated = dfConsolidated[statsColumnNames]
    dfConsolidated.reset_index(inplace=True)
    dfConsolidated.to_html(os.path.join(args.baseOut,'ConsolidatedPosRpt.html'))

    #  html files opened in browser
    if args.mode == 'v':
        webbrowser.open_new_tab(os.path.join(args.baseOut,'ConsolidatedPosRpt.html'))
    dfConsolidated.to_csv(os.path.join(args.baseOut,'ConsolidatedPosRpt.csv'),index=False)
    endTime = datetime.today()
    tdelta = endTime - startTime
    print('PosReportAlpha Start: ', startTime, ' End : ', endTime)

    print('PosReport  done in : ', tdelta)

if __name__ == '__main__':
    main()
