#!/bin/bash 
#[20:32:16lanarayan@wqropsapi009:~/MLData/Backtests/Fit-A-2019$] find ./*/*/*/20190131/* -name "positions.txt" -size +0
#find ./201902* -name "positions*" -size +0 -exec cat {} \;


find ./*/*/*/20190131/* -name "positions.txt" -size +0
