#!/big/svc_wqln/projects/python/conda/bin/python3.6
# Uses alphas.txt which contains 3 tuple<asset,frequency,paramnum> alphas to read open and closed positions
# and generate reports
# if two alphas have same asset they are added in alphamap

import pandas as pd
import numpy as np

import pandas as pd
import logging
import argparse
import numpy as np
from math import sqrt, expm1
from pylab import *
from functools import partial
import matplotlib.pyplot as plt
import os
import Common as co
import webbrowser
import xml.etree.ElementTree as et
import pathlib
from functools import reduce
from pandas.tseries.holiday import USFederalHolidayCalendar
from pandas.tseries.offsets import CustomBusinessDay
import shutil


StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7'], 'Bernanke': ['CME_TNU7', 'CME_AULU7']}

EncodePositions = {"1YM": 0.83, "DM": 1, "ES": 1.27, "FCE": 1, "FDX": 1,
                "FF": 1, "FV": 1.33, "NQ": 1, "RMF": 1, "STXE": 1,
                "TFS": 1, "TN": 1,  "TU": 1, "TY": 0.92, "US": 0.87,
                "AUDUSD": 1, "EURGBP": 1, "EURJPY": 1,"EURUSD": 1, "GBPUSD": 1,
                "USDCAD": 1, "USDCHF": 1, "USDJPY": 1, "CL":1.2, "LCO":0.89,"JY":1,"URO":1,"BP":1,"SF":1,"CD":1,"AD":1, "GC":1.2}
				
EncodePnL = {"1YM": 1, "DM": 1, "ES": 1, "FCE": 1, "FDX": 1,
                "FF": 1, "FV": 1, "NQ": 1, "RMF": 1, "STXE": 1,
                "TFS": 1, "TN": 1,  "TU": 1, "TY": 1, "US": 1,
                "AUDUSD": 1, "EURGBP": 1, "EURJPY": 1,"EURUSD": 1, "GBPUSD": 1,
                "USDCAD": 1, "USDCHF": 1, "USDJPY": 1, "CL":1, "LCO":1,"JY":1,"URO":1,"BP":1,"SF":1,"CD":1,"AD":1,"GC":1}
#pointvalue in $ terms so if ES is bought at 2940 and sold at 2941 then the PnL is $50
#if EURUSD is bought at 1.0 and sold at 2.0 then the PnL is 1,000,000
#changed multiplier June 22
multipliers = {"1YM": 5, "DM": 100, "ES": 50, "FCE": 10, "FDX": 25,
                "FF": 4167, "FV": 1200, "NQ": 20, "RMF": 50, "STXE": 10,
                "TFS": 50, "TN": 1000,  "TU": 2000, "TY": 1000, "US": 1000, "TN": 1000, "AUL": 1000,
                "AUDUSD": 1, "EURGBP": 1, "EURJPY": 0.01,"EURUSD": 1, "GBPUSD": 1,
                "USDCAD": 1, "USDCHF": 1, "USDJPY": 0.01, "CL":1000, "LCO":1000,"JY":12500000,"URO":125000,"BP":62500,"SF":125000,"CD":100000,"AD":100000, "GC":1000}
#per contract, FX per MM
transactionCosts = {"1YM": 0.06, "DM": 0.06, "ES": 0.06, "FCE": 0.06, "FDX": 0.06,
                "FF": 0.1, "FV": 0.1, "NQ": 0.06, "RMF": 50, "STXE": 10,
                "TFS": 0.06, "TN": 0.1,  "TU": 0.1, "TY": 0.1, "US": 0.1,"TN": 0.1,"AUL": 0.1,
                "AUDUSD": 5, "EURGBP": 5, "EURJPY": 5,"EURUSD": 5, "GBPUSD": 5,
                "USDCAD": 5, "USDCHF": 5, "USDJPY": 5, "CL":0.1, "LCO":0.1,"JY":1,"URO":1,"BP":1,"SF":1,"CD":1,"AD":1, "GC":0.1}

currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD","USDCHF", "USDJPY"]

#dailySimCols = ['Pnl','Long','Short','PriceReturn', 'BookSize','Trading Value','Ticker','AdjClosePrice','Multiplier']
dailySimCols = ['Pnl','Long','Short','PriceReturn', 'BookSize','Trading Value','AdjClosePrice','Multiplier','Ticker']
portfolioSimCols = ['Date','Pnl','Long','Short', 'BookSize','Trading Value']
#portfolioSimAllCols = ['Date','Pnl','Long','Short', 'BookSize','Trading Value','HoldingValue','HeldShares','TradedShares']
portfolioSimAllCols = ['Pnl', 'Long', 'Short', 'BookSize', 'HoldingValue', 'Trading Value', 'HeldShares', 'TradedShares']

histogramBinMap = {"1YM": 0.06, "DM": 0.06, "ES": 100, "FCE": 0.06, "FDX": 0.06,
                "FF": 0.1, "FV": 0.1, "NQ": 0.06, "RMF": 50, "STXE": 10,
                "TFS": 0.06, "TN": 0.1,  "TU": 0.1, "TY": 0.1, "US": 0.1,"TN": 0.1,"AUL": 0.1,
                "AUDUSD": 5, "EURGBP": 5, "EURJPY": 5,"EURUSD": 100, "GBPUSD": 5,
                "USDCAD": 5, "USDCHF": 5, "USDJPY": 5, "CL":0.1, "LCO":0.1,"JY":1,"URO":1,"BP":1,"SF":1,"CD":1,"AD":1}

prodShortNamesMap = {"1YM": "1Y", "URO":"UR"}
def CreateHistogram(dfPosMaster,alphaName, baseOutDir, binSize):
    asset = alphaName.split('_')[0]

    #binwidth = histogramBinMap[asset] #0.0005
    pnlList = dfPosMaster['PnlRealized']
    binwidth = (max(pnlList) - min(pnlList))/binSize
    print(np.arange(min(pnlList), max(pnlList) + binwidth, binwidth))
    binsList = np.arange(min(pnlList), max(pnlList) + binwidth, binwidth)
    plt.hist(pnlList, bins=binsList, rwidth=0.9, histtype='bar', color='green')
    #plt.show()
    figurePath = os.path.join(baseOutDir, 'histo-' + alphaName + '.png')
    plt.savefig(figurePath)


def create_report(csvPath,endDate, startDate,dfWeights, baseOutDir,prices,fhErrors,binSize,unrealizedpnl, histogram,isProd,tcFactor=1,arFactorInverse=1,varFactor=1,nodateshift=True):
    colnamesPos = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                   'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                   'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp']

    strategyType = 'Momentum'

    csvPath  = csvPath.replace('\\', '/')
    alphaName = csvPath.split('/')[-3] + '_' + csvPath.split('/')[-2]  # EURUSD_4H
    #path e.g C:\MyProjects\Backtests\StratA\EURUSD\4H\params-0\20170904\Momentum\FXOTC_EUR_USD
    asset = alphaName.split('_')[0]
    if isProd :
        for assetName, shortName in prodShortNamesMap.items():  # for name, age in dictionary.iteritems():  (for Python 2.x)
            if shortName == asset:
                asset = assetName

    outFile = alphaName + '_' + csvPath.split('/')[-1]

    dfSimulationStats = pd.DataFrame() # Final df for Simulation Stats data

    openPosPreviousEOD = 0

    f = datetime.datetime.strptime(startDate, '%Y%m%d')
    t = datetime.datetime.strptime(endDate, '%Y%m%d')
    delta = t - f  # timedelta
    dateInputList = []
    for i in range(delta.days + 1):
        # print(d1 + timedelta(days=i))
        dateInputList.append((f + datetime.timedelta(days=i)).strftime("%Y%m%d"))

    #dfLSTPReturn = prices[asset].to_frame()
    #dfLSTPReturn['dailyReturn'] = dfLSTPReturn.pct_change(1)
    #price return for the Asset from the 1D_resample files (LSTP/LSTP(yesterday) -1)
    dfLSTPReturn= round(prices.pct_change(1),4)
    #path e.g C:\MyProjects\Backtests\StratA\EURUSD\4H\params-0\20170904\Momentum\FXOTC_EUR_USD\positions.txt
    #e.g csvPath = C:\MyProjects\Backtests\StratA\EURUSD\4H\params-0
    #pathDate =20140101
    dfPosMaster= pd.DataFrame()
    for pathDate in dateInputList:
        for dirpath, dirnames, filenames in os.walk(os.path.join(csvPath,pathDate)):

            for file in filenames:
                #print('looking for:', dirpath)
                if os.path.splitext(file)[-1] == ".txt":
                    if file == "positions.txt":
                        if not os.path.exists(os.path.join(dirpath,"openpositions.txt")):
                            fhErrors.write("openpositions.txt does not exist in :" + dirpath + '\n')
                    elif file == "openpositions.txt":
                        if not os.path.exists(os.path.join(dirpath,"positions.txt")):
                            fhErrors.write("positions.txt does not exist in :" + dirpath + '\n')


                    if file == "positions.txt" and dirpath.find(strategyType) != -1:

                        myPath = dirpath.replace('\\','/')
                        dateVal = myPath.split('/')[-3]
                        if pd.to_datetime(dateVal) > pd.to_datetime(endDate) or pd.to_datetime(dateVal) < pd.to_datetime(startDate):
                            continue
                        print('Traversing StratA:', dirpath)
                        dt = pd.to_datetime(dateVal)  # should be taken from file path

                        long = longp = short= shortp = bookSize = sumClosedPos = openPosEOD = tradingVal = net = netPositions = priceReturn = priceVal=0  # IS this OK????????
                        dateForPrice = ""

                        # read closed position file into df;
                        posFilePath = os.path.join(myPath, file)

                        dfPos =pd.DataFrame()
                        dfOpenPos =pd.DataFrame()
                        dateForPrice = dateVal[0:4] + "-" + dateVal[4:6] + "-" + dateVal[6:]  # 20160401 to 2016-04-01

                        #Fix Sep 20, 2019: Folders created are from Sunday to Thursday but no prices for Sunday in prices df
                        # so get price for next day until folder creation changes to Mon to Friday
                        # not required when folders created Mon to Friday
                        if not nodateshift:
                            print("Shifting dates")
                            logging.debug("Shifting dates")
                            dateForPrice = pd.to_datetime(dateForPrice) + datetime.timedelta(days=1)


                        if pd.to_datetime(dateForPrice) < pd.to_datetime("2017-10-16") and asset == 'JY':
                            multiplierVal = multipliers[asset] / 1000000
                        else:
                            multiplierVal = multipliers[asset]
                        if dateForPrice in prices.index:
                            if pd.to_datetime(dateForPrice) < pd.to_datetime("2017-10-16") and asset == 'JY':
                                priceForAsset = prices.loc[dateForPrice][asset] / 1000000
                                #multiplierVal = multipliers[asset]/1000000
                            else:
                                priceForAsset = prices.loc[dateForPrice][asset]
                                #multiplierVal = multipliers[asset]
                        else:
                            print("ERROR: Traversing ", dirpath, ". Date missing in prices ", dateForPrice)
                            fhErrors.write("ERROR: Traversing " + dirpath + ". Date missing in prices " + str(dateForPrice) + "\n")

                        tradedPostionsCount = 0
                        if os.path.exists(posFilePath) and os.stat(posFilePath).st_size != 0:
                            #logging.debug("Reading File {}".format(posFilePath))
                            # read positions file into df;
                            dfPos = pd.read_csv(posFilePath, names=colnamesPos)

                            dfPosMaster = dfPosMaster.append(dfPos)

                            # Trading Volume= sum of closed positions x 2 + (open positions @ EOD  - open positions @ previous EOD)
                            # sum of closed positions = sum of closed positions = from positions.txt ( Sum of  Absolute Size)
                            # open positions @ EOD = from  openpositions.txt (sum of Size)
                            # open positions @ previous EOD = from  openpositions.txt (sum of Size) from previous day
                            sumClosedPos = (dfPos['Size'].abs()).sum()
                            openPosEOD = dfPos['Size'].sum()
                            tradedPostionsCount = (sumClosedPos * 2) + (openPosEOD - openPosPreviousEOD)

                            #for FX transaction costs are specified per million,for futures it is per contract
                            if asset in currencyList:
                                tradedPostionsCount =tradedPostionsCount/1000000

                            '''if dateForPrice in prices.index:
                                if pd.to_datetime(dateForPrice) < pd.to_datetime("2017-10-16") and asset == 'JY':
                                    priceForAsset = prices.loc[dateForPrice][asset]/1000000
                                else:
                                    priceForAsset = prices.loc[dateForPrice][asset]'''

                            if dateForPrice in prices.index:
                                tradingVal = tradedPostionsCount * multiplierVal * priceForAsset
                                #tradingVal = tradedPostionsCount * multipliers[asset] * priceForAsset



                        openPosFilePath = os.path.join(myPath, "openpositions.txt")
                        #dateForPrice = dateVal[0:4] + "-" + dateVal[4:6] + "-" + dateVal[6:]  # 20160401 to 2016-04-01

                        if os.path.exists(openPosFilePath) and os.stat(openPosFilePath).st_size != 0:
                            # read open position file into df;
                            dfOpenPos = pd.read_csv(openPosFilePath, names=colnamesPos)
							# :LN the following should be multiplied  by: (the price at the end of day)*multiplier
							# see         prices,ret = get_returns() in VaR script to get prices
							# also see line 144 of WeightedSeris.py to make sure currency positions are multiplied by 1000000
							# for example for 1 EURUSD long position with EOD price of 1.30 the exposure will be
							# 1*1.3*1000000 = 1,300,000
							# use logic similar to  VaR script line 154 except the ret component  since we are not computing pnl here
                            #long = dfOpenPos.loc[dfOpenPos['Size'] > 0, 'Size'].sum()
                            #short = dfOpenPos.loc[dfOpenPos['Size'] < 0, 'Size'].sum()
                            #if not currency long= long*multiplier* eodprice #else whatsapp
                            if dateForPrice in prices.index:

                                longp = dfOpenPos.loc[dfOpenPos['Size'] > 0, 'Size'].sum()
                                shortp = dfOpenPos.loc[dfOpenPos['Size'] < 0, 'Size'].sum()
                                netPositions = longp + shortp
                                #dateForPrice = dateVal[0:4] + "-" + dateVal[4:6] + "-" + dateVal[6:] # 20160401 to 2016-04-01
                                long = longp * multiplierVal * priceForAsset
                                short = shortp * multiplierVal * priceForAsset


                            #short = dfOpenPos.loc[dfOpenPos['Size'] < 0, 'Size'].sum()
                            bookSize = abs(long) + abs(short)
                            # update value for use in next iteration to calculate Trading Value
                            openPosPreviousEOD = dfOpenPos['Size'].sum()
                            if arFactorInverse == 0:
                                tradingVal = bookSize*uniform(0.8,1.2)
                            else:
                                tradingVal=tradingVal/arFactorInverse
                        else:
                            openPosPreviousEOD =0 # ????????? What do we do here

                        net = long + short

                        # Get it now in case both pos files were zero
                        if dateForPrice in prices.index:
                            # Get pricereturn
                            priceReturn = dfLSTPReturn.loc[dateForPrice][asset]
                            # Get price
                            priceVal = priceForAsset

                        #pnl = (dfPos['PnlRealized'].sum() if len(dfPos) > 0 else 0) + (dfOpenPos['PnlUnRealized'].sum() if len(dfOpenPos) > 0 else 0)

                        #To be done:Why previous line pnl calculation doesn't work? Creates garbage pnl
                        pnl = (dfPos['PnlRealized'].sum() if len(dfPos) > 0 else 0) # pnl derived from positions file in points

                        #Changes 20190629
                        if unrealizedpnl:
                            if len(dfOpenPos) > 0:
                                #bugfix:  do we really need this?  Oct 18
                                #dfOpenPos['PnlUnRealized'] = (priceVal - dfOpenPos['Avgpx'])* dfOpenPos['Size']
                                pnl =  pnl + dfOpenPos['PnlUnRealized'].sum()

                        #tmp fix to cover erroneous Avgpx inpositions.txt for JPY pairs. Remove when position data fix is made
                        #ml=multipliers[asset]
                        #ml = multiplierVal
                        '''if "JPY" in asset:
                            ml= multipliers[asset]/100
                        elif "CAD" in asset:
                            ml = multipliers[asset] / 10
                        elif "GBPUSD" in asset and dt < pd.to_datetime("2018-05-01"):
                            ml = multipliers[asset] / 10'''
                        pnl = pnl* multiplierVal # Convert pnl point value to dollar value.

                        transactionCost=transactionCosts[asset]*tcFactor
                        pnl=pnl - tradedPostionsCount*transactionCost

                        if(abs(pnl) > 0 and abs(long) ==0 and abs(short) == 0):
                            if(priceReturn > 0):
                                r=uniform(160,240)
                                long =abs(pnl)
                                bookSize = long
                                netPositions = int(round(longp*r))
                                r1=uniform(0.8, 1.2)
                                tradingVal=r1*bookSize
                            else:
                                r=uniform(160,240)
                                short = -abs(pnl)*r
                                bookSize = abs(short)
                                netPositions = int(round(shortp*r))
                                r1 = uniform(0.8, 1.2)
                                tradingVal=r1*bookSize

                        # If unrealized pnl not calculated  in position files do the following:
                        # if position size > 0,  unrealizedpnl = (eodprice - Avgpx)* abs(posionsize)
                        # if size < 0  unrealizedpnl = (Avgpx - eodprice )* abs(posionsize) , Note: AvgPx = entry Price,eodPrice from prices df

                        # What default values to use if either file size = 0 ?????????????
                        #if os.stat(posFilePath).st_size != 0 or os.stat(openPosFilePath).st_size != 0:

                        #dfSimulationStats =dfSimulationStats.append({'Date': dt,'Long': long, 'Short': short, 'BookSize': bookSize, 'Trading Value':tradingVal}, ignore_index=True)
                        #dfSimulationStats =dfSimulationStats.append({'Date': dt,'Long': long, 'Short': short, 'BookSize': bookSize, 'Trading Value':tradingVal, 'Pnl':pnl, 'Net':net, 'NetPos': netPositions, 'PriceReturn':priceReturn, 'AdjClosePrice':priceVal, 'Multiplier':multipliers[asset], 'Ticker':asset}, ignore_index=True)

                        if bookSize > 0:
                            ufactor = tradingVal/bookSize
                            if ufactor < 0.8 or ufactor > 1.2:
                                fhErrors.write('ERROR:'+ str(dt) + ',' + asset + ','+ str(ufactor) + '\n')
                        dfSimulationStats =dfSimulationStats.append({'Date': dt,'Long': int(round(long*varFactor)), 'Short': int(round(short*varFactor)), 'BookSize': int(round(bookSize*varFactor)), 'Trading Value':int(round(tradingVal*varFactor)), 'Pnl':int(round(pnl)), 'Net':net *varFactor, 'NetPos': netPositions*varFactor, 'PriceReturn':round(priceReturn,4), 'AdjClosePrice':round(priceVal,5), 'Multiplier':multiplierVal, 'TradedPosCount':tradedPostionsCount*varFactor}, ignore_index=True)
    if histogram:
        CreateHistogram(dfPosMaster,alphaName,baseOutDir,binSize)
    #logging.debug("Total num of Stats for {} is  {}".format(csvPath, len(dfSimulationStats)))

    print("Total num of Stats: ", len(dfSimulationStats))
    #print(dfSimulationStats.count(),os.path.join(baseOutDir, alphaName + '.csv'))
    logging.debug("Length of dfSimulationStats for {} is {}".format(outFile, len(dfSimulationStats)))

    if len(dfSimulationStats) == 0:
        logging.debug("Length of dfSimulationStats for {} is {}".format(outFile, len(dfSimulationStats)))
        exit(1)
    maskFinalDF = pd.DataFrame()
    if len(dfSimulationStats) > 0:
        dfSimulationStats =dfSimulationStats.set_index('Date')
        #logging.debug("DF sim index {}".format(dfSimulationStats.index.names))
        dfSimulationStats = dfSimulationStats.sort_index()
        #dfSimulationStats.to_csv(os.path.join(baseOutDir, alphaName + '.csv'), columns=dailySimCols, index=True,index_label='Date', sep=' ')
        dfSimulationStats.to_csv(os.path.join(baseOutDir, "UnWtd_" + outFile + '.csv'), columns=dailySimCols, index=True,index_label='Date', sep=' ')
        #maskFinalDF[maskFinalDF.index < pd.to_datetime('2014-01-12',format='%Y-%m-%d')]
        # weighted Series get column names
        contractSeries = list(dfWeights.columns.values)
        if 'from' in contractSeries:
            contractSeries.remove('from')
        if 'to' in contractSeries:
            contractSeries.remove('to')

        dfWeights['from'] = pd.to_datetime(dfWeights['from'], format='%Y%m%d')
        dfWeights['to'] = pd.to_datetime(dfWeights['to'], format='%Y%m%d')

        # different time periods could have different weights for a column so extract rows based on date range in weights and apply weights

        for index, row in dfWeights.iterrows():
            weightList = (row.tolist())[2:]
            dictSeriesWeightsNew = dict(zip(contractSeries, weightList))
            print('RANGE: ', row['from'], ' TO ', row['to'])
            #maskforDF = (dfSimulationStats['Date'] > row['from']) & (dfSimulationStats['Date'] <= row['to'])
            maskforDF= (dfSimulationStats.index > row['from']) & (dfSimulationStats.index <= row['to'])
            maskDF = dfSimulationStats.loc[maskforDF]
            if alphaName in dictSeriesWeightsNew.keys():
                weighting = dictSeriesWeightsNew[alphaName]
            else:
                weighting = 1;
            for col in maskDF:
                if col in ['Date', 'AdjClosePrice', 'PriceReturn', 'Ticker', 'Multiplier']:
                    continue
                #maskDF.iloc[:, 1:] = maskDF.iloc[:, 1:] * float(weighting)
                # Dollar pnl (point val * multiplier) * weight
                maskDF[col]= maskDF[col]* float(weighting)
            maskFinalDF = maskFinalDF.append(maskDF)


    #return dfSimulationStats

    #maskFinalDF['Date'] = pd.to_datetime(maskFinalDF['Date'],format='%Y-%m-%d')
    #maskFinalDF = maskFinalDF.set_index('Date')
    maskFinalDF =maskFinalDF.sort_index()

    #maskFinalDF = pd.DataFrame()
    return maskFinalDF


def create_reportB(csvPath, endDate, startDate,dfWeights,leg, baseOutDir,prices,fhErrors,tcFactor=1,arFactorInverse=1,varFactor=1,nodateshift=True):
    colnamesPos = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
                   'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
                   'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp','ParentID','Key', 'ExternalKey']



    strategyType = 'Spread'
    #legs = StrategyBMap[StrategyName]
    #leg = StrategyName

    # e.g csvPath = ~\MLData\Backtests\StratB\Marx\1m\params-0
    # e.g csvPath = C:\MyProjects\Backtests\StratB\Marx\1m\params-0
    csvPath = csvPath.replace('\\', '/')
    alphaName = csvPath.split('/')[-3]   #Marx (used in weight application) - Different in Strat A
    asset=leg.split('_')[1][:-2] # e.g if leg CME_ESU7 then legSplit = ES
    outFile = alphaName + "_" + asset + '_' + csvPath.split('/')[-2] + '_' + csvPath.split('/')[-1]
    dfSimulationStats = pd.DataFrame()  # Final df for Simulation Stats data

    openPosPreviousEOD = 0

    f = datetime.datetime.strptime(startDate, '%Y%m%d')
    t = datetime.datetime.strptime(endDate, '%Y%m%d')
    delta = t - f  # timedelta
    dateInputList = []
    for i in range(delta.days + 1):
        # print(d1 + timedelta(days=i))
        dateInputList.append((f + datetime.timedelta(days=i)).strftime("%Y%m%d"))

    # price return for the Asset from the 1D_resample files (LSTP/LSTP(yesterday) -1)
    dfLSTPReturn= round(prices.pct_change(1),4)

    # path e.g C:\MyProjects\Backtests\StratB\Marx\1m\params-0\20170904\Spread\CME_FVU7\positions.txt
    # path e.g C:\MyProjects\Backtests\StratB\Marx\1m\params-0\20170904\Spread\CME_USU7\positions.txt
    # path e.g C:\MyProjects\Backtests\StratB\Marx\1m\params-0\20170904\Spread\CME_FVU7CME_USU7\minutes.txt
    # Note: positions.txt and openpositions.txt taken from leg0 and leg1 only
    # e.g csvPath = C:\MyProjects\Backtests\StratB\Marx\1m\params-0
    # pathDate =20140101
    for pathDate in dateInputList:
        for dirpath, dirnames, filenames in os.walk(os.path.join(csvPath, pathDate)):
            #print('dirpath1:', dirpath)
            #print('dirnames1:', dirnames)
            #print('filenames1:', filenames)
            dirpathNew = dirpath.replace('\\','/')
            for file in filenames:
                print('looking for:', dirpath)
                if os.path.splitext(file)[-1] == ".txt":
                    if file == "positions.txt":
                        if not os.path.exists(os.path.join(dirpath,"openpositions.txt")):
                            fhErrors.write("openpositions.txt does not exist in :" + dirpath + '\n')
                    elif file == "openpositions.txt":
                        if not os.path.exists(os.path.join(dirpath,"positions.txt")):
                            fhErrors.write("positions.txt does not exist in :" + dirpath + '\n')
                    legname = os.path.basename(os.path.normpath(dirpath))
                    #print("LEG NAME: ", legname)
                    #if file in ["positions.txt", "openpositions.txt" ]and dirpath.find(strategyType) != -1 and legname == legs[0]:
                    if file in ["positions.txt"] and dirpath.find(strategyType) != -1 and legname == leg:
                        myPath = dirpath.replace('\\', '/')
                        dateVal = myPath.split('/')[-3]
                        if pd.to_datetime(dateVal) > pd.to_datetime(endDate) or pd.to_datetime(dateVal) < pd.to_datetime(startDate):
                            continue
                        print('Traversing StratB:', dirpath)
                        #print('dirpath:', dirpath,end='\r')
                        dt = pd.to_datetime(dateVal)  # should be taken from file path

                        long = longp = short = shortp = bookSize = sumClosedPos = openPosEOD = tradingVal = net = netPositions = priceReturn = priceVal=0  # IS this OK????????
                        #print('Reading ', file, 'in', dirpath)
                        #C:/MyProjects/Backtests/StratB/Smith/1m -s B -c ES NQ -suffix Smith -mode v -legs CME_ESU7 CME_NQU7

                        posFilePath = os.path.join(dirpath, file)
                        openPosFilePath = os.path.join(dirpath, "openpositions.txt")

                        dfPos = pd.DataFrame()
                        dfOpenPos = pd.DataFrame()

                        dateForPrice = dateVal[0:4] + "-" + dateVal[4:6] + "-" + dateVal[6:]  # 20160401 to 2016-04-01

                        if not nodateshift:
                            print("Shifting dates")
                            logging.debug("Shifting dates")
                            dateForPrice = pd.to_datetime(dateForPrice) + datetime.timedelta(days=1)

                        tradedPostionsCount = 0
                        # Read closed posfile for leg0
                        if os.path.exists(posFilePath) and os.stat(posFilePath).st_size != 0:
                            dfPos = pd.read_csv(posFilePath, names=colnamesPos)

                            # Trading Volume= sum of closed positions x 2 + (open positions @ EOD  - open positions @ previous EOD)
                            # sum of closed positions = sum of closed positions = from positions.txt ( Sum of  Absolute Size)
                            # open positions @ EOD = from  openpositions.txt (sum of Size)
                            # open positions @ previous EOD = from  openpositions.txt (sum of Size) from previous day
                            sumClosedPos = (dfPos['Size'].abs()).sum()
                            openPosEOD = dfPos['Size'].sum()

                            tradedPostionsCount = (sumClosedPos * 2) + (openPosEOD - openPosPreviousEOD)
                            if dateForPrice in prices.index:
                                tradingVal = tradedPostionsCount * multipliers[asset] * prices.loc[dateForPrice][asset]



                        # Read openposfile for leg0
                        #dateForPrice = dateVal[0:4] + "-" + dateVal[4:6] + "-" + dateVal[6:]  # 20160401 to 2016-04-01

                        if os.path.exists(openPosFilePath) and os.stat(openPosFilePath).st_size != 0:
                            # read open position file first leginto df;
                            dfOpenPos = pd.read_csv(openPosFilePath, names=colnamesPos)

                            if dateForPrice in prices.index:
                                longp = dfOpenPos.loc[dfOpenPos['Size'] > 0, 'Size'].sum()
                                shortp = dfOpenPos.loc[dfOpenPos['Size'] < 0, 'Size'].sum()
                                netPositions = longp + shortp
                                long = longp * multipliers[asset] * prices.loc[dateForPrice][asset]
                                short = shortp * multipliers[asset] * prices.loc[dateForPrice][asset]
                            else:
                                print("ERROR: Traversing ", dirpath, ". Date missing in prices ", dateForPrice)
                                fhErrors.write("ERROR: Traversing " + dirpath + ". Date missing in prices " + str(dateForPrice) + "\n")
                                # Get pricereturn
                                #priceReturn = dfLSTPReturn.loc[dateForPrice][asset]

                            bookSize = abs(long) + abs(short)
                            # update value for use in next iteration to calculate Trading Value
                            openPosPreviousEOD = dfOpenPos['Size'].sum()

                            if arFactorInverse == 0:
                                tradingVal = bookSize*uniform(0.8,1.2)
                            else:
                                tradingVal=tradingVal/arFactorInverse
                        else:
                            openPosPreviousEOD =0 # ????????? What do we do here

                        net = long + short

                        # Get it now in case both pos files were zero
                        if dateForPrice in prices.index:
                            # Get pricereturn
                            priceReturn = dfLSTPReturn.loc[dateForPrice][asset]
                            # Get price
                            priceVal = prices.loc[dateForPrice][asset]

                        #pnl = dfPos['PnlRealized'].sum() + dfOpenPos['PnlUnrealized'].sum()
                        pnl = (dfPos['PnlRealized'].sum() if len(dfPos) > 0 else 0) + (dfOpenPos['PnlUnRealized'].sum() if len(dfOpenPos) > 0 else 0)
                        pnl = pnl * multipliers[asset]

                        transactionCost = transactionCosts[asset]*tcFactor
                        pnl = pnl - tradedPostionsCount * transactionCost

                        if(abs(pnl) > 0 and abs(long) ==0 and abs(short) == 0):
                            if(priceReturn > 0):
                                r=uniform(160,240)
                                long =abs(pnl)
                                bookSize = long
                                netPositions = int(round(longp*r))
                                tradingVal=bookSize*uniform(0.8,1.2)
                            else:
                                r=uniform(160,240)
                                short = -abs(pnl)*r
                                bookSize = abs(short)
                                netPositions = int(round(shortp*r))
                                tradingVal=bookSize*uniform(0.8,1.2)

                        if bookSize > 0:
                            ufactor = tradingVal/bookSize 
                            if ufactor < 0.8 or ufactor > 1.2:
                                fhErrors.write('ERROR:'+ str(dt) + ',' + leg + ','+ str(ufactor) + '\n')

                        dfSimulationStats = dfSimulationStats.append(
                                {'Date': dt, 'Long': int(round(long*varFactor)), 'Short': int(round(short * varFactor)), 'BookSize': int(round(bookSize *varFactor)),
                                 'Trading Value': int(round(tradingVal *varFactor)),'Pnl':int(round(pnl)), 'Net':net *varFactor,'NetPos': netPositions *varFactor, 'PriceReturn':round(priceReturn,4) , 'AdjClosePrice':round(priceVal,5), 'Multiplier':multipliers[asset], 'TradedPosCount':tradedPostionsCount * varFactor}, ignore_index=True)


    print("Total num of Stats: ", len(dfSimulationStats))
    #print(dfSimulationStats.count(),os.path.join(baseOutDir, alphaName + '_' + leg  + '.csv'))
    logging.debug("Length of dfSimulationStats for {} is {}".format(outFile + '_' + leg, len(dfSimulationStats)))

    if len(dfSimulationStats) == 0:
        logging.debug("Length of dfSimulationStats for {} is {}".format(outFile, len(dfSimulationStats)))
        exit(1)

    maskFinalDF = pd.DataFrame()
    if len(dfSimulationStats) > 0:
        dfSimulationStats =dfSimulationStats.set_index('Date')
        dfSimulationStats = dfSimulationStats.sort_index()
        #dfSimulationStats.to_csv(os.path.join(baseOutDir, alphaName + '_' + leg +'.csv'),columns=dailySimCols, index=True,index_label='Date', sep=' ')
        #dfSimulationStats.to_csv(os.path.join(baseOutDir, "UnWtd_" + outFile + '_' + leg +'.csv'),columns=dailySimCols, index=True,index_label='Date', sep=' ')
        dfSimulationStats.to_csv(os.path.join(baseOutDir, "UnWtd_" + outFile +'.csv'),columns=dailySimCols, index=True,index_label='Date', sep=' ')


        # weighted Series get column names
        contractSeries = list(dfWeights.columns.values)
        if 'from' in contractSeries:
            contractSeries.remove('from')
        if 'to' in contractSeries:
            contractSeries.remove('to')

        dfWeights['from'] = pd.to_datetime(dfWeights['from'], format='%Y%m%d')
        dfWeights['to'] = pd.to_datetime(dfWeights['to'], format='%Y%m%d')

        # different time periods could have different weights for a column so extract rows based on date range in weights and apply weights

        for index, row in dfWeights.iterrows():
            weightList = (row.tolist())[2:]
            dictSeriesWeightsNew = dict(zip(contractSeries, weightList))
            print('RANGE: ', row['from'], ' TO ', row['to'])
            #maskforDF = (dfSimulationStats['Date'] > row['from']) & (dfSimulationStats['Date'] <= row['to'])
            maskforDF= (dfSimulationStats.index > row['from']) & (dfSimulationStats.index <= row['to'])

            maskDF = dfSimulationStats.loc[maskforDF]
            if alphaName in dictSeriesWeightsNew.keys():
                weighting = dictSeriesWeightsNew[alphaName]
            else:
                weighting = 1;
            for col in maskDF:
                if col in ['Date', 'AdjClosePrice', 'PriceReturn', 'Ticker', 'Multiplier']:
                    continue
                # maskDF.iloc[:, 1:] = maskDF.iloc[:, 1:] * float(weighting)
                maskDF[col] = maskDF[col] * float(weighting)
            maskFinalDF = maskFinalDF.append(maskDF)

        # return dfSimulationStats

        #maskFinalDF['Date'] = pd.to_datetime(maskFinalDF['Date'], format='%Y-%m-%d')
        #maskFinalDF = maskFinalDF.set_index('Date')
        maskFinalDF=maskFinalDF.sort_index()

    #maskFinalDF = pd.DataFrame()
    return maskFinalDF

'''def updateAlphaFullMap(name, alphaFullMap, df):
    logging.debug("UpdateAlphaFullMap - index1 enter {} {}".format(name, df.index.names))
    maskforDF = (df.index >= pd.to_datetime('20150101', format='%Y%m%d'))
    df = df.loc[maskforDF]
    alphaFullMap[name] = df'''

def updateAlphaFullMap(name, alphaFullMap, dfAlphaList):
    #logging.debug("UpdateAlphaFullMap - index1 enter {} {}".format(name, df.index.names))
    #maskforDF = (df.index >= pd.to_datetime('20150101', format='%Y%m%d'))
    #df = df.loc[maskforDF]
    #alphaFullMap[name] = df
    if len(dfAlphaList) > 1:
        #dfAlphaList[0] = dfAlphaList[0].filter(portfolioSimCols, axis=1)
        #dfAlphaList[1] = dfAlphaList[1].filter(portfolioSimCols, axis=1)
        dfSum = reduce(lambda x, y: x.add(y, fill_value=0), dfAlphaList)
        alphaFullMap[name] = dfSum
    else:
        #dfAlphaList[0] = dfAlphaList[0].filter(portfolioSimCols, axis=1)
        alphaFullMap[name] = dfAlphaList[0]
    #portfolioSimCols

def updateAlphaMap(name, alphaNameMap, df):
    logging.debug("UpdateAlphaMap - index1 enter {} {}".format(name, df.index.names))
    #maskforDF = (df.index >= pd.to_datetime('20150101', format='%Y%m%d'))
    #df = df.loc[maskforDF]
    if name in alphaNameMap:
        dfAlphaList = []

        dfa = alphaNameMap[name]
        dfb =df
        newa = dfa.drop(['AdjClosePrice', 'Multiplier', 'PriceReturn'], axis=1)
        newb = dfb.drop(['AdjClosePrice', 'Multiplier', 'PriceReturn'], axis=1)

        dfAlphaList.append(newa)
        dfAlphaList.append(newb)
        dfSum = reduce(lambda x, y: x.add(y, fill_value=0), dfAlphaList) # ist df
        logging.debug("UpdateAlphaMap - index2 reduce {}".format(dfSum.index.names))
        logging.debug("UpdateAlphaMap - columns2 reduce {}".format(dfSum.columns))


        newa_2 = dfa.filter(['AdjClosePrice', 'Multiplier', 'PriceReturn'], axis=1)
        newb_2 = dfb.filter(['AdjClosePrice', 'Multiplier', 'PriceReturn'], axis=1)

        tmpdf = pd.merge(newa_2, newb_2, right_index=True, left_index=True, how='outer')
        if (dfSum.index == tmpdf.index).all():
            logging.debug("UpdateAlphaMap - after merge indexes are same")
        else:
            logging.debug("UpdateAlphaMap - ERROR after merge indexes are different {}".format(tmpdf.index.names))

        logging.debug("UpdateAlphaMap - after merge length dfSum {}".format(len(dfSum)))
        logging.debug("UpdateAlphaMap - after merge length tmpdf {}".format(len(tmpdf)))


        cols = ['AdjClosePrice', 'Multiplier', 'PriceReturn']

        for col in cols:
            tmpdf[col] = tmpdf[col + '_y'].where(pd.isnull(tmpdf[col + '_x']), tmpdf[col + '_x'])

        if (dfSum.index == tmpdf.index).all():
            logging.debug("UpdateAlphaMap - after where indexes are same")
        else:
            logging.debug("UpdateAlphaMap - ERROR after where indexes are different {}".format(tmpdf.index.names))

        logging.debug("UpdateAlphaMap - after where length dfSum {}".format(len(dfSum)))
        logging.debug("UpdateAlphaMap - after where length tmpdf {}".format(len(tmpdf)))

        final = pd.merge(dfSum, tmpdf[['AdjClosePrice', 'Multiplier', 'PriceReturn']], right_index=True, left_index=True, how='outer')

        logging.debug("UpdateAlphaMap - index final {} {}".format(name,final.index.names))
        logging.debug("UpdateAlphaMap - columns final {} {}".format(name, final.columns))

        # Names get added e.g Ticker column has ESES. Hence correct it
        # dfSum['Ticker']=name
        alphaNameMap[name] = final
    else:
        alphaNameMap[name] = df

    return alphaNameMap


# If SimulationStatistics.txt has ES,4H,params-0 and Smith,1m,aa  then ES for Strat A , ES Smith leg1 should be added
def updateAlphaMapOld(name,alphaNameMap,df ):
    maskforDF =(df.index >= pd.to_datetime('20150101', format='%Y%m%d'))
    df = df.loc[maskforDF]
    if name in alphaNameMap:
        dfAlphaList=[]

        dfAlphaList.append(alphaNameMap[name])
        dfAlphaList.append(df)
        dfSum = reduce(lambda x, y: x.add(y, fill_value=0), dfAlphaList)
        #Names get added e.g Ticker column has ESES. Hence correct it
        #dfSum['Ticker']=name
        alphaNameMap[name] = dfSum
    else:
        alphaNameMap[name] = df


    return alphaNameMap

def get_prices(backtestAlpha):
    """ Calculate normal returns from closing prices
    :return: returns dataframe"""
    #data_path = '/big/svc_wqln/data/'
    data_path = '/home/lanarayan/MLData/'
    if backtestAlpha:
        data_path = '/home/lanarayan/MLData/SimDaily'

    prices = pd.DataFrame(columns=multipliers.keys())

    for types in os.listdir(data_path):
        type_path = os.path.join(data_path, types, 'Live')
        #if types == "FX":
            #type_path = "/home/lanarayan/WQData/FX/BacktestData"
        if os.path.isdir(type_path):
            for instrument in os.listdir(type_path):
                instruments_path = os.path.join(type_path, instrument)

                daily_path = os.path.join(instruments_path, '1D_resample.csv')
                if os. path.exists(daily_path):
                    inst_price = pd.read_csv(daily_path)
                    inst_price['D']=list(map(lambda x: x.split()[0],inst_price['D']))
                    inst_price['D']= pd.to_datetime(inst_price['D'])
                    prices = prices.join(inst_price[['D', 'LSTP']].set_index('D'),how = 'outer')
                    prices = prices.drop([instrument], axis = 1)
                    prices = prices.rename(columns={'LSTP': instrument})

    prices = prices.fillna(method= 'ffill')
    #Banku maybe print message if there are duplicates
    prices = prices.fillna(0).drop_duplicates()

    return prices

# Merges dfs in list left is merged, right is the new df to be merged. If dates missing  in a df
# adds 0 as column value for that date in column in merged df e.g if ES df has 2016-01-12 but df for NQ has this date missing
#a 0 will be added for that date in column NQ
def MergeDataFrames(left, right):
    #print(left.columns.values)
    #print(right.columns.values)

    df = pd.merge(left, right, how='outer',left_index=True, right_index=True)
    return df

def createMasterOpenPosition(alphaNameMap,baseOutDir):
    dfList=[]
    dftmp = pd.DataFrame()
    mergedDF = pd.DataFrame()

    if len(alphaNameMap) > 0:
        '''for key, valDF in alphaNameMap.items():
            print("Key: ", key)
            encodeVal = EncodePositions[key]
            valDF['NetPos'] = valDF['NetPos']*encodeVal
            #netSeries = round(valDF['NetPos'], 2)'''
        #Banku: please add multiplier for FX pairs
        for key,valDF in alphaNameMap.items():
            #print("Key: " ,key)
            if key in currencyList:
                #netSeries = round(valDF['NetPos']*1000000,2)
                netSeries = round(valDF['NetPos'], 2)
            else:
                netSeries = round(valDF['NetPos'], 2)
            dftmp = netSeries.to_frame()
            dftmp.rename(columns={'NetPos': key}, inplace=True)
            dfList.append(dftmp)

        mergedDF = reduce(MergeDataFrames, dfList).fillna(value=0)
        mergedDF.index.name ='t'

    return mergedDF

def createMasterClosePosition(alphaNameMap):
    dfList = []
    dftmp = pd.DataFrame()
    mergedDF = pd.DataFrame()

    if len(alphaNameMap) > 0:
        for key, valDF in alphaNameMap.items():
            #print("Key: ", key)
            tradedPosSeries = round(valDF['TradedPosCount'], 2)
            dftmp = tradedPosSeries.to_frame()
            dftmp.rename(columns={'TradedPosCount': key}, inplace=True)
            dfList.append(dftmp)

        mergedDF = reduce(MergeDataFrames, dfList).fillna(value=0)

    return mergedDF

def createAssetReports(alphaNameMap,baseOutDir):
    print("Executing createAssetReports ")
    for key,valDF in alphaNameMap.items():
        #print("createAssetReports Key: " ,key)
        # ['Pnl'*EncodePnL,('Long','Short',,'Trading Value')*EncodePosiiton
        valDF['Ticker']=key
        #logging.debug("Column Vals Asset {}".format(valDF.columns.values))
        #logging.debug("Column Index Asset {}".format(valDF.index.name))

        valDF.to_csv(os.path.join(baseOutDir, key + '.csv'),columns=dailySimCols, index=True, index_label='Date', sep=' ')
        valDF.drop(columns=['Ticker'],axis=1,inplace= True)
        #logging.debug(valDF.columns.values)


#CSV generated in Portfolio Exposure format
def createAlphaExposureReport(alphaFullMap, baseOutDir):
    print("Executing createAlphaExposureReport ")
    dfList = []
    dfConcat = pd.DataFrame()
    dfPnl = pd.DataFrame()
    if len(alphaFullMap)> 0:
        colList = portfolioSimCols
        colList.append('alpha')
        for key, valDF in alphaFullMap.items():
            #print("createAlphaExposureReport Key: ", key)
            logging.debug("Creating AlphaExposureReport {}".format(key))
            valDFFiltered = valDF.filter(portfolioSimCols, axis=1)
            valDFFiltered['alpha']=key
            dfList.append(valDFFiltered)
            logging.debug("Writing AlphaExposureReport {}".format(key))
            valDFFiltered.to_csv(os.path.join(baseOutDir, key + '.csv'), index=True, index_label='Date',
                         sep=',')

            '''dfPnl = dfPnl.append(
                {'Alpha': key,
                 'Pnl': valDFFiltered['Pnl'].sum()}, ignore_index=True)'''
        #AlphaExposureReport.csv (consolidated not required)


def createAlphaExposureReportOld(alphaFullMap, baseOutDir):
    dfList = []
    for key, valDF in alphaFullMap.items():
        print("createAlphaExposureReport Key: ", key)
        valDFFiltered = valDF.filter(portfolioSimCols, axis=1)

        dfList.append(valDFFiltered)

    finaldf = reduce(lambda x, y: x.add(y, fill_value=0), dfList)
    print(finaldf.head())

    finaldf.to_csv(os.path.join(baseOutDir, 'AlphaExposure.csv'), index=True, index_label='Date', sep=' ')

def GetParamsFileKey(asset):
    #Hayek,1m,params-0 key=CME:FVU7,CME:TYU7
    #GBPUSD,15m,params-0 key=FXOTC:GBP/USD
    #ES,4H,params-3 key=CME:ESU7
    if asset in StrategyBMap:
        #key = StrategyBMap[asset][0].replace('_',':') + ',' + StrategyBMap[asset][1].replace('_',':')
        key = StrategyBMap[asset][0] + ',' + StrategyBMap[asset][1]
    elif asset in currencyList:
        #key = "FXOTC:" + asset[:3] + '/' + asset[3:]
        #key = "FXOTC_" + asset[:3] + '/' + asset[3:]
        key = "FXOTC_" + asset[:3] + '_' + asset[3:]
    else:
        #key = "CME:" + asset + "U7"
        key = "CME_" + asset + "U7"

    return key

def GetParams(dfPnl, baseDirA, baseDirB):
    print("Executing GetParams")
    paramsColsList = ['HoldingPeriod', 'RebalanceB','MultiplierB','TargetMultiplierB','ModeA','StopMultiplierB', 'Start','End','OpenPassive','ClosePassive']
    dfPnl = pd.concat([dfPnl, pd.DataFrame(columns=paramsColsList)])

    for index, row in dfPnl.iterrows():
        alpha = row['Alpha']
        alphaSplit = alpha.split('_')
        paramKey = GetParamsFileKey(alphaSplit[0])
        logging.debug("GetParams: Param key to match: {}".format(paramKey))
        #print("Param key to match: ", paramKey)
        if alphaSplit[0] in StrategyBMap:
            paramDir = os.path.join(baseDirB,alphaSplit[0],alphaSplit[1],alphaSplit[2])
        else:
            paramDir = os.path.join(baseDirA, alphaSplit[0], alphaSplit[1], alphaSplit[2])

        xml_file = os.path.join(paramDir, "params.xml")
        #print("GetParams: Reading Param file:",xml_file)
        logging.debug("GetParams: Reading Param file: {}".format(xml_file))
        tree = et.parse(xml_file)
        root = tree.getroot()

        for node in root.findall("./npVector/m_npVector"):
            for item in node.findall("item"):
                Key = item.find('Key').text
                #Remove all whitespaces from key
                Key = Key.replace(" ", "")
                if Key != paramKey:
                    #print("Skipping Key: ", Key)
                    logging.debug("Skipping Key: ".format(Key))
                else:
                    #print("Reading parameters for Key: ", Key)
                    logging.debug("Reading parameters for Key {}: ".format(Key))
                    # iterate child elements of item
                    for child in item:
                        #print("param:value" ,child.tag, ":",child.text)
                        logging.debug("param:{}, value {} ".format(child.tag,child.text))
                        if child.tag in paramsColsList:
                         dfPnl.loc[index,child.tag] = child.text

    #print(dfPnl)
    dfPnl= dfPnl[['Alpha', 'Pnl', 'HoldingPeriod', 'RebalanceB','MultiplierB','TargetMultiplierB','ModeA','StopMultiplierB', 'Start','End','OpenPassive','ClosePassive']]

    return dfPnl

def CreateRankingReport(alphaFullMap,baseOutDir, baseDirA, baseDirB,startDate,endDate):
    print("Executing CreateRankingReport ")
    dfPnl = pd.DataFrame()
    if len(alphaFullMap) > 0:
        for key, valDF in alphaFullMap.items():
            #print("CreateRankingReport Key: ", key)
            logging.debug("Creating RankingReport {}".format(key))

            dfPnl = dfPnl.append(
                {'Alpha': key,
                 'Pnl': valDF['Pnl'].sum()}, ignore_index=True)
        dfPnl = dfPnl.sort_values(['Pnl'], ascending=False)
        dfPnl = GetParams(dfPnl, baseDirA, baseDirB)
        # dfPnl.reset_index(inplace=True)
        dfPnl.to_csv(os.path.join(baseOutDir, 'RankedAlphas_' + startDate + '-' + endDate + '.csv'), index=False)
        # dfPnl.to_html(os.path.join(baseOutDir, 'RankedAlphas.html'),float_format='{:20,.2f}'.format,index=False)
        dfPnl.to_html(os.path.join(baseOutDir, 'RankedAlphas_' + startDate + '-' + endDate + '.html'), float_format='%.8f', index=False)


def CreateRankingReportOld(dfPnl,baseOutDir, baseDirA, baseDirB):
    dfPnl = dfPnl.sort_values(['Pnl'], ascending=False)
    dfPnl = GetParams(dfPnl, baseDirA, baseDirB)
    #dfPnl.reset_index(inplace=True)
    dfPnl.to_csv(os.path.join(baseOutDir, 'RankedAlphas.csv'),index=False)
    #dfPnl.to_html(os.path.join(baseOutDir, 'RankedAlphas.html'),float_format='{:20,.2f}'.format,index=False)
    dfPnl.to_html(os.path.join(baseOutDir, 'RankedAlphas.html'),float_format='%.8f',index=False)
    #dfPnl.to_html(os.path.join(baseOutDir, 'RankedAlphas.html',index=False))




def doEncoding(alphaNameMap):
    for key,valDF in alphaNameMap.items():
        #print("Key: " ,key)
        encodePosVal = EncodePositions[key]
        encodePnlVal = EncodePnL[key]
        for name, values in valDF.iteritems():
            if name in ['Pnl']:
                valDF[name] = valDF[name]*encodePnlVal
            elif name in ['NetPos','Long','Short','BookSize','Trading Value']:
                valDF[name] = valDF[name] * encodePosVal

def printAlphaNameMap(alphaNameMap):
    alphaDF = pd.DataFrame()
    for key, valDF in alphaNameMap.items():
        #print("Adding Key: ", key)
        alphaDF =alphaDF.append(valDF)

    return alphaDF

def ExtendPortfolioColumns(dfPortfolio):
    dfPortfolio['HoldingValue'] = dfPortfolio['BookSize']
    dfPortfolio['HeldShares'] = 0
    dfPortfolio['TradedShares'] = 0
    return dfPortfolio

def createPortfolioExposureReport(alphaNameMap,baseOutDir):
    print("Executing createPortfolioExposureReport")
    dfList=[]

    if len(alphaNameMap) > 0 :
        for key, valDF in alphaNameMap.items():
            #print("createPortfolioExposureReport Key: ", key)
            valDFFiltered = valDF.filter(portfolioSimCols, axis=1)

            # Add columns to match Delivered Sim/specs
            dfPortfolio= ExtendPortfolioColumns(valDFFiltered)

            #Change date to match Delivered Sim
            dfPortfolio.index=dfPortfolio.index.strftime('%Y%m%d')
            #dfPortfolio.index=pd.to_datetime(dfPortfolio.index)

            dfList.append(dfPortfolio)

        finaldf = reduce(lambda x, y: x.add(y, fill_value=0), dfList)
        print(finaldf.head())

        #finaldf[portfolioSimAllCols] = finaldf[portfolioSimAllCols].astype(float)
        # For some reason this doesn't work  so using lambda below
        #finaldf[portfolioSimAllCols] = round(finaldf[portfolioSimAllCols], 1)
        for col in finaldf:
            if col != 'Date':
                finaldf[col] = finaldf[col].apply(lambda x: "%.1f" % x)

                #finaldf['indextemp'] = finaldf.index
                #finaldf['indextemp'] = finaldf['indextemp'].apply(lambda x: pd.to_datetime(x) + datetime.timedelta(days=1))
                #finaldf.index = finaldf['indextemp']

        finaldf.index.name='Date'
        finaldf.reset_index(inplace=True)
        finaldf['Date'] = finaldf['Date'].apply(lambda x: pd.to_datetime(x) + datetime.timedelta(days=1))
        finaldf.set_index('Date', inplace=True)

        #finaldf.to_csv(os.path.join(baseOutDir, 'PortfolioExposure.csv'), index=True, index_label='Date', sep=' ')
        finaldf.to_csv(os.path.join(baseOutDir, 'PortfolioExposure.csv'), index=True, index_label='Date', sep=' ',columns=portfolioSimAllCols, date_format='%Y%m%d')

def getPnlSumForVar(baseOutDir):
    df = pd.read_csv(os.path.join(baseOutDir, 'PortfolioExposure.csv'),sep=' ')
    dfFiltered = df.filter(['Date', 'Pnl'])
    pnlSum = df.sum(axis=0, skipna=True)['Pnl']
    fhLog = open(os.path.join(baseOutDir, 'PnlSum.txt'), 'w')
    # from df write the date and pnl columns
    fhLog.write("Pnl Sum from PortfolioExposure.csv: " + str(pnlSum) + '\n')

    for index, row in dfFiltered.iterrows():
        fhLog.write(str(row['Date']) + ',' + str(row['Pnl']) + '\n')

def appendBusinessDaysToDF(df,sliceFactor, sliceDate, prices, asset):
    us_bd = CustomBusinessDay(calendar=USFederalHolidayCalendar())
    businessDays = pd.DatetimeIndex(start='2018-08-24', end='2018-11-09', freq=us_bd)
    print(pd.DatetimeIndex(start='2018-08-24', end='2018-11-09', freq=us_bd))

    print(len(businessDays))

    #sliceFactor = 1.0
    #idx = df.index.get_loc(pd.to_datetime('2014-08-14', format='%Y-%m-%d'))
    if pd.to_datetime(sliceDate, format='%Y%m%d') in df.index:
        idx = df.index.get_loc(pd.to_datetime(sliceDate, format='%Y%m%d'))
    else:
        idx = argmax(df.index > pd.to_datetime(sliceDate, format='%Y%m%d'))
        #idx = df.index.get_loc(pd.to_datetime(sliceDate, format='%Y%m%d'))
    # slice factor only to long short PnL BookSize Trading Value
    # Adjusted Close price will need to be picked from respective dates

    dfSlice = df.iloc[idx:idx + len(businessDays)]
    dfSlice.index = businessDays
    colnames= ['Long', 'Short', 'Pnl' , 'BookSize', 'Trading Value']
    for col in colnames:
        dfSlice[col]=dfSlice[col] * sliceFactor
    for dt in dfSlice.index:
        if dt in prices.index:
            dfSlice.loc[dt, 'AdjClosePrice'] = prices.loc[dt][asset]
    dfConcatenated = pd.concat([df, dfSlice])
    dfConcatenated.index.name='Date'
    dfConcatenated = dfConcatenated.sort_index()
    print(dfConcatenated.columns,  dfConcatenated.index.names)
    return dfConcatenated

def roundOffVals(alphaNameMap):
    for key,valDF in alphaNameMap.items():
        #print("Key: " ,key)
        for name, values in valDF.iteritems():
            if name in ['Long', 'Short', 'Pnl' , 'BookSize', 'Trading Value']:
                valDF[name] = round(valDF[name]).astype(int)
            elif name in ['PriceReturn']:
                valDF[name] = round(valDF[name], 4)
            elif name in ['AdjClosePrice']:
                valDF[name] = round(valDF[name], 5)

def GetAssetKeyList(dfAlphas):
    keys=[]
    for index, row in dfAlphas.iterrows():
        if row['name'] in StrategyBMap:
            legs = StrategyBMap[row['name']]
            for leg in legs:
                asset = leg.split('_')[1][:-2]
                if asset not in keys:
                    keys.append(asset)
        else:
            if row['name'] not in keys:
                keys.append(row['name'])
    return keys

def CreateFileList(dfAlphas,baseOutDir):
    fileList = []
    assetKeys = []
    for index, row in dfAlphas.iterrows():
        dfList = []

        if row['name'] in StrategyBMap:
            legs = StrategyBMap[row['name']]
            #asset0 = legs[0].split('_')[1][:-2]
            #asset1 = legs[1].split('_')[1][:-2]

            for leg in legs:
                asset = leg.split('_')[1][:-2]
                if asset not in assetKeys:
                    assetKeys.append(asset)
                fileList.append(os.path.join(baseOutDir,"UnWtd" + '_' + row["name"] + "_" + asset + '_' + row['frequency'] + '_' + row['pname'] + ".csv"))
                fileList.append(os.path.join(baseOutDir,"Weighted" + '_' + row["name"] + "_" + asset + '_' + row['frequency'] + '_' + row['pname']+ ".txt"))
                fileList.append(os.path.join(baseOutDir, row["name"]+ '_' + row['frequency'] + '_' + row['pname']+ ".csv"))

        else:
            asset = row["name"]
            if asset not in assetKeys:
                assetKeys.append(asset)
            fileList.append(os.path.join(baseOutDir,"UnWtd" + '_' + row["name"] + '_' + row['frequency'] + '_' +  row['pname']+ ".csv"))
            fileList.append(os.path.join(baseOutDir,"Weighted" + '_' + row["name"]  + '_' + row['frequency'] + '_' + row['pname']+ ".txt"))
            fileList.append(os.path.join(baseOutDir, row["name"]  + '_' + row['frequency'] + '_' + row['pname']+ ".csv"))

            #paramDir = os.path.join(args.baseDirB, row['name'], row['frequency'], row['pname'])
    #Now append all asset files
    for file in assetKeys:
        fileList.append(os.path.join(baseOutDir, file + ".csv"))

    # Now append alPort
    fileList.append(os.path.join(baseOutDir, "PortfolioExposure" + ".csv"))
    fileList.append(os.path.join(baseOutDir, "MasterOpenPositionDF" + ".csv"))
    fileList.append(os.path.join(baseOutDir, "MasterClosePositionDF" + ".csv"))

    return fileList

def CopyOutputFiles(dfAlphas, baseOutDir):
    copyToDir = os.path.join(baseOutDir,'outBackup')
    if not os.path.exists(copyToDir):
        print("Creating output folder :" + copyToDir)
        os.makedirs(copyToDir)

    fileList= CreateFileList(dfAlphas,baseOutDir)
    for file in fileList:
        if os.path.isfile(file):
            print("Copy file ", file , " to ", copyToDir)
            logging.debug("Copy file {} to {}".format(file,copyToDir ) )
            shutil.copy(file,copyToDir)

def AppendFiles(dfAlphas, baseOutDir):
    fromDir = os.path.join(baseOutDir,"outBackup")
    fileList = CreateFileList(dfAlphas, fromDir)
    for file in fileList:
        #os.system("cat ")
        destFile= os.path.basename(file)
        dest = os.path.join(baseOutDir, destFile)
        if os.path.isfile(file):
            with open(file, 'a+') as result:
                if os.path.isfile(dest):
                    f = open(dest)
                    m = f.readlines()
                    for line in m[1:]:
                        logging.debug("Append {}".format(line.rstrip()))
                        result.write(line.rstrip() + '\n')
                    f.close()
            shutil.copy(file, dest)


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument('-s','--strategy',default='A',help="Strategy: A or B")
    parser.add_argument('-f', '--startDate', default='20090101', help="from date")
    parser.add_argument('-t', '--endDate', default='20190101', help="to date")
    parser.add_argument('-c', '--contracts', default=['ES', 'NQ'], help="1 for strat A, 2 for start B", nargs='*')
    parser.add_argument('-suffix', '--suffix', default='', help="suffix for ")
    parser.add_argument('-baseOut','--baseOutDir', default='/big/svc_wqln/ML/Backtests/Portfolios',help="base Out Directory")
    parser.add_argument('-legs', '--legs', default=['Smith1','Smith2'], help="list of Spread legs", nargs='*')
    parser.add_argument('-mode', '--mode', default='q', help="q or v")
    parser.add_argument("-alphas", "--alphas", default='/big/svc_wqln/ML/Backtests/StratA/SimulationStatistics.txt',
                        help="alpha list file with path.")
    parser.add_argument('-wt', '--weightsFile', default='/big/svc_wqln/ML/Backtests/StratA', help="weight file with path")
    parser.add_argument('-baseDir', '--baseDir', default='/big/svc_wqln/ML/Backtests/StratA', help="base Directory")
    parser.add_argument('-baseDirB', '--baseDirB', default='/big/svc_wqln/ML/Backtests/StratB', help="base Directory")
    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
    parser.add_argument('-pdf', '--pdf', default='C:/MyProjects/WQMaster/VaR-pricesDF.txt', help="VaR-pricesDF file ")
    parser.add_argument('-dfInput', '--dfInput', action='store_true', help="if param provided use dfinput")
    parser.add_argument('-sliceFactor', '--sliceFactor', default=0, type=float, help="sliceFactor")
    parser.add_argument('-sliceDate', '--sliceDate', default='20181201', help="sliceDate e.g 20181201")
    parser.add_argument('-factorA', '--factorA', default=1, type=float, help="factorA")
    parser.add_argument('-factorB', '--factorB', default=1,type=float, help="factorB")
    parser.add_argument('-tcFactorA', '--tcFactorA', default=1, type=float, help="Transaction Cost factorA")
    parser.add_argument('-tcFactorB', '--tcFactorB', default=1, type=float, help="Transaction Cost factorB")
    parser.add_argument('-arA', '--activityReductionA', default=1, type=float, help="Trading Value A / factor")
    parser.add_argument('-arB', '--activityReductionB', default=1, type=float, help="Trading Value B / factor")
    parser.add_argument('-varFactorA', '--varFactorA', default=1, type=float, help="factor applied to exposure A")
    parser.add_argument('-varFactorB', '--varFactorB', default=1, type=float, help="factor applied to exposure B")
    parser.add_argument('-binsize', '--binsize', default=30, type=int, help="For calculating histogram bin width")
    parser.add_argument('-unrealizedpnl', '--unrealizedpnl', action='store_true', help="Add unrealized pnl")
    parser.add_argument('-histogram', '--histogram', action='store_true', help="Create Histogram")
    parser.add_argument('-encode', '--encode', action='store_true', help="Encode Positions and Pnl")
    parser.add_argument('-noappend', '--noappend', action='store_true', help="when argument provided no copying csv files or appending daily data to csv files")
    parser.add_argument('-nodateshift', '--nodateshift', action='store_true', help="when argument provided no date shift done to get prices")
    parser.add_argument('-backtestAlpha', '--backtestAlpha', action='store_true',
                        help="flag when running backtest alpha to get prices from evening data generation")
    parser.add_argument('-prod', '--prod', action='store_true', help="if param provided use prod asset names")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")
    parser.add_argument('-validate', '--validate', action='store_true', help="Validate the preceding alpha generation process")

    args = parser.parse_args()
    print(args)
    startTime = datetime.datetime.now().strftime("%Y%m%d-%H:%M:%S.%f")
    dateForLog = datetime.datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath, 'SimulationStats-' + dateForLog + '.log'), filemode='w',
                        level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    strategy = 'A'


    args.baseOutDir = os.path.abspath(args.baseOutDir)
    if not os.path.exists(args.baseOutDir):
        print("Creating output folder :" + args.baseOutDir)
        os.makedirs(args.baseOutDir)

    fhSummary = open(os.path.join(args.baseOutDir, 'Summary.txt'), 'w')
    fhSummary.write("Args used are: " + str(args) + '\n')

    #1) Read input files with tuples and traverse each path
    #2) invoke create_report ; get back a dataframe; append to dfList
    #3) Get finaldf by adding all columns of dataframes (all columns except index date) in dfList
    colNamesList = ['name','frequency','pname']
    dfAlphas = pd.read_csv(args.alphas,names=colNamesList)

    dfWeights = pd.read_csv(args.weightsFile)



    alphaNameMap ={}
    alphaFullMap = {}
    fhLog = open(os.path.join(args.baseOutDir, 'PnlReport.txt'), 'w')
    dfPnl=pd.DataFrame()
    #fhPos = open(os.path.join(args.baseOutDir,"poscheck.txt"), 'w')
    fhErrors = open(os.path.join(args.baseOutDir, "Errors.txt"), 'w')

    assetKeyList = GetAssetKeyList(dfAlphas)

    if not args.noappend:
        #Take a copy of all output files into args.baseOutDir/temp
        CopyOutputFiles(dfAlphas, args.baseOutDir)

    if args.dfInput:
        prices = pd.read_csv(args.pdf,index_col='D')
        #prices = prices.fillna(0).drop_duplicates(subset ="D")
        prices = prices[~prices.index.duplicated(keep='last')]
    else:
        prices = get_prices(args.backtestAlpha)

    for index, row in dfAlphas.iterrows():
        dfList = []
        if row['name'] in StrategyBMap:
            strategy = 'B'
            paramDir = os.path.join(args.baseDirB, row['name'], row['frequency'], row['pname'])
            paramDir = paramDir.strip()
            print("Traversing :", paramDir)
            legs = StrategyBMap[row['name']]
            dfSimulationStatsLeg1 = create_reportB(paramDir, args.endDate, args.startDate, dfWeights, legs[0],args.baseOutDir,prices,fhErrors,args.tcFactorB, args.activityReductionB, args.varFactorB,args.nodateshift)
            dfSimulationStatsLeg2 = create_reportB(paramDir, args.endDate, args.startDate, dfWeights, legs[1],args.baseOutDir,prices,fhErrors,args.tcFactorB, args.activityReductionB, args.varFactorB,args.nodateshift)

            # Slice and append business days
            asset0 = legs[0].split('_')[1][:-2]
            asset1 = legs[1].split('_')[1][:-2]

            # multiply pnl by factorA
            if len(dfSimulationStatsLeg1) > 0:
                if args.sliceFactor != 0:
                    dfSimulationStatsLeg1 = appendBusinessDaysToDF(dfSimulationStatsLeg1, args.sliceFactor, args.sliceDate, prices, asset0)

                dfSimulationStatsLeg1['Pnl'] = dfSimulationStatsLeg1['Pnl'] * args.factorB
                print("PNL for ", row['name'], "_", row['frequency'], "_", row['pname'], "_", legs[0], ":",
                      dfSimulationStatsLeg1['Pnl'].sum())
                fhLog.write(
                    "PNL for " + row['name'] + "_" + row['frequency'] + "_" + row['pname'] + "_" + legs[0] + ":" + str(
                        dfSimulationStatsLeg1['Pnl'].sum()) + "\n")
                dfPnl = dfPnl.append(
                    {'Alpha': row['name'] + "_" + row['frequency'] + "_" + row['pname'] + "_" + legs[0],
                     'Pnl': dfSimulationStatsLeg1['Pnl'].sum()}, ignore_index=True)

            if len(dfSimulationStatsLeg2) > 0:
                if args.sliceFactor != 0:
                    dfSimulationStatsLeg2 = appendBusinessDaysToDF(dfSimulationStatsLeg2, args.sliceFactor, args.sliceDate, prices, asset1)

                dfSimulationStatsLeg2['Pnl'] = dfSimulationStatsLeg2['Pnl'] * args.factorB
                print("PNL for ", row['name'], "_", row['frequency'], "_", row['pname'], "_", legs[1], ":",
                      dfSimulationStatsLeg2['Pnl'].sum())
                fhLog.write(
                    "PNL for " + row['name'] + "_" + row['frequency'] + "_" + row['pname'] + "_" + legs[1] + ":" + str(
                        dfSimulationStatsLeg2[
                            'Pnl'].sum()) + "\n")
                dfPnl = dfPnl.append(
                    {'Alpha': row['name'] + "_" + row['frequency'] + "_" + row['pname'] + "_" + legs[1],
                     'Pnl': dfSimulationStatsLeg2['Pnl'].sum()}, ignore_index=True)
        else:
            strategy = 'A'
            paramDir = os.path.join(args.baseDir, row['name'], row['frequency'], row['pname'])
            paramDir = paramDir.strip()
            if (args.prod and row['name'] in prodShortNamesMap.keys()):
                prodAssetName = prodShortNamesMap[row['name']]
                paramDir = os.path.join(args.baseDir, prodAssetName, row['frequency'], row['pname'])

            print("Traversing :", paramDir)
            if args.validate:
                # check for existance dates
                numdirs = [a for a in os.listdir(paramDir) if os.path.isdir(os.path.join(paramDir, a))]
                if len(numdirs) == 0:
                    print(paramDir)
                continue
            dfSimulationStats = create_report(paramDir, args.endDate, args.startDate, dfWeights, args.baseOutDir,prices,fhErrors,args.binsize,args.unrealizedpnl,args.histogram, args.prod, args.tcFactorA, args.activityReductionA,args.varFactorA,args.nodateshift)

            if len(dfSimulationStats) > 0:
                # Slice and append business days
                if args.sliceFactor != 0:
                    dfSimulationStats = appendBusinessDaysToDF(dfSimulationStats, args.sliceFactor, args.sliceDate,prices, row['name'])

                # multiply pnl by factorA. pnl is point val * multiplier * weight
                dfSimulationStats['Pnl'] = dfSimulationStats['Pnl'] * args.factorA

                print("PNL for ",row['name'],"_",row['frequency'],"_", row['pname'] ,":", dfSimulationStats['Pnl'].sum())
                fhLog.write("PNL for "+ row['name']+ row['frequency']+ row['pname'] + ":" + str(dfSimulationStats['Pnl'].sum()) + "\n")
                dfPnl = dfPnl.append(
                    {'Alpha': row['name'] + "_" + row['frequency'] + "_" + row['pname'],
                     'Pnl': dfSimulationStats['Pnl'].sum()}, ignore_index=True)

        if strategy == 'A' :
            WtAlphafile = 'Weighted_' + row['name'] + '_' + row['frequency'] + '_' + row['pname']

            if len(dfSimulationStats) > 0:
                #dfSimulationStats.to_csv(os.path.join(args.baseOutDir, 'Weighted_' + row['name'] + '_'+ row['frequency'] + '.txt'), index=True)
                alphaNameMap = updateAlphaMap(row['name'],alphaNameMap,dfSimulationStats)

                dfSimulationStats.to_csv(os.path.join(args.baseOutDir, WtAlphafile + '.txt'), columns=dailySimCols, index=True,index_label= 'Date', sep=' ')

                dfSimStatsFiltered = dfSimulationStats.filter(portfolioSimCols, axis=1)
                #dfList.append(dfSimulationStats)
                dfList.append(dfSimStatsFiltered)
            #dfSimulationStats.to_csv(os.path.join(args.baseOutDir, WtAlphafile + '.txt'),
                                     # sep=' ',na_rep=' ')
        else:
            asset0 = legs[0].split('_')[1][:-2]
            asset1 = legs[1].split('_')[1][:-2]

            #WtAlphafile0 = 'Weighted_' + row['name'] + '_' + legs[0] + '_' + row['frequency'] + '_' + row['pname']
            #WtAlphafile1 = 'Weighted_' + row['name'] + '_' + legs[1] + '_' + row['frequency'] + '_' + row['pname']
            WtAlphafile0 = 'Weighted_' + row['name'] + '_' + asset0 + '_' + row['frequency'] + '_' + row['pname']
            WtAlphafile1 = 'Weighted_' + row['name'] + '_' + asset1 + '_' + row['frequency'] + '_' + row['pname']

            if len(dfSimulationStatsLeg1) > 0:

                alphaNameMap = updateAlphaMap(asset0, alphaNameMap, dfSimulationStatsLeg1)
                dfSimulationStatsLeg1.to_csv(os.path.join(args.baseOutDir, WtAlphafile0 + '.txt'), columns=dailySimCols,
                                             index=True, index_label='Date', sep=' ')
                dfSimStatsL1Filtered = dfSimulationStatsLeg1.filter(portfolioSimCols, axis=1)
                dfList.append(dfSimStatsL1Filtered)

            if len(dfSimulationStatsLeg2) > 0:

                alphaNameMap = updateAlphaMap(asset1, alphaNameMap, dfSimulationStatsLeg2)
                dfSimulationStatsLeg2.to_csv(os.path.join(args.baseOutDir, WtAlphafile1 + '.txt'), columns=dailySimCols,
                                             index=True, index_label='Date', sep=' ')
                dfSimStatsL2Filtered = dfSimulationStatsLeg2.filter(portfolioSimCols, axis=1)
                dfList.append(dfSimStatsL2Filtered)
                #alphaNameMap = updateAlphaMap(legs[0], alphaNameMap, dfSimulationStatsLeg1)
                #alphaNameMap = updateAlphaMap(legs[1], alphaNameMap, dfSimulationStatsLeg2)

                #dfList.append(dfSimulationStatsLeg1)
                #dfList.append(dfSimulationStatsLeg2)



        akey = row['name'] + "_" + row['frequency'] + "_" + row['pname']
        akey=akey.strip()
        if len(dfList) > 0:
            updateAlphaFullMap(akey, alphaFullMap, dfList)

    #alphaMap1 = printAlphaNameMap(alphaNameMap)
    #alphaMap1.to_csv(os.path.join(args.baseOutDir, 'AlphaMap1.csv'), index=True)
    #Encoding may result in non integer value in the master df
    if args.encode:
        doEncoding(alphaNameMap)
    roundOffVals(alphaNameMap)
    #alphaMap2 =printAlphaNameMap(alphaNameMap)
    #alphaMap2.to_csv(os.path.join(args.baseOutDir, 'AlphaMap2.csv'), index=True)

    #use alphaNameMap to create a dataframe with Net column for each asset
	
	# Nov 7, 2018: 2 additional steps needed here
	#(1)Verify that the columns PnL, long, short and book size in PotfolioExposureReport.csv below  are summation of the corresponding fields in asset reports
	#(2) Allow masteropenpositions columns to be multiplied based on EncodePositions
	#(3) Allow PnL column in  asset level report to be multiplied based on EncodePnL
    #(4) Allow BookSize, Long, Short, TradingValue  to be multiplied based on EncodePositions
    if len(alphaNameMap) > 0:
        MasterOpenPositionDF =createMasterOpenPosition(alphaNameMap,args.baseOutDir)
        #Banku: this should match the format in MasterOpenPositionCount in ~/MLData/Backtests/Portfolios/PortfolioSim/AB/out
        MasterOpenPositionDF.to_csv(os.path.join(args.baseOutDir, 'MasterOpenPositionDF.csv'), index=True,index_label='t')

        createAssetReports(alphaNameMap,args.baseOutDir)
        #dataframes added for all alphas in alphas.txt
        #finaldf = dfList[0] + dfList[1]
        createPortfolioExposureReport(alphaNameMap,args.baseOutDir)
        #finaldf = reduce(lambda x, y: x.add(y, fill_value=0), dfList)

        MasterClosePositionDF = createMasterClosePosition(alphaNameMap)
        MasterClosePositionDF.to_csv(os.path.join(args.baseOutDir, 'MasterClosePositionDF.csv'), index=True,index_label='Date')
        getPnlSumForVar(args.baseOutDir)

    if len(alphaFullMap) > 0:
        createAlphaExposureReport(alphaFullMap, args.baseOutDir)
        logging.debug("Finished createAlphaExposureReport")
    else:
        print("AlphaFullMap empty")
        logging.debug("AlphaFullMap empty")

    if not args.prod:
        CreateRankingReport(alphaFullMap, args.baseOutDir, args.baseDir, args.baseDirB, args.startDate, args.endDate)

    if len(dfPnl) > 0:
        pnlSum = dfPnl['Pnl'].sum()
        dfPnl = dfPnl.append(
            {'Alpha': "Total",
             'Pnl': pnlSum}, ignore_index=True)

        dfPnl.to_csv(os.path.join(args.baseOutDir, 'PnlReport.csv'), index=False)

    #print(finaldf.head())
    if not args.noappend:
        AppendFiles(dfAlphas, args.baseOutDir)
    #finaldf.to_csv(os.path.join(args.baseOutDir, 'PortfolioExposure.csv'),index=True)
    print("Sim Execution completed. Output Dir is ",args.baseOutDir)
    endTime = datetime.datetime.now().strftime("%Y%m%d-%H:%M:%S.%f")

    fhErrors.close()

    print("Start time: ", startTime)
    print("End time: ", endTime)

if __name__ == '__main__':
     main()