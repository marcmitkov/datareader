#!/bin/bash 
DIRROOTA=/big/svc_wqln/ML/Backtests
VERSION=V3
#FR=20190306
#TO=20190306

FR=20190201
TO=20190228

FR=20190417
TO=20190417

echo AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
/home/lanarayan/MyProjects/ML/GraphSimTemp.bash -v V3 -e A -t ${TO} -f ${FR}
echo BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
/home/lanarayan/MyProjects/ML/GraphSimTemp.bash -v V3 -e B -t ${TO} -f ${FR}

echo ABABABABAB
/home/lanarayan/MyProjects/ML/GraphSimTemp.bash -v V3 -e AB -t ${TO} -f ${FR}


echo tail ${DIRROOTA}/OutSim/Fit-A-2019/${VERSION}/PortfolioExposure.csv
tail ${DIRROOTA}/OutSim/Fit-A-2019/${VERSION}/PortfolioExposure.csv
echo tail ${DIRROOTA}/OutSim/Fit-B-2019/${VERSION}/PortfolioExposure.csv
tail ${DIRROOTA}/OutSim/Fit-B-2019/${VERSION}/PortfolioExposure.csv
echo tail ${DIRROOTA}/OutSim/Fit-AB-2019/${VERSION}/PortfolioExposure.csv
tail ${DIRROOTA}/OutSim/Fit-AB-2019/${VERSION}/PortfolioExposure.csv