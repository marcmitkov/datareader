#!/big/svc_wqln/projects/python/conda/bin/python3.6
# Synopsis: datafile is snipped from ~/MLData/<FX,Futures>/Live/<asset>/<frequency>_resample.csv created at 7am UCT (3am EST)
# script is designed to be run for past simdate dates only, i.e. if simdate is Oct 1, 2019, should be run no earlier than
# Oct 2nd 7 am UCT (3am EST)
# Special case: if simdate is Oct 1, 2019, and need to run on Oct 1, 2019 evening AFTER the evening run, then use
# dataDir = ~/MLData/SimDaily/FX,Futures/Live/<asset>/<frequency>_resample.csv

# Notes: Prerequisite: args.baseDirA/args.asset/args.frequency/'params'-args.params already exists with required params,
# config and datafile.Config will after copying to new dir #3 will be updated to new location for
# datafile
# In new test dir structure all inputs ie config,params,datafile are in args.inputDir/args.version/"InputsA/B"
# and all outputs ie. positions are in args.inputDir/args.version/"OutputsA/B"
# bugfix:  inputDir and outputDir NEED to be the same since output of positions from previous day is input to next day
# -z  and <End> tag  in params needs  to be same to match with backtest

# 1. args.baseDirA/args.asset/args.frequency/'params'-args.params is the source location from where
# params.xml, config.xml  will be copied from to the destination #3
# 2. args.baseDirA/args.asset/args.frequency/<datafile> is the source location from where
# <datafile.csv> will be copied from to the destination #3
# 3. -inputDir: (args.inputDir/args.version/"InputsA" is  new dir where params.xml, config.xml and
# datafile will be copied
# -inputDir: (args.inputDir/args.version/"OutputsA" is  new dir where positions file structure will be created
# -version: version num e.g V1 will be added to inputDir to create new dir structure for input/output
# -nocopy: if param provided run test Sim only, no copying of parms.xml, config.xml and datafile done from baseDirA
# -norun: if param provided  do not run test Sim; only copying of params.xml, config.xml and datafile done)
#-exeDir: location of C++ testSimulator exe
# -f : from date to snip copied datafile ; if empty no snipping done
# -t : to date to snip copied datafile; if empty no snipping done
#
# Sample Commands:
# -baseDirA /home/lanarayan/MLData/BacktestsV4/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsV4/Fit-B-2014 -version V1 -inputDir /home/lanarayan/MyTests -norun
# -baseDirA /home/lanarayan/MLData/BacktestsV4/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsV4/Fit-B-2014 -version V1 -inputDir /home/lanarayan/MyTests -norun -copyPos -simDate 20190101
# -baseDirA /home/lanarayan/MLData/BacktestsV4/Fit-A-2019 -baseDirB /home/lanarayan/MLData/BacktestsV4/Fit-B-2014 -version V1 -inputDir /home/lanarayan/MyTests -norun -copyPos -simDate 20190101 -f 20190105 -t 20190120

import logging
import argparse
import os
import shutil
from datetime import datetime,timedelta
import pandas as pd
import xml.etree.ElementTree as et
import numpy as np
from pandas.tseries.offsets import BDay

StrategyBMap ={'Keynes':['CME_TUU7','CME_USU7'], 'Buffet':['CME_ESU7','CME_1YMU7'], 'Smith':['CME_ESU7','CME_NQU7'],
               'Nash':['CME_TYU7','CME_USU7'], 'Friedman':['CME_TUU7','CME_TYU7'], 'Hayek':['CME_FVU7','CME_TYU7'],
               'Marx':['CME_FVU7','CME_USU7'],'Tinbergen':[],'Kondratiev':['CME_CLU7','CME_LCOU7']}


def EditConfigFile(asset,inputDir):
    legs = []
    if asset in StrategyBMap:
        legsArr = StrategyBMap[asset]
        legs.append(legsArr[0].split('_')[1][:-2])
        legs.append(legsArr[1].split('_')[1][:-2])
    else:
        legs.append(asset)

    treeCfg = et.parse(os.path.join(inputDir, "config.xml"))
    rootCfg = treeCfg.getroot()
    for elem in rootCfg.iter('Instrument1'):
        # update File node
        node = elem.find('File')
        if asset in StrategyBMap:
            prodNode = elem.find('Product')
            if prodNode.text == legsArr[0].split('_')[1]:
                node.text = os.path.join(inputDir, legs[0]+ ".csv")
            else:
                node.text = os.path.join(inputDir, legs[1]+ ".csv")

        else:
            node.text = os.path.join(inputDir, legs[0]+ ".csv")
    for elem in rootCfg.iter('Instrument2'):
        # update File node
        node = elem.find('File')
        prodNode = elem.find('Product')
        if prodNode.text == legsArr[1].split('_')[1]:
            node.text = os.path.join(inputDir, legs[1]+ ".csv")
        else:
            node.text = os.path.join(inputDir, legs[0] + ".csv")

    shutil.copyfile(os.path.join(inputDir, 'config.xml'), os.path.join(inputDir, 'configOld.xml'))

    treeCfg.write(os.path.join(inputDir, 'config.xml'))

def EditDataFileForSimDate(asset,inputDir,simDate,wqStartTime, wqEndTime,eveningData):
    if asset in StrategyBMap:
        dataFiles =[]
        legs = StrategyBMap[asset]
        legs0 = legs[0].split('_')[1][0:-2]  # TU
        legs1 = legs[1].split('_')[1][0:-2]  # TY

        dataFiles.append(os.path.join(inputDir, legs0 + ".csv"))
        dataFiles.append(os.path.join(inputDir, legs1 + ".csv"))
        simDateNextDay = pd.to_datetime(simDate) + timedelta(1)
        wqStartTime = " " + wqStartTime
        wqEndTime = " " + wqEndTime
        startDate = simDateNextDay.strftime("%Y%m%d") + wqStartTime
        endDate = simDateNextDay.strftime("%Y%m%d") + wqEndTime
        print("fromDate: ", startDate)
        print("toDate: ", endDate)
        start = pd.to_datetime(startDate)
        startFourDAgo = start - BDay(2)
        startStr = startFourDAgo.strftime("%Y%m%d") + ' 21:00:00'
        start = pd.to_datetime(startStr)
        end = pd.to_datetime(endDate)
        print("Start: ", start, 'End: ', end)
        for dataFile in dataFiles:
            df = pd.read_csv(dataFile)
            dfNew = df[(df.index >= start) & (df.index <= end)]
            # print(dfNew.head())
            dfNew.to_csv(dataFile, index=True)
    else:
        dataFile = os.path.join(inputDir, asset + ".csv")
        print("Backing up ", dataFile, " to ", inputDir)
        logging.debug("Copying {} to {}".format(dataFile, inputDir))
        # shutil.copyfile(dataFile, os.path.join(inputDir, asset +"_bkup.csv"))

        simDateNextDay = pd.to_datetime(simDate) + timedelta(1)
        # bugfix: on Sep 29 from 7:00 am to 1:00 am (essentially snip 100 candles from the min(<Start> tag in params.xml)
        #wqStartTime = ' 01:00:00'
        #wqEndTime = ' 21:00:00'

        wqStartTime = ' ' + wqStartTime
        wqEndTime = ' ' + wqEndTime
        startDate = simDateNextDay.strftime("%Y%m%d") + wqStartTime
        endDate = simDateNextDay.strftime("%Y%m%d") + wqEndTime
        print("fromDate: ", startDate)
        print("toDate: ", endDate)

        df = pd.read_csv(dataFile)
        df['D'] = pd.to_datetime(df.D)
        df = df.set_index('D')
        df.sort_index(inplace=True)

        utcOffset =5
        start = pd.to_datetime(startDate) + timedelta(hours=utcOffset)
        end = pd.to_datetime(endDate) + timedelta(hours=utcOffset)
        print("Start: ", start, 'End: ', end)

        #Nov 12 Rinky 2 differences when running BTA(BacktestAlpha) mode vs Backtest mode (using morning data):
        #BTA mode means running for current date i.e using evening data as source
        #source data is different and header line becomes important for evening data
        if eveningData:
            headerLine=1 #evening data
        else:
            headerLine=0 # morning data

        if asset in StrategyBMap:
            startFourDAgo =start -BDay(2)
            startStr= startFourDAgo.strftime("%Y%m%d") + ' 21:00:00'
            start = pd.to_datetime(startStr)
            dfNew = df[(df.index >= start) & (df.index <= end)]
            # print(dfNew.head())
            dfNew.to_csv(dataFile,index=True)
        else:
            signalCandleIndex=99 +headerLine
            if start in df.index:
                idx = df.index.get_loc(start)
            else:
                idx = np.argmax(df.index > start)
            if idx < signalCandleIndex:
                print("Idx is less than 99/100.Exiting SingleTestSim")
                logging.debug("Idx is less than 99/100.Exiting SingleTestSim")
                exit(1)
            # gets 100 rows before idx
            dfSlice = df.iloc[idx - signalCandleIndex:idx]
            dfNew = df[(df.index >= start) & (df.index <= end)]
            # print(dfNew.head())

            dfConcatenated = pd.concat([dfSlice, dfNew])
            dfConcatenated.sort_index(inplace=True)
            # print(dfConcatenated.head())

            print("Snipped file: ", dataFile)
            dfConcatenated.to_csv(dataFile, index=True)


def EditDataFileForSimDateOld(asset, inputDir, simDate, wqStartTime, wqEndTime):
    dataFile = os.path.join(inputDir, asset + ".csv")
    #print("Backing up ", dataFile, " to ", inputDir)
    #logging.debug("Copying {} to {}".format(dataFile, inputDir))
    # shutil.copyfile(dataFile, os.path.join(inputDir, asset +"_bkup.csv"))

    simDateNextDay = pd.to_datetime(simDate) + timedelta(1)

    # startDate = simDateNextDay.strftime("%Y%m%d") + ' 07:00:00'
    # endDate = simDateNextDay.strftime("%Y%m%d") + ' 19:00:00'

    wqStartTime = " " + wqStartTime
    wqEndTime = " " + wqEndTime
    startDate = simDateNextDay.strftime("%Y%m%d") + wqStartTime
    endDate = simDateNextDay.strftime("%Y%m%d") + wqEndTime
    print("fromDate: ", startDate)
    print("toDate: ", endDate)

    df = pd.read_csv(dataFile)
    df['D'] = pd.to_datetime(df.D)
    df = df.set_index('D')
    df.sort_index(inplace=True)

    start = pd.to_datetime(startDate)
    end = pd.to_datetime(endDate)
    print("Start: ", start, 'End: ', end)

    if asset in StrategyBMap:

        startFourDAgo = start - BDay(2)
        startStr = startFourDAgo.strftime("%Y%m%d") + ' 21:00:00'
        start = pd.to_datetime(startStr)
        dfNew = df[(df.index >= start) & (df.index <= end)]
        # print(dfNew.head())

        dfNew.to_csv(dataFile, index=True)

    else:
        if start in df.index:
            idx = df.index.get_loc(start)
        else:
            idx = np.argmax(df.index > start)

        # gets 100 rows before idx
        dfSlice = df.iloc[idx - 99:idx]
        dfNew = df[(df.index >= start) & (df.index <= end)]
        # print(dfNew.head())

        dfConcatenated = pd.concat([dfSlice, dfNew])
        dfConcatenated.sort_index(inplace=True)
        # print(dfConcatenated.head())

        print("Snipped file: ", dataFile)
        dfConcatenated.to_csv(dataFile, index=True)


def EditDataFile(dataFile,startDate,endDate):
    df = pd.read_csv(dataFile)
    df['D'] = pd.to_datetime(df.D)
    df = df.set_index('D')
    df.sort_index(inplace=True)

    start = pd.to_datetime(startDate)
    end = pd.to_datetime(endDate)
    print("Start: ", start, 'End: ', end)

    dfNew = df[(df.index >= start) & (df.index <= end)]

    dfNew.to_csv(dataFile, index=True)

def main():

    #Note: If asset is StratA arguments with suffixA will be used else args with suffix B will be used
    #params,frequency and exeDir args used in both cases
    #config file copied has to be manually changed
    parser = argparse.ArgumentParser()

    parser.add_argument('-asset', '--asset', default='Smith', help="Smith , 1YM etc")
    parser.add_argument('-params', '--params', default='0', help="param number e.g 0 1 2 ")
    parser.add_argument('-frequency', '--frequency', default='1m', help="1m or 1H or 4H or 15m or 1D")
    parser.add_argument('-dataDir', '--dataDir', default='/home/lanarayan/MLData/Futures/Live', help="source Data dir;Fx for Futures;MLData/SimDaily for evening data")
    parser.add_argument('-baseDirA', '--baseDirA', default='/home/lanarayan/MLData/Backtests/Fit-A-2019', help="Source dir for Strat A")
    parser.add_argument('-baseDirB', '--baseDirB', default='/home/lanarayan/MLData/Backtests/Fit-B-2014', help="Source dir for Strat B")
    parser.add_argument('-version', '--version', default='V1', help="V , V1 etc ")
    parser.add_argument('-inputDir', '--inputDir', default='/home/lanarayan/MyTests', help="StratA: Destination dir for copying config,data files")
    #parser.add_argument('-outputDir', '--outputDir', default='/home/lanarayan/MyTests', help="StratA: Output positions dir for testSimulator")
    parser.add_argument('-nocopy', '--nocopy', action='store_true', help="if param provided run test Sim only, no copying done")
    parser.add_argument('-norun', '--norun', action='store_true', help="if param provided  do not run test Sim; only copying done")
    parser.add_argument('-f', '--startDate', default='', help="start date e.g 20180101. If set edit data file")
    parser.add_argument('-t', '--endDate', default='', help="end date 20190101. If set edit data file")
    parser.add_argument('-exeDir', '--exeDir', default='/home/lanarayan/MLData/UATDev/TestSimulatorWIP/build', help="TestSimulator exe")
    parser.add_argument('-copyPos', '--copyPos', action='store_true', help="if param provided copy openpositions.txt from folder date copyPosDate")
    parser.add_argument('-copyPosDate', '--copyPosDate', default='', help="e.g 20190801. Date used to create dir path to get openpositions.txt for coping ")
    parser.add_argument('-simDate', '--simDate', default='', help="e.g 20190101 used with copyPos True option")
    # WQ live trading window expansion:  update this to sync with actual start time of trading
    parser.add_argument('-wqStart', '--wqStartTime', default='02:00:00', help="HH:MM:SS format in EST")
    parser.add_argument('-wqEnd', '--wqEndTime', default='17:00:00', help="HH:MM:SS format in EST")
    parser.add_argument('-eveningData', '--eveningData', action='store_true', help="if param provided evening data path assumed for "
                                                                                   "datadir. headerLine used based on this in EditDatFileforSimDate function")

    parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")

    #parser.add_argument('-log', '--logPath', default='C:/MyProjects/PyCharmProjects/HelloWorldProj',
    #                                   help="log file  path")
    parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                        help="log file  path")


    args = parser.parse_args()
    print(args)

    currencyList = ["EURUSD", "AUDUSD", "GBPUSD", "EURGBP", "EURJPY", "USDCAD", "USDCHF", "USDJPY"]

    dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")
    logging.basicConfig(filename=os.path.join(args.logPath, 'SingleTestSim-' + dateForLog + '.log'),
                        filemode='w', level=getattr(logging, args.logLevel),
                        format='%(asctime)s %(levelname)s %(message)s')

    assetDir = args.asset + '_' + args.frequency + '_' + 'params-' + args.params

    if args.asset in StrategyBMap:
        inputSimDir = os.path.join(args.inputDir,args.version,assetDir,"InputsB")
        #outputSimDir = os.path.join(args.inputDir,args.version,assetDir,"OutputsB")
    else:
        inputSimDir = os.path.join(args.inputDir, args.version, assetDir,"InputsA")
        #outputSimDir = os.path.join(args.inputDir, args.version,assetDir, "OutputsA")

    logging.debug("Strting SingleTestSim  with norun={} and nocopy={}".format(args.norun, args.nocopy))
    print("Starting SingleTestSim  with norun=", args.norun, " and nocopy=", args.nocopy)
    if not args.nocopy:
        if not os.path.exists(inputSimDir):
            print("Creating input folder :" + inputSimDir)
            os.makedirs(inputSimDir)
        '''if not os.path.exists(outputSimDir):
            print("Creating output folder :" + outputSimDir)
            os.makedirs(outputSimDir)'''

        if args.asset in StrategyBMap:
            #path for getting params, config
            path = os.path.join(args.baseDirB, args.asset, args.frequency)
            param = "params-" + args.params # param name
            paramsFile = os.path.join(path, param, "params.xml")
            configFile = os.path.join(path, param, "config.xml")

            #path for getting data files
            legs = StrategyBMap[args.asset]
            legs0 = legs[0].split('_')[1][0:-2]  # TU
            legs1 = legs[1].split('_')[1][0:-2]  # TY
            dataPath = os.path.join(args.dataDir, legs0 + legs1 )
            dataFile1 = os.path.join(dataPath,legs0 +".csv")
            dataFile2 = os.path.join(dataPath,legs1 +".csv")


            #Copy params,config and data files
            print("Copying ", paramsFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(paramsFile,inputSimDir))
            shutil.copy(paramsFile,inputSimDir)

            print("Copying ", configFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(configFile,inputSimDir))
            shutil.copy(configFile, inputSimDir)

            print("Copying ", dataFile1, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(dataFile1,inputSimDir))
            shutil.copy(dataFile1,inputSimDir)

            print("Copying ", dataFile2, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(dataFile2,inputSimDir))
            shutil.copy(dataFile2,inputSimDir)

            if args.startDate != '' and args.endDate != '':
                # Edit leg0 data file
                copiedDataFile = os.path.join(inputSimDir, legs0 + ".csv")
                print("Start date and end date provided. Start: ", args.startDate, " End: ",args.endDate, " Editing data file: ",copiedDataFile)
                logging.debug("Start date and end date provided. Start: {} End: {}. Editing data file: {}. ".format(args.startDate,args.endDate,copiedDataFile))
                EditDataFile(copiedDataFile,args.startDate,args.endDate)
                # Edit leg1 data file
                # copiedDataFile = os.path.join(inputSimDir, legs1 + ".csv")
                print("Start date and end date provided. Start: ", args.startDate, " End: ", args.endDate,
                      " Editing data file: ", copiedDataFile)
                logging.debug("Start date and end date provided. Start: {} End: {}. Editing data file: {}. ".format(
                    args.startDate, args.endDate, copiedDataFile))
                EditDataFile(copiedDataFile, args.startDate, args.endDate)
            else:
                print("Editing data file for simdate. ")
                logging.debug("Editing data file for simdate. ")

                EditDataFileForSimDate(args.asset,inputSimDir, args.simDate, args.wqStartTime, args.wqEndTime,args.eveningData)

            EditConfigFile(args.asset, inputSimDir)

        else:
            # path for getting params, config files
            path = os.path.join(args.baseDirA, args.asset, args.frequency)
            # path for getting datafiles
            # e.g ~/MLData/Futures/Live/NQ or ~/MLData/SimDaily/Futures/Live/NQ (For FX, replace Futures by FX in path)
            dataPath = os.path.join(args.dataDir, args.asset)
            param = "params-" + args.params

            paramsFile = os.path.join(path, param, "params.xml")
            configFile = os.path.join(path, param, "config.xml")
            dataFile = os.path.join(dataPath,args.frequency + '_resample.csv')

            # Copy params,config and data file
            print("Copying ", paramsFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(paramsFile,inputSimDir))
            shutil.copy(paramsFile, inputSimDir)

            print("Copying ", configFile, " to ", inputSimDir)
            logging.debug("Copying {} to {}".format(configFile,inputSimDir))
            shutil.copy(configFile, inputSimDir)

            print("Copying ", dataFile, " to ", inputSimDir, " as ", args.asset + ".csv")
            logging.debug("Copying {} to {} as {}.csv".format(dataFile,inputSimDir, args.asset))
            shutil.copy(dataFile, os.path.join(inputSimDir,args.asset + ".csv"))

            if args.startDate != '' and args.endDate != '':
                # datafile to be modified is now in inputSimDir
                copiedDataFile = os.path.join(inputSimDir, args.asset + ".csv")
                print("Start date and end date provided. Start: ", args.startDate, " End: ",args.endDate, " Editing data file. ")
                logging.debug("Start date and end date provided. Start: {} End: {}. Editing data file. ".format(args.startDate,args.endDate))
                EditDataFile(copiedDataFile,args.startDate,args.endDate)
            else:
                print("Editing data file for simdate. ")
                logging.debug("Editing data file for simdate. ")

                EditDataFileForSimDate(args.asset,inputSimDir, args.simDate, args.wqStartTime, args.wqEndTime,args.eveningData)

            EditConfigFile(args.asset, inputSimDir)

    if args.copyPos:
        #simDate = args.simDate
        print("Copying Positions")
        posPath = os.path.join(args.baseDirA, args.asset, args.frequency, "params-" + args.params)
        exchange ='CME_'
        suffix = 'U7'
        asset = args.asset

        if asset in currencyList:
            exchange = 'FXOTC_'
            suffix = ''
            asset = args.asset[0:3] + '_' + args.asset[3:]

        #openPosFilePath = os.path.join(posPath, simDate, 'Momentum', exchange + asset + suffix, 'openpositions.txt')
        #simFolder = os.path.join(inputSimDir, simDate, 'Momentum', exchange + asset + suffix)
        openPosFilePath = os.path.join(posPath, args.copyPosDate, 'Momentum', exchange + asset + suffix, 'openpositions.txt')
        simFolder = os.path.join(inputSimDir, args.copyPosDate, 'Momentum', exchange + asset + suffix)
        if not os.path.exists(simFolder):
            print("Creating  folder :" + simFolder)
            os.makedirs(simFolder)

        print("Copying ", openPosFilePath, " to ",simFolder)
        logging.debug("Copying {} to {}".format(openPosFilePath,  simFolder))
        shutil.copy(openPosFilePath, simFolder)

        standPosFilePath = os.path.join(posPath, args.copyPosDate, 'Momentum', exchange + asset + suffix,
                                       'standingpositions.txt')
        print("Copying ", standPosFilePath, " to ", simFolder)
        logging.debug("Copying {} to {}".format(standPosFilePath, simFolder))
        shutil.copy(standPosFilePath, simFolder)

    #-z is in EST
    # US stock market NYSE closes at 4 PM EST
    # CME restarts at 6 PM EST
    # 4:45 PM EST is AFTER close of NYSE and 3:45 PM CST which is near close of CME session at 4PM CST
    if args.copyPos:
        #cmd = " -r " + inputSimDir + " -o " + outputSimDir + " -d " + args.simDate + " -z 16.75 -g"
        cmd = " -r " + inputSimDir + " -o " + inputSimDir + " -d " + args.simDate + " -z 16.75 -g"
    else:
        #cmd = " -r " + inputSimDir + " -o " + outputSimDir + " -z 16.75 -g"
        cmd = " -r " + inputSimDir + " -o " + inputSimDir + " -z 16.75 -g"

    exePath = os.path.join(args.exeDir, "TestSimulator")

    if not args.norun:
        print("Executing " + exePath + cmd)
        logging.debug("Executing {}".format(exePath + cmd))
        os.system(exePath + cmd)
    else:
        print("args.norun is ", args.norun, " .NOT executing " + exePath + cmd)
        logging.debug("args.norun is {}. NOT Executing {}".format(args.norun,exePath + cmd))


    print("SingleTestSim done with norun=",args.norun, " and nocopy=",args.nocopy)
    logging.debug("SingleTestSim done with norun={} and nocopy={}".format(args.norun,args.nocopy))



if __name__ == '__main__':
     main()