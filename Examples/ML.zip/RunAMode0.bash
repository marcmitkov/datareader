#!/bin/bash 
export PROMPT_COMMAND="echo - ne '1033]O; Runs Prod A SHOSTNAME $PWD\007". 
echo "you have provide $# argument" 
echo "arguments are $@" 
echo "usage: RunStratA.bash -e all|risk|pos|test -f|from 20190101 -t|to 20190202 -h|--hold 2,3,4,5"
echo "usage: RunStratA.bash -e all|risk|pos|test -f 20190101 -t 20190202 -h 2,3,4,5" 

function Test {
echo cp ${SCRIPTDIR}/Configs/config-${INS}-${TIME}.xml config.xml

}

function RunAll {
  echo BASE is ${BASE}
[ -d ${BASE} ] || echo mkdir -p ${BASE} 
[ -d ${BASE} ] || mkdir -p ${BASE}
    echo cp ${SCRIPTDIR}/Configs/config-${INS}-${TIME}.xml ${BASE}/config.xml 
        cp ${SCRIPTDIR}/Configs/config-${INS}-${TIME}.xml ${BASE}/config.xml 
        echo cp ${SCRIPTDIR}/params.xml ${BASE}/params.xml
        cp ${SCRIPTDIR}/params.xml ${BASE}/params.xml
        if [ $? -eq 0 ]; then
                echo ${SCRIPTDIR}/CombinatorV3.py -r ${ROOT}/${RUN}/$INS/$TIME/ -baseDir ${BASE} -Rhoa 6 -HoldingPeriod ${HOLD} -MinLengthA 100 -CushionA ${CUSHION} -ModeA ${MODE} -OpenPassive ${OPENPASSIVE} -ClosePassive ${CLOSEPASSIVE} -ClearHistoryA 0
                echo ${SCRIPTDIR}/CombinatorV3.py -r ${ROOT}/${RUN}/$INS/$TIME/ -baseDir ${BASE} -RhoA 6 -HoldingPeriod ${HOLD} -MinLengthA 100 -CushionA ${CUSHION} -ModeA ${MODE} -OpenPassive ${OPENPASSIVE} -ClosePassive ${CLOSEPASSIVE} -ClearHistoryA 0 >> ${LOGFILE} 
                 ${SCRIPTDIR}/CombinatorV3.py -r ${ROOT}/${RUN}/$INS/$TIME/ -baseDir ${BASE} -RhoA 6 -HoldingPeriod ${HOLD} -MinLengthA 100 -CushionA ${CUSHION} -ModeA ${MODE} -OpenPassive ${OPENPASSIVE} -ClosePassive ${CLOSEPASSIVE} -ClearHistoryA 0 
                echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${INS}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinciFinal/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} ${IGNORE} 
                echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${INS}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinciFinal/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} ${IGNORE} >> ${LOGFILE}
                ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN}  -alpha ${ROOT}/${RUN}/${INS}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinciFinal/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} ${IGNORE}

                
        else
                echo FAIL $INS
        fi
}

function RunRisk {
        echo ${SCRIPTDIR}/RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/$INS/$TIME -baseOut ${ROOT}/${RUN}/$INS/$TIME -s A -c $INS -suffix $TIME $RISKPARAMS -ptable >> ${LOGFILE} 
        echo ${SCRIPTDIR}/RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/$INS/$TIME -baseOut ${ROOT}/${RUN}/$INS/$TIME -s A -c $INS -suffix $TIME $RISKPARAMS -ptable 
        ${SCRIPTDIR}/RiskReport.py -f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/$INS/$TIME -baseOut ${ROOT}/${RUN}/$INS/$TIME -s A -c $INS -suffix $TIME $RISKPARAMS -ptable
        if [ $? -eq 0 ]; 
        then
                echo PASS ${INS}-${TIME}
        else 
                echo FAIL ${INS}-${TIME}
        fi
        }
        
function RunPos {
        #INS1=${INS: 0:3}_${INS:3:3}
        echo ${SCRIPTDIR}/PosReport.py - f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/$INS/$TIME -output ${ROOT}/${RUN}/$INS/$TIME -groupBy Strategy -s ${EXCHANGE}_${INS1} -v True echo 
        echo ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/$INS/$TIME -output ${ROOT}/${RUN}/$INS/$TIME -groupBy Strategy -s ${EXCHANGE}_${INS1} -v True >> ${LOGFILE} 
        ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN}/$INS/$TIME -output ${ROOT}/${RUN}/$INS/$TIME -groupBy Strategy -s ${EXCHANGE}_${INS1} -v True
        if [ $? -eq 0 ]; then
                echo PASS ${INS}-${TIME} 
        else
                echo FAIL ${INS}-${TIME}
        fi
        }
        
function TestRunAll {
        echo cp ${SCRIPTDIR}/Configs/config-${INS}-${TIME}.xml config.xml 
        if [ $? -eq 0 ]; 
        then
                echo ${SCRIPTDIR}/CombinatorV3.py -r ${ROOT}/${RUN}/$INS/$TIME/ -baseDir ./ -RhoA 6 -HoldingPeriod ${HOLD} -MinLengthA 100 -CushionA ${CUSHION} -ModeA 0 -OpenPassive 0 -ClosePassive 1 -ClearHistoryA 0 
                echo ${SCRIPTDIR}/RunAlphaList.py -paramsDir ${ROOT}/${RUN} -alpha ${ROOT}/${RUN}/${INS}/${TIME}/alphas.txt -ex /home/lanarayan/MLData/UATDev/DaVinciNew/build -baseDataDir /home/lanarayan/MLData -s ${FROM} -e ${TO} ${IGNORE}
                echo ${SCRIPTDIR}/RiskReport.py - f ${FROM} -t ${TO} -p ${ROOT}/${RUN}/$INS/$TIME -baseOut ${ROOT}/${RUN}/$INS/$TIME -s A -c $INS -suffix $TIME -ptable 
                echo ${SCRIPTDIR}/PosReport.py -f ${FROM} -t ${TO} -baseDir ${ROOT}/${RUN} /$INS/$TIME -output ${ROOT}/${RUN}/$INS/$TIME -groupBy Strategy -s ${EXCHANGE}_${INS1} -v True
        else
                echo FAIL $INS
        fi
        }
        
startScript=$(date -u) 
SCRIPTDIR='/home/lanarayan/MyProjects/ML'
#for i in ES NQ 1YM AUDUSD EURGBP EURUSD GBPUSD USDCAD USDCHF EURJPY USDJPY CL
#for j in 1D 4H 1H 15m 
ROOT='/big/svc_wqln/ML/BacktestsMode0' 
echo ROOT is $ROOT
[ -d ${ROOT} ] || echo mkdir -p ${ROOT} 
[ -d ${ROOT} ] || mkdir -p ${ROOT}
LOGROOT='/big/svc_wqln/ML/Backtests'
RISKPARAMS='-param 0' #e.g -param 0
#for arg in "$@"
#       do
#               if [ "$arg" == "--help" ] || [ "$arg" == "-h" ] 
#               then
#                       echo "-t ROOT set to /big/svc_wqln/ML/Othertests"
#               fi
#               if [ "$arg" == "--test" ] || [ "$arg" == "-t" ] 
#               then
#                       ROOT='/big/svc_wqln/ML/Othertests' 
#                       echo "ROOT set to $ROOT"
#               fi
#       done 
        
LOGDIR=${LOGROOT}/Logs
LOGFILE=${LOGDIR}/RunAMode0-$(date '+%d%m%Y-%H:%M:%S').txt; 
echo LOGFILE is $LOGFILE
[ -d ${LOGDIR} ] || echo mkdir -p ${LOGDIR} 
[ -d ${LOGDIR} ] || mkdir -p ${LOGDIR}

RUN="Fit-A-2019" 
#FROM="20190109" 
#FROM="20180824" 
#TO="20190124" 
FROM="20190129" 
TO="20190201"
EXCHANGE="FXOTC" 
#use only 2 for 15 minutes 
#HOLD=2,3,4,5
HOLD=2
SNIP="-snip" 
#Start
while [[ $# -gt 0 ]]
do
key="$1"
echo "Key is $key"
echo "Value is $2"
case $key in
    -f|--from)
    FROM="$2"
    shift # past argument
    shift # past value
    ;;
    -t|--to)
    TO="$2"
    shift # past argument
    shift # past value
    ;;
    -h|--hold)
    HOLD="$2"
    shift # past argument
    shift # past value
    ;;
        -e|--execute)
        lowerCaseArg="${2,,}"
    EXECUTE=${lowerCaseArg}
    shift # past argument
    shift # past value
    ;;
        -b|--basedir)
    EXECUTE="$2"
    shift # past argument
    shift # past value
    ;;   
    *)    # unknown option
    echo "unknown Argument $1"
        echo "usage: RunStratA.bash -e all|risk|pos|test -f|from 20190101 -t|to 20190202 -h|--hold 2,3,4,5"
        echo "usage: RunStratA.bash -e all|risk|pos|test -f 20190101 -t 20190202 -h 2,3,4,5"
   
    ;;
esac
done

echo ROOT = ${ROOT}
echo RUN = ${RUN}
echo FROM  = "${FROM}"
echo TO    = "${TO}"
echo HOLD     = "${HOLD}"
echo EXECUTE         = "${EXECUTE}"
#end

BASE=${ROOT}/${RUN}
echo Base is ${BASE}
echo SCRIPTDIR is $SCRIPTDIR
CLOSEPASSIVE=1
OPENPASSIVE=1

#for i in ES TY US AUL TN NQ 1YM CL LCO EURJPY USDJPY

#for i in FV TU US ES NQ 1YM CL LCO TY EURGBP EURUSD GBPUSD USDCAD EURJPY USDJPY USDCHF AUDUSD TN AUL GC URO JY
for i in EURJPY USDJPY EURGBP EURUSD GBPUSD USDCAD USDCHF AUDUSD URO JY
do
        #for j in 15m 1D 4H 1H 
        for j in 1H
        #for j in 15m
        do
                INS=$i 
                TIME=$j
                if [ "$j" == "1D" ]; 
                        then
                        IGNORE="-ignore" 
                else
                        IGNORE=""
                fi
                if [ "$j" == "15m" ]; 
                then
                        HOLD=2
                else
                        HOLD=2
                fi
                case $i in
                        ES | NQ | FV| TU |AUL | TN)                               
                                INS1=${INS}U7
                                #CUSHION=2
                                CUSHION=0
                                MODE=0
                                EXCHANGE="CME";; 
                        1YM)
                                INS1=${INS}U7 
                                EXCHANGE="CME"
                                MODE=0
                                CUSHION=20;; 
                                
                        CL|LCO|GC)
                                INS1=${INS}U7 
                                EXCHANGE="CME"
                                MODE=0
                                CUSHION=0.20;; 
                        EURJPY | USDJPY)

                                INS1=${INS:0:3}_${INS:3:3} 
                                EXCHANGE="FXOTC"
                                MODE=0
                                HOLD=2
                                CUSHION=0;;

                        TY | US)
                                INS1=${INS}U7
                                EXCHANGE="CME"
                                MODE=0
                                HOLD=2
                                CUSHION=0;;
                                
                        JY | AD | BP | URO | CD |SF)
                                INS1=${INS}U7
                                EXCHANGE="CME"
                                MODE=0
                                HOLD=2
                                CUSHION=0;;
                        *)
                                INS1=${INS:0:3}_${INS:3:3}
                                EXCHANGE="FXOTC"
                                MODE=0
                                CUSHION=0.0020;; 
                esac 
        #RunOnly 
        #RunRisk 
        #RunPos 
        #TestRunAll
        #RunAll 
        #Myscript
        if [ "$EXECUTE" == "all" ] 
                then
                        echo "Executing RunAll"
                        RunAll
                elif [ "$EXECUTE" == "risk" ]
                then
                        echo "Executing RunRisk"
                        RunRisk
                elif [ "$EXECUTE" == "pos" ]
                then
                        echo "Executing RunPos"
                        RunPos
                elif [ "$EXECUTE" == "test" ]
                then
                        echo "Executing TestRunAll"
                        TestRunAll
                else
                        echo "Executing Default TestRunAll"
                        TestRunAll
        fi
        
        #end My script
        done 
done 
echo 'StartTime:' $startScript
endScript=$(date -u)
echo 'EndTime:'$endScript
exit 0


