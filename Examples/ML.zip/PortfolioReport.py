#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
import numpy as np
import argparse
import Common as co
import webbrowser
import shutil
import os

# Create Portfolio Report using AnnualretSharpe and InceptionReturnSharpe data from WeightedRiskReport

def CreatePortfolioReport(baseDir,baseOutDir):
    counter=0
    p1 = pd.DataFrame()
    p2 = pd.DataFrame()
    p3 = pd.DataFrame()
    inceptionDF = pd.DataFrame()
    for dirpath, dirnames, filenames in os.walk(baseDir):
        for file in filenames:
            if file.startswith('AnnualRetSharpe'):
                counter = counter+1
                dftmp = pd.DataFrame()
                csvPath = os.path.join(dirpath, file)
                dftmp = pd.read_csv(csvPath,index_col='t')
                dftmpReturn = dftmp['ann_return']
                dftmpSharpe = dftmp['ann_sharpe']

                # read InceptionRetSharpe.csv
                dftmpInception = pd.read_csv(os.path.join(dirpath, "InceptionRetSharpe.csv"))
                p1Return = pd.DataFrame({'t': dftmpReturn.index, 'p' + str(counter): dftmpReturn.values})
                p1Sharpe = pd.DataFrame({'t': dftmpSharpe.index, 'p' + str(counter): dftmpSharpe.values})
                '''if counter == 1:
                    p1Return = pd.DataFrame({'t': dftmpReturn.index, 'p' + str(counter): dftmpReturn.values})
                    p1Sharpe = pd.DataFrame({'t': dftmpSharpe.index, 'p' + str(counter): dftmpSharpe.values})
                elif counter == 2:
                    p2Return = pd.DataFrame({'t' : dftmpReturn.index, 'p' + str(counter): dftmpReturn.values})
                    p2Sharpe = pd.DataFrame({'t' : dftmpSharpe.index, 'p' + str(counter): dftmpSharpe.values})
                else:
                    p3Return = pd.DataFrame({'t' : dftmpReturn.index, 'p' + str(counter): dftmpReturn.values})
                    p3Sharpe = pd.DataFrame({'t' : dftmpSharpe.index, 'p' + str(counter): dftmpSharpe.values})'''
                inceptionDF = inceptionDF.append(pd.DataFrame(
                    {'Return': dftmpInception.TotalReturn, 'Sharpe': dftmpInception.SharpeRatio,
                     'portfolio': 'p' + str(counter)}))

    #tmpMergeRet = pd.merge(p1Return, p2Return, right_on='t', left_on='t')
    #dfReturn = pd.merge(tmpMergeRet, p3Return, right_on='t', left_on='t')
    dfReturn = p1Return
    dfReturn['Type'] = 'Return'
    print(dfReturn)

    #tmpMergeSharpe = pd.merge(p1Sharpe, p2Sharpe, right_on='t', left_on='t')
    #dfSharpe = pd.merge(tmpMergeSharpe, p3Sharpe, right_on='t', left_on='t')
    dfSharpe = p1Sharpe
    dfSharpe['Type'] = 'Sharpe'
    print(dfSharpe)

    finalDf = pd.DataFrame()
    finalDf =finalDf.append(dfReturn)
    finalDf =finalDf.append(dfSharpe)
    print(finalDf)

    finalDf.to_csv(os.path.join(baseOutDir, 'PortfolioReport.csv'),index=False)
    inceptionDF.to_csv(os.path.join(baseOutDir, 'PortfolioInceptReport.csv'),index=False)







def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-baseDir', '--baseDir', default='C:/MyProjects/WQMaster/portfolioTestWQ', help="base Directory")

    parser.add_argument('-baseOut', '--baseOutDir', default='C:/MyProjects/WQMaster/posdataTestWQ', help="output Directory")
    #parser.add_argument('-pdir', '--portfolioDir', default='C:/MyProjects/WQMaster/posdataTestWQ/UN', help="output Directory")

    args = parser.parse_args()
    print(args)
    args.baseDir = os.path.abspath(args.baseDir)

    if not os.path.exists(args.baseOutDir):
        os.makedirs(args.baseOutDir)

    #CreatePortfolioReport(args.baseDir,args.baseOutDir,args.portfolioDir)
    CreatePortfolioReport(args.baseDir,args.baseOutDir)
    # CreateWeightsFile

if __name__ == '__main__':
    main()