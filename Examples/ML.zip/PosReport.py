#!/big/svc_wqln/projects/python/conda/bin/python3.6
import pandas as pd
# from IPython.display import display
# from IPython.display import Image
import datetime
import argparse
import numpy as np
import glob
# import datetime
import dateutil.relativedelta
from datetime import date, timedelta
from datetime import datetime
import sys
import platform
import os
import webbrowser
import Common as co
import matplotlib.pyplot as plt
import pathlib
import xml.etree.ElementTree as et
import logging

class Contract:
    def __init__(self, n, pp, m):
        self.name = n
        self.pointvalue = pp
        self.margin = m


# positions file has position size denominated in number of contracts
# so for EURUSD, for example,  position size is 1 (by default)  and hence
# implicit notional value is 1000,000 (per unit position), for JPY the equivalent number
# should be  10,000
# for StratB, default positon size is 100, point value for futures is slef explanatory
#changed position size for FX to 1,000,000  through params.xml  July 4 , 2019
contractsTable = {
    'ES': Contract('ES', 50, 6000),
    'NQ': Contract('NQ', 20, 6000),
    'TY': Contract('TY', 1000, 2500),
    'FV': Contract('FV', 1000, 2500),
    'US': Contract('US', 1000, 2500),
    'TU': Contract('TU', 2000, 500),
    '1YM': Contract('1YM', 5, 5000),
    'EURUSD': Contract('EURUSD', 1, 100000),
    'USDJPY': Contract('USDJPY', 0.01, 100000),
# point value 100 as opposed to 10,000 because price quoted in ~/WQData/FX/USDJPY/1m-new.csv 9085.00
    'EURGBP': Contract('EURGBP', 1.3, 130000),
    'EURJPY': Contract('EURJPY', 0.01, 100000),
# point value 100 as opposed to 10,000 because price quoted in ~/WQData/FX/USDJPY/1m-new.csv 9085.00
    'GBPUSD': Contract('GBPUSD', 1, 100000),
    'AUDUSD': Contract('AUDUSD', 1, 100000),
    'USDCHF': Contract('USDCHF', 1, 100000),
    'USDCAD': Contract('USDCAD', 1, 100000),
    'FCE': Contract('FCE', 1000000, 100000),
    'FDX': Contract('FDX', 1000000, 100000),
    'CL': Contract('CL', 1000, 2550),
    'LCO': Contract('LCO', 1000, 2550),
    'TN': Contract('TN', 1000, 2500),
    'AUL': Contract('AUL', 1000, 2500),
    'GC': Contract('GC', 1000, 2500),
    'URO': Contract('URO', 62500, 2500),
    'JY': Contract('JY', 6250000, 2500)    
}

StrategyBList = ["Smith", "Buffet", "Hayek", "Nash", "Friedman", "Keynes", "Marx", "Kondratiev", "Bernanke"]

StrategyBMap = {'Keynes': ['CME_TUU7', 'CME_USU7'], 'Buffet': ['CME_ESU7', 'CME_1YMU7'],
                       'Smith': ['CME_ESU7', 'CME_NQU7'],
                       'Nash': ['CME_TYU7', 'CME_USU7'], 'Friedman': ['CME_TUU7', 'CME_TYU7'],
                       'Hayek': ['CME_FVU7', 'CME_TYU7'],
                       'Marx': ['CME_FVU7', 'CME_USU7'], 'Tinbergen': [], 'Kondratiev': ['CME_CLU7', 'CME_LCOU7'], 'Bernanke': ['CME_TNU7', 'CME_AULU7']}


def GetTickSize(strategy):
    if strategy in ['FXOTC_USD_JPY', 'FXOTC_EUR_JPY']:
        return 1
    elif strategy in ['CME_TYU7', 'CME_FVU7', 'CME_USU7', 'CME_TUU7']:
        return 0.015625
    elif strategy in ['CME_CLU7']:
        return 0.01
    elif strategy in ['CME_ESU7', 'CME_NQU7']:
        return 0.25
    elif strategy in ['CME_1YMU7']:
        return 1
    elif strategy in ['CME_GCU7', 'CME_CLU7', 'CME_LCO_U7']:
        return 0.01
    else:  # all currencies
        return 0.00001


def writeOutliersToFile(maindf, fh):
    msg = ""
    dfOutlier = pd.DataFrame()
    if len(maindf[maindf.PnlRealized < -0.1000]) > 0:
        msg = "Unusually large numbers in realized pnl 1:"
        dfOutlier = maindf[maindf.PnlRealized < -0.1000]
        print(msg)
        print(dfOutlier)
        fh.write('\n' + msg + '\n')
        for row in dfOutlier.itertuples():
            fh.write(str(row) + '\n')
        # print (maindf[maindf.PnlRealized < -0.0009])
    if len(maindf[maindf.PnlRealized > 0.1000]) > 0:
        msg = "Unusually large numbers in realized pnl 2:"
        dfOutlier = (maindf[maindf.PnlRealized > 0.1000])
        print(msg)
        print(dfOutlier)
        fh.write('\n' + msg + '\n')
        for row in dfOutlier.itertuples():
            fh.write(str(row) + '\n')
    if len(maindf[maindf.PnlUnRealized < -0.1000]) > 0:
        msg = "Unusually large numbers in unrealized pnl 1:"
        dfOutlier = (maindf[maindf.PnlUnRealized < -0.1000])
        print(msg)
        print(dfOutlier)
        fh.write('\n' + msg + '\n')
        for row in dfOutlier.itertuples():
            fh.write(str(row) + '\n')
    if len(maindf[maindf.PnlUnRealized > 0.1000]) > 0:
        msg = "Unusually large numbers in unrealized pnl 2:"
        print(msg)
        print(dfOutlier)
        dfOutlier = (maindf[maindf.PnlUnRealized > 0.1000])
        fh.write('\n' + msg + '\n')
        for row in dfOutlier.itertuples():
            fh.write(str(row) + '\n')
    # if (len(dfOutlier) > 0):


# params: dfTotalSorted, csv path/file, args.roundOff,args.maxExp,args.output
def CreateComboReport(dfTotalSorted, comboRpt, roundOffVal, maxExp, outputPath, yearGroup):
    # print("outputPath:",outputPath)

    dfTotalSorted.to_csv(comboRpt)
    if not yearGroup:
        htmlHeaders = 'Category,' + 'pnlRealized,' + 'pnlUnRealized,' + 'winnersCount,' + 'losersCount,' + 'flatCount,' + 'averageWin,' + 'averageLoss,' + 'averageHoldingPeriod,' + 'TotalTrades,' + 'WinTicks,' + 'LossTicks,' + 'TotalPnl,' + 'pnames,' + 'Histogram'
    else:
        htmlHeaders = 'Category,' + 'Year,' + 'pnlRealized,' + 'pnlUnRealized,' + 'winnersCount,' + 'losersCount,' + 'flatCount,' + 'averageWin,' + 'averageLoss,' + 'averageHoldingPeriod,' + 'TotalTrades,' + 'WinTicks,' + 'LossTicks,' + 'TotalPnl,' + 'pnames,' + 'Histogram'
    if maxExp == 'True':
        htmlHeaders = htmlHeaders + ',MaxExposure'
    # dfTotalSortedNew = dfTotalSorted.drop(dfTotalSorted.columns[[0]], axis=1)
    # print(dfTotalSortedNew)
    htmlHeadersList = htmlHeaders.split(',')
    title = '<b>' + args.fromDate + ' - ' + args.toDate + '</b><br>'
    htmlStr = co.addHTMLHeadElement() + title + '<Table><tr>'
    roundOffVal = args.roundOff
    for i in range(len(htmlHeadersList)):
        htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
        print('<th>' + htmlHeadersList[i] + '</th>')
    htmlStr += '</tr>'
    rowCounter = 1
    for index, row in dfTotalSorted.iterrows():
        '''if (index %2 == 0):
            htmlStr += '<tr bgcolor="lightcyan">'
        else:
            htmlStr += '<tr>' '''
        htmlStr += '<td>' + str(row["Category"]) + '</td>'
        if yearGroup:
            htmlStr += '<td>' + str(row["Year"]) + '</td>'
        htmlStr += '<td>' + str(round(row["pnlRealizedStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["pnlUnRealizedStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["winnersCountStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["losersCountStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["flatCountStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["averageWinStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["averageLossStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["averageHoldingPeriodStat"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["TotalTrades"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["avgWinTicks"], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(row["avgLossTicks"], roundOffVal)) + '</td>'
        htmlStr += '<td title="StratB - PnlRealizedStat 2 legs">' + str(round(row["TotalPnl"], roundOffVal)) + '</td>'

        paramsPath = os.path.join(outputPath, 'ConsolidatedParams.html')
        paramsPathUrl = pathlib.Path(paramsPath).as_uri()
        htmlStr += '<td>' + '<a href=' + paramsPathUrl + ' target="_blank">' + str(row["pname"]) + '</a>' + '</td>'
        # htmlStr += '<td>' + str(row["pname"]) + '</td>'

        histoPath = os.path.join(outputPath, 'histo-' + str(row["pname"]) + '.png')
        histoPathUrl = pathlib.Path(histoPath).as_uri()
        htmlStr += '<td><a href=' + histoPathUrl + ' target="_blank">img' + '</a></td>'

        # htmlStr += '<td><a href="file:///' + outputPath + 'histo-' + str(row["pname"]) + '.png" target="_blank">img'  + '</a></td>'

        if maxExp == 'True':
            htmlStr += '<td>' + str(round(row["MaxExposure"], roundOffVal)) + '</td>'
        htmlStr += '</tr>'
        if ((rowCounter) % 3 == 0):
            htmlStr += '<tr bgcolor="lightcyan"><td colspan=' + str(len(htmlHeadersList)) + '></td></tr>'
        rowCounter = rowCounter + 1
    htmlStr += '</Table>'
    htmlStr += co.addHTMLBodyEndTag()
    # print(htmlStr)
    combolHtml = os.path.join(outputPath, 'positionsCombo.html')
    fCombo = open(combolHtml, 'w')
    fCombo.write(htmlStr)
    fCombo.close()
    webbrowser.open_new_tab(outputPath + '/positionsCombo.html')


def CreateParamsTable(dirname, paramDir):
    xml_file = os.path.join(paramDir, "params.xml")
    tree = et.parse(xml_file)
    root = tree.getroot()

    values = root.find('.//item')
    print(values)
    colList = []
    valList = []
    for value in values:
        colList.append(value.tag)
        valList.append(value.text)

    print(colList)
    print(valList)

    paramsDF = pd.DataFrame(valList)
    paramsDF = paramsDF.T
    paramsDF.columns = colList
    paramsDF['pname'] = dirname

    # select columns required only
    paramsDF = paramsDF[['pname', 'HoldingPeriod', 'RebalanceB', 'MultiplierB', 'TargetMultiplierB', 'StopMultiplierB', 'ModeA', 'Start', 'End', 'OpenPassive', 'ClosePassive']]

    # paramsConsolidatedDF = paramsConsolidatedDF.append(paramsDF)

    return paramsDF


def CreateParamsHtmlReport(paramsConsolidatedDF, outputPath):
    htmlHeaders = 'Holding,' + 'Rebalance,' + 'Multiplier,' + 'MultiplierTarget,' + 'MultiplierStop,' + 'ModeA,' + 'Start,'+ 'End,'+ 'OpenPassive,' + 'ClosePassive,' +'pname'
    htmlHeadersList = htmlHeaders.split(',')
    htmlStr = co.addHTMLHeadElement() + '<Table><tr>'

    for i in range(len(htmlHeadersList)):
        htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
        print('<th>' + htmlHeadersList[i] + '</th>')
    htmlStr += '</tr>'

    for index, row in paramsConsolidatedDF.iterrows():
        htmlStr += '<tr>'
        # htmlStr += '<td>' + str(index) + '</td>'
        htmlStr += '<td>' + str(row["HoldingPeriod"]) + '</td>'
        htmlStr += '<td>' + str(row["RebalanceB"]) + '</td>'
        htmlStr += '<td>' + str(row["MultiplierB"]) + '</td>'
        htmlStr += '<td>' + str(row["TargetMultiplierB"]) + '</td>'
        htmlStr += '<td>' + str(row["StopMultiplierB"]) + '</td>'
        htmlStr += '<td>' + str(row["ModeA"]) + '</td>'
        htmlStr += '<td>' + str(row["Start"]) + '</td>'
        htmlStr += '<td>' + str(row["End"]) + '</td>'
        htmlStr += '<td>' + str(row["OpenPassive"]) + '</td>'
        htmlStr += '<td>' + str(row["ClosePassive"]) + '</td>'
        htmlStr += '<td>' + str(row["pname"]) + '</td>'
        htmlStr += '</tr>'

    htmlStr += '</Table>'
    htmlStr += co.addHTMLBodyEndTag()
    combolHtml = os.path.join(outputPath, 'ConsolidatedParams.html')
    fCombo = open(combolHtml, 'w')
    fCombo.write(htmlStr)
    fCombo.close()


parser = argparse.ArgumentParser(description="Create Positions Reports Script")

parser.add_argument('-sg', '--strategyGroup', default=['Spread', 'Momentum'], help="file location input series a",
                    nargs='*')
#parser.add_argument('-s', '--strategy', default=['Welsley', 'Smith', 'Smith1', 'Smith2', 'CME_FVU7CME_TYU7', 'CME_FVU7', 'CME_TYU7',
#                            'CME_TYH5CME_FVH5', 'CME_ESU7CME_NQU7', 'FXOTC_EUR_USD', 'CME_TYH5', 'CME_FVH5',
#                             'CME_ESU7', 'CME_NQU7', 'CME_TYH8', 'CME_FVH8'], help="file location input series a",  nargs='*')
parser.add_argument('-s', '--strategy', default='Smith', help="e.g For B Smith, For A : CME_FVU7")
parser.add_argument('-f', '--fromDate', default='19991001', help="from date")
parser.add_argument('-t', '--toDate', default='20201021', help="to date")
parser.add_argument('-groupBy', '--groupByParam', default='StrategyGroup',
                    help="group by parameter- Strategy, StrategyGroup or D")
parser.add_argument('-v', '--verbose', default='False', help="verbose")
parser.add_argument('-env', '--env', default='dev', help="dev environ")
parser.add_argument('-posFile', '--posFile', default='positions.txt', help="positions input file name")
parser.add_argument('-round', '--roundOff', default=5, type=int,
                    help="round hedge ratio to decimal places specified as parameter")
parser.add_argument('-maxExp', '--maxExp', default='False', help="To compute Max exposure set to True")
parser.add_argument('-histAuto', '--histogramAuto', default='True',
                    help="True: use auto bins or False: set values using histBin arg value")
parser.add_argument('-histBin', '--histoBinWidth', default=0.0005, help="binwidth for histogram")
parser.add_argument('-mode', '--mode', default='q', help="q - not display  or v - display each param report on browser")
parser.add_argument('-yearGroup', '--yearGroup', action='store_true', help="True - group by year else False")
parser.add_argument('-strategyType', '--strategyType', default='A', help="A or B")
parser.add_argument('-param', '--param', default='', help="select a specific param")
parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                    help="log file  path")
# args = parser.parse_args()
args, unknown = parser.parse_known_args()
print(args)

environment = args.env
currentPlatform = platform.system()

prodBase = '/home/lanarayan/MyProjects/TestSimulator/'
# prodBase = '/home/svc_wqln/MyProjects/WQMaster/cpp/cmake-build-debug/'
# winBase='C:/MyProjects/MacroQ/output/'
# winBase = 'C:/MyProjects/WQMaster/output/outputZ0/'
# winBase = 'C:/MyProjects/WQMaster/data/PositionsNew/'
unixBase = "/home/lanarayan/MyProjects/WQMaster/"
winBase = 'C:/MyProjects/WQMaster/data/PositionsCombo'
if (currentPlatform == 'Windows'):
    parser.add_argument('-baseDir', '--baseDirectory', default=winBase, help="base Directory")
    parser.add_argument('-debugFile', '--debugFile', default='debugLog.txt', help="Debug file name")
    parser.add_argument('-output', '--output', default='C:/MyProjects/WQMaster/output/', help="output Directory")
elif (environment == 'prod'):
    parser.add_argument('-baseDir', '--baseDirectory', default=prodBase, help="base Directory")
    parser.add_argument('-debugFile', '--debugFile', default='debugLog.txt', help="Debug file name")
    parser.add_argument('-output', '--output', default='/home/lanarayan/MyProjects/output/', help="output Directory")
else:
    parser.add_argument('-baseDir', '--baseDirectory', default='/home/lanarayan/MyProjects/WQMaster/data/Positions',
                        help="base Directory")
    parser.add_argument('-debug', '--debugFile', default='debugLog.txt', help="Debug file name")
    parser.add_argument('-output', '--output', default='/home/lanarayan/MyProjects/WQMaster/output/',
                        help="output Directory")

parser.print_help()
args = parser.parse_args()
print(args)

dateForLog = datetime.now().strftime("%Y%m%d-%H%M%S.%f")

logging.basicConfig(filename=os.path.join(args.logPath, 'PosReport-' + dateForLog + '.log'),
                    filemode='w', level=getattr(logging, args.logLevel),
                    format='%(asctime)s %(levelname)s %(message)s')

# Gets absolute path even if all path folders dont exist, first do this then do os.path.exists to create if required
args.baseDirectory = os.path.abspath(args.baseDirectory)
args.output = os.path.abspath(args.output)

# will also create args.output if doesn't exist
tempPath = os.path.join(args.output, 'temp')
if not os.path.exists(tempPath):
    os.makedirs(tempPath)

# Columns Orderas follows:
# ID,TimeStamp,Size,Avgpx,PnlRealized,PnlUnRealized,FillPx,Open,ClosePx,CloseTimeStamp,Remaining,EntryCriteriaType,EntryCriteriaVal,EntryCriteriaStrength,Status,ExitCriteriaStopSize,ExitCriteriaTgtSize,ExitCriteriaExpiry,CloseCode,CloseRemaining,CloseFillPx,CloseFillTimeStamp,FillTimeStamp

colnames = ['ID', 'TimeStamp', 'Size', 'Avgpx', 'PnlRealized', 'PnlUnRealized', 'FillPx', 'Open', 'ClosePx',
            'CloseTimeStamp', 'Remaining', 'EntryCriteriaTypeValStrength', 'Status', 'ECStopSizeTgtSizeExpiry',
            'CloseCode', 'CloseRemaining', 'CloseFillPx', 'CloseFillTimeStamp', 'FillTimeStamp', 'ParentID', 'Key',
            'ExternalKey']

baseDir = args.baseDirectory

dateInputList = []
StrategyGroupInputList = []
# ['Spread','Momentum']
StrategyInputList = []
# ['ESNQ']

# date range
# d1 = date(2017, 8, 15)  # start date
# d2 = date(2017, 9, 15)  # end date
d1 = datetime.strptime(args.fromDate, '%Y%m%d')
d2 = datetime.strptime(args.toDate, '%Y%m%d')
delta = d2 - d1  # timedelta

for i in range(delta.days + 1):
    # print(d1 + timedelta(days=i))
    dateInputList.append((d1 + timedelta(days=i)).strftime("%Y%m%d"))

# Strategy Group
StrategyGroupInputList = args.strategyGroup;

# Strategy
StrategyInputList.append(args.strategy)

# For Strat B Spread name e.g will be provide in args.strategy. Add the legs, combined legs and spread name to StrategyInputlist
#  for compatibility with old folder struct and new design (folder CME_ESU7CME_NQU is now named as Smith).
#  Also same for other Strat Bs

if args.strategy in StrategyBMap.keys():
    StrategyInputList = StrategyBMap[args.strategy]
    StrategyInputList.append(StrategyBMap[args.strategy][0] + StrategyBMap[args.strategy][1])
    StrategyInputList.append(args.strategy)

# positions file name
datafile = args.posFile

debugFile = os.path.join(args.output, 'temp', args.debugFile)
fh = open(debugFile, 'w')
maindf = pd.DataFrame()
dfTotal = pd.DataFrame()  # combined data frame
counter = 0
paramsConsolidatedDF = pd.DataFrame()
# main outer For loop begins
for paramFolder in glob.glob(baseDir + '/*'):
    maindf = pd.DataFrame()
    paramFolder = paramFolder.replace('\\', '/')
    paramfolderSubstr = paramFolder.split('/')[-1]
    if not paramfolderSubstr.startswith('params-'):
        continue;

    if args.param:
        selectedparam = "params-" + args.param
        if paramfolderSubstr != selectedparam:
            continue
    # if not paramfolderSubstr.startswith( 'param' ):
    #   paramfolderSubstr = ''
    paramDir = os.path.join(baseDir, paramfolderSubstr)
    paramsConsolidatedDF = paramsConsolidatedDF.append(CreateParamsTable(paramfolderSubstr, paramDir))
    for x in dateInputList:
        for sgfolder in glob.glob(baseDir + '/' + paramfolderSubstr + '/' + x + '/*'):
            # print("Traversing Strategy Group:" + sgfolder)
            fh.write("\nTraversing Strategy Group:" + sgfolder)
            # In Win we get \\ before strategyGroup folder, Unix we get /, so replace done to work in both envs
            sgfolder = sgfolder.replace('\\', '/')
            sgfolderSubstr = sgfolder.split('/')[-1]
            if sgfolderSubstr not in StrategyGroupInputList and len(StrategyGroupInputList) != 0:
                # print("Skipping Strategy Group folder" + sgfolder + " not in StrategyGroupInputList")
                fh.write("\nSkipping Strategy Group folder" + sgfolder + " not in StrategyGroupInputList")
                continue;
            else:
                for sfolder in glob.glob(sgfolder + '/*'):
                    # print("Checking Strategy  folder: "  + sfolder)
                    fh.write("\nChecking Strategy  folder: " + sfolder)
                    sfolder = sfolder.replace('\\', '/')
                    sfolderSubstr = sfolder.split('/')[-1]
                    if sfolderSubstr not in StrategyInputList and len(StrategyInputList) != 0:
                        # print("Skipping Strategy" + sfolder + " not in StrategyInputList")
                        fh.write("\nSkipping Strategy" + sfolder + " not in StrategyInputList")
                        continue;
                    else:
                        print("Reading Strategy folder: " + sfolder)
                        fh.write("\nReading Strategy folder: " + sfolder)
                        if os.path.isfile(os.path.join(sfolder, datafile)):
                            print("Reading " + datafile + " in Strategy folder: " + sfolder)
                            fh.write("\nReading " + datafile + "Strategy folder: " + sfolder)
                            df = pd.read_csv(os.path.join(sfolder, datafile), names=colnames, index_col=False)
                            df['StrategyGroup'] = sgfolderSubstr
                            df['Strategy'] = sfolderSubstr
                            maindf = maindf.append(df)
                        else:
                            # print(datafile  + " does not exist in Strategy folder: "  + sfolder)
                            fh.write("\n" + datafile + " does not exist in Strategy folder: " + sfolder)

    # print(maindf.columns)

    # print(len(maindf))
    # print(maindf.head())
    if len(maindf) == 0:
        fh.write("\nExiting program dataframe length is zero")
        # No need to exit here. Other params-x folders may have positions data , instead loop again
        # sys.exit("Exitting program dataframe length is zero")
        continue

    maindf = maindf.fillna(0)

    # For Strat B if both Smith and CME_ESU7CME_NQU7 Strategies in df delete rows with strategy CME_ESU7CME_NQU7
    # else replace CME_ESU7CME_NQU7 with Smith to meet new
    # design (folder CME_ESU7CME_NQU7 is named as Smith). Also same for other Strat Bs
    # NOTE:DeleteStratBdirs.py can be used to delete old combined leg folders where new folder exists
    uniqueStrategyList = list(maindf.Strategy.unique())
    print("Unique Strategy List: ", uniqueStrategyList)
    logging.debug("Unique Strategy List: {}".format(uniqueStrategyList))
    if len(uniqueStrategyList) > 3:
        #delete all rows with combined leg as strategy name
        stratComboName = StrategyBMap[args.strategy][0] + StrategyBMap[args.strategy][1]
        maindf = maindf[maindf.Strategy != stratComboName]
    elif len(uniqueStrategyList) == 3:
        stratForReplace = StrategyBMap[args.strategy][0] + StrategyBMap[args.strategy][1]
        print("In maindf replacing ", stratForReplace, " with ", args.strategy)
        logging.debug("In maindf replacing {} with {}".format(stratForReplace,args.strategy))
        maindf.Strategy = maindf.Strategy.replace({stratForReplace: args.strategy})

    writeOutliersToFile(maindf, fh)
    # dftemp = pd.DataFrame(maindf.ECStopSizeTgtSizeExpiry.str.split(';',2).tolist(),
    #                                   columns = ['StopSize','TargetSize','Expiry'])

    # maindf['ExpiryDate'] = dftemp.Expiry
    maindf[['StopSize', 'TargetSize', 'ExpiryDate']] = maindf.ECStopSizeTgtSizeExpiry.str.split(';', expand=True)


    # Create a column for closeTimeStamp based on if closeTimeStamp is not-a date then use Expirydate
    def funcCloseExpireTS(maindf):
        # print(df['a'])
        if maindf['CloseTimeStamp'] == 'not-a-date-time':
            return maindf['ExpiryDate']
        else:
            return maindf['CloseTimeStamp']


    maindf['closeExpireTimeStamp'] = maindf.apply(funcCloseExpireTS, axis=1)

    # create a column for Date only for grouping bydate
    # maindf['D'] = maindf['TimeStamp'].astype(str).str[:10]
    dateTimeSeries = maindf['TimeStamp'].str.split(' ', 1)
    dateList = [el[0] for el in dateTimeSeries]
    maindf['D'] = dateList

    # Create year column
    mySeries = maindf['TimeStamp'].str.split('-', 1)
    yearList = [el[0] for el in mySeries]
    maindf['Y'] = yearList
    # print(maindf.head())
    # Create a column for sum of PnlRealized and PnlUnRealized
    maindf['pnl'] = maindf['PnlRealized'] + maindf['PnlUnRealized']

    # maindf['PnLTicks'] = maindf['pnl'] / (abs(maindf['Size'])*args.tickSize)

    maindf['PnLTicks'] = maindf.apply(lambda df: df.pnl / (abs(df.Size) * GetTickSize(df.Strategy)), axis=1)

    if args.verbose == 'True':
        mainDfCSV = os.path.join(args.output, 'temp')
        mainDfCSV = os.path.join(mainDfCSV, 'mainDataFrame.csv')
        maindf.to_csv(mainDfCSV, index=False)

    # Group by Startegy Group
    # ====================================================

    argsyearGroup = args.yearGroup

    if argsyearGroup:
        grouped = maindf.groupby([args.groupByParam, 'Y'])
    else:
        grouped = maindf.groupby([args.groupByParam])
    # 1. Stats Realized P&L = Sum of pnl
    pnlRealizedStat = grouped['PnlRealized'].agg(np.sum)
    # print(type(pnlRealizedStat))

    # 2. Stats Unrealized P&L = sum of unpl
    pnlUnRealizedStat = grouped['PnlUnRealized'].agg(np.sum)


    # 3. Winners = count of positions that have  realized + unrealized > 0
    def funcApply(df):
        return sum((df['PnlRealized'] + df['PnlUnRealized']) > 0)


    winnersCountStat = grouped.apply(lambda df: sum((df['PnlRealized'] + df['PnlUnRealized']) > 0))
    winnersCountStat = grouped.apply(funcApply)


    # print(type(winnersCountStat))
    # print(winnersStatSum.Momentum)
    # print("winnersCountStat:",winnersCountStat)

    # 4. Losers = count of positions that have  realized + unrealized < 0
    def funcLosersCount(df):
        return sum((df['PnlRealized'] + df['PnlUnRealized']) < 0)


    losersCountStat = grouped.apply(lambda df: sum((df['PnlRealized'] + df['PnlUnRealized']) < 0))
    losersCountStat = grouped.apply(funcLosersCount)
    # print(type(losersCountStat))
    # print(winnersStatSum.Momentum)
    # print("losersCountStat:",losersCountStat)

    # 5. Flat = count of positions that have  realized + unrealized == 0

    flatCountStat = grouped.apply(lambda df: sum((df['PnlRealized'] + df['PnlUnRealized']) == 0))


    # flatCountStat = grouped.apply(funcLosersCount)
    # print(type(flatCountStat))
    # print(winnersStatSum.Momentum)
    # print("flatCountStat:",flatCountStat)

    # 6. Average Win = Sum of realized + unrealized >0 / num of winners
    def funcAverageWin(x):
        return x[x > 0].mean()


    def funcAverageWinTicks(x):
        return x[x > 0].mean()


    def funcAverageLossTicks(x):
        return x[x < 0].mean()


    averageWinStat = grouped.agg({'pnl': funcAverageWin})
    print(averageWinStat)

    # seems like a good place to start the discussion
    # https://stackoverflow.com/questions/21828398/what-is-the-difference-between-pandas-agg-and-apply-function
    # avgWinTicks0 = grouped.apply(lambda df: sum( df['PnLTicks'] > 0) / len(df['PnLTicks'] > 0) )
    # print('**Average Win Ticks:' , avgWinTicks0)
    # print('\n')

    avgWinTicks = grouped.agg({'PnLTicks': funcAverageWinTicks})
    avgLossTicks = grouped.agg({'PnLTicks': funcAverageLossTicks})


    # 7. Average Loss = Sum of positions that have  realized + unrealized < 0/ num of losers

    def funcAverageLoss(x):
        return x[x < 0].mean()


    averageLossStat = grouped.agg({'pnl': funcAverageLoss})


    # print(averageLossStat)

    # 8 .Average holding period = closed time stamp - timestamp/ num of positions
    def funcAvgHoldPeriod(x):
        print('funcAvgHoldPeriod-closeExpireTimeStamp :', x['closeExpireTimeStamp'])
        print('funcAvgHoldPeriod-TimeStamp :', x['TimeStamp'])
        return (pd.to_datetime(x['closeExpireTimeStamp']) - pd.to_datetime(x['TimeStamp'])).astype(
            'timedelta64[s]').mean()


    averageHoldingPeriodStat = grouped.apply(funcAvgHoldPeriod)

    # 9. Trades = Total number of positions

    totalTradesStat = grouped.size()


    # 10 max exposure
    def interval_overlaps(a, b):
        # print(type(a), type(b))
        # print(a["end"], b["end"], ' ', min(a["end"], b["end"]))
        # print(a["start"], b["start"], ' ', max(a["start"], b["start"]))
        # return (min(a["end"], b["end"]) - max(a["start"], b["start"]) ) >np.timedelta64(0,s)
        return a["Size"] * (
                    min(a["ExpiryDate"], b["ExpiryDate"]) - max(a["TimeStamp"], b["TimeStamp"]) > np.timedelta64(0,
                                                                                                                 's'))


    def count_overlaps(df1):
        return pd.Series(
            [df1.apply(lambda x: interval_overlaps(x, df1.iloc[i]), axis=1).sum() for i in range(len(df1))])


    if args.maxExp == 'True':
        maindf['TimeStamp'] = pd.to_datetime(maindf.TimeStamp)
        maindf['ExpiryDate'] = pd.to_datetime(maindf.ExpiryDate)
        if argsyearGroup:
            groupedNew = maindf.groupby([args.groupByParam, 'Y'])
        else:
            groupedNew = maindf.groupby(args.groupByParam)

        # print(groupedNew)
        df1 = grouped.apply(count_overlaps)
        if not isinstance(df1, pd.Series):
            maindf["count"] = df1.iloc[0]
        else:
            maindf["count"] = df1.values

        # maindf["count"] = groupedNew.apply(count_overlaps).values
        maindf["countabs"] = abs(maindf["count"])
        maxExposureStat = groupedNew['countabs'].max()
        # maindf["overlapCount"] = groupedNew.apply(count_overlaps).values

    # STATISTICS
    print('\n\n\nSTATISTICS:: Grouped By ', args.groupByParam)
    print('pnlRealizedStat:', pnlRealizedStat)
    print('\n')
    print('pnlUnRealizedStat:', pnlUnRealizedStat)
    print('\n')

    print('Winners Count:', winnersCountStat)
    print('\n')

    print('Losers Count :', losersCountStat)
    print('\n')

    print('Flat Count :', flatCountStat)
    print('\n')

    print('Average Win Stat:', averageWinStat)
    print('\n')

    print('Average Win Ticks:', avgWinTicks)
    print('\n')

    print('Average Loss Stat:', averageLossStat)
    print('\n')

    print('Average Loss Ticks:', avgLossTicks)
    print('\n')

    print('Average Holding Period Stat:', averageHoldingPeriodStat)
    print('\n')

    print('Total Trades:', totalTradesStat)
    print('\n')

    if args.maxExp == 'True':
        print('Max Exposure:', maxExposureStat)

    # print(str(averageWinStat.iloc[0,0]))
    # print(str(averageWinStat.iloc[1,0]))

    # Write to file
    try:
        # fhNew = open(args.report, 'w')
        # Note:this csv gets overwritten in every loop, gets added to  combined dataframe (dfTotal)
        posReportPath = os.path.join(args.output + '/PositionsReportTmp.csv')
        fhNew = open(posReportPath, 'w')
    except Exception as err:
        print('Error in file open')
        print(str(err))
        sys.exit(1)
    if args.maxExp == 'True':
        # if args.yearGroup == 'False':
        if not argsyearGroup:
            fhNew.write(
                'Category,' + 'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' + 'averageHoldingPeriodStat,' + 'TotalTrades,' + 'avgWinTicks,' + 'avgLossTicks,' + 'MaxExposure' + '\n')
        else:
            fhNew.write(
                'Category,' + 'Year,' + 'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' + 'averageHoldingPeriodStat,' + 'TotalTrades,' + 'avgWinTicks,' + 'avgLossTicks,' + 'MaxExposure' + '\n')
    else:
        if not argsyearGroup:
            fhNew.write(
                'Category,' + 'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' + 'averageHoldingPeriodStat,' + 'TotalTrades,' + 'avgWinTicks,' + 'avgLossTicks' + '\n')
        else:
            fhNew.write(
                'Category,' + 'Year,' + 'pnlRealizedStat,' + 'pnlUnRealizedStat,' + 'winnersCountStat,' + 'losersCountStat,' + 'flatCountStat,' + 'averageWinStat,' + 'averageLossStat,' + 'averageHoldingPeriodStat,' + 'TotalTrades,' + 'avgWinTicks,' + 'avgLossTicks' + '\n')

    for x in range(len(averageWinStat)):
        if not argsyearGroup:
            fhNew.write(str(averageWinStat.index[x]) + ',')
        else:
            fhNew.write(str(averageWinStat.index[x][0]) + ',')
            fhNew.write(str(averageWinStat.index[x][1]) + ',')
        fhNew.write(str(pnlRealizedStat.iloc[x]) + ',')
        fhNew.write(str(pnlUnRealizedStat.iloc[x]) + ',')
        fhNew.write(str(winnersCountStat.iloc[x]) + ',')
        fhNew.write(str(losersCountStat.iloc[x]) + ',')
        fhNew.write(str(flatCountStat[x]) + ',')
        fhNew.write(str(averageWinStat.iloc[x, 0]) + ',')
        fhNew.write(str(averageLossStat.iloc[x, 0]) + ',')
        fhNew.write(str(averageHoldingPeriodStat.iloc[x]) + ',')
        fhNew.write(str(totalTradesStat.iloc[x]) + ',')
        fhNew.write(str(avgWinTicks.iloc[x, 0]) + ',')
        fhNew.write(str(avgLossTicks.iloc[x, 0]))
        if args.maxExp == 'True':
            fhNew.write(',' + str(maxExposureStat.iloc[x]))
        fhNew.write('\n')

    fhNew.close()
    # fh.close()
    # create image for individual reports
    for name, group in grouped:
        # print (name)
        # print (group)
        grp = grouped.get_group(name)
        pnlList = list(grp['pnl'])
        plt.xlabel('pnl')
        plt.ylabel('Occurences')
        plt.title('Pnl Analysis')
        if args.histogramAuto == 'True':
            plt.hist(pnlList, rwidth=0.9, histtype='bar', color='green')
        else:
            binwidth = args.histoBinWidth
            print(np.arange(min(pnlList), max(pnlList) + binwidth, binwidth))
            binsList = np.arange(min(pnlList), max(pnlList) + binwidth, binwidth)
            plt.hist(pnlList, bins=binsList, rwidth=0.9, histtype='bar', color='green')
        figurePath = os.path.join(args.output, 'histo-' + paramfolderSubstr + '.png')
        plt.savefig(figurePath)
    # ZZZZ
    print("counter: ", counter)
    if counter == 0:
        # dfTotal = pd.read_csv(args.report ,index_col=False)
        posReportPath = os.path.join(args.output + '/PositionsReportTmp.csv')
        dfTotal = pd.read_csv(posReportPath, index_col=False)
        print(dfTotal)
        dfTotal['pname'] = paramfolderSubstr

        # sort by category so combined for legB is last
        dfTotal.index = dfTotal['Category'].str.len()
        dfTotal = dfTotal.sort_index(ascending=True).reset_index(drop=True)
    else:
        # tmpdf = pd.read_csv(args.report)
        posReportPath = os.path.join(args.output + '/PositionsReportTmp.csv')
        tmpdf = pd.read_csv(posReportPath)
        tmpdf['pname'] = paramfolderSubstr

        # sort by category so combined for legB is last
        tmpdf.index = tmpdf['Category'].str.len()
        tmpdf = tmpdf.sort_index(ascending=True).reset_index(drop=True)

        dfTotal = dfTotal.append(tmpdf, ignore_index=True)
    counter = counter + 1
    print("Length dfTotal: ", len(dfTotal))
    # ZZZZ
    if not argsyearGroup:
        htmlHeaders = 'Category,' + 'pnlRealized,' + 'pnlUnRealized,' + 'winnersCount,' + 'losersCount,' + 'flatCount,' + 'averageWin,' + 'averageLoss,' + 'averageHoldingPeriod,' + 'TotalTrades,' + 'WinTicks,' + 'LossTicks,' + 'Histogram'
    else:
        htmlHeaders = 'Category,' + 'Year,' + 'pnlRealized,' + 'pnlUnRealized,' + 'winnersCount,' + 'losersCount,' + 'flatCount,' + 'averageWin,' + 'averageLoss,' + 'averageHoldingPeriod,' + 'TotalTrades,' + 'WinTicks,' + 'LossTicks,' + 'Histogram'

    if args.maxExp == 'True':
        htmlHeaders = htmlHeaders + ',MaxExposure'

    htmlHeadersList = htmlHeaders.split(',')
    htmlStr = co.addHTMLHeadElement() + '<Table><tr>'

    roundOffVal = args.roundOff
    for i in range(len(htmlHeadersList)):
        htmlStr += '<th>' + htmlHeadersList[i] + '</th>'
        print('<th>' + htmlHeadersList[i] + '</th>')
    htmlStr += '</tr>'
    for x in range(len(averageWinStat)):
        htmlStr += '<tr>'
        if not argsyearGroup:
            htmlStr += '<td>' + str(averageWinStat.index[x]) + '</td>'
        else:
            htmlStr += '<td>' + str(averageWinStat.index[x][0]) + '</td>'
            htmlStr += '<td>' + str(averageWinStat.index[x][1]) + '</td>'
        htmlStr += '<td>' + str(round(pnlRealizedStat.iloc[x], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(pnlUnRealizedStat.iloc[x], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(winnersCountStat.iloc[x], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(losersCountStat.iloc[x], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(flatCountStat[x], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(averageWinStat.iloc[x, 0], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(averageLossStat.iloc[x, 0], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(averageHoldingPeriodStat.iloc[x], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(totalTradesStat.iloc[x], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(avgWinTicks.iloc[x, 0], roundOffVal)) + '</td>'
        htmlStr += '<td>' + str(round(avgLossTicks.iloc[x, 0], roundOffVal)) + '</td>'
        # htmlStr += '<td><a href="file:///C:/MyProjects/WQMaster/python/histo-' + paramfolderSubstr + '.png">img'  + '</a></td>'

        histoPath = os.path.join(args.output, 'histo-' + paramfolderSubstr + '.png')
        histoPathUrl = pathlib.Path(histoPath).as_uri()
        htmlStr += '<td><a href=' + histoPathUrl + '>img' + '</a></td>'
        # htmlStr += '<td><a href="file:///' + args.output + 'histo-' + paramfolderSubstr + '.png">img'  + '</a></td>'

        if args.maxExp == 'True':
            htmlStr += '<td>' + str(round(maxExposureStat.iloc[x], roundOffVal)) + '</td>'
        htmlStr += '</tr>'
    htmlStr += '</Table>'
    htmlStr += co.addHTMLBodyEndTag()
    # print(htmlStr)
    poshtml = os.path.join(args.output + '/positions' + '-' + paramfolderSubstr + '.html')
    f = open(poshtml, 'w')
    f.write(htmlStr)
    f.close()

    # individual files (that are included in combo) opened in browser
    # mode == 'q' will not open individual files(just the combo will be displayed in CreateComboReport
    if args.mode == 'v':
        webbrowser.open_new_tab(poshtml)

    # Plot Histogram pnlRealized -xaxis, frequency -y
    '''pnlRealizedList = list(maindf['pnl'])
    plt.xlabel('pnlRealized')
    plt.ylabel('Occurences')
    plt.title('Pnl Analysis')
    if args.histogramAuto == 'True':
        plt.hist(pnlRealizedList, rwidth =0.9, histtype='bar',color='green')
    else:
        binwidth =  args.histoBinWidth
        print(np.arange(min(pnlRealizedList), max(pnlRealizedList) + binwidth, binwidth))
        binsList = np.arange(min(pnlRealizedList), max(pnlRealizedList) + binwidth, binwidth)
        plt.hist(pnlRealizedList, bins =binsList, rwidth =0.9, histtype='bar',color='green')'''

    # plt.show()
    # plt.savefig(args.output + 'histo-' + paramfolderSubstr + '.png')
    if not paramfolderSubstr.startswith('param'):
        break;
# print(dfTotal.head())
# Outer main For loop ends
if len(dfTotal) == 0:
    fh.write("\nExitting program Combined dataframe length is zero")
    sys.exit("Exitting program Combined dataframe length is zero")

print(paramsConsolidatedDF)
CreateParamsHtmlReport(paramsConsolidatedDF, baseDir)

if args.strategyType == 'B' and args.groupByParam == 'Strategy':
    StratBlegs = list(dfTotal.Category.unique())  # unique will return an array, convert to list  to use del
    # StratBlegs = ['CME_ESU7', 'Bernanke','CME_NQU7' ]
    if StratBlegs[0] in StrategyBList:
        del (StratBlegs[0])
    elif StratBlegs[1] in StrategyBList:
        del (StratBlegs[1])
    else:
        del (StratBlegs[2])
    StratBlegsSorted = sorted(StratBlegs, key=len)
    # del(StratBlegsSorted[2])

    StratBparams = dfTotal.pname.unique()

    dfTotal['TotalPnl'] = 0
    dfTotal['Test'] = dfTotal.pname + dfTotal.Category
    for x in StratBparams:
        leg1 = StratBlegsSorted[0].split('_')[1][
               0:-2]  # [0:-2]removes last two characters from StratBlegsSorted[0].split('_')[1] string
        leg2 = StratBlegsSorted[1].split('_')[1][0:-2]
        c = contractsTable[leg1]
        pointVal1 = c.pointvalue
        c = contractsTable[leg2]
        pointVal2 = c.pointvalue

        # dfTotal.loc[dfTotal['pname'] == x, 'TotalPnl'] = dfTotal.loc[(dfTotal['Test'] ==  x + StratBlegsSorted[0]),"pnlRealizedStat" ].tolist()[0] + dfTotal.loc[(dfTotal['Test'] ==  x + StratBlegsSorted[1]),"pnlRealizedStat" ].tolist()[0]
        # dfTotal.loc[dfTotal['pname'] == x, 'TotalPnl'] = dfTotal.loc[(dfTotal['Test'] ==  x + StratBlegsSorted[1]),"pnlRealizedStat" ].tolist()[0]
        dfTotal.loc[dfTotal['pname'] == x, 'TotalPnl'] = (dfTotal.loc[
            (dfTotal['Category'] == StratBlegsSorted[0]) & (dfTotal['pname'] == x), "pnlRealizedStat"].tolist()[
            0]) * pointVal1 \
                                                         + (dfTotal.loc[
            (dfTotal['Category'] == StratBlegsSorted[1]) & (dfTotal['pname'] == x), "pnlRealizedStat"].tolist()[
            0]) * pointVal2

    # dfTotalSorted = dfTotal.sort_values(['pnlRealizedStat'],ascending=False)
    dfTotalSorted = dfTotal.sort_values(['TotalPnl'], ascending=False)
elif args.strategyType == 'A' and args.groupByParam == 'Strategy':
    # Get category from first row as all values in category column are same for A
    asset = dfTotal.iloc[0].Category
    # Note dir naming : Futures Momentum/CME_ESU7  and for FX Momentum/FXOTC_EUR_USD
    asset = asset.split('_')
    if len(asset) == 2:
        asset = asset[1][0:-2]  # For Futures
    else:
        asset = asset[1] + asset[2]
    c = contractsTable[asset]
    pointVal = c.pointvalue
    dfTotal['TotalPnl'] = 0
    dfTotal['TotalPnl'] = dfTotal['pnlRealizedStat'] * pointVal
    dfTotalSorted = dfTotal.sort_values(['pnlRealizedStat'], ascending=False)
else:
    dfTotal['TotalPnl'] = 0
    dfTotal['TotalPnl'] = dfTotal['pnlRealizedStat']
    dfTotalSorted = dfTotal.sort_values(['pnlRealizedStat'], ascending=False)

print(dfTotal)
# params: dfTotalSorted, csv path/file, args.roundOff,args.maxExp,args.output
posComboCSV = os.path.join(args.output + "/PositionsComboReport.csv")
CreateComboReport(dfTotalSorted, posComboCSV, args.roundOff, args.maxExp, args.output, argsyearGroup)
fh.close()
