#!/bin/bash 


#Set OUTSIM, VERSION hardcoded
#./MonthlyProcess.bash  -m test -e  all  -f 20190701 -t 20190731 -d /big/svc_wqln/ML/BacktestsJulyV4 
# ./MonthlyProcess.bash  -m test -e  graph -v 1 -c 83000000
startScript=$(date -u) 
echo "you have provide $# argument" 
echo "arguments are $@" 
echo "usage: MonthlyProcess.bash  -m|--mode test|run -e|execute all|sim|var|graph -f 20190701 -t 20191201 -d /big/svc_wqln/ML/BacktestsJulyV4 -a|alphafile alphasA.txt -v|version V0 -o|out OutSimAug3M -g|viewgraph 0|1" 

MODE='test'
EXECUTE='allz'
VIEWGRAPH=0
CAPITALBASE=0

NOAPPEND="-noappend"

ROOT=/home/lanarayan/MyProjects/ML
#DIRROOT=/big/svc_wqln/ML/BacktestsJulyV4
DIRROOT=/big/svc_wqln/ML/BacktestsV4
#OUTSIM=OutSimCurrent
#OUTSIM=OutSimJulyEndNoJY
OUTSIM=OutSimAug3M
FROM=20190701 
TO=20190731
VERSION=V0
INPUT=Fit-A-2019
INPUTB=Fit-B-2014 
OUTPUT=Fit-A-2019
ALPHAFILE=alphasA.txt





while [[ $# -gt 0 ]]
do
key="$1"
echo "Key is $key"
echo "Value is $2"
case $key in
    -f|--from)
    FROM="$2"
    shift # past argument
    shift # past value
    ;;
    -t|--to)
    TO="$2"
    shift # past argument
    shift # past value
    ;;
    -d|--dir)
    DIRROOT="$2"
    shift # past argument
    shift # past value
    ;;
   -a|--alphafile)
    ALPHAFILE="$2"
    shift # past argument
    shift # past value
    ;;
   -v|--version)
    VERSION="$2"
    shift # past argument
    shift # past value
    ;;
   -o|--out)
    OUTSIM="$2"
    shift # past argument
    shift # past value
    ;;
    -c|--capital)
    CAPITALBASE="$2"
    shift # past argument
    shift # past value
    ;;
    -m|--mode)
    MODE="$2"
    shift # past argument
    shift # past value
    ;; 
    -g|--viewgraph)
    VIEWGRAPH="$2"
    shift # past argument
    shift # past value
    ;;  
    -e|--execute)
       lowerCaseArg="${2,,}"
    EXECUTE=${lowerCaseArg}
    shift # past argument
    shift # past value
    ;;
    *)    # unknown option
    echo "unknown Argument $1"
        echo "usage: MonthlyProcess.bash  -m|--mode test|run -e|execute all|sim|var|graph -f 20190701 -t 20191201 -d /big/svc_wqln/ML/BacktestsJulyV4 -a|alphafile alphasA.txt -v|version V0 -o|out OutSimAug3M -g|viewgraph 0|1" 
     exit
    ;;
esac
done

echo Mode is ${MODE}
echo  Execute is ${EXECUTE}
echo From is ${FROM}
echo To is ${TO}
echo Dirroot is ${DIRROOT}
echo ALPHAFILE is ${ALPHAFILE}
echo VERSION is ${VERSION}
echo OUTSIM is ${OUTSIM}
echo viewgraph is ${VIEWGRAPH}
echo capitalbase is ${CAPITALBASE}

ALPHAS=${DIRROOT}/AlphaList/${VERSION}/${ALPHAFILE} 
WEIGHTS=${DIRROOT}/AlphaList/${VERSION}/weightsA.txt

LOGDIR=${DIRROOT}/Logs 
LOGFILE=${LOGDIR}/MonthlyProcess-$(date '+%d%m%Y-%H:%M:%S').txt; 
echo $LOGFILE
[ -d ${LOGDIR} ] || echo mkdir -p ${LOGDIR} 
[ -d ${LOGDIR} ] || mkdir -p ${LOGDIR}

function ShowStatus {
if [ $? -eq 0 ]
 then
        echo PASS $1
        #echo PASS $1 >>${LOGFILE} 
 else
        echo FAIL $1 
        #echo FAIL $1 >>${LOGFILE} 
        exit 1
fi
}

function RunSim
{
#  ./Sim.py -baseDir /big/svc_wqln/ML/BacktestsJulyV4/Fit-A-2019 -baseDirB /big/svc_wqln/ML/BacktestsJulyV4/Fit-B-2014 -f 20190701 -t 20190731 -alphas /big/svc_wqln/ML/BacktestsJulyV4/AlphaList/V0/alphasA15m.txt -wt /big/svc_wqln/ML/BacktestsJulyV4/AlphaList/V0/weightsA.txt -baseOut /big/svc_wqln/ML/BacktestsJulyV4/OutSimRank15m/Fit-A-2019/V1 -sliceFactor 0 -sliceDate 20160301 -tcFactorA 1 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1 -noappend

    echo ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 1 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1 ${NOAPPEND}
    
    
    if [ ${MODE} == 'run' ]
    then
    echo  ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 1 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1 ${NOAPPEND} >> ${LOGFILE}
  
    ${ROOT}/Sim.py -baseDir ${DIRROOT}/${INPUT} -baseDirB ${DIRROOT}/${INPUTB} -f ${FROM} -t ${TO} -alphas ${ALPHAS} -wt ${WEIGHTS} -baseOut ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION} -sliceFactor 0 -sliceDate 20160301 -tcFactorA 1 -tcFactorB 10 -arA 0 -arB 0 -factorA 1 -factorB 0.1 -varFactorA 1 -varFactorB 1 ${NOAPPEND}
    
    ShowStatus RunSim
    echo Output location is: ${DIRROOT}/OutSim/${OUTPUT}/${VERSION}
    echo Alpha location is: ${ALPHAS}
    echo Weights: ${WEIGHTS}
    
    fi
}



function RunVar 
{
  
 # ./VarAnalysisWQ.py -p  /home/lanarayan/MLData/Backtests1H/OutSimMOPCNew/Fit-A-2019/V1/MasterOpenPositionDF.csv -baseOut /home/lanarayan/MLData/Backtests1H/OutSimVarNew/Fit-A-2019/V1
  echo ${ROOT}/VarAnalysisWQ.py -p  ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/MasterOpenPositionDF.csv -baseOut ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}
  if [ ${MODE} == 'run' ]
    then
  echo ${ROOT}/VarAnalysisWQ.py -p  ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/MasterOpenPositionDF.csv -baseOut ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION} >> ${LOGFILE}
  ${ROOT}/VarAnalysisWQ.py -p  ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/MasterOpenPositionDF.csv -baseOut ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}
  
  ShowStatus RunVar

  echo MOPC: ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/MasterOpenPositionDF.csv
  echo Output: ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/VaRReport.txt
  echo cat ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/VaRReport.txt
  cat ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/VaRReport.txt
  fi
  
  }


# CapitalBase = VaR * 100
# iA : location of PortfolioExposure.csv
function RunGraph {
  
  
  #${ROOT}/perf_calc -t -iA /home/lanarayan/MLData/Backtests1H/OutSimMOPC/Fit-A-2019/V1 -capitalBase 260000000
  echo ${ROOT}/perf_calc.py -t -iA ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION} -cb ${CAPITALBASE} 
  if [ ${MODE} == 'run' ]
    then
  echo ${ROOT}/perf_calc.py -t -iA ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION} -cb ${CAPITALBASE} >> ${LOGFILE}
  ${ROOT}/perf_calc.py -t -iA ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION} -cb ${CAPITALBASE}
  
  ShowStatus RunGraph
  
  echo Graph Output: ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/DD.png
  echo Graph Output: ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/DDChart.png
  
  if [ ${VIEWGRAPH}  == 1 ]
     then
        eog ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/DD.png ${DIRROOT}/${OUTSIM}/${OUTPUT}/${VERSION}/DDChart.png
     fi
     
    fi
  
  }


if [ "$EXECUTE" == "all" ] 
then
        echo "Executing all in mode " ${MODE}
        
        RunSim
        RunVar
        
  elif [ "$EXECUTE" == "sim" ]
  then
        echo "Executing RunSim in mode" ${MODE} 
        RunSim
  elif [ "$EXECUTE" == "var" ]
  then
        echo "Executing RunVar in mode" ${MODE} 
        RunVar       
  elif [ "$EXECUTE" == "graph" ]
  then
        echo "Executing RunGraph in mode" ${MODE} 
        RunGraph
  else
        echo "Invalid Execute option"
        echo "usage: MonthlyProcess.bash  -m|--mode test|run -e|execute all|sim|var|graph -f 20190701 -t 20191201 -d /big/svc_wqln/ML/BacktestsJulyV4 -v|viewgraph 0|1"
  fi
  
  
  
echo 'StartTime MonthlyProcess:' $startScript
endScript=$(date -u)
echo 'EndTime MonthlyProcess:'$endScript
