#!/bin/bash
/home/lanarayan/MyProjects/ML/DailyDataA.bash
/home/lanarayan/MyProjects/ML/DailyDataB.bash