cd ~/MLData/UATDev/DaVinciFinal
#rm -rf ~/MLData/UATDev/DaVinciFinal/build
cp -r ~/UAT/VishnuWIP/build  ~/MLData/UATDev/DaVinciFinal
rm build/CMakeCache.txt
/home/lanarayan/clion-2017.3.4/bin/cmake/bin/cmake --build /home/lanarayan/MLData/UATDev/DaVinciFinal/build --target DaVinci -- -j 24