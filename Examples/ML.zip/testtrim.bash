#!/bin/bash 

value=$(</big/svc_wqln/ML/BacktestsV4/OutSimAug1M/Fit-A-2019/V5/VaRReport.txt)
echo "$value"
my_array=($(echo $value | tr "," "\n"))
echo ${my_array[1]}

var=${my_array[1]}
echo var is $var
absvar="${var:1}"
echo absvar is $absvar
cb=$(echo "scale=2; $absvar*100" | bc)
echo cb is $cb

