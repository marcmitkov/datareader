#!/big/svc_wqln/projects/python/conda/bin/python3.6
#Incremental process to generate 1 minute candles - to be run daily
import pandas as pd
import datetime
import argparse
import numpy as np
import os
import Common as co
from pandas.tseries.offsets import BDay
import logging

parser = argparse.ArgumentParser(description="Incremental process to generate 1 minute candles - to be run daily")
#parser.add_argument('-f','--fromDate', default='20180904',help="from date")
parser.add_argument('-t','--toDate', default='20190907',help="to date")
parser.add_argument('-contract','--contract', default='ES',help="contract")
#parser.add_argument('-input','--inputFile', default= '/home/svc_wqln/big/data/Futures/Live/ES/1m.csv',help="base Directory")
parser.add_argument('-base','--baseDir', default= '/big/svc_wqln/data/Futures',help="base Directory")
parser.add_argument('-baseOut','--baseOutDir', default='/big/svc_wqln/data/Futures/Live',help="base output Directory")
parser.add_argument('-offset','--offset', default=1, type=int ,help="Business day offset")
parser.add_argument("-l", "--log", dest="logLevel", default="DEBUG",
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Set the logging level")
parser.add_argument('-log', '--logPath', default='/home/lanarayan/MLData/Backtests/Logs/',
                    help="log file  path")
#parser.print_help()
args = parser.parse_args()
print(args)

dateForLog = datetime.datetime.now().strftime("%Y%m%d-%H%M%S.%f")

logging.basicConfig(filename=os.path.join(args.logPath, 'LiveDataFilter-' + dateForLog + '.log'),
                    filemode='w', level=getattr(logging, args.logLevel),
                    format='%(asctime)s %(levelname)s %(message)s')

fxList = ['EURGBP', 'EURJPY']
fxInverseDict =	{
  "AUDUSD": "USDAUD=R",
  "USDCHF": "CHFUSD=R",
  "EURUSD": "USDEUR=R",
  "USDCAD": "CADUSD=R",
  "USDJPY": "JPYUSD=R",
  "GBPUSD": "USDGBP=R"
}

# first phase
outdir =  os.path.join(args.baseOutDir, args.contract)
if not os.path.exists(outdir):
        os.makedirs(outdir)
outFile = os.path.join(outdir, '1m_live.csv')

# TODO: validate this comment  June 14
# and clearly translate the situation to use offset
# runs for June 12 and 13 were skipped
# data was available till June 11 7am
# to run this for data to be ready for before 7 am run June 14
# fromDate = "20190610"
# toDate ="20190613"

print("Processing contract ",args.contract)

logging.debug("Processing contract {}".format(args.contract))


fromDate = datetime.datetime.strftime( (datetime.date.today() -BDay(args.offset)), '%Y%m%d')
toDate = datetime.datetime.strftime( (datetime.date.today() -BDay(args.offset))+ BDay(1), '%Y%m%d')


print("From: ", fromDate, " To: ", toDate)
logging.debug("From: {}  To: {}".format(fromDate, toDate))

df = pd.DataFrame()

if not co.IsFX(args.contract):
    df = co.FuturesData(fromDate, toDate, args.baseDir, args.contract)
    #df = co.FuturesData("20190415", "20190425", args.baseDir, args.contract)
    if (df.empty):
        print("Empty dataframe for Futures: ", args.contract)
        logging.debug("Exitting. Empty dataframe for Futures: {} ".format(args.contract))
        exit(1)
    #previousDate = str(datetime.date.today() - datetime.timedelta(1))
elif co.IsFX(args.contract):
     #df = co.FuturesData(args.fromDate, args.toDate, args.baseDir, args.contract, True)
     # if EURGBP=R  then exactly the same thing with False => EURGBP
     # if USDAUD=R with True to take reciprocal of all price fields upto 5 significant figure => AUDUSD
     # if JPYUSD=R with True to take reciprocal of all price fields upto 3 significant figure => USDJPY
     #3 sig digit:USDJPY EURJPY; 5 significant digits:EURGBP AUDUSD USDCHF EURUSD USDCAD GBPUSD
     if args.contract in fxList:
         baseDir = os.path.join(args.baseDir , args.contract + "=R")
         df = co.FXData(fromDate, toDate,baseDir,args.contract,outdir, False)
         if(df.empty):
             print("Empty dataframe for FX: ", args.contract)
             logging.debug("Exitting. Empty dataframe for FX: {} ".format(args.contract))
             exit(1)

     else:
         contract = fxInverseDict[args.contract]
         baseDir = os.path.join(args.baseDir , contract)
         #corrected args.toDate to toDate on Sep 11, 2019
         df = co.FXData(fromDate, toDate, baseDir,args.contract,outdir, True)
         if (df.empty):
             print("Empty dataframe for FX: ", args.contract)
             logging.debug("Exitting. Empty dataframe for FX: {} ".format(args.contract))
             exit(1)
         df["SYBL"] = args.contract
else:
    factor = 100000
    if 'JPY' in args.contract:
        factor=1000
    print('./TestBinaryCreator', 'FX', args.contract[0:3] + '/' + args.contract[3:6],
          "/dat/mdwarehouse/public/NEX/EBSL1", fromDate, toDate, outFile, factor, 0)
    cmd = '/home/lanarayan/MyProjects/ML/TestBinaryCreator FX ' + args.contract[0:3] + '/' + args.contract[3:6] + " /dat/mdwarehouse/public/NEX/EBSL1 " + fromDate + ' ' + toDate + ' ' + outFile + ' ' + str(factor) + ' 0'
    print(cmd)
    os.system(cmd)
    #subprocess.call['./TestBinaryCreator', 'FX', args.contract[0:2] + '/' args.contract[3:5], "/dat/mdwarehouse/public/NEX/EBSL1", args.fromDate, args.toDate, outFile, factor, 0]
        # example command
        # ./TestBinaryCreator "FX" "${INS}" "/dat/mdwarehouse/public/NEX/EBSL1" ${FROMDATE} "20191231" "${i}.txt" 1000 0
    df=pd.read_csv(outFile)

# second phase

previousDate = str(datetime.date.today() - BDay(args.offset))
currentDate =  str(datetime.date.today() - BDay(args.offset)  + BDay(1))

#previousDate = fromDate
#currentDate = toDate

#UTC is 8 suring Sep - March 10, 2019 when system comes up at 3 am EST;  then Nov 3, 2019 2am EST  DST ends
#filterDateA = pd.to_datetime(currentDate + ' 08:00:00')
#filterDateB = pd.to_datetime(previousDate + ' 08:00:00')
#  CRITICAL: change this when we go 22x5

utcOffset=5
wqStartTime= ' 02:00:00'  # in EST
filterDateA = pd.to_datetime(currentDate +  wqStartTime)
filterDateA = filterDateA + datetime.timedelta(hours=utcOffset)
filterDateB = pd.to_datetime(previousDate + wqStartTime)
filterDateB= filterDateB + datetime.timedelta(hours=utcOffset)

print('Filter Dates: ',filterDateB, ' to ', filterDateA)
logging.debug("Filter Dates {} to {}".format(filterDateB,filterDateA))

#print(filterDateB)


#df = pd.read_csv(args.inputFile)
df['D'] = pd.to_datetime(df['D'], format='%Y-%m-%d %H:%M:%S')
df = df.sort_values(['D'], ascending=True)
df = df.drop_duplicates(subset=['D'])

#mask = (df['D'] > filterDateB) | (df['D'] < filterDateA)
logging.debug("Filter applied > {} and <= {}".format(filterDateB,filterDateA))
# BUG FIX:Changing mask Oct 15, 2019
#mask = (df['D'] > filterDateB) & (df['D'] <= filterDateA)
mask = (df['D'] >= filterDateB) & (df['D'] <= filterDateA)


df =df[mask]

#BUG FIX: Commenting Oct 15, 2019
# Get last row; change D and T ; Add changed row as last row
# Uncommenting Nov1 : Resampling.py requires 7Am candle to genrate 7 am data ??
# Nov 11: commenting below  because on Nov 11 3 am EST = 8am UCT
## so final candle from morning run  should be 7am UCT  for 1H and 7:45 am UCT for 15m
## TODO:  make sure evening process includes the 8 am candles for both 1H and 15m
## NEFARIOUS BUG:  this code was placed prior to the application of the mask and hence last candle was incorrect  (Nov 11, 2019)
'''lastrow = df.iloc[-1]
lastrow.D = filterDateA
lastrow.T = '70000'
df = df.append(lastrow, ignore_index=True)'''


#Remove rows where both LSTA and LSTB are 0; Also drop rows where LSTA and LSTB are empty filelds in csv(i.e NaN in df)
maskDel = (df.LSTA == 0) & (df.LSTB == 0)
df = df[~maskDel]
df = df.dropna(subset=['LSTA', 'LSTB'])

#Remove weekends
#TODO: Banku  pick up sunday after UTC 10 pm (22 hrs)
df = df[df.D.dt.dayofweek < 5]

#sunday candles
#df2 = df[df.D.dt.dayofweek == 6]
# filed candles after 10pm UCT

df.to_csv(outFile, index=False)
logging.debug("output in {}".format(outFile))
#print("output in ", outFile)
#print(df.head())
#print(filterDateA)
#print(filterDateB)